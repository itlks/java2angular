package com.santander.component.domain;

import java.math.BigDecimal;

import javax.xml.datatype.XMLGregorianCalendar;

import com.altec.bsbr.app.ibe.webclient.bks.contacorrente.ComBanestoAlIbuycoServcontasEFCbCBDetalleCuentaSType;

public class SaldoContaCorrenteOE {

	// Os campos com valores zerados n�o constam no documento de AS-IS
	private BigDecimal OE_SALDO_BLQ_DIA = null;
	private BigDecimal LANC_PROV_CREDITO = null;
	private BigDecimal LANC_PROV_DEBITO = null;
	private BigDecimal SLD_CTBPOUP = null;
	private BigDecimal VL_SALDOCC = null;
	private BigDecimal OE_SALDO_DISP = null;
	private BigDecimal VL_SALDOCI = null;
	private BigDecimal VL_TOTAL_CC_CI = null;
	private BigDecimal VL_CHEQUES_BLOQ = null;
	private BigDecimal VL_BLOQ24 = null;
	private BigDecimal VL_BLOQ48 = null;
	private BigDecimal VL_BLOQIND = null;
	private BigDecimal OE_SALDO_BLQ_JUD = null;
	private BigDecimal OE_SALDO_PROV_ENC = null;
	private BigDecimal OE_JUROS_ACUM_PROV = null;
	private BigDecimal OE_IOF_ACUM_PROV = null;
	private BigDecimal VL_CPMF = null;
	private BigDecimal OE_CPMF_ACUM = null;
	private BigDecimal OE_VL_SEG_PREST_FECH = null;
	private BigDecimal OE_CC_SALDO_DISPONIV = null;
	private BigDecimal VL_RESG_AUT = null;
	private BigDecimal VL_TOTAL_SALDO = null;
	private String OE_DESC_PRIM_LIMITE = null;
	private String OE_SEG_PRIM_LIMITE = null;
	private BigDecimal VL_LIMITE = null;
	private BigDecimal OE_CHQ_INV_LIMITE = null;
	private BigDecimal VL_DISPONIVEL = null;
	private BigDecimal VLJUR_NAO_DEB = null;
	private Integer QT_DIA_NDIA = null;
	private BigDecimal VL_JUROS = null;
	private BigDecimal VL_IOF = null;
	private XMLGregorianCalendar OE_CHQ_INV_VENC = null;
	private XMLGregorianCalendar DT_ULT_MOV = null;
	private XMLGregorianCalendar DT_DEB_JUROS = null;
	private XMLGregorianCalendar DT_DEB_IOF = null;
	private String IND_CPMF = null;
	private String FLAG_MOSTRA_CI = null;
	private String IND_POUPMAX = null;
	private XMLGregorianCalendar dtVctoCeb;
	private BigDecimal vlTxJurosMensal;
	private BigDecimal vlLimite;
	private XMLGregorianCalendar oeChqEspUltima; 
	private Integer qtDiaNdia;
	private BigDecimal oeChqEspUtilizado;
	private BigDecimal oeChqEspDisp;
	private BigDecimal vlJurNaoDeb;

	
	public SaldoContaCorrenteOE() {
	}

	public SaldoContaCorrenteOE(ComBanestoAlIbuycoServcontasEFCbCBDetalleCuentaSType result) {
		OE_SALDO_BLQ_DIA = result.getSaldoBloqueadoDia();
		LANC_PROV_CREDITO = result.getLanzamientosProvisoriosCredito();
		LANC_PROV_DEBITO = result.getLanzamientosProvisoriosDebito();
		SLD_CTBPOUP = result.getSaldoInvertidoContaMax();
		VL_SALDOCC = result.getSaldoCuenta();
		OE_SALDO_DISP = result.getSALDODISP();
		VL_SALDOCI = result.getSaldoDisponibleCuentaInvestimento();
		VL_TOTAL_CC_CI = result.getSaldoDisponibleCuentaCorriente();
		VL_CHEQUES_BLOQ = result.getTotalImporteChequesBloqueo();
		VL_BLOQ24 = result.getImporteChequesBloqueo24Hs();
		VL_BLOQ48 = result.getImporteChequesBloqueo48Hs();
		VL_BLOQIND = result.getVLBLOQIND();
		OE_SALDO_BLQ_JUD = result.getSaldoBloqueadoJudicial();
		OE_SALDO_PROV_ENC = result.getSaldoProvisionCargos();
		OE_JUROS_ACUM_PROV = result.getJurosAcumuladosProv();
		OE_IOF_ACUM_PROV = result.getIOFAcumuladosProv();
		VL_CPMF = result.getImporteCPMFAcumulado();
		OE_CPMF_ACUM = result.getCPMFProvisiSobreSaldo();
		OE_VL_SEG_PREST_FECH = result.getImporteSeguroChequeEspecial();
		OE_CC_SALDO_DISPONIV = result.getSaldoDisponible();
		VL_RESG_AUT = result.getImporteResgateAutomatico();
		VL_TOTAL_SALDO = result.getSaldoTotal();
		OE_DESC_PRIM_LIMITE = result.getDescripcionPremeroLimite();
		OE_SEG_PRIM_LIMITE = result.getDescripcionSegundoLimite();
		VL_LIMITE = result.getLimiteCuenta();
		OE_CHQ_INV_LIMITE = result.getImporteInvertidoChequeLimite();
		VL_DISPONIVEL = result.getSaldoTotalDisponible();
		VLJUR_NAO_DEB = result.getImporteJurosNoDebitado();
		QT_DIA_NDIA = result.getNumeroDiasSinCargos();
		VL_JUROS = result.getJurosAcumuladosProv();
		VL_IOF = result.getIOFAcumulada();
		OE_CHQ_INV_VENC = result.getFechaChequeVencido();
		DT_ULT_MOV = result.getFechaContabile();
		DT_DEB_JUROS = result.getFechaDebitosJuros();
		DT_DEB_IOF = result.getFechaDebitoIOF();
		IND_CPMF = result.getIndicadorCPMFAcumulado();
		FLAG_MOSTRA_CI = result.getIndicadorCuentaInvestimento();
		IND_POUPMAX = result.getIndicadorContaMax();
		dtVctoCeb = result.getFechaVencimientoSantanderMaster();
		vlTxJurosMensal = result.getImporteTasaJurosMensal();
		vlLimite = result.getLimiteCuenta();
		oeChqEspUltima = result.getFechaUltimaUtilizChequeEspecial();
		qtDiaNdia = result.getNumeroDiasSinCargos(); 
		oeChqEspUtilizado = result.getChequeEspecialUtilizado();
		oeChqEspDisp = result.getChequeEspecialDisponible();
		vlJurNaoDeb = result.getImporteJurosNoDebitado();
	}

	/**
	 * @return the oE_SALDO_BLQ_DIA
	 */
	public BigDecimal getOE_SALDO_BLQ_DIA() {
		return OE_SALDO_BLQ_DIA;
	}

	/**
	 * @param oE_SALDO_BLQ_DIA
	 *            the oE_SALDO_BLQ_DIA to set
	 */
	public void setOE_SALDO_BLQ_DIA(BigDecimal oE_SALDO_BLQ_DIA) {
		OE_SALDO_BLQ_DIA = oE_SALDO_BLQ_DIA;
	}

	/**
	 * @return the lANC_PROV_CREDITO
	 */
	public BigDecimal getLANC_PROV_CREDITO() {
		return LANC_PROV_CREDITO;
	}

	/**
	 * @param lANC_PROV_CREDITO
	 *            the lANC_PROV_CREDITO to set
	 */
	public void setLANC_PROV_CREDITO(BigDecimal lANC_PROV_CREDITO) {
		LANC_PROV_CREDITO = lANC_PROV_CREDITO;
	}

	/**
	 * @return the lANC_PROV_DEBITO
	 */
	public BigDecimal getLANC_PROV_DEBITO() {
		return LANC_PROV_DEBITO;
	}

	/**
	 * @param lANC_PROV_DEBITO
	 *            the lANC_PROV_DEBITO to set
	 */
	public void setLANC_PROV_DEBITO(BigDecimal lANC_PROV_DEBITO) {
		LANC_PROV_DEBITO = lANC_PROV_DEBITO;
	}

	/**
	 * @return the sLD_CTBPOUP
	 */
	public BigDecimal getSLD_CTBPOUP() {
		return SLD_CTBPOUP;
	}

	/**
	 * @param sLD_CTBPOUP
	 *            the sLD_CTBPOUP to set
	 */
	public void setSLD_CTBPOUP(BigDecimal sLD_CTBPOUP) {
		SLD_CTBPOUP = sLD_CTBPOUP;
	}

	/**
	 * @return the vL_SALDOCC
	 */
	public BigDecimal getVL_SALDOCC() {
		return VL_SALDOCC;
	}

	/**
	 * @param vL_SALDOCC
	 *            the vL_SALDOCC to set
	 */
	public void setVL_SALDOCC(BigDecimal vL_SALDOCC) {
		VL_SALDOCC = vL_SALDOCC;
	}

	/**
	 * @return the oE_SALDO_DISP
	 */
	public BigDecimal getOE_SALDO_DISP() {
		return OE_SALDO_DISP;
	}

	/**
	 * @param oE_SALDO_DISP
	 *            the oE_SALDO_DISP to set
	 */
	public void setOE_SALDO_DISP(BigDecimal oE_SALDO_DISP) {
		OE_SALDO_DISP = oE_SALDO_DISP;
	}

	/**
	 * @return the vL_SALDOCI
	 */
	public BigDecimal getVL_SALDOCI() {
		return VL_SALDOCI;
	}

	/**
	 * @param vL_SALDOCI
	 *            the vL_SALDOCI to set
	 */
	public void setVL_SALDOCI(BigDecimal vL_SALDOCI) {
		VL_SALDOCI = vL_SALDOCI;
	}

	/**
	 * @return the vL_TOTAL_CC_CI
	 */
	public BigDecimal getVL_TOTAL_CC_CI() {
		return VL_TOTAL_CC_CI;
	}

	/**
	 * @param vL_TOTAL_CC_CI
	 *            the vL_TOTAL_CC_CI to set
	 */
	public void setVL_TOTAL_CC_CI(BigDecimal vL_TOTAL_CC_CI) {
		VL_TOTAL_CC_CI = vL_TOTAL_CC_CI;
	}

	/**
	 * @return the vL_CHEQUES_BLOQ
	 */
	public BigDecimal getVL_CHEQUES_BLOQ() {
		return VL_CHEQUES_BLOQ;
	}

	/**
	 * @param vL_CHEQUES_BLOQ
	 *            the vL_CHEQUES_BLOQ to set
	 */
	public void setVL_CHEQUES_BLOQ(BigDecimal vL_CHEQUES_BLOQ) {
		VL_CHEQUES_BLOQ = vL_CHEQUES_BLOQ;
	}

	/**
	 * @return the vL_BLOQ24
	 */
	public BigDecimal getVL_BLOQ24() {
		return VL_BLOQ24;
	}

	/**
	 * @param vL_BLOQ24
	 *            the vL_BLOQ24 to set
	 */
	public void setVL_BLOQ24(BigDecimal vL_BLOQ24) {
		VL_BLOQ24 = vL_BLOQ24;
	}

	/**
	 * @return the vL_BLOQ48
	 */
	public BigDecimal getVL_BLOQ48() {
		return VL_BLOQ48;
	}

	/**
	 * @param vL_BLOQ48
	 *            the vL_BLOQ48 to set
	 */
	public void setVL_BLOQ48(BigDecimal vL_BLOQ48) {
		VL_BLOQ48 = vL_BLOQ48;
	}

	/**
	 * @return the vL_BLOQIND
	 */
	public BigDecimal getVL_BLOQIND() {
		return VL_BLOQIND;
	}

	/**
	 * @param vL_BLOQIND
	 *            the vL_BLOQIND to set
	 */
	public void setVL_BLOQIND(BigDecimal vL_BLOQIND) {
		VL_BLOQIND = vL_BLOQIND;
	}

	/**
	 * @return the oE_SALDO_BLQ_JUD
	 */
	public BigDecimal getOE_SALDO_BLQ_JUD() {
		return OE_SALDO_BLQ_JUD;
	}

	/**
	 * @param oE_SALDO_BLQ_JUD
	 *            the oE_SALDO_BLQ_JUD to set
	 */
	public void setOE_SALDO_BLQ_JUD(BigDecimal oE_SALDO_BLQ_JUD) {
		OE_SALDO_BLQ_JUD = oE_SALDO_BLQ_JUD;
	}

	/**
	 * @return the oE_SALDO_PROV_ENC
	 */
	public BigDecimal getOE_SALDO_PROV_ENC() {
		return OE_SALDO_PROV_ENC;
	}

	/**
	 * @param oE_SALDO_PROV_ENC
	 *            the oE_SALDO_PROV_ENC to set
	 */
	public void setOE_SALDO_PROV_ENC(BigDecimal oE_SALDO_PROV_ENC) {
		OE_SALDO_PROV_ENC = oE_SALDO_PROV_ENC;
	}

	/**
	 * @return the oE_JUROS_ACUM_PROV
	 */
	public BigDecimal getOE_JUROS_ACUM_PROV() {
		return OE_JUROS_ACUM_PROV;
	}

	/**
	 * @param oE_JUROS_ACUM_PROV
	 *            the oE_JUROS_ACUM_PROV to set
	 */
	public void setOE_JUROS_ACUM_PROV(BigDecimal oE_JUROS_ACUM_PROV) {
		OE_JUROS_ACUM_PROV = oE_JUROS_ACUM_PROV;
	}

	/**
	 * @return the oE_IOF_ACUM_PROV
	 */
	public BigDecimal getOE_IOF_ACUM_PROV() {
		return OE_IOF_ACUM_PROV;
	}

	/**
	 * @param oE_IOF_ACUM_PROV
	 *            the oE_IOF_ACUM_PROV to set
	 */
	public void setOE_IOF_ACUM_PROV(BigDecimal oE_IOF_ACUM_PROV) {
		OE_IOF_ACUM_PROV = oE_IOF_ACUM_PROV;
	}

	/**
	 * @return the vL_CPMF
	 */
	public BigDecimal getVL_CPMF() {
		return VL_CPMF;
	}

	/**
	 * @param vL_CPMF
	 *            the vL_CPMF to set
	 */
	public void setVL_CPMF(BigDecimal vL_CPMF) {
		VL_CPMF = vL_CPMF;
	}

	/**
	 * @return the oE_CPMF_ACUM
	 */
	public BigDecimal getOE_CPMF_ACUM() {
		return OE_CPMF_ACUM;
	}

	/**
	 * @param oE_CPMF_ACUM
	 *            the oE_CPMF_ACUM to set
	 */
	public void setOE_CPMF_ACUM(BigDecimal oE_CPMF_ACUM) {
		OE_CPMF_ACUM = oE_CPMF_ACUM;
	}

	/**
	 * @return the oE_VL_SEG_PREST_FECH
	 */
	public BigDecimal getOE_VL_SEG_PREST_FECH() {
		return OE_VL_SEG_PREST_FECH;
	}

	/**
	 * @param oE_VL_SEG_PREST_FECH
	 *            the oE_VL_SEG_PREST_FECH to set
	 */
	public void setOE_VL_SEG_PREST_FECH(BigDecimal oE_VL_SEG_PREST_FECH) {
		OE_VL_SEG_PREST_FECH = oE_VL_SEG_PREST_FECH;
	}

	/**
	 * @return the oE_CC_SALDO_DISPONIV
	 */
	public BigDecimal getOE_CC_SALDO_DISPONIV() {
		return OE_CC_SALDO_DISPONIV;
	}

	/**
	 * @param oE_CC_SALDO_DISPONIV
	 *            the oE_CC_SALDO_DISPONIV to set
	 */
	public void setOE_CC_SALDO_DISPONIV(BigDecimal oE_CC_SALDO_DISPONIV) {
		OE_CC_SALDO_DISPONIV = oE_CC_SALDO_DISPONIV;
	}

	/**
	 * @return the vL_RESG_AUT
	 */
	public BigDecimal getVL_RESG_AUT() {
		return VL_RESG_AUT;
	}

	/**
	 * @param vL_RESG_AUT
	 *            the vL_RESG_AUT to set
	 */
	public void setVL_RESG_AUT(BigDecimal vL_RESG_AUT) {
		VL_RESG_AUT = vL_RESG_AUT;
	}

	/**
	 * @return the vL_TOTAL_SALDO
	 */
	public BigDecimal getVL_TOTAL_SALDO() {
		return VL_TOTAL_SALDO;
	}

	/**
	 * @param vL_TOTAL_SALDO
	 *            the vL_TOTAL_SALDO to set
	 */
	public void setVL_TOTAL_SALDO(BigDecimal vL_TOTAL_SALDO) {
		VL_TOTAL_SALDO = vL_TOTAL_SALDO;
	}

	/**
	 * @return the oE_DESC_PRIM_LIMITE
	 */
	public String getOE_DESC_PRIM_LIMITE() {
		return OE_DESC_PRIM_LIMITE;
	}

	/**
	 * @param oE_DESC_PRIM_LIMITE
	 *            the oE_DESC_PRIM_LIMITE to set
	 */
	public void setOE_DESC_PRIM_LIMITE(String oE_DESC_PRIM_LIMITE) {
		OE_DESC_PRIM_LIMITE = oE_DESC_PRIM_LIMITE;
	}

	/**
	 * @return the oE_SEG_PRIM_LIMITE
	 */
	public String getOE_SEG_PRIM_LIMITE() {
		return OE_SEG_PRIM_LIMITE;
	}

	/**
	 * @param oE_SEG_PRIM_LIMITE
	 *            the oE_SEG_PRIM_LIMITE to set
	 */
	public void setOE_SEG_PRIM_LIMITE(String oE_SEG_PRIM_LIMITE) {
		OE_SEG_PRIM_LIMITE = oE_SEG_PRIM_LIMITE;
	}

	/**
	 * @return the vL_LIMITE
	 */
	public BigDecimal getVL_LIMITE() {
		return VL_LIMITE;
	}

	/**
	 * @param vL_LIMITE
	 *            the vL_LIMITE to set
	 */
	public void setVL_LIMITE(BigDecimal vL_LIMITE) {
		VL_LIMITE = vL_LIMITE;
	}

	/**
	 * @return the oE_CHQ_INV_LIMITE
	 */
	public BigDecimal getOE_CHQ_INV_LIMITE() {
		return OE_CHQ_INV_LIMITE;
	}

	/**
	 * @param oE_CHQ_INV_LIMITE
	 *            the oE_CHQ_INV_LIMITE to set
	 */
	public void setOE_CHQ_INV_LIMITE(BigDecimal oE_CHQ_INV_LIMITE) {
		OE_CHQ_INV_LIMITE = oE_CHQ_INV_LIMITE;
	}

	/**
	 * @return the vL_DISPONIVEL
	 */
	public BigDecimal getVL_DISPONIVEL() {
		return VL_DISPONIVEL;
	}

	/**
	 * @param vL_DISPONIVEL
	 *            the vL_DISPONIVEL to set
	 */
	public void setVL_DISPONIVEL(BigDecimal vL_DISPONIVEL) {
		VL_DISPONIVEL = vL_DISPONIVEL;
	}

	/**
	 * @return the vLJUR_NAO_DEB
	 */
	public BigDecimal getVLJUR_NAO_DEB() {
		return VLJUR_NAO_DEB;
	}

	/**
	 * @param vLJUR_NAO_DEB
	 *            the vLJUR_NAO_DEB to set
	 */
	public void setVLJUR_NAO_DEB(BigDecimal vLJUR_NAO_DEB) {
		VLJUR_NAO_DEB = vLJUR_NAO_DEB;
	}

	/**
	 * @return the qT_DIA_NDIA
	 */
	public Integer getQT_DIA_NDIA() {
		return QT_DIA_NDIA;
	}

	/**
	 * @param qT_DIA_NDIA
	 *            the qT_DIA_NDIA to set
	 */
	public void setQT_DIA_NDIA(Integer qT_DIA_NDIA) {
		QT_DIA_NDIA = qT_DIA_NDIA;
	}

	/**
	 * @return the vL_JUROS
	 */
	public BigDecimal getVL_JUROS() {
		return VL_JUROS;
	}

	/**
	 * @param vL_JUROS
	 *            the vL_JUROS to set
	 */
	public void setVL_JUROS(BigDecimal vL_JUROS) {
		VL_JUROS = vL_JUROS;
	}

	/**
	 * @return the vL_IOF
	 */
	public BigDecimal getVL_IOF() {
		return VL_IOF;
	}

	/**
	 * @param vL_IOF
	 *            the vL_IOF to set
	 */
	public void setVL_IOF(BigDecimal vL_IOF) {
		VL_IOF = vL_IOF;
	}

	/**
	 * @return the oE_CHQ_INV_VENC
	 */
	public XMLGregorianCalendar getOE_CHQ_INV_VENC() {
		return OE_CHQ_INV_VENC;
	}

	/**
	 * @param oE_CHQ_INV_VENC
	 *            the oE_CHQ_INV_VENC to set
	 */
	public void setOE_CHQ_INV_VENC(XMLGregorianCalendar oE_CHQ_INV_VENC) {
		OE_CHQ_INV_VENC = oE_CHQ_INV_VENC;
	}

	/**
	 * @return the dT_ULT_MOV
	 */
	public XMLGregorianCalendar getDT_ULT_MOV() {
		return DT_ULT_MOV;
	}

	/**
	 * @param dT_ULT_MOV
	 *            the dT_ULT_MOV to set
	 */
	public void setDT_ULT_MOV(XMLGregorianCalendar dT_ULT_MOV) {
		DT_ULT_MOV = dT_ULT_MOV;
	}

	/**
	 * @return the dT_DEB_JUROS
	 */
	public XMLGregorianCalendar getDT_DEB_JUROS() {
		return DT_DEB_JUROS;
	}

	/**
	 * @param dT_DEB_JUROS
	 *            the dT_DEB_JUROS to set
	 */
	public void setDT_DEB_JUROS(XMLGregorianCalendar dT_DEB_JUROS) {
		DT_DEB_JUROS = dT_DEB_JUROS;
	}

	/**
	 * @return the dT_DEB_IOF
	 */
	public XMLGregorianCalendar getDT_DEB_IOF() {
		return DT_DEB_IOF;
	}

	/**
	 * @param dT_DEB_IOF
	 *            the dT_DEB_IOF to set
	 */
	public void setDT_DEB_IOF(XMLGregorianCalendar dT_DEB_IOF) {
		DT_DEB_IOF = dT_DEB_IOF;
	}

	/**
	 * @return the iND_CPMF
	 */
	public String getIND_CPMF() {
		return IND_CPMF;
	}

	/**
	 * @param iND_CPMF
	 *            the iND_CPMF to set
	 */
	public void setIND_CPMF(String iND_CPMF) {
		IND_CPMF = iND_CPMF;
	}

	/**
	 * @return the fLAG_MOSTRA_CI
	 */
	public String getFLAG_MOSTRA_CI() {
		return FLAG_MOSTRA_CI;
	}

	/**
	 * @param fLAG_MOSTRA_CI
	 *            the fLAG_MOSTRA_CI to set
	 */
	public void setFLAG_MOSTRA_CI(String fLAG_MOSTRA_CI) {
		FLAG_MOSTRA_CI = fLAG_MOSTRA_CI;
	}

	/**
	 * @return the iND_POUPMAX
	 */
	public String getIND_POUPMAX() {
		return IND_POUPMAX;
	}

	/**
	 * @param iND_POUPMAX
	 *            the iND_POUPMAX to set
	 */
	public void setIND_POUPMAX(String iND_POUPMAX) {
		IND_POUPMAX = iND_POUPMAX;
	}

	/**
	 * @return the dtVctoCeb
	 */
	public XMLGregorianCalendar getDtVctoCeb() {
		return dtVctoCeb;
	}

	/**
	 * @param dtVctoCeb the dtVctoCeb to set
	 */
	public void setDtVctoCeb(XMLGregorianCalendar dtVctoCeb) {
		this.dtVctoCeb = dtVctoCeb;
	}

	/**
	 * @return the vlTxJurosMensal
	 */
	public BigDecimal getVlTxJurosMensal() {
		return vlTxJurosMensal;
	}

	/**
	 * @param vlTxJurosMensal the vlTxJurosMensal to set
	 */
	public void setVlTxJurosMensal(BigDecimal vlTxJurosMensal) {
		this.vlTxJurosMensal = vlTxJurosMensal;
	}

	/**
	 * @return the vlLimite
	 */
	public BigDecimal getVlLimite() {
		return vlLimite;
	}

	/**
	 * @param vlLimite the vlLimite to set
	 */
	public void setVlLimite(BigDecimal vlLimite) {
		this.vlLimite = vlLimite;
	}

	/**
	 * @return the oeChqEspUltima
	 */
	public XMLGregorianCalendar getOeChqEspUltima() {
		return oeChqEspUltima;
	}

	/**
	 * @param oeChqEspUltima the oeChqEspUltima to set
	 */
	public void setOeChqEspUltima(XMLGregorianCalendar oeChqEspUltima) {
		this.oeChqEspUltima = oeChqEspUltima;
	}

	/**
	 * @return the qtDiaNdia
	 */
	public Integer getQtDiaNdia() {
		return qtDiaNdia;
	}

	/**
	 * @param qtDiaNdia the qtDiaNdia to set
	 */
	public void setQtDiaNdia(Integer qtDiaNdia) {
		this.qtDiaNdia = qtDiaNdia;
	}

	/**
	 * @return the oeChqEspUtilizado
	 */
	public BigDecimal getOeChqEspUtilizado() {
		return oeChqEspUtilizado;
	}

	/**
	 * @param oeChqEspUtilizado the oeChqEspUtilizado to set
	 */
	public void setOeChqEspUtilizado(BigDecimal oeChqEspUtilizado) {
		this.oeChqEspUtilizado = oeChqEspUtilizado;
	}

	/**
	 * @return the oeChqEspDisp
	 */
	public BigDecimal getOeChqEspDisp() {
		return oeChqEspDisp;
	}

	/**
	 * @param oeChqEspDisp the oeChqEspDisp to set
	 */
	public void setOeChqEspDisp(BigDecimal oeChqEspDisp) {
		this.oeChqEspDisp = oeChqEspDisp;
	}

	/**
	 * @return the vlJurNaoDeb
	 */
	public BigDecimal getVlJurNaoDeb() {
		return vlJurNaoDeb;
	}

	/**
	 * @param vlJurNaoDeb the vlJurNaoDeb to set
	 */
	public void setVlJurNaoDeb(BigDecimal vlJurNaoDeb) {
		this.vlJurNaoDeb = vlJurNaoDeb;
	}


}
