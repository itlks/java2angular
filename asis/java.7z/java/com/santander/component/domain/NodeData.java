package com.santander.component.domain;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class NodeData extends Node {
	
	private int qty;
	
	private BigDecimal competenceValue = new BigDecimal(0);
	
	private BigDecimal dailyLimit = new BigDecimal(0);
	
	private boolean showCompetenceValue = true;
	
	private boolean showDailyLimit = true;
	
	public NodeData(String id, String description) {
		super(id, description);
	}
	
	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public BigDecimal getCompetenceValue() {
		return competenceValue;
	}

	public void setCompetenceValue(BigDecimal competenceValue) {
		this.competenceValue = competenceValue;
	}

	public BigDecimal getDailyLimit() {
		return dailyLimit;
	}

	public void setDailyLimit(BigDecimal dailyLimit) {
		this.dailyLimit = dailyLimit;
	}

	public boolean isShowCompetenceValue() {
		return showCompetenceValue;
	}

	public void setShowCompetenceValue(boolean showCompetenceValue) {
		this.showCompetenceValue = showCompetenceValue;
	}

	public boolean isShowDailyLimit() {
		return showDailyLimit;
	}

	public void setShowDailyLimit(boolean showDailyLimit) {
		this.showDailyLimit = showDailyLimit;
	}

	public List<NodeData> getNodesData() {

		List<NodeData> nodesData = new ArrayList<NodeData>();
		
		for(Node node: super.getNodes()){
			nodesData.add((NodeData) node);
		}
		
		
		return nodesData;
	}

}
