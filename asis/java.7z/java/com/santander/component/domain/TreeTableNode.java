package com.santander.component.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TreeTableNode implements Serializable {

	private static final long serialVersionUID = -6322503455186275697L;

private static int counter = 0;
	
	private String id;
	
	private int level;
	
	private TreeTableNode parent;
	
	private String description;
	
	private String nodePaiEvento;
	
	private boolean disabled;
	
	private boolean selected;
	
	private boolean manualId;
	
	private int coluna;
	
	private List<TreeTableNode> nodes = new ArrayList<TreeTableNode>();
	
	public TreeTableNode(String id, String description) {
		super();
		this.id = id;
		this.description = description;
		this.manualId = true;
	}

	public TreeTableNode(String description) {
		super();
		this.description = description;
		this.id = String.valueOf(counter++);
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	public List<TreeTableNode> getNodes() {
		return Collections.unmodifiableList(nodes);
	}
	
	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public TreeTableNode getParent() {
		return parent;
	}

	public void setParent(TreeTableNode parent) {
		this.parent = parent;
	}
	
	public boolean isDisabled() {
		return disabled;
	}

	public void setDisabled(boolean disabled) {
		this.disabled = disabled;
	}

	public String getNodePaiEvento() {
		
		if(nodePaiEvento == null){
			nodePaiEvento = "";
		}
		
		return nodePaiEvento;
	}

	public void setNodePaiEvento(String nodePaiEvento) {
		this.nodePaiEvento = nodePaiEvento;
	}

	public void addNode(TreeTableNode node){
		node.setParent(this);
		node.setLevel(node.getParent().getLevel() + 1);
		
		if (!manualId){
			node.setId(this.getId() + "." + node.getId());	
		}
		
		this.nodes.add(node);
	}
	
	public void addNode(TreeTableNode[] nodes){
		for (int i = 0; i < nodes.length; i++) {
			addNode(nodes[i]);
		}
	}

	public int getColuna() {
		return coluna;
	}

	public void setColuna(int coluna) {
		this.coluna = coluna;
	}

}
