package com.santander.component.fluidtreeview;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.el.ELContext;
import javax.el.ValueExpression;
import javax.faces.component.UIInput;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;
import javax.servlet.http.HttpSession;

import org.primefaces.context.RequestContext;

import com.santander.component.domain.Node;

public class FluidTreeView extends UIInput {

	public static final String FAMILY = "com.santander.component.FluidTreeView";
	
	private boolean exibirCheckboxApenasFilhos;
	
	private boolean iniciarTreeviewRetraido;
	
	private String idsFirstLevel;
	
	private boolean exibeMarcarTodos = true;
	
	private boolean exibeExpandirTodos = true;
	
	public FluidTreeView() {
	
	}

	
	/**
	 * @param exibirCheckboxApenasFilhos: true exibir componente checkbox apenas nas linhas dos filhos
	 * @param iniciarTreeviewRetraido: true para iniciar o componente treeview retraido
	 */
	public FluidTreeView(boolean exibirCheckboxApenasFilhos, boolean iniciarTreeviewRetraido){
		this.exibirCheckboxApenasFilhos = exibirCheckboxApenasFilhos;
		this.iniciarTreeviewRetraido = iniciarTreeviewRetraido;
	}
	
	/**
	 * @param exibirCheckboxApenasFilhos: true exibir componente checkbox apenas nas linhas dos filhos
	 * @param iniciarTreeviewRetraido: true para iniciar o componente treeview retraido
	 * @param exibeMarcarTodos: true para exibir as opcoes Marcar Todos e Desmarcar todos
	 */
	public FluidTreeView(boolean exibirCheckboxApenasFilhos, boolean iniciarTreeviewRetraido, boolean exibeMarcarTodos){
		this.exibirCheckboxApenasFilhos = exibirCheckboxApenasFilhos;
		this.iniciarTreeviewRetraido = iniciarTreeviewRetraido;
		this.exibeMarcarTodos = exibeMarcarTodos;
	}
	
	/**
	 * @param iniciarTreeviewRetraido: true para iniciar o componente treeview retraido
	 */
	public FluidTreeView(boolean iniciarTreeviewRetraido){
		this.iniciarTreeviewRetraido = iniciarTreeviewRetraido;
	}
	
	@Override
	public String getFamily() {
		return FAMILY;
	}

	@Override
	public String getRendererType() {
		return null;
	}

	private Map<String, String> selectedNodes = new HashMap<String, String>();

	private String selectedNode;

	private String eventCheck;
	
	private String eventMarcarTodos;

	public void update() {
		this.selectedNodes.clear();
		this.selectedNode = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("formGeral:nodesSelected");
		String[] nodes = this.selectedNode.split(",");
		for (int i = 0; i < nodes.length; i++) {
			this.selectedNodes.put(nodes[i], nodes[i]);
		}

		HttpSession httpSession = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		httpSession.setAttribute(this.getId(), this.selectedNode);
	}

	public void update(String selectedNode) {
		String[] nodes = this.selectedNode.split(",");
		for (int i = 0; i < nodes.length; i++) {
			this.selectedNodes.put(nodes[i], nodes[i]);
		}

		HttpSession httpSession = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		httpSession.setAttribute(this.getId(), this.selectedNode);

	}

	public String getSelectedNode() {
		return selectedNode;
	}
	
	public void setSelectedNode(String selectedNode){
		this.selectedNode = selectedNode;
	}

	@Override
	public void setValue(Object value) {
		super.setValue(value);
	}

	@Override
	public void encodeBegin(FacesContext context) throws IOException {

        if (this.selectedNode != null){
               update(this.selectedNode);
        }else{
        	selectedNode = "";
        }

		
		Node[] nodeValues = (Node[]) super.getValue();

		StringBuilder sbFirstLevel = new StringBuilder();

		StringBuilder nodesOutput = new StringBuilder();
		ResponseWriter writer = context.getResponseWriter(); 

		sbFirstLevel.append("[");

		for (int i = 0; i < nodeValues.length; i++) {
			sbFirstLevel.append("" + nodeValues[i].getId() + ",");	
		}

		sbFirstLevel.append("]");
		
		this.setIdsFirstLevel(sbFirstLevel.toString());
		
		String[] nodesFirstLevel = idsFirstLevel.split(",");
		@SuppressWarnings("unused")
		String[] nodes = selectedNode.split(",");
//		if(this.isIniciarTreeviewRetraido()){
//			//Se treeview inicia retraida, expande apenas os n�s de primeiro nivel que possua filhos marcados
//			if (!selectedNode.isEmpty()) {
//				for(String firstLevel : nodesFirstLevel){
//					firstLevel = firstLevel.replace("[", "").replace("]", "");
//					for (String node : nodes) {
//						if(node.contains(firstLevel)){
//							//RequestContext.getCurrentInstance().execute("expandirAoIniciarTela(" + firstLevel + ")");
//						}
//					}
//				}
//			}
//		}
		
		// Setando no javascript a quantidade total de n�s de primeiro nivel
		RequestContext.getCurrentInstance().execute("setarQtdTotalFirstLevel(" + (nodesFirstLevel.length - 1) + ")");
		// Indicando para o javascript quando treeview for da tela AcessoRapido
		if(exibirCheckboxApenasFilhos && iniciarTreeviewRetraido && !exibeMarcarTodos){
			RequestContext.getCurrentInstance().execute("setarTelaAcessoRapido(true)");
		}

		Object toolbar = this.getAttributes().get("showToolbar");
		Object eventCheckObj = this.getAttributes().get("eventCheck");
		Object metodoMarcarTodos = this.getAttributes().get("eventMarcarTodos");
		
		if(metodoMarcarTodos != null){
			eventMarcarTodos = metodoMarcarTodos.toString();
		}else{
			eventMarcarTodos = "";
		}

		if (toolbar != null && Boolean.valueOf(toolbar.toString()) && exibeMarcarTodos){
			nodesOutput.append("<span class=\"toolbar\" style=\"margin-bottom: 10px; width: 100%;\">");
			nodesOutput.append("<a id=\"expandirLink\" class=\"link-toolbar\" onclick=expandAreas(" + sbFirstLevel.toString() + ");><strong>&gt;</strong>Expandir todas as �reas</a>");
			nodesOutput.append("<a id=\"contractLink\" class=\"link-toolbar\" onclick=contractAreas(" + sbFirstLevel.toString() + "); style=\"display:none;\"><strong>&gt;</strong>Retrair todas as �reas</a>");

			if(metodoMarcarTodos != null){
				nodesOutput.append("<a id=\"contractLink\" class=\"link-toolbar\" onclick="+ eventMarcarTodos +";><strong>&gt;</strong>Marcar todos</a>");
			} else{
				nodesOutput.append("<a id=\"contractLink\" class=\"link-toolbar\" onclick=\"marcarAreas(" + sbFirstLevel.toString() + ");\"><strong>&gt;</strong>Marcar todos</a>");
			}
			nodesOutput.append("<a id=\"contractLink\" class=\"link-toolbar\" onclick=desmarcarAreas(" + sbFirstLevel.toString() + ");><strong>&gt;</strong>Desmarcar todos</a>");
			nodesOutput.append("</span><p>");
		} else {
			
			if(!exibeExpandirTodos){
				nodesOutput.append("<span class=\"toolbar\" style=\"margin-bottom: 10px; width: 100%;\">");
				nodesOutput.append("<a id=\"expandirLink\" class=\"link-toolbar\" onclick=expandAreas(" + sbFirstLevel.toString() + "); style=\"display:none;\"><strong>&gt;</strong>Expandir todos os itens</a>");
				nodesOutput.append("<a id=\"contractLink\" class=\"link-toolbar\" onclick=contractAreas(" + sbFirstLevel.toString() + ");><strong>&gt;</strong>Retrair todos os itens</a>");					
				nodesOutput.append("</span><p>");
			}
			else
			{
				nodesOutput.append("<span class=\"toolbar\" style=\"margin-bottom: 10px; width: 100%;\">");
				nodesOutput.append("<a id=\"expandirLink\" class=\"link-toolbar\" onclick=expandAreas(" + sbFirstLevel.toString() + ");><strong>&gt;</strong>Expandir todos os itens</a>");
				nodesOutput.append("<a id=\"contractLink\" class=\"link-toolbar\" onclick=contractAreas(" + sbFirstLevel.toString() + "); style=\"display:none;\"><strong>&gt;</strong>Retrair todos os itens</a>");					
				nodesOutput.append("</span><p>");
			}
	     }

		if(eventCheckObj == null){
			eventCheck = "";
		}else{
			eventCheck = eventCheckObj.toString();
		}

		if (nodeValues != null) {        

			nodesOutput.append("<input id=\"formGeral:nodesSelected\" type=\"hidden\" name=\"formGeral:nodesSelected\" value='" + selectedNode + "'/>");

			for (int i = 0; i < nodeValues.length; i++) {
				printNodes(nodeValues[i], nodesOutput, 1);	
			}
		}
		
		writer.write(nodesOutput.toString());
	}

	private String printNodes(Node node, StringBuilder nodesOutput, int level){

		if (node.getParent() != null && node.getLevel() > 2 && !iniciarTreeviewRetraido){
			nodesOutput.append("<div id=\"" + node.getId() + "_parent\" name="  + node.getParent().getId() + "_div class='li-nivel" + level + "'>");
		} else if (node.getLevel() == 2 && iniciarTreeviewRetraido){
            nodesOutput.append("<div id=\"" + node.getId() + "_parent\" name="  + node.getParent().getId() + "_div class='li-nivel" + level + "' style=\"visibility: hidden;\">");     
		} else {
			nodesOutput.append("<div id=\"" + getId() + "\" class='li-nivel" + level + "' style=\"width: 100%;\">");
		}

		if (node.getLevel() == 2 && iniciarTreeviewRetraido){
            nodesOutput.append("<ul class=\"closed\" style=\"width: 100%;\">");
	    } else {
	        nodesOutput.append("<ul style=\"width: 100%;\">");       
	    }


		if (!node.getId().equals("0") && node.getParent() != null && !node.getNodes().isEmpty()){

			nodesOutput.append("<li>");

			if (selectedNodes.containsKey(node.getId()) || node.isSelected()) {

				nodesOutput.append("<div display=\"none\" class=\"checkbox\" style=\"margin-left:19px;\">");

				if(isExibirCheckboxApenasFilhos()){
					if(node.getLevel() >= 3){
						if (node.isDisabled()){
							nodesOutput.append("<input id=\"" + node.getId() + "\" name=\"" + node.getParent().getId() + "\" type=\"checkbox\" disabled checked style=\"margin-left:1px;\" onchange='show(this.id);" + eventCheck + "'/>");	
						} else {
							nodesOutput.append("<input id=\"" + node.getId() + "\" name=\"" + node.getParent().getId() + "\" type=\"checkbox\" checked style=\"margin-left:1px;\" onchange='show(this.id);" + eventCheck + "'/>");
						}
					}					
					
				} else{
					if (node.isDisabled()){
						nodesOutput.append("<input id=\"" + node.getId() + "\" name=\"" + node.getParent().getId() + "\" type=\"checkbox\" disabled checked style=\"margin-left:1px;\" onchange='show(this.id);" + eventCheck + "'/>");	
					} else {
						nodesOutput.append("<input id=\"" + node.getId() + "\" name=\"" + node.getParent().getId() + "\" type=\"checkbox\" checked style=\"margin-left:1px;\" onchange='show(this.id);" + eventCheck + "'/>");
					}
				}

				if(isExibirCheckboxApenasFilhos()){
					if(node.getLevel() < 3){						
						nodesOutput.append("<label class=\"treeview-itens\" style=\"font-weight:bold;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + node.getDescription() + "</label>");
					}else{
						nodesOutput.append("<label class=\"treeview-itens\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + node.getDescription() + "</label>");
					}
				}else{
					nodesOutput.append("<label class=\"treeview-itens\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + node.getDescription() + "</label>");				
				}
				nodesOutput.append("</div>");


			} else {

				nodesOutput.append("<div class=\"checkbox\" style=\"margin-left:19px;\">");

				if(isExibirCheckboxApenasFilhos()){
					if(node.getLevel() >= 3){
						if (node.isDisabled()){
							nodesOutput.append("<input id=\"" + node.getId() + "\" name=\"" + node.getParent().getId() + "\" type=\"checkbox\" disabled style=\"margin-left:1px;\" onchange='show(this.id);" + eventCheck + "'/>");	
						} else {
							nodesOutput.append("<input id=\"" + node.getId() + "\" name=\"" + node.getParent().getId() + "\" type=\"checkbox\" style=\"margin-left:1px;\" onchange='show(this.id);" + eventCheck + "'/>");
						}
					}
				} else {
					if (node.isDisabled()){
						nodesOutput.append("<input id=\"" + node.getId() + "\" name=\"" + node.getParent().getId() + "\" type=\"checkbox\" disabled style=\"margin-left:1px;\" onchange='show(this.id);" + eventCheck + "'/>");	
					} else {
						nodesOutput.append("<input id=\"" + node.getId() + "\" name=\"" + node.getParent().getId() + "\" type=\"checkbox\" style=\"margin-left:1px;\" onchange='show(this.id);" + eventCheck + "'/>");
					}
				}

				if(isExibirCheckboxApenasFilhos()){
					if(node.getLevel() < 3){						
						nodesOutput.append("<label class=\"treeview-itens\" style=\"font-weight:bold;\">" + node.getDescription() + "</label>");
					}else{
						nodesOutput.append("<label class=\"treeview-itens\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + node.getDescription() + "</label>");
					}
				}else{
					nodesOutput.append("<label class=\"treeview-itens\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + node.getDescription() + "</label>");				
				}
				nodesOutput.append("</div>");
			}

		} else if (!node.getId().equals("0") && node.getParent() != null && node.getNodes().isEmpty()){

			nodesOutput.append("<li>");

			if (selectedNodes.containsKey(node.getId()) || node.isSelected()) {

				//Tratamento especifico para o submenu SuperCash do menu Cobran�a e Recebimentos que causava desalinhamento no componente
				if("4478.4890".equals(node.getId()))
					nodesOutput.append("<div class=\"checkbox\" style=\"margin-top:10px;margin-left:10px;\">");
				else
					nodesOutput.append("<div class=\"checkbox\" style=\"margin-top:-5px;margin-left:10px;\">");

				if(isExibirCheckboxApenasFilhos()){
					if(node.getLevel() >= 3){
						if (node.isDisabled()){
							nodesOutput.append("<input id=\"" + node.getId() + "\" name=\"" + node.getParent().getId() + "\" type=\"checkbox\" disabled checked style=\"margin-left:1px;\" onchange='show(this.id);" + eventCheck + "'/>");	
						} else {
							nodesOutput.append("<input id=\"" + node.getId() + "\" name=\"" + node.getParent().getId() + "\" type=\"checkbox\" checked style=\"margin-left:1px;\" onchange='show(this.id);" + eventCheck + "'/>");
						}
					}
				} else {
					if (node.isDisabled()){
						nodesOutput.append("<input id=\"" + node.getId() + "\" name=\"" + node.getParent().getId() + "\" type=\"checkbox\" disabled checked style=\"margin-left:1px;\" onchange='show(this.id);" + eventCheck + "'/>");	
					} else {
						nodesOutput.append("<input id=\"" + node.getId() + "\" name=\"" + node.getParent().getId() + "\" type=\"checkbox\" checked style=\"margin-left:1px;\" onchange='show(this.id);" + eventCheck + "'/>");
					}
				}


				if(isExibirCheckboxApenasFilhos()){
					if(node.getLevel() < 3){						
						nodesOutput.append("<label class=\"treeview-itens\" style=\"font-weight:bold;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + node.getDescription() + "</label>");
					}else{
						nodesOutput.append("<label class=\"treeview-itens\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + node.getDescription() + "</label>");
					}
				}else{
					nodesOutput.append("<label class=\"treeview-itens\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + node.getDescription() + "</label>");				
				}
				nodesOutput.append("</div>");

			} else {

				//Tratamento especifico para o submenu SuperCash do menu Cobran�a e Recebimentos que causava desalinhamento no componente
				if("4478.4890".equals(node.getId()))
					nodesOutput.append("<div class=\"checkbox\" style=\"margin-top:10px;margin-left:10px;\">");
				else
					nodesOutput.append("<div class=\"checkbox\" style=\"margin-top:-5px;margin-left:10px;\">");

				if(isExibirCheckboxApenasFilhos()){
					if(node.getLevel() >= 3){
						if (node.isDisabled()){
							nodesOutput.append("<input id=\"" + node.getId() + "\" name=\"" + node.getParent().getId() + "\" type=\"checkbox\" disabled style=\"margin-left:1px;\" onchange='show(this.id);" + eventCheck + "'/>");	
						} else {
							nodesOutput.append("<input id=\"" + node.getId() + "\" name=\"" + node.getParent().getId() + "\" type=\"checkbox\" style=\"margin-left:1px;\" onchange='show(this.id);" + eventCheck + "'/>");
						}
					}
				} else{
					if (node.isDisabled()){
						nodesOutput.append("<input id=\"" + node.getId() + "\" name=\"" + node.getParent().getId() + "\" type=\"checkbox\" disabled style=\"margin-left:1px;\" onchange='show(this.id);" + eventCheck + "'/>");	
					} else {
						nodesOutput.append("<input id=\"" + node.getId() + "\" name=\"" + node.getParent().getId() + "\" type=\"checkbox\" style=\"margin-left:1px;\" onchange='show(this.id);" + eventCheck + "'/>");
					}
				}

				if(isExibirCheckboxApenasFilhos()){
					if(node.getLevel() < 3){						
						nodesOutput.append("<label class=\"treeview-itens\" style=\"font-weight:bold;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + node.getDescription() + "</label>");
					}else{
						nodesOutput.append("<label class=\"treeview-itens\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + node.getDescription() + "</label>");
					}
				}else{
					nodesOutput.append("<label class=\"treeview-itens\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + node.getDescription() + "</label>");				
				}
				nodesOutput.append("</div>");

			}

		} else {

			nodesOutput.append("<li>");
			
			if (selectedNodes.containsKey(node.getId()) || node.isSelected()){

				if (!node.getNodes().isEmpty()){
					nodesOutput.append("<a id=\"" + node.getId() + "_link\" href=\"#/\" onclick=hideDiv(\""+ node.getId() +"\");><span id='" + node.getId() + "_img' class=\"button-expandir treeview-plus\"/></a>");
				}

				nodesOutput.append("<div class=\"checkbox node-pai\">");
				
				if(isExibirCheckboxApenasFilhos()){
					if(node.getLevel() >= 3){
						if (node.isDisabled()){
							nodesOutput.append("<input id=\"" + node.getId() + "\" type=\"checkbox\" disabled checked onchange='show(this.id); hideDivClickCheckbox(this.id); " + eventCheck + node.getNodePaiEvento() + "'style=\"margin-left:1px;\"/>");
						}else{
							nodesOutput.append("<input id=\"" + node.getId() + "\" type=\"checkbox\" checked onchange='show(this.id); hideDivClickCheckbox(this.id); " + eventCheck + node.getNodePaiEvento() + "'style=\"margin-left:1px;\"/>");
						}
					}
				} else{
					if (node.isDisabled()){
						nodesOutput.append("<input id=\"" + node.getId() + "\" type=\"checkbox\" disabled checked onchange='show(this.id); hideDivClickCheckbox(this.id); " + eventCheck + node.getNodePaiEvento() + "'style=\"margin-left:1px; margin-top:-5px\"/>");
					}else{
						nodesOutput.append("<input id=\"" + node.getId() + "\" type=\"checkbox\" checked onchange='show(this.id); hideDivClickCheckbox(this.id); " + eventCheck + node.getNodePaiEvento() + "'style=\"margin-left:1px; margin-top:-5px\"/>");
					}
				}
				if(isExibirCheckboxApenasFilhos()){
					if(node.getLevel() < 3){						
						nodesOutput.append("<label class=\"treeview-itens\" style=\"font-weight:bold;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + node.getDescription() + "</label>");
					}else{
						nodesOutput.append("<label class=\"treeview-itens\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + node.getDescription() + "</label>");
					}
				}else{
					nodesOutput.append("<label class=\"treeview-itens\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + node.getDescription() + "</label>");				
				}
				nodesOutput.append("</div>");

			} else {

				if (!node.getNodes().isEmpty()){
					nodesOutput.append("<a id=\"" + node.getId() + "_link\" onclick=hideDiv(\""+ node.getId() +"\");><span id='" + node.getId() + "_img' class=\"button-expandir treeview-plus\"/></a>");
				}

				nodesOutput.append("<div class=\"checkbox node-pai\">");
				if(isExibirCheckboxApenasFilhos()){
					if(node.getLevel() >= 3){
						if (node.isDisabled()){
							nodesOutput.append("<input id=\"" + node.getId() + "\" type=\"checkbox\" disabled onchange='show(this.id); hideDivClickCheckbox(this.id); " + eventCheck + node.getNodePaiEvento() + "'style=\"margin-left:1px;\"/>");
						}else{
							nodesOutput.append("<input id=\"" + node.getId() + "\" type=\"checkbox\" onchange='show(this.id); hideDivClickCheckbox(this.id); " + eventCheck + node.getNodePaiEvento() + "'style=\"margin-left:1px;\"/>");										
						}
					}
				} else{
					if (node.isDisabled()){
						nodesOutput.append("<input id=\"" + node.getId() + "\" type=\"checkbox\" disabled onchange='show(this.id); hideDivClickCheckbox(this.id); " + eventCheck + node.getNodePaiEvento() + "'style=\"margin-left:1px; margin-top:-5px\"/>");
					}else{
						nodesOutput.append("<input id=\"" + node.getId() + "\" type=\"checkbox\" onchange='show(this.id); hideDivClickCheckbox(this.id); " + eventCheck + node.getNodePaiEvento() + "'style=\"margin-left:1px; margin-top:-5px\"/>");										
					}
				}
				
				if(isExibirCheckboxApenasFilhos()){
					if(node.getLevel() < 3){						
						nodesOutput.append("<label class=\"treeview-itens\" style=\"font-weight:bold;\">" + node.getDescription() + "</label>");
					}else{
						nodesOutput.append("<label class=\"treeview-itens\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + node.getDescription() + "</label>");
					}
				}else{
					nodesOutput.append("<label class=\"treeview-itens\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + node.getDescription() + "</label>");				
				}
				nodesOutput.append("</div>");

			}
		}

		if (!node.getNodes().isEmpty()){
			level += 1;
			for (Node nodeChild : node.getNodes()) {
				printNodes(nodeChild, nodesOutput, level);				
			}
		} else {
			level -= 1;
		}
		
		if(node.getParent() != null && node.getLevel() > 1){
			nodesOutput.append("<hr id=\"" + node.getId() + "_sep\" name=\"" + node.getParent().getId() + "_sep\"  style=\"visibility: hidden; width: 100%;\">");
		} else{
			nodesOutput.append("<hr id=\"" + node.getId() + "_sep\" class=\"last-hr\" style=\"visibility: hidden; width: 100%;\">");
		}
		
		nodesOutput.append("</ul>");
		nodesOutput.append("</div>");

		return nodesOutput.toString();

	}

	public static void setValue2ValueExpression(final Object value, final String expression) {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		ELContext elContext = facesContext.getELContext();

		ValueExpression targetExpression = 
				facesContext.getApplication().getExpressionFactory().createValueExpression(elContext, expression, Object.class);
		targetExpression.setValue(elContext, value);
	}

	public boolean isExibirCheckboxApenasFilhos() {
		return exibirCheckboxApenasFilhos;
	}

	public void setExibirCheckboxApenasFilhos(boolean exibirCheckboxApenasFilhos) {
		this.exibirCheckboxApenasFilhos = exibirCheckboxApenasFilhos;
	}

	public boolean isIniciarTreeviewRetraido() {
		return iniciarTreeviewRetraido;
	}

	public void setIniciarTreeviewRetraido(boolean iniciarTreeviewRetraido) {
		this.iniciarTreeviewRetraido = iniciarTreeviewRetraido;
	}


	public String getIdsFirstLevel() {
		return idsFirstLevel;
	}


	public void setIdsFirstLevel(String idsFirstLevel) {
		this.idsFirstLevel = idsFirstLevel;
	}


	public boolean isExibeMarcarTodos() {
		return exibeMarcarTodos;
	}


	public void setExibeMarcarTodos(boolean exibeMarcarTodos) {
		this.exibeMarcarTodos = exibeMarcarTodos;
	}


	public boolean isExibeExpandirTodos() {
		return exibeExpandirTodos;
	}


	public void setExibeExpandirTodos(boolean exibeExpandirTodos) {
		this.exibeExpandirTodos = exibeExpandirTodos;
	}

}
