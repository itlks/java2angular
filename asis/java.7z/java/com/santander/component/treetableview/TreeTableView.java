package com.santander.component.treetableview;

import java.io.IOException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import javax.el.ELContext;
import javax.el.ValueExpression;
import javax.faces.component.UIInput;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;
import javax.servlet.http.HttpSession;

import com.santander.component.domain.TreeTableNode;

public class TreeTableView extends UIInput implements Serializable  {

	private static final long serialVersionUID = -7600487701222478461L;

	public static final String FAMILY = "com.santander.component.TreeTableView";

	private String idsFirstLevel;

	private boolean estaEmPreenchimento;

	private boolean exibirCheckboxApenasFilhos;

	private boolean iniciarTreeviewRetraido;

	private boolean exibeMarcarTodos = true;
	
	private String eventCheck;

	public TreeTableView() {
		this.estaEmPreenchimento = true;
	}

	public TreeTableView(boolean exibirCheckboxApenasFilhos, boolean iniciarTreeviewRetraido,
			boolean exibeMarcarTodos) {
		setExibirCheckboxApenasFilhos(exibirCheckboxApenasFilhos);
		this.iniciarTreeviewRetraido = iniciarTreeviewRetraido;
		this.exibeMarcarTodos = exibeMarcarTodos;
	}

	@Override
	public String getFamily() {
		return FAMILY;
	}

	@Override
	public String getRendererType() {
		return null;
	}

	private Map<String, String> selectedNodes = new HashMap<String, String>();

	private String selectedNode;

	public void update() {
		this.selectedNodes.clear();
		this.selectedNode = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap()
				.get("formGeral:nodesSelected");
		this.estaEmPreenchimento = Boolean.getBoolean(FacesContext.getCurrentInstance().getExternalContext()
				.getRequestParameterMap().get("formGeral:estaEmPreenchimento"));

		String[] nodes = this.selectedNode.split(",");
		for (int i = 0; i < nodes.length; i++) {
			this.selectedNodes.put(nodes[i], nodes[i]);
		}

		HttpSession httpSession = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		httpSession.setAttribute(this.getId(), this.selectedNode);
	}

	public void update(String selectedNode) {
		String[] nodes = this.selectedNode.split(",");
		for (int i = 0; i < nodes.length; i++) {
			this.selectedNodes.put(nodes[i], nodes[i]);
		}

		HttpSession httpSession = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		httpSession.setAttribute(this.getId(), this.selectedNode);

	}

	public String getSelectedNode() {
		return selectedNode;
	}

	public void setSelectedNode(String selectedNode) {
		this.selectedNode = selectedNode;
	}

	@Override
	public void setValue(Object value) {
		super.setValue(value);
	}

	@Override
	public void encodeBegin(FacesContext context) throws IOException {

		if (this.selectedNode != null) {
			update(this.selectedNode);
		} else {
			selectedNode = "";
		}

		TreeTableNode[] nodeValues = (TreeTableNode[]) super.getValue();

		StringBuilder sbFirstLevel = new StringBuilder();

		StringBuilder nodesOutput = new StringBuilder();
		ResponseWriter writer = context.getResponseWriter();

		sbFirstLevel.append("[");

		if (nodeValues != null) {
			for (int i = 0; i < nodeValues.length; i++) {
				sbFirstLevel.append("" + nodeValues[i].getId() + ",");
			}
		}
		sbFirstLevel.append("]");

		this.setIdsFirstLevel(sbFirstLevel.toString());

		Object toolbar = this.getAttributes().get("showToolbar");
		Object eventCheckObj = this.getAttributes().get("eventCheck");
		
		if(eventCheckObj == null){
			eventCheck = "";
		}else{
			eventCheck = eventCheckObj.toString();
		}

		if (toolbar != null && Boolean.valueOf(toolbar.toString())) {
			nodesOutput.append("<span class=\"toolbar\" style=\"margin-bottom: -10px; width: 100%;\">");

			nodesOutput.append("<strong style=\"color:red;\">&gt;&nbsp;</strong>");
			nodesOutput.append("<a id=\"linkExpadirTodos\" class=\"link-toolbar\" onclick=exibirTodasCategorias(" + sbFirstLevel.toString() + ");>Expandir todas as �reas</a>");
			nodesOutput.append("<a id=\"linkEsconderTodos\" class=\"link-toolbar\" onclick=esconderTodasCategorias(" + sbFirstLevel.toString() + "); style=\"display:none;\">Retrair todas as �reas</a>");

			if (!exibirCheckboxApenasFilhos){
				nodesOutput.append("<strong style=\"color:red;\">&gt;&nbsp;</strong>");
			nodesOutput.append(
					"<a id=\"linkMarcarTodos\" class=\"link-toolbar\" onclick=\"marcarDesmarcarTodasCategorias(true);\">Marcar todas</a>");
			nodesOutput.append("<strong style=\"color:red;\">&gt;&nbsp;</strong>");
			nodesOutput.append(
					"<a id=\"linkDesmarcarTodos\" class=\"link-toolbar\" onclick=\"marcarDesmarcarTodasCategorias(false);\")>Desmarcar todas</a>");
			}

			nodesOutput.append("</span><p>");
		}

		if (nodeValues != null) {
			nodesOutput.append("<input id=\"formGeral:nodesSelected\" type=\"hidden\" name=\"formGeral:nodesSelected\" value='" + selectedNode + "'/>");
			nodesOutput.append("<input id=\"formGeral:estaEmPreenchimento\" type=\"hidden\" name=\"formGeral:estaEmPreenchimento\" value='" + this.estaEmPreenchimento + "'/>");

			nodesOutput.append("<div style=\"display: inline-table; width: 100%;\">");

			nodesOutput.append("<table id=\"treeTableView\" style=\"width: 100%; float: left; margin-left: 10px;\">");
			nodesOutput.append("<tbody>");

			for (int i = 0; i < nodeValues.length; i++) {
				TreeTableNode node = nodeValues[i];

				if (node.getLevel() == 1) {
					nodesOutput.append(this.desenharLevel1(node));

					nodesOutput.append("<tr id=\"" + node.getId() + "\" name=\"level2\" valign=\"top\" style=\"width: 100%; display: none\">");
					nodesOutput.append("<td style=\"width: 33%; padding-bottom: 20px\">");
					int count = 0;
					for (TreeTableNode nodeFilho : node.getNodes()) {

						if (nodeFilho.getColuna() == 1) {

							nodesOutput.append(this.desenharLevel2(nodeFilho, count == 0, nodeFilho.getColuna()));

							for (TreeTableNode nodeNeto : nodeFilho.getNodes()) {
								if (nodeNeto.getColuna() == 1) {
									nodesOutput.append(this.desenharLevel3(nodeNeto));
								}
							}
						}
						count++;
					}
					nodesOutput.append("</div>"); // fechando a div aberta no Level 1
					nodesOutput.append("</td>");

					nodesOutput.append("<td style=\"width: 33%; padding-bottom: 20px\">");
					nodesOutput.append("<div style=\"width: 100%;\">");
					count = 0;
					for (TreeTableNode nodeFilho : node.getNodes()) {
						if (nodeFilho.getColuna() == 2) {
							nodesOutput.append(this.desenharLevel2(nodeFilho, count == 0, nodeFilho.getColuna()));

							for (TreeTableNode nodeNeto : nodeFilho.getNodes()) {
								if (nodeNeto.getColuna() == 2) {
									nodesOutput.append(this.desenharLevel3(nodeNeto));
								}
							}
							count++;
						}
					}
					nodesOutput.append("</div>"); // fechando a div aberta no Level 1
					nodesOutput.append("</td>");

					nodesOutput.append("<td style=\"width: 33%; padding-bottom: 20px\">");
					nodesOutput.append("<div style=\"width: 100%;\">");
					count = 0;
					for (TreeTableNode nodeFilho : node.getNodes()) {
						if (nodeFilho.getColuna() == 3) {
							nodesOutput.append(this.desenharLevel2(nodeFilho, count == 0, nodeFilho.getColuna()));

							for (TreeTableNode nodeNeto : nodeFilho.getNodes()) {
								if (nodeNeto.getColuna() == 3) {
									nodesOutput.append(this.desenharLevel3(nodeNeto));
								}
							}
							count++;
						}
					}
					nodesOutput.append("</div>"); // fechando a div aberta no Level 1
					nodesOutput.append("</td>");

					nodesOutput.append("</tr>");
				}
			}
			nodesOutput.append("</tbody>");
			nodesOutput.append("</table>");

			nodesOutput.append("</div>");
		}

		writer.write(nodesOutput.toString());
	}

	private String desenharLevel1(TreeTableNode node) {
		StringBuilder nivel1 = new StringBuilder();

		nivel1.append("<tr>");
		nivel1.append("<td colspan='3' name='level1'>");
		nivel1.append("<a id=\"" + node.getId() + "_link\" onclick=collapseRow(\""+ node.getId() +"\");><span id='" + node.getId() + "_img' class=\"button-expandir treeview-plus\"/></a>");

		if (node.isSelected()) {
			if (node.isDisabled())
				nivel1.append("<input id=\"" + node.getId() + "_ck\" name=\"" + node.getId() + "\" type=\"checkbox\" checked disabled style=\"margin-left:5px; margin-top:-2px;\" onchange='marcarCategoria(this.id)'</input>");
			else
				nivel1.append("<input id=\"" + node.getId() + "_ck\" name=\"" + node.getId() + "\" type=\"checkbox\" checked style=\"margin-left:5px; margin-top:-2px;\" onchange='marcarCategoria(this.id)'</input>");
		} else {
			if (!exibirCheckboxApenasFilhos){
				if (node.isDisabled())
					nivel1.append("<input id=\"" + node.getId() + "_ck\" name=\"" + node.getId() + "\" type=\"checkbox\" disabled style=\"margin-left:5px; margin-top:-2px;\" onchange='marcarCategoria(this.id);' </input>");
				else
					nivel1.append("<input id=\"" + node.getId() + "_ck\" name=\"" + node.getId() + "\" type=\"checkbox\" style=\"margin-left:5px; margin-top:-2px;\" onchange='marcarCategoria(this.id);' </input>");
			}
		}
		
		if (!exibirCheckboxApenasFilhos)
			nivel1.append("<label class=\"treeview-itens\" name=\"itensLevel1\" style=\"font-weight:bold; margin-top:-20px; margin-left:10px\">" + node.getDescription() + "</label>");
		else
			nivel1.append("<label class=\"treeview-itens\" name=\"itensLevel1\" style=\"font-weight:bold; margin-top:-40px\">" + node.getDescription() + "</label>");
		
		nivel1.append("</td>");
		nivel1.append("<tr>");

		return nivel1.toString();
	}

	private String desenharLevel2(TreeTableNode node, boolean primeiroDaColuna, int colunaAtual) {
		StringBuilder nivel2 = new StringBuilder();

		if (!primeiroDaColuna)
			nivel2.append("<hr name=\"hrNivel2\" style=\"margin-left:30px;\">");

		if (node.isSelected()) {
			if (node.isDisabled())
				nivel2.append("<input id=\"" + node.getId() + "_ck\" name=\"" + node.getId().substring(0, 4)+ "\" type=\"checkbox\" checked disabled style=\"margin:15px 0px 0px 30px;\" onchange='marcarDesmarcar(this.id)'</input>");
			else
				nivel2.append("<input id=\"" + node.getId() + "_ck\" name=\"" + node.getId().substring(0, 4)+ "\" type=\"checkbox\" checked style=\"margin:15px 0px 0px 30px;\" onchange='marcarDesmarcar(this.id)'</input>");
		} else {
			if (!exibirCheckboxApenasFilhos){
				if (node.isDisabled())
						nivel2.append("<input id=\"" + node.getId() + "_ck\" name=\"" + node.getId().substring(0, 4) + "\"  type=\"checkbox\" disabled style=\"margin:15px 0px 0px 30px;\" onchange='marcarDesmarcar(this.id)'</input>");
				else
						nivel2.append("<input id=\"" + node.getId() + "_ck\" name=\"" + node.getId().substring(0, 4) + "\"  type=\"checkbox\" style=\"margin:15px 0px 0px 30px;\" onchange='marcarDesmarcar(this.id)'</input>");
			}
		}

		if (!exibirCheckboxApenasFilhos)
			nivel2.append("<label class=\"treeview-itens\" name=\"itensLevel2\" style=\"font-weight:bold; margin:15px 0px 0px 30px;\">" + node.getDescription() + "</label>");
		else
			nivel2.append("<label class=\"treeview-itens\" name=\"itensLevel2\" style=\"font-weight:bold; margin:15px 0px 0px 30px;\">" + node.getDescription() + "</label>");

		return nivel2.toString();
	}

	private String desenharLevel3(TreeTableNode node) {
		StringBuilder nivel3 = new StringBuilder();
		
		if (!exibirCheckboxApenasFilhos){
		if (node.isSelected()) {
			if (node.isDisabled())
				nivel3.append("<input id=\"" + node.getId() + "_ck\" name=\"" + node.getId().substring(0, 4) + "\" type=\"checkbox\" checked disabled style=\"margin:5px 0px 0px 60px;\" onchange='marcarDesmarcar(this.id);'/>");
			else
				nivel3.append("<input id=\"" + node.getId() + "_ck\" name=\"" + node.getId().substring(0, 4) + "\" type=\"checkbox\" checked style=\"margin:5px 0px 0px 60px;\" onchange='marcarDesmarcar(this.id);'/>");
		} else {
			if (node.isDisabled())
				nivel3.append("<input id=\"" + node.getId() + "_ck\" name=\"" + node.getId().substring(0, 4) + "\" type=\"checkbox\" disabled style=\"margin:5px 0px 0px 60px;\" onchange='marcarDesmarcar(this.id);'/>");
			else
				nivel3.append("<input id=\"" + node.getId() + "_ck\" name=\"" + node.getId().substring(0, 4)
						+ "\" type=\"checkbox\" style=\"margin:5px 0px 0px 60px;\" onchange='marcarDesmarcar(this.id);" + eventCheck + "'/>");
			}
		}
		else{
			if (node.isSelected()) {
				if (node.isDisabled())
					nivel3.append("<input id=\"" + node.getId() + "\" name=\"" + node.getId().substring(0, 4) + "\" type=\"checkbox\" checked disabled style=\"margin:5px 0px 0px 60px;\" onchange='marcarDesmarcar(this.id);'/>");
				else
					nivel3.append("<input id=\"" + node.getId() + "\" name=\"" + node.getId().substring(0, 4) + "\" type=\"checkbox\" checked style=\"margin:5px 0px 0px 60px;\" onchange='marcarDesmarcar(this.id);" + eventCheck + "'/>");
			} else {
				if (node.isDisabled())
					nivel3.append("<input id=\"" + node.getId() + "\" name=\"" + node.getId().substring(0, 4) + "\" type=\"checkbox\" disabled style=\"margin:5px 0px 0px 60px;\" onchange='marcarDesmarcar(this.id);'/>");
				else
					nivel3.append("<input id=\"" + node.getId() + "\" name=\"" + node.getId().substring(0, 4)
							+ "\" type=\"checkbox\" style=\"margin:5px 0px 0px 60px;\" onchange='marcarDesmarcar(this.id);" + eventCheck + "'/>");
			}
		}

		nivel3.append("<label class=\"treeview-itens\" name=\"itensLevel3\" style=\"margin:5px 0px 0px 60px;\">" + node.getDescription() + "</label>");

		return nivel3.toString();
	}

	public static void setValue2ValueExpression(final Object value, final String expression) {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		ELContext elContext = facesContext.getELContext();

		ValueExpression targetExpression = 
				facesContext.getApplication().getExpressionFactory().createValueExpression(elContext, expression, Object.class);
		targetExpression.setValue(elContext, value);
	}

	public String getIdsFirstLevel() {
		return idsFirstLevel;
	}

	public void setIdsFirstLevel(String idsFirstLevel) {
		this.idsFirstLevel = idsFirstLevel;
	}

	public boolean isEstaEmPreenchimento() {
		return estaEmPreenchimento;
	}

	public void setEstaEmPreenchimento(boolean estaEmPreenchimento) {
		this.estaEmPreenchimento = estaEmPreenchimento;
	}

	/**
	 * @return the exibirCheckboxApenasFilhos
	 */
	public boolean isExibirCheckboxApenasFilhos() {
		return exibirCheckboxApenasFilhos;
	}

	/**
	 * @param exibirCheckboxApenasFilhos
	 *            the exibirCheckboxApenasFilhos to set
	 */
	public void setExibirCheckboxApenasFilhos(boolean exibirCheckboxApenasFilhos) {
		this.exibirCheckboxApenasFilhos = exibirCheckboxApenasFilhos;
	}

	/**
	 * @return the iniciarTreeviewRetraido
	 */
	public boolean isIniciarTreeviewRetraido() {
		return iniciarTreeviewRetraido;
	}

	/**
	 * @param iniciarTreeviewRetraido
	 *            the iniciarTreeviewRetraido to set
	 */
	public void setIniciarTreeviewRetraido(boolean iniciarTreeviewRetraido) {
		this.iniciarTreeviewRetraido = iniciarTreeviewRetraido;
	}

	/**
	 * @return the exibeMarcarTodos
	 */
	public boolean isExibeMarcarTodos() {
		return exibeMarcarTodos;
	}

	/**
	 * @param exibeMarcarTodos
	 *            the exibeMarcarTodos to set
	 */
	public void setExibeMarcarTodos(boolean exibeMarcarTodos) {
		this.exibeMarcarTodos = exibeMarcarTodos;
	}

}
