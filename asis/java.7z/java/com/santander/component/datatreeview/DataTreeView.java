package com.santander.component.datatreeview;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.el.ELContext;
import javax.el.ValueExpression;
import javax.faces.component.UIInput;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;

import com.santander.component.domain.Category;
import com.santander.component.domain.NodeData;

public class DataTreeView extends UIInput {
	
	public static final String FAMILY = "com.santander.component.DataTreeView";
	
	private Map<String, NodeData> selectedNodes = new HashMap<String, NodeData>();

	private String selectedNode;
	
	private NodeData nodeData;
	
	public DataTreeView() {
		nodeData = new NodeData("0", "Aplicar a todas as transa��es de todos os produtos");
		nodeData.setLevel(0);
	}
	
	@Override
	public String getFamily() {
		return "com.santander.datatreeview";
	}
	
	@Override
	public void setValue(Object value) {
		super.setValue(value);
	}
	
	public NodeData getNodeData() {
		return nodeData;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void encodeBegin(FacesContext context) throws IOException {
		List<Category> values = (List<Category>) super.getValue();
		
		List<Category> categories = values;
		 
        if (categories != null && !categories.isEmpty()) {        
        
        	ResponseWriter writer = context.getResponseWriter();
        	
        	StringBuilder nodesOutput = new StringBuilder();
        	
        	StringBuilder sbFirstLevel = new StringBuilder();
        	
        	sbFirstLevel.append("[");
        	
        	for (Category category : categories) {
        		sbFirstLevel.append("" + category.getNodeData().getId() + ","); 
        	}
        	
        	sbFirstLevel.append("]");
        	
        	nodesOutput.append("<input id=\"formId:nodesSelected\" type=\"hidden\" name=\"formId:nodesSelected\"/>");
        	
        	nodesOutput.append("<div class=\"box-shadow\">");

        	nodesOutput.append("<td><a id=\"expandirLink\" href=\"#\" class=\"link-marker\" onclick=expandAreas(" + sbFirstLevel.toString() + ");><strong>&gt;</strong>Expandir todas as �reas</a></span></td>");
        	
        	nodesOutput.append("<td><a id=\"contractLink\" href=\"#\" class=\"link-marker\" onclick=contractAreas(" + sbFirstLevel.toString() + "); style=\"display:none;\"><strong>&gt;</strong>Retrair todas as �reas</a></span></td>");
        	
        	nodesOutput.append("<hr>");
        	nodesOutput.append("<table>\n");
        	
        	nodesOutput.append("<tr>");
            	nodesOutput.append("<td class=\"checkbox\" style=\"padding:5px;\">");
            	
            		if (nodeData.isSelected()){
            			nodesOutput.append("<input id=\"" + nodeData.getId() + "\" type=\"checkbox\" checked onchange='dtselect(this.id);' style=\"margin-left:-8px;\">");	
            		} else {
            			nodesOutput.append("<input id=\"" + nodeData.getId() + "\" type=\"checkbox\" onchange='dtselect(this.id);' style=\"margin-left:-8px;\">");
            		}
            		
            		nodesOutput.append("<label class=\"checkbox-inline\" style=\"margin-left:-10px;width:400px;\">&nbsp;&nbsp;&nbsp;" + nodeData.getDescription() + "</label>");

            	nodesOutput.append("</td>");

    			if (selectedNodes.containsKey(nodeData.getId())) {
    				this.nodeData = selectedNodes.get(nodeData.getId());
    				this.nodeData.setDescription("Aplicar a todas as transa��es de todos os produtos");
    				this.nodeData.setSelected(true);
    			}
            	
    			if (nodeData.isSelected()){

					nodesOutput.append("<td style=\"width:10%;padding:5px;\">");
					nodesOutput.append("Qtd. Ass.");
					nodesOutput.append("<input id=\"" + nodeData.getId() + "_inputQty\" value=\"" + nodeData.getQty()
							+ "\" class=\"form-control\" onkeypress='return event.charCode >= 48 && event.charCode <= 57' onchange='dtUpdateValue(\""
							+ nodeData.getId() + "\", this.id,this.name, this.value);' type=\"text\">");
					nodesOutput.append("</td>\n");
	
					nodesOutput.append("<td style=\"width:10%;padding:5px;\">");
					nodesOutput.append("Valor Al�ada (R$)");
					nodesOutput.append(
							"<input id=\"" + nodeData.getId() + "_inputComp\" value=\"" + formatCurrency(nodeData.getCompetenceValue())
									+ "\" class=\"form-control\" onblur='format(this);' onchange='dtUpdateValue(\""
									+ nodeData.getId() + "\", this.id,this.name, this.value);' type=\"text\"></td>");
					nodesOutput.append("</td>\n");
	
					nodesOutput.append("<td style=\"width:10%;padding:5px;\">");
					nodesOutput.append("Limite Di�rio (R$)");
					nodesOutput
							.append("<input id=\"" + nodeData.getId() + "_inputDaily\" value=\"" + formatCurrency(nodeData.getDailyLimit())
									+ "\" class=\"form-control\" onblur='format(this);' onchange='dtUpdateValue(\""
									+ nodeData.getId() + "\", this.id,this.name, this.value);' type=\"text\"></td>");
					nodesOutput.append("</td>\n");
						
    			} else {
    				
					nodesOutput.append("<td style=\"width:10%;padding:5px;\">");
					nodesOutput.append("Qtd. Ass.");
					nodesOutput.append("<input id=\"" + nodeData.getId() + "_inputQty\" value=\"" + nodeData.getQty()
							+ "\" class=\"form-control\" disabled onkeypress='return event.charCode >= 48 && event.charCode <= 57' onchange='dtUpdateValue(\""
							+ nodeData.getId() + "\", this.id,this.name, this.value);' type=\"text\">");
					nodesOutput.append("</td>\n");
	
					nodesOutput.append("<td style=\"width:10%;padding:5px;\">");
					nodesOutput.append("Valor Al�ada (R$)");
					nodesOutput.append(
							"<input id=\"" + nodeData.getId() + "_inputComp\" value=\"" + formatCurrency(nodeData.getCompetenceValue())
									+ "\" class=\"form-control\" disabled onblur='format(this);' onchange='dtUpdateValue(\""
									+ nodeData.getId() + "\", this.id,this.name, this.value);' type=\"text\"></td>");
					nodesOutput.append("</td>\n");
	
					nodesOutput.append("<td style=\"width:10%;padding:5px;\">");
					nodesOutput.append("Limite Di�rio (R$)");
					nodesOutput
							.append("<input id=\"" + nodeData.getId() + "_inputDaily\" value=\"" + formatCurrency(nodeData.getDailyLimit())
									+ "\" class=\"form-control\" disabled onblur='format(this);' onchange='dtUpdateValue(\""
									+ nodeData.getId() + "\", this.id,this.name, this.value);' type=\"text\"></td>");
					nodesOutput.append("</td>\n");
    				
    			}
            	
            nodesOutput.append("</tr>\n");
        	nodesOutput.append("</table><hr><p>");

        	writer.write(nodesOutput.toString());
        	
            for (Category category : categories) {

            	nodesOutput = new StringBuilder();

           		nodesOutput.append(category.getDescription()+"<br/><br/>");

            	nodesOutput.append("<table width=\"100%\">\n");
            	nodesOutput.append("<tr>");

            		nodesOutput.append("<td style=\"width:31%\">");
	            		nodesOutput.append("Transa��es");
	            	nodesOutput.append("</td>\n");
	            	
            		nodesOutput.append("<td style=\"width:3%\">");
	            		nodesOutput.append("Qtd. Ass.");
	            	nodesOutput.append("</td>\n");
	
	        		nodesOutput.append("<td style=\"width:4%\">");
		        		nodesOutput.append("Valor Al�ada (R$)");
		        	nodesOutput.append("</td>\n");
	
		    		nodesOutput.append("<td style=\"width:6%\">");
			    		nodesOutput.append("Limite Di�rio (R$)");
			    	nodesOutput.append("</td>\n");

	            nodesOutput.append("</tr>\n");
	            nodesOutput.append("</table>\n");
           		
            	nodesOutput.append("<table>\n");
	            
	            nodesOutput.append("<tr>");
	            	nodesOutput.append("<td colspan=\"4\">");
	            		category.getNodeData().setParent(this.nodeData);
	            		printNodes(category.getNodeData(), nodesOutput, 1);
	            	nodesOutput.append("</td>\n");
            	nodesOutput.append("</tr>\n");

            	nodesOutput.append("</table><p>");
            
            	writer.write(nodesOutput.toString());
            }
            
            nodesOutput = new StringBuilder();
            nodesOutput.append("</div>");
            writer.write(nodesOutput.toString());
        	
        }
    }
	
	private String printNodes(NodeData node, StringBuilder nodesOutput, int level){
		
		if (node.getParent() != null && level >= 2){
			nodesOutput.append("<div id=\"" + node.getId() + "_parent\" name="  + node.getParent().getId() + "_div class='dt-li-nivel" + level + "' style=\"visibility: hidden;\">");	
		} else if (level == 1){
			nodesOutput.append("<div id=\"" + node.getId() + "_parent\" class='dt-li-nivel" + level + "'>");
		}
		
		if (level >= 1){
			nodesOutput.append("<ul class=\"closed\">");	
		} else {
			nodesOutput.append("<ul>");
		}
		
		
		if (!node.getId().equals("0") && level > 1){

			nodesOutput.append("<li>");
			
			if (selectedNodes.containsKey(node.getId())) {
				
				NodeData nodeDataMapped = selectedNodes.get(node.getId());
				
				node.setQty(nodeDataMapped.getQty());
				node.setCompetenceValue(nodeDataMapped.getCompetenceValue());
				node.setDailyLimit(nodeDataMapped.getDailyLimit());
				node.setSelected(true);
				
				
				nodesOutput.append("<table>");
				nodesOutput.append("<tr>");
				
				if (!node.getNodes().isEmpty()){
					nodesOutput.append("<td style=\"padding:5px;\"><a id=\"" + node.getId() + "_link\" href=\"#\" onclick=dthideDivWithParent(\""+ node.getId() +"\",\"" + node.getParent().getId() + "\");><img id='" + node.getId() + "_img' src=\"../images/u34.png\"  style=\"margin-left:5px;\"/></a></td>");
				}

				if (node.getParent().isSelected()){
					nodesOutput.append("<td style=\"padding:5px;\" class=\"checkbox\"><input id=\"" + node.getId() + "\" type=\"checkbox\" name=\"" + node.getParent().getId() + "\" onchange='dtselect(this.id);' checked disabled><label class=\"checkbox-inline\" style=\"margin-left:-20px;\">&nbsp;&nbsp;&nbsp;" + node.getDescription() + "</label></td>");
					nodesOutput.append("<td style=\"width:5%;padding:5px;\"><input id=\"" + node.getId() + "_inputQty\" class=\"form-control\" style=\"width:70px;\" name=\"" + node.getParent().getId() + "\" value=\"" + node.getQty() + "\" disabled onblur='format(this);' onchange='dtUpdateValue(\""+ node.getId() +"\", this.id,this.name, this.value);' type=\"text\"></td>");
				} else {
					nodesOutput.append("<td  style=\"padding:5px;\" class=\"checkbox\"><input id=\"" + node.getId() + "\" type=\"checkbox\" name=\"" + node.getParent().getId() + "\" onchange='dtselect(this.id);' checked><label class=\"checkbox-inline\" style=\"margin-left:-20px;\">&nbsp;&nbsp;&nbsp;" + node.getDescription() + "</label></td>");
					nodesOutput.append("<td style=\"width:5%;padding:5px;\"><input id=\"" + node.getId() + "_inputQty\" class=\"form-control\" style=\"width:70px;\" name=\"" + node.getParent().getId() + "\" value=\"" + node.getQty() + "\" onblur='format(this);' onchange='dtUpdateValue(\""+ node.getId() +"\", this.id,this.name, this.value);' type=\"text\"></td>");
				}

					
				if(node.isShowCompetenceValue()){
					if (node.getParent().isSelected()){
						nodesOutput.append("<td style=\"width:10%;padding:5px;\"><input id=\"" + node.getId() + "_inputComp\" class=\"form-control\" name=\"" + node.getParent().getId() + "\" value=\"" + formatCurrency(node.getCompetenceValue()) + "\" disabled onblur='format(this);' onchange='dtUpdateValue(\""+ node.getId() +"\", this.id,this.name, this.value);' type=\"text\"></td>");	
					} else {
						nodesOutput.append("<td style=\"width:10%;padding:5px;\"><input id=\"" + node.getId() + "_inputComp\" class=\"form-control\" name=\"" + node.getParent().getId() + "\" value=\"" + formatCurrency(node.getCompetenceValue()) + "\" onblur='format(this);' onchange='dtUpdateValue(\""+ node.getId() +"\", this.id,this.name, this.value);' type=\"text\"></td>");	
					}
				} else {
					nodesOutput.append("<td style=\"width:10%;padding:5px;\"><label id=\"" + node.getId() + "_inputComp\">---</label></td>");
				}
				
				if (node.isShowDailyLimit()){
					if (node.getParent().isSelected()){
						nodesOutput.append("<td style=\"width:10%;padding:5px;\"><input id=\"" + node.getId() + "_inputDaily\" class=\"form-control\" name=\"" + node.getParent().getId() + "\" value=\"" + formatCurrency(node.getDailyLimit()) + "\" disabled onblur='format(this);' onchange='dtUpdateValue(\""+ node.getId() +"\", this.id,this.name, this.value);' type=\"text\"></td>");	
					} else {
						nodesOutput.append("<td style=\"width:10%;padding:5px;\"><input id=\"" + node.getId() + "_inputDaily\" class=\"form-control\" name=\"" + node.getParent().getId() + "\" value=\"" + formatCurrency(node.getDailyLimit()) + "\" onblur='format(this);' onchange='dtUpdateValue(\""+ node.getId() +"\", this.id,this.name, this.value);' type=\"text\"></td>");	
					}
				} else {
					nodesOutput.append("<td style=\"width:10%;padding:5px;\"><label id=\"" + node.getId() + "_inputDaily\">---</label></td>");
				}
				
				
				nodesOutput.append("</tr>");
				nodesOutput.append("</table>");
				
				nodesOutput.append("</li>");
			
			} else {
				
				nodesOutput.append("<table>");
				nodesOutput.append("<tr>");
				
				if (!node.getNodes().isEmpty()){
					nodesOutput.append("<td style=\"padding:5px;\"><a id=\"" + node.getId() + "_link\" href=\"#\" onclick=dthideDivWithParent(\""+ node.getId() +"\",\"" + node.getParent().getId() + "\");><img id='" + node.getId() + "_img' src=\"../images/u34.png\" class=\"expanded\"  style=\"margin-left:5px;\"/></a></td>");
				}

				nodesOutput.append("<td style=\"padding:5px;\" class=\"checkbox\"><input id=\"" + node.getId() + "\"  type=\"checkbox\" name=\"" + node.getParent().getId() + "\" onchange='dtselect(this.id);'><label class=\"checkbox-inline\" style=\"margin-left:-20px;\">&nbsp;&nbsp;&nbsp;" + node.getDescription() + "</label></td>");

				nodesOutput.append("<td style=\"width:5%;padding:5px;\"><input id=\"" + node.getId() + "_inputQty\" class=\"form-control\" style=\"width:70px;\" name=\"" + node.getParent().getId() + "\" value=\"" + node.getQty() + "\" onchange='dtUpdateValue(\""+ node.getId() +"\", this.id,this.name, this.value);' type=\"text\" disabled></td>");
				
				if(node.isShowCompetenceValue()){
					nodesOutput.append("<td style=\"width:10%;padding:5px;\"><input id=\"" + node.getId() + "_inputComp\" class=\"form-control\" name=\"" + node.getParent().getId() + "\" value=\"" + formatCurrency(node.getCompetenceValue()) + "\" onblur='format(this);' onchange='dtUpdateValue(\""+ node.getId() +"\", this.id,this.name, this.value);' type=\"text\" disabled></td>");	
				} else {
					nodesOutput.append("<td style=\"width:10%;padding:5px;\"><label id=\"" + node.getId() + "_inputComp\">---</label></td>");
				}
				
				if (node.isShowDailyLimit()){
					nodesOutput.append("<td style=\"width:10%;padding:5px;\"><input id=\"" + node.getId() + "_inputDaily\" class=\"form-control\" name=\"" + node.getParent().getId() + "\" value=\"" + formatCurrency(node.getDailyLimit()) + "\" onblur='format(this);' onchange='dtUpdateValue(\""+ node.getId() +"\", this.id,this.name, this.value);' type=\"text\" disabled></td>");	
				} else {
					nodesOutput.append("<td style=\"width:10%;padding:5px;\"><label id=\"" + node.getId() + "_inputDaily\">---</label></td>");
				}

				
				nodesOutput.append("</tr>");
				nodesOutput.append("</table>");
				
				nodesOutput.append("</li>");
				
			}
				
		} else {

			nodesOutput.append("<li>");
			
			if (selectedNodes.containsKey(node.getId())){
				
				NodeData nodeDataMapped = selectedNodes.get(node.getId());
				
				node.setQty(nodeDataMapped.getQty());
				node.setCompetenceValue(nodeDataMapped.getCompetenceValue());
				node.setDailyLimit(nodeDataMapped.getDailyLimit());
				node.setSelected(true);
				

				nodesOutput.append("<table width:100%;\">");
				nodesOutput.append("<tr>");
				
				if (!node.getNodes().isEmpty()){
					nodesOutput.append("<td style=\"width:4%;padding:5px;\"><a id=\"" + node.getId() + "_link\" href=\"#\" onclick=dthideDiv(\""+ node.getId() +"\");><img id='" + node.getId() + "_img' src=\"../images/u34.png\" style=\"margin-left:5px;\"/></a></td>");
				}

				if (node.isSelected()){
					nodesOutput.append("<td style=\"padding:5px;\" class=\"checkbox\"><input id=\"" + node.getId() + "\" type=\"checkbox\" checked name=\"" + node.getParent().getId() + "\" onchange='dtselect(this.id);'><label class=\"checkbox-inline\" style=\"margin-left:-20px;\">&nbsp;&nbsp;&nbsp;" + node.getDescription() + "</label></td>");	
				} else {
					nodesOutput.append("<td style=\"padding:5px;\" class=\"checkbox\"><input id=\"" + node.getId() + "\" type=\"checkbox\" name=\"" + node.getParent().getId() + "\" onchange='dtselect(this.id);'><label class=\"checkbox-inline\" style=\"margin-left:-20px;\">&nbsp;&nbsp;&nbsp;" + node.getDescription() + "</label></td>");
				}

				if (node.getParent().isSelected()){ // Se o pai estiver selecionado os campos ficam desabilitados
					nodesOutput.append("<td style=\"width:5%;padding:5px;\"><input id=\"" + node.getId() + "_inputQty\" class=\"form-control\" style=\"width:70px;\" name=\"" + node.getId() + "\" value=\"" + node.getQty() + "\" onkeypress='return event.charCode >= 48 && event.charCode <= 57' onchange='dtUpdateValue(\""+ node.getId() +"\", this.id, this.name, this.value);' type=\"text\" disabled></td>");
					nodesOutput.append("<td style=\"width:10%;padding:5px;\"><input id=\"" + node.getId() + "_inputComp\" class=\"form-control\" name=\"" + node.getId() + "\" value=\"" + formatCurrency(node.getCompetenceValue()) + "\" onblur='format(this);' onchange='dtUpdateValue(\""+ node.getId() +"\", this.id, this.name, this.value);' type=\"text\" disabled></td>");	
					nodesOutput.append("<td style=\"width:10%;padding:5px;\"><input id=\"" + node.getId() + "_inputDaily\" class=\"form-control\" name=\"" + node.getId() + "\" value=\"" + formatCurrency(node.getDailyLimit()) + "\" onblur='format(this);' onchange='dtUpdateValue(\""+ node.getId() +"\", this.id, this.name, this.value);' type=\"text\" disabled></td>");	
				} else if (node.isSelected()){ // Se o no estiver selecionado os campos ficam habilitados
					nodesOutput.append("<td style=\"width:5%;padding:5px;\"><input id=\"" + node.getId() + "_inputQty\" class=\"form-control\" style=\"width:70px;\" name=\"" + node.getId() + "\" value=\"" + node.getQty() + "\" onblur='format(this);' onchange='dtUpdateValue(\""+ node.getId() +"\", this.id, this.name, this.value);' type=\"text\"></td>");
					nodesOutput.append("<td style=\"width:10%;padding:5px;\"><input id=\"" + node.getId() + "_inputComp\" class=\"form-control\" name=\"" + node.getId() + "\" value=\"" + formatCurrency(node.getCompetenceValue()) + "\" onblur='format(this);' onchange='dtUpdateValue(\""+ node.getId() +"\", this.id, this.name, this.value);' type=\"text\"></td>");	
					nodesOutput.append("<td style=\"width:10%;padding:5px;\"><input id=\"" + node.getId() + "_inputDaily\" class=\"form-control\" name=\"" + node.getId() + "\" value=\"" + formatCurrency(node.getDailyLimit()) + "\" onblur='format(this);' onchange='dtUpdateValue(\""+ node.getId() +"\", this.id, this.name, this.value);' type=\"text\"></td>");	
				} else { // Se o pai e o no n�o estiver selecionado os campos ficam desabilitados
					nodesOutput.append("<td style=\"width:5%;padding:5px;\"><input id=\"" + node.getId() + "_inputQty\" class=\"form-control\" style=\"width:70px;\" name=\"" + node.getId() + "\" value=\"" + node.getQty() + "\" onblur='format(this);' onchange='dtUpdateValue(\""+ node.getId() +"\", this.id, this.name, this.value);' type=\"text\" disabled></td>");
					nodesOutput.append("<td style=\"width:10%;padding:5px;\"><input id=\"" + node.getId() + "_inputComp\" class=\"form-control\" name=\"" + node.getId() + "\" value=\"" + formatCurrency(node.getCompetenceValue()) + "\" onblur='format(this);' onchange='dtUpdateValue(\""+ node.getId() +"\", this.id, this.name, this.value);' type=\"text\" disabled></td>");	
					nodesOutput.append("<td style=\"width:10%;padding:5px;\"><input id=\"" + node.getId() + "_inputDaily\" class=\"form-control\" name=\"" + node.getId() + "\" value=\"" + formatCurrency(node.getDailyLimit()) + "\" onblur='format(this);' onchange='dtUpdateValue(\""+ node.getId() +"\", this.id, this.name, this.value);' type=\"text\" disabled></td>");	
				}
				
				
				nodesOutput.append("</tr>");
				nodesOutput.append("</table>");

				
			} else {

				nodesOutput.append("<table width:100%;\">");
				nodesOutput.append("<tr>");
				
				if (!node.getNodes().isEmpty()){
					nodesOutput.append("<td style=\"width:4%;padding:5px;\"><a id=\"" + node.getId() + "_link\" href=\"#\" onclick=dthideDiv(\""+ node.getId() +"\");><img id='" + node.getId() + "_img' src=\"../images/u34.png\"  style=\"margin-left:5px;\"/></a></td>");
				}
				
				if (node.isSelected()){
					nodesOutput.append("<td style=\"padding:5px;\" class=\"checkbox\"><input id=\"" + node.getId() + "\" type=\"checkbox\" checked name=\"" + node.getParent().getId() + "\" onchange='dtselect(this.id);'><label class=\"checkbox-inline\" style=\"margin-left:-20px;\">&nbsp;&nbsp;&nbsp;" + node.getDescription() + "</label></td>");	
				} else {
					nodesOutput.append("<td style=\"padding:5px;\" class=\"checkbox\"><input id=\"" + node.getId() + "\" type=\"checkbox\" name=\"" + node.getParent().getId() + "\" onchange='dtselect(this.id);'><label class=\"checkbox-inline\" style=\"margin-left:-20px;\">&nbsp;&nbsp;&nbsp;" + node.getDescription() + "</label></td>");
				}
				
				if (node.getParent().isSelected()){ // Se o pai estiver selecionado os campos ficam desabilitados
					nodesOutput.append("<td style=\"width:5%;padding:5px;\"><input id=\"" + node.getId() + "_inputQty\" class=\"form-control\" style=\"width:70px;\" name=\"" + node.getId() + "\" value=\"" + node.getQty() + "\" onkeypress='return event.charCode >= 48 && event.charCode <= 57' onchange='dtUpdateValue(\""+ node.getId() +"\", this.id, this.name, this.value);' type=\"text\" disabled></td>");
					nodesOutput.append("<td style=\"width:10%;padding:5px;\"><input id=\"" + node.getId() + "_inputComp\" class=\"form-control\" name=\"" + node.getId() + "\" value=\"" + formatCurrency(node.getCompetenceValue()) + "\" onblur='format(this);' onchange='dtUpdateValue(\""+ node.getId() +"\", this.id, this.name, this.value);' type=\"text\" disabled></td>");	
					nodesOutput.append("<td style=\"width:10%;padding:5px;\"><input id=\"" + node.getId() + "_inputDaily\" class=\"form-control\" name=\"" + node.getId() + "\" value=\"" + formatCurrency(node.getDailyLimit()) + "\" onblur='format(this);' onchange='dtUpdateValue(\""+ node.getId() +"\", this.id, this.name, this.value);' type=\"text\" disabled></td>");	
				} else if (node.isSelected()){ // Se o no estiver selecionado os campos ficam habilitados
					nodesOutput.append("<td style=\"width:5%;padding:5px;\"><input id=\"" + node.getId() + "_inputQty\" class=\"form-control\" style=\"width:70px;\" name=\"" + node.getId() + "\" value=\"" + node.getQty() + "\" onkeypress='return event.charCode >= 48 && event.charCode <= 57' onchange='dtUpdateValue(\""+ node.getId() +"\", this.id, this.name, this.value);' type=\"text\"></td>");
					nodesOutput.append("<td style=\"width:10%;padding:5px;\"><input id=\"" + node.getId() + "_inputComp\" class=\"form-control\" name=\"" + node.getId() + "\" value=\"" + formatCurrency(node.getCompetenceValue()) + "\" onblur='format(this);' onchange='dtUpdateValue(\""+ node.getId() +"\", this.id, this.name, this.value);' type=\"text\"></td>");	
					nodesOutput.append("<td style=\"width:10%;padding:5px;\"><input id=\"" + node.getId() + "_inputDaily\" class=\"form-control\" name=\"" + node.getId() + "\" value=\"" + formatCurrency(node.getDailyLimit()) + "\" onblur='format(this);' onchange='dtUpdateValue(\""+ node.getId() +"\", this.id, this.name, this.value);' type=\"text\"></td>");	
				} else { // Se o pai e o no n�o estiver selecionado os campos ficam desabilitados
					nodesOutput.append("<td style=\"width:5%;padding:5px;\"><input id=\"" + node.getId() + "_inputQty\" class=\"form-control\" style=\"width:70px;\" name=\"" + node.getId() + "\" value=\"" + node.getQty() + "\" onkeypress='return event.charCode >= 48 && event.charCode <= 57' onchange='dtUpdateValue(\""+ node.getId() +"\", this.id, this.name, this.value);' type=\"text\" disabled></td>");
					nodesOutput.append("<td style=\"width:10%;padding:5px;\"><input id=\"" + node.getId() + "_inputComp\" class=\"form-control\" name=\"" + node.getId() + "\" value=\"" + formatCurrency(node.getCompetenceValue()) + "\" onblur='format(this);' onchange='dtUpdateValue(\""+ node.getId() +"\", this.id, this.name, this.value);' type=\"text\" disabled></td>");	
					nodesOutput.append("<td style=\"width:10%;padding:5px;\"><input id=\"" + node.getId() + "_inputDaily\" class=\"form-control\" name=\"" + node.getId() + "\" value=\"" + formatCurrency(node.getDailyLimit()) + "\" onblur='format(this);' onchange='dtUpdateValue(\""+ node.getId() +"\", this.id, this.name, this.value);' type=\"text\" disabled></td>");	
				}
				
				
				nodesOutput.append("</tr>");
				nodesOutput.append("</table>");

			}
		}
		
		if (!node.getNodes().isEmpty()){
			level += 1;
			for (NodeData nodeChild : node.getNodesData()) {
				printNodes(nodeChild, nodesOutput, level);				
			}
		} else {
			level -= 1;
		}

		nodesOutput.append("</ul>");
		nodesOutput.append("</div>");
		
		return nodesOutput.toString();
		
	}
	
	public static void setValue2ValueExpression(final Object value, final String expression) {
	    FacesContext facesContext = FacesContext.getCurrentInstance();
	    ELContext elContext = facesContext.getELContext();

	    ValueExpression targetExpression = 
	        facesContext.getApplication().getExpressionFactory().createValueExpression(elContext, expression, Object.class);
	    targetExpression.setValue(elContext, value);
	}

	
	
	
	public String getSelectedNode() {
		return selectedNode;
	}

	public void update() {

		this.selectedNode = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("formId:nodesSelected");
		
		String[] nodes = this.selectedNode.split(",");
		for (int idx = 1; idx < nodes.length; idx+=5) {
			
			if (idx == 1){

				NodeData nodeData = new NodeData(nodes[idx], "");
						 nodeData.setQty(Integer.valueOf(nodes[idx+1]));
						 nodeData.setCompetenceValue(new BigDecimal(nodes[idx+2]));
						 nodeData.setDailyLimit(new BigDecimal(nodes[idx+3]));
						 nodeData.setSelected(Boolean.valueOf(nodes[idx+4]));

						 this.nodeData.setQty(nodeData.getQty());
						 this.nodeData.setCompetenceValue(nodeData.getCompetenceValue());
						 this.nodeData.setDailyLimit(nodeData.getDailyLimit());
						 this.nodeData.setSelected(nodeData.isSelected());
				
			} else {

				NodeData nodeData = new NodeData(nodes[idx], "");
						 nodeData.setQty(Integer.valueOf(nodes[idx+1]));
						 nodeData.setCompetenceValue(new BigDecimal(nodes[idx+2]));
						 nodeData.setDailyLimit(new BigDecimal(nodes[idx+3]));
						 nodeData.setSelected(Boolean.valueOf(nodes[idx+4]));
						 
				this.selectedNodes.put(nodes[idx], nodeData);						 
			}
			
			
		}
	}
	
	public void reset(){
		this.selectedNodes.clear();
	}
	
	public String formatCurrency(BigDecimal number){
		double amount = number.doubleValue();    
		return String.format("%,.2f", amount);
	}
	
}
