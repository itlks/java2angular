package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;

public class ContaCorrenteListaMovimentosExtratoDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 337552795855511144L;

	private String fechaMovimiento;
	private String descripcion;
	private Integer numeroDocumento;
	private BigDecimal importe;
	private String signoLanzamiento;
	private String dadosCheque;
	private String documento;
	private String status;
	private BigDecimal saldoMovimiento;
    private String indChequeDigitalizado;
    
    @SuppressWarnings("unused")
	private String porPeriodo;
    
	/**
	 * @return the fechaMovimiento
	 */
	public String getFechaMovimiento() {
		return fechaMovimiento;
	}
	/**
	 * @param fechaMovimiento the fechaMovimiento to set
	 */
	public void setFechaMovimiento(String fechaMovimiento) {
		this.fechaMovimiento = fechaMovimiento;
	}
	/**
	 * @return the descripcion
	 */
	public String getDescripcion() {
		return descripcion;
	}
	/**
	 * @param descripcion the descripcion to set
	 */
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	/**
	 * @return the numeroDocumento
	 */
	public Integer getNumeroDocumento() {
		return numeroDocumento;
	}
	/**
	 * @param numeroDocumento the numeroDocumento to set
	 */
	public void setNumeroDocumento(Integer numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}
	/**
	 * @return the importe
	 */
	public BigDecimal getImporte() {
		return importe;
	}
	/**
	 * @param importe the importe to set
	 */
	public void setImporte(BigDecimal importe) {
		this.importe = importe;
	}
	/**
	 * @return the signoLanzamiento
	 */
	public String getSignoLanzamiento() {
		return signoLanzamiento;
	}
	/**
	 * @param signoLanzamiento the signoLanzamiento to set
	 */
	public void setSignoLanzamiento(String signoLanzamiento) {
		this.signoLanzamiento = signoLanzamiento;
	}
	/**
	 * @return the dadosCheque
	 */
	public String getDadosCheque() {
		return dadosCheque;
	}
	/**
	 * @param dadosCheque the dadosCheque to set
	 */
	public void setDadosCheque(String dadosCheque) {
		this.dadosCheque = dadosCheque;
	}
	/**
	 * @return the documento
	 */
	public String getDocumento() {
		return documento;
	}
	/**
	 * @param documento the documento to set
	 */
	public void setDocumento(String documento) {
		this.documento = documento;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the saldoMovimiento
	 */
	public BigDecimal getSaldoMovimiento() {
		return saldoMovimiento;
	}
	/**
	 * @param saldoMovimiento the saldoMovimiento to set
	 */
	public void setSaldoMovimiento(BigDecimal saldoMovimiento) {
		this.saldoMovimiento = saldoMovimiento;
	}
	/**
	 * @return the indChequeDigitalizado
	 */
	public String getIndChequeDigitalizado() {
		return indChequeDigitalizado;
	}
	/**
	 * @param indChequeDigitalizado the indChequeDigitalizado to set
	 */
	public void setIndChequeDigitalizado(String indChequeDigitalizado) {
		this.indChequeDigitalizado = indChequeDigitalizado;
	}
	
    
    
}
