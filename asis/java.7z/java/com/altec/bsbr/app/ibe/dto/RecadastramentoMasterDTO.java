package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class RecadastramentoMasterDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5222395913195874033L;
	private String cnpj;
	private String cpf;
	private String senhaNova;
	private String senhaConfirmacao;
	private String pergunta;
	private String resposta;
	private String txtResposta;
	private String nome;
	private String agencia;
	private String conta;
	private String msgErroJavaStript;
	private String codigoUsuario;
	private String hash;
	

	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getSenhaNova() {
		return senhaNova;
	}

	public void setSenhaNova(String senhaNova) {
		this.senhaNova = senhaNova;
	}

	public String getSenhaConfirmacao() {
		return senhaConfirmacao;
	}

	public void setSenhaConfirmacao(String senhaConfirmacao) {
		this.senhaConfirmacao = senhaConfirmacao;
	}

	public String getPergunta() {
		return pergunta;
	}

	public void setPergunta(String pergunta) {
		this.pergunta = pergunta;
	}

	public String getResposta() {
		return resposta;
	}

	public void setResposta(String resposta) {
		this.resposta = resposta;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getConta() {
		return conta;
	}

	public void setConta(String conta) {
		this.conta = conta;
	}

	public String getMsgErroJavaStript() {
		return msgErroJavaStript;
	}

	public void setMsgErroJavaStript(String msgErroJavaStript) {
		this.msgErroJavaStript = msgErroJavaStript;
	}

	public String getTxtResposta() {
		return txtResposta;
	}

	public void setTxtResposta(String txtResposta) {
		this.txtResposta = txtResposta;
	}

	public String getCodigoUsuario() {
		return codigoUsuario;
	}

	public void setCodigoUsuario(String codigoUsuario) {
		this.codigoUsuario = codigoUsuario;
	}

	public String getHash() {
		return hash;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}
	
}
