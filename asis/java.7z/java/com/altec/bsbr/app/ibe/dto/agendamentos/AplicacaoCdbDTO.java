package com.altec.bsbr.app.ibe.dto.agendamentos;

import java.io.Serializable;
import java.math.BigDecimal;

public class AplicacaoCdbDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8418206174460331127L;

	private String numeroContratoCDB;

	private BigDecimal valorTaxa;

	private Integer prazoMax;

	public String getNumeroContratoCDB() {
		return numeroContratoCDB;
	}

	public void setNumeroContratoCDB(String numeroContratoCDB) {
		this.numeroContratoCDB = numeroContratoCDB;
	}

	public BigDecimal getValorTaxa() {
		return valorTaxa;
	}

	public void setValorTaxa(BigDecimal valorTaxa) {
		this.valorTaxa = valorTaxa;
	}

	public Integer getPrazoMax() {
		return prazoMax;
	}

	public void setPrazoMax(Integer prazoMax) {
		this.prazoMax = prazoMax;
	}

}
