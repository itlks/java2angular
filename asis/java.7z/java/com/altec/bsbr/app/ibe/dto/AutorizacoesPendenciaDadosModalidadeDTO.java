package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class AutorizacoesPendenciaDadosModalidadeDTO implements Serializable{
		
	private static final long serialVersionUID = 2300455692057605743L;
	
	private String agrupamento;
	private List<AutorizacoesPendenciaDadosAnaliticaDTO> listaModalidade;
	private Integer quantidade;
	private BigDecimal valor;
	private boolean selecionado;
	private boolean flgAutorizarModalidade;
	
	public AutorizacoesPendenciaDadosModalidadeDTO(String agrupamento) {
		this.agrupamento = agrupamento;
		this.listaModalidade = new ArrayList<AutorizacoesPendenciaDadosAnaliticaDTO>();
	}
	public String getAgrupamento() {
		return agrupamento;
	}
	public void setAgrupamento(String agrupamento) {
		this.agrupamento = agrupamento;
	}
	public List<AutorizacoesPendenciaDadosAnaliticaDTO> getlistaModalidade() {
		return listaModalidade;
	}
	public void setlistaModalidade(List<AutorizacoesPendenciaDadosAnaliticaDTO> listaModalidade) {
		this.listaModalidade = listaModalidade;
	}
//	public int getQuantidade() {
//		quantidade = calculaQuantidadeTotal();
//		return quantidade;
//	}
//	private int calculaQuantidadeTotal() {
//		int resultado = 0;
//		for (int i = 0; i < listaModalidade.size(); i++) {
//			resultado++;
//		}
//		return resultado;
//	}
//	/**
//	 * @return the valor
//	 */
//	public String getValor() {
//		if (UtilFunction.isNotBlankOrNull(listaModalidade)) {
//			return UtilFunction.convertBigDecimalToStringFormatoBR(calculaValorTotal());		
//		}
//		return UtilFunction.convertBigDecimalToStringFormatoBR(valor);
//	}
//	private BigDecimal calculaValorTotal() {
//		BigDecimal retorno = BigDecimal.ZERO;
//		for (AutorizacoesPendenciaDadosAnaliticaDTO analitica : listaModalidade) {
//			BigDecimal valorConvertido = analitica.getValorUsuarioPendencia();
//			retorno = retorno.add(valorConvertido);
//		}
//		return retorno;
//	}
	public Integer getQuantidade() {
		return quantidade;
	}
	public void setQuantidade(Integer quantidade) {
		this.quantidade = quantidade;
	}
	public BigDecimal getValor() {
		return valor;
	}
	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}
	public boolean isSelecionado() {
		return selecionado;
	}
	public void setSelecionado(boolean selecionado) {
		this.selecionado = selecionado;
	}
	public void adicionaAnalitica(AutorizacoesPendenciaDadosAnaliticaDTO analitica) {
		if (!listaModalidade.contains(analitica)) {
			this.listaModalidade.add(analitica);
		}
	}
	public boolean isFlgAutorizarModalidade() {
		return flgAutorizarModalidade;
	}
	public void setFlgAutorizarModalidade(boolean flgAutorizarModalidade) {
		this.flgAutorizarModalidade = flgAutorizarModalidade;
	}
}
