package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.List;

import com.altec.bsbr.app.ibe.dto.superdoccontas.ErrosDTO;

public class ManutFavoritosTranferenciaDTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4322333728319137799L;
	
	private String saida;
	private ErrosDTO erros;
	private List<FavoritoTranferenciaDTO> rsFixedSai;
	private String strChave23;
	private String strChave23SemCript;
	public String getSaida() {
		return saida;
	}
	public void setSaida(String saida) {
		this.saida = saida;
	}
	public ErrosDTO getErros() {
		return erros;
	}
	public void setErros(ErrosDTO erros) {
		this.erros = erros;
	}
	public List<FavoritoTranferenciaDTO> getRsFixedSai() {
		return rsFixedSai;
	}
	public void setRsFixedSai(List<FavoritoTranferenciaDTO> rsFixedSai) {
		this.rsFixedSai = rsFixedSai;
	}
	public String getStrChave23() {
		return strChave23;
	}
	public void setStrChave23(String strChave23) {
		this.strChave23 = strChave23;
	}
	public String getStrChave23SemCript() {
		return strChave23SemCript;
	}
	public void setStrChave23SemCript(String strChave23SemCript) {
		this.strChave23SemCript = strChave23SemCript;
	}
	
	

}
