package com.altec.bsbr.app.ibe.enumeration;

public enum TipoPessoaEnum {
	
	PESSOAFISICA ("F"),
	PESSOAJURIDICA ("J");
	
	private String codPessoa;
	
	private TipoPessoaEnum (String codPessoa) {
		this.codPessoa = codPessoa;
	}
	
	public String getCodPessoa() {
		return this.codPessoa;
	}

}
