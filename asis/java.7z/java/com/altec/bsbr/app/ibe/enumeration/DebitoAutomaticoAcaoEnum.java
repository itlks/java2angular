package com.altec.bsbr.app.ibe.enumeration;

public enum DebitoAutomaticoAcaoEnum {
	
	DEBITO_INCLUIR("IC"),
	DEBITO_ALTERAR("AC"),
	DEBITO_EXCLUIR("EC"),
	DEBITO_CONSULTAR("CC"),
	AGENDADO_CONSULTA("CL"),
	AGENDADO_BLOQUEIO("BL"),
	AGENDADO_DESBLOQUEIO("DC");
	
	private String acao;
	
	private DebitoAutomaticoAcaoEnum(String acao){
		this.acao = acao;
	}

	public String getAcao() {
		return acao;
	}
	
	public static DebitoAutomaticoAcaoEnum findByAcao(String acao){
		DebitoAutomaticoAcaoEnum retorno = null;
				
		if(acao == null || "".equals(acao)) {
			retorno = null;
		}
		
		for(DebitoAutomaticoAcaoEnum opcao: DebitoAutomaticoAcaoEnum.values()){
			if(opcao.getAcao().equals(acao)){
				retorno = opcao;
				break;
			}
		}
		return retorno;
	}
	
}
