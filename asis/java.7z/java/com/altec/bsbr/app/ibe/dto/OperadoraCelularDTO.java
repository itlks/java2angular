package com.altec.bsbr.app.ibe.dto;

import java.util.ArrayList;
import java.util.List;

public class OperadoraCelularDTO {

	private BancoDTO contrato;
	private String nomeOperadora;
	private String verifNumeroCelular;
	private boolean isNoveDigitos;
	private String msgPromocional;
	private String codigoTransacao;
	private List<RecargaCelularDTO> listaRecargas = new ArrayList<RecargaCelularDTO>();

	public String getNomeOperadora() {
		return nomeOperadora;
	}

	public void setNomeOperadora(String nomeOperadora) {
		this.nomeOperadora = nomeOperadora;
	}

	public String getVerifNumeroCelular() {
		return verifNumeroCelular;
	}

	public void setVerifNumeroCelular(String verifNumeroCelular) {
		this.verifNumeroCelular = verifNumeroCelular;
	}

	public boolean isNoveDigitos() {
		return isNoveDigitos;
	}

	public void setNoveDigitos(boolean isNoveDigitos) {
		this.isNoveDigitos = isNoveDigitos;
	}

	public String getMsgPromocional() {
		return msgPromocional;
	}

	public void setMsgPromocional(String msgPromocional) {
		this.msgPromocional = msgPromocional;
	}

	public String getCodigoTransacao() {
		return codigoTransacao;
	}

	public void setCodigoTransacao(String codigoTransacao) {
		this.codigoTransacao = codigoTransacao;
	}

	public List<RecargaCelularDTO> getListaRecargas() {
		return listaRecargas;
	}

	public void setListaRecargas(List<RecargaCelularDTO> listaRecargas) {
		this.listaRecargas = listaRecargas;
	}

	public BancoDTO getContrato() {
		return contrato;
	}

	public void setContrato(BancoDTO contrato) {
		this.contrato = contrato;
	}

}
