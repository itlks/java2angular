package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;



public class DetalheAcessoDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private int retCode; 
	
	private List<DetalheAcessoListaDTO> listaResponse = new ArrayList<DetalheAcessoListaDTO>();
	
	public DetalheAcessoDTO() {
		
	}
	
	/**
	 * @return the retCode
	 */
	public int getRetCode() {
		return retCode;
	}

	/**
	 * @param retCode the retCode to set
	 */
	public void setRetCode(int retCode) {
		this.retCode = retCode;
	}

	/**
	 * @return the listaResponse
	 */
	public List<DetalheAcessoListaDTO> getListaResponse() {
		return listaResponse;
	}

	/**
	 * @param listaResponse the listaResponse to set
	 */
	public void setListaResponse(List<DetalheAcessoListaDTO> listaResponse) {
		this.listaResponse = listaResponse;
	}

	
		

}
