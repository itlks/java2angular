package com.altec.bsbr.app.ibe.rest.portfolio.dto;

import java.io.Serializable;

public class SavingPortifolio implements Serializable{
	
	private static final long serialVersionUID = 1L;

	private String header;
	private String productCode;
	private String byproductCode;
	private String byproductDescription;
	private String degreeCode;
	private String degreeDescription;
	private String degreeColor;
	private String categoryCode;
	private String categoryDescription;
	private String caterogryColor;
	private Double liquidValue;
	private Double bruteValue;
	private String participationPercentual;
	private Double liquidValueTotal;
	private Double bruteValueTotal;
	private String participationPercentualTotal;
	public String getHeader() {
		return header;
	}
	public void setHeader(String header) {
		this.header = header;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getByproductCode() {
		return byproductCode;
	}
	public void setByproductCode(String byproductCode) {
		this.byproductCode = byproductCode;
	}
	public String getByproductDescription() {
		return byproductDescription;
	}
	public void setByproductDescription(String byproductDescription) {
		this.byproductDescription = byproductDescription;
	}
	public String getDegreeCode() {
		return degreeCode;
	}
	public void setDegreeCode(String degreeCode) {
		this.degreeCode = degreeCode;
	}
	public String getDegreeDescription() {
		return degreeDescription;
	}
	public void setDegreeDescription(String degreeDescription) {
		this.degreeDescription = degreeDescription;
	}
	public String getDegreeColor() {
		return degreeColor;
	}
	public void setDegreeColor(String degreeColor) {
		this.degreeColor = degreeColor;
	}
	public String getCategoryCode() {
		return categoryCode;
	}
	public void setCategoryCode(String categoryCode) {
		this.categoryCode = categoryCode;
	}
	public String getCategoryDescription() {
		return categoryDescription;
	}
	public void setCategoryDescription(String categoryDescription) {
		this.categoryDescription = categoryDescription;
	}
	public String getCaterogryColor() {
		return caterogryColor;
	}
	public void setCaterogryColor(String caterogryColor) {
		this.caterogryColor = caterogryColor;
	}
	public Double getLiquidValue() {
		return liquidValue;
	}
	public void setLiquidValue(Double liquidValue) {
		this.liquidValue = liquidValue;
	}
	public Double getBruteValue() {
		return bruteValue;
	}
	public void setBruteValue(Double bruteValue) {
		this.bruteValue = bruteValue;
	}
	public String getParticipationPercentual() {
		return participationPercentual;
	}
	public void setParticipationPercentual(String participationPercentual) {
		this.participationPercentual = participationPercentual;
	}
	public Double getLiquidValueTotal() {
		return liquidValueTotal;
	}
	public void setLiquidValueTotal(Double liquidValueTotal) {
		this.liquidValueTotal = liquidValueTotal;
	}
	public Double getBruteValueTotal() {
		return bruteValueTotal;
	}
	public void setBruteValueTotal(Double bruteValueTotal) {
		this.bruteValueTotal = bruteValueTotal;
	}
	public String getParticipationPercentualTotal() {
		return participationPercentualTotal;
	}
	public void setParticipationPercentualTotal(String participationPercentualTotal) {
		this.participationPercentualTotal = participationPercentualTotal;
	}
	
	
	

}
