package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.altec.bsbr.app.ibe.dto.consultaVeiculos.ConsultaSubServicosResponseDTO;

public class TaxasDetranSpSubServicosDTO implements Serializable {

	private static final long serialVersionUID = 6458058102627499205L;
	
	private Integer codigoSubservico;
	private String descricaoSubservico;
	private String identConsultiva;
	private Integer tipoIdentificador;
	private String descricaoIdentificador;
	private Integer tamanhoIdentificador;
	
	private List<ConsultaSubServicosResponseDTO> listaSubServicos = new ArrayList<ConsultaSubServicosResponseDTO>();
	
	public Integer getCodigoSubservico() {
		return codigoSubservico;
	}

	public void setCodigoSubservico(Integer codigoSubservico) {
		this.codigoSubservico = codigoSubservico;
	}

	public String getDescricaoSubservico() {
		return descricaoSubservico;
	}
	
	public void setDescricaoSubservico(String descricaoSubservico) {
		this.descricaoSubservico = descricaoSubservico;
	}

	public String getIdentConsultiva() {
		return identConsultiva;
	}

	public void setIdentConsultiva(String identConsultiva) {
		this.identConsultiva = identConsultiva;
	}

	public Integer getTipoIdentificador() {
		return tipoIdentificador;
	}

	public void setTipoIdentificador(Integer tipoIdentificador) {
		this.tipoIdentificador = tipoIdentificador;
	}

	public String getDescricaoIdentificador() {
		return descricaoIdentificador;
	}

	public void setDescricaoIdentificador(String descricaoIdentificador) {
		this.descricaoIdentificador = descricaoIdentificador;
	}

	public Integer getTamanhoIdentificador() {
		return tamanhoIdentificador;
	}

	public void setTamanhoIdentificador(Integer tamanhoIdentificador) {
		this.tamanhoIdentificador = tamanhoIdentificador;
	}

	public List<ConsultaSubServicosResponseDTO> getListaSubServicos() {
		return listaSubServicos;
	}

	public void setListaSubServicos(List<ConsultaSubServicosResponseDTO> listaSubservicos) {
		this.listaSubServicos = listaSubservicos;
	}

}
