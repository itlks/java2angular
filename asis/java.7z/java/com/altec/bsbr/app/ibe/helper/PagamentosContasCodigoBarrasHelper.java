package com.altec.bsbr.app.ibe.helper;

import static org.apache.commons.lang3.StringUtils.leftPad;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;

import com.altec.bsbr.app.ibe.dto.CartaoDTO;
import com.altec.bsbr.app.ibe.dto.pagamentocodigobarra.ValidaCodigoBarrasResponseDTO;
import com.altec.bsbr.app.ibe.dto.titulos.ConsultaDadosTitulosYKEntradaDTO;
import com.altec.bsbr.app.ibe.dto.titulos.ConsultaDadosTitulosYKSaidaDTO;
import com.altec.bsbr.app.ibe.dto.titulos.EfetivaPgtoTitulosYKOEEntradaDTO;
import com.altec.bsbr.app.ibe.dto.titulos.EfetivaPgtoTitulosYKOESaidaDTO;
import com.altec.bsbr.app.ibe.dto.titulosoutrosbancos.ObterTentativasConsultaCIPEntradaDTO;
import com.altec.bsbr.app.ibe.dto.titulosoutrosbancos.ObterTentativasConsultaCIPSaidaDTO;
import com.altec.bsbr.app.ibe.dto.titulosoutrosbancos.PgtoTitulosVTIBEntradaDTO;
import com.altec.bsbr.app.ibe.dto.titulosoutrosbancos.PgtoTitulosVTIBSaidaDTO;
import com.altec.bsbr.app.ibe.util.FormatoData;
import com.altec.bsbr.app.ibe.util.UtilFunction;
import com.altec.bsbr.app.ibe.util.WSFormat;
import com.altec.bsbr.app.ibe.util.WSFormat.Position;
import com.altec.bsbr.app.ibe.web.jsf.attributes.AtributosDaSessao;

/**
 *
 * @author x187169 - Julio R.G. Leme
 * @since 2017-05-18
 * @version 1.1
 *          <p>
 * 			Classe para auxilio na construcao de requests e responses da
 *          funcionalidade da Nova Cobran�a de T�tulos
 *          </p>
 *
 */
public class PagamentosContasCodigoBarrasHelper {

	private static final String PGTO_CC = "CB";
	private static final String PGTO_CARTAO = "C1";

	public PagamentosContasCodigoBarrasHelper() {
	}


	public static ObterTentativasConsultaCIPEntradaDTO montaRequestTentativasCIP(AtributosDaSessao atributosDaSessao,
																				 String codBarra, String dataAgendamento) {
		ObterTentativasConsultaCIPEntradaDTO request = new ObterTentativasConsultaCIPEntradaDTO();
		request.setStrBanco(WSFormat.getFormatString(atributosDaSessao.getBanco(), 4, "0", Position.RIGHT));
		request.setStrAgencia(WSFormat.getFormatString(atributosDaSessao.getAgencia(), 4, "0", Position.RIGHT));
		request.setStrConta(WSFormat.getFormatString(atributosDaSessao.getConta(), 10, "0", Position.RIGHT));
		request.setStrTipoPessoa(atributosDaSessao.getTipoPessoa());
		request.setStrIDUsuario(atributosDaSessao.getIdUsuarioLogin());

		request.setStrlngIDConexao("1");
		request.setStrIDCanal(String.valueOf(atributosDaSessao.getCanal()));
		request.setStrIDCanalLimite(atributosDaSessao.getCanalLimite());
		request.setStrIPAddrCliente(atributosDaSessao.getClientIP());
		request.setStrIPAddrServer(atributosDaSessao.getServerIP());
		request.setStrCodigoBarras(codBarra);
		request.setStrDataAgendamento(dataAgendamento);
		request.setStrIndNovaCobranca("");
		request.setStrIndConvivencia("");
		return request;
	}

	public static PgtoTitulosVTIBEntradaDTO montaRequestPagamentoTitulosVTIB(
			String opcao,
			AtributosDaSessao atributosDaSessao,
			PgtoTitulosVTIBSaidaDTO pgtoVTIBSaida,
			String codBarra,
			CartaoDTO cartaoDto,
			String formaPgto,
			Date dataAgendamento,
			Date dataVencimento,
			BigDecimal valorTotalPagoNoBoleto,
			boolean flagVr,
			String tipoPessoaCliente,
			String documentoCliente,
			String nomeCliente,
			String tipoPessoaPagadorOriginal,
			String documentoPagadorOriginal,
			String nomePagadorOriginal) {

		PgtoTitulosVTIBEntradaDTO request = new PgtoTitulosVTIBEntradaDTO();
		request.setStrBanco(atributosDaSessao.getBanco());
		request.setStrAgencia(atributosDaSessao.getAgencia());
		request.setStrConta(atributosDaSessao.getConta());
		request.setStrTipoPessoa(atributosDaSessao.getTipoPessoa());
		request.setStrlngIDConexao("1");
		request.setStrIDUsuario(atributosDaSessao.getCodigoUsuario());
		request.setStrIDCanal(String.valueOf(atributosDaSessao.getCanal()));
		request.setStrIDCanalLimite(String.valueOf(atributosDaSessao.getCanalLimite()));
		request.setStrIDContrato(atributosDaSessao.getContrato());
		request.setStrIPAddrCliente(atributosDaSessao.getClientIP());
		request.setStrIPAddrServer(atributosDaSessao.getServerIP());
		request.setStrCodBarras(codBarra);
		request.setStrCNPJSacado(atributosDaSessao.getCnpj());
		request.setStrOpcao(opcao);
		request.setStrChave23(pgtoVTIBSaida.getStrChave23());
		request.setStrChave23SemCript(pgtoVTIBSaida.getStrChave23SemCript());
		request.setStrGerouPendencia(pgtoVTIBSaida.getStrGerouPendencia());
		request.setStrInstFinac(pgtoVTIBSaida.getOEZWNMBANCOIFS2());
		if (!"000".equals(pgtoVTIBSaida.getOEZWCDBANCDESTS1()) && !"988".equals(pgtoVTIBSaida.getOEZWCDBANCDESTS1())) {
			request.setStrCodigoISPB(pgtoVTIBSaida.getOEZWCDBANCDESTS1());
		} else {
			request.setStrCodigoISPB(pgtoVTIBSaida.getOEZWCDISPBS2());
		}

		request.setOEZWCHAVEAMARRACAO(pgtoVTIBSaida.getOEZWCHAVEAMARRACAO());
		request.setOEZWPENUMPER(atributosDaSessao.getPernumper());
		request.setOEZWINDCLIENTE(atributosDaSessao.getTipoPessoa());
		request.setOEZWINDFORMPGTO(formaPgto);

		if (PGTO_CARTAO.equals(formaPgto)) {
			request.setOEZWPAN(cartaoDto.getNumero());
			request.setOEZWCARTAOBANCO(cartaoDto.getBanco());
			request.setOEZWCARTAOAGENCIA(cartaoDto.getAgencia());
			request.setOEZWCARTAOCONTRATO(cartaoDto.getContrato().toString());
			request.setStrtxtBandeira(cartaoDto.getCodBandeira());
			request.setStrtxtTipo(cartaoDto.getCodTipo());
		}

		request.setOEZWTARIFAVALOR(pgtoVTIBSaida.getOEZWTARIFAVALOR());
		request.setOEZWTARIFAPERC(pgtoVTIBSaida.getOEZWTARIFAPERC());
		request.setOEZWTARIFAMINIMA(pgtoVTIBSaida.getOEZWTARIFAMINIMA());
		request.setOEZWTARIFAMAXIMA(pgtoVTIBSaida.getOEZWTARIFAMAXIMA());

		request.setOEZWLINDIGITAVELSR(codBarra);
		request.setOEZWCDBANCDEST(pgtoVTIBSaida.getOEZWCDBANCDEST());
		request.setOEZWCDMOED(pgtoVTIBSaida.getOEZWCDMOED());
		request.setOEZWNRCODIBARR1(pgtoVTIBSaida.getOEZWNRCODIBARR1());
		request.setOEZWNRDIGICODIBAR1(pgtoVTIBSaida.getOEZWNRDIGICODIBAR1());
		request.setOEZWNRCODIBARR2(pgtoVTIBSaida.getOEZWNRCODIBARR2());
		request.setOEZWNRDIGICODIBAR2(pgtoVTIBSaida.getOEZWNRDIGICODIBAR2());
		request.setOEZWNRCODIBARR3(pgtoVTIBSaida.getOEZWNRCODIBARR3());
		request.setOEZWNRDIGICODIBAR3(pgtoVTIBSaida.getOEZWNRDIGICODIBAR3());
		request.setOEZWNRDIGICODIBARR(pgtoVTIBSaida.getOEZWNRDIGICODIBARR());
		request.setOEZWNRBLOCOFIM(pgtoVTIBSaida.getOEZWNRBLOCOFIM());

		// VERIFICAR O QUE O USUARIO DIGITOU STRING 17
		//define o valor que esta sendo pago do boleto
		request.setOEZWVLRECB(leftPad(UtilFunction
				.removeCaracteresEspeciais(UtilFunction.converterBigDecimalToString(valorTotalPagoNoBoleto)), 12, "0"));
		
		if (dataVencimento != null) {
			request.setOEZWDTVENCTITU(UtilFunction.dateToStringPattern(dataVencimento, FormatoData.YYYYMMDD));
		} else {
			request.setOEZWDTVENCTITU(StringUtils.leftPad("0", 8));
		}
		
		// VERIFICAR O QUE O USUARIO DIGITOU
		if (dataAgendamento != null) {
			request.setOEZWDATAAGENDAMENTO(UtilFunction.dateToStringPattern(dataAgendamento, FormatoData.YYYYMMDD));
		} else {
			request.setOEZWDATAAGENDAMENTO("");
		}

		request.setOEZWCDCPTU("T");
		request.setOEZWDTPGTOTITU(pgtoVTIBSaida.getOEZWDTPGTOTITUS1());
		request.setOEZWIDDDA(pgtoVTIBSaida.getOEZWIDDDAS1());
		if (flagVr) {
			request.setOEZWTPPESSCEDE(tipoPessoaCliente);
			request.setOEZWNRDCMCEDE(documentoCliente);
			request.setOEZWNMCEDE(nomeCliente);
			request.setOEZWNMSACD(nomePagadorOriginal);
			request.setOEZWTPPESSSACD(tipoPessoaPagadorOriginal);
			request.setOEZWNRDCMSACD(documentoPagadorOriginal);
		} else {
			if ("S".equals(pgtoVTIBSaida.getOEZWTITDDAS1())) {
				request.setOEZWTPPESSCEDE(pgtoVTIBSaida.getOEZWTPPESSCEDEDDAS2());
				request.setOEZWNRDCMCEDE(pgtoVTIBSaida.getOEZWNRDCMCEDEDDAS2());
				request.setOEZWNMCEDE(pgtoVTIBSaida.getOEZWNMRAZAOCEDDDAS2());
				request.setOEZWNMSACD(pgtoVTIBSaida.getOEZWNMRAZAOSACDDAS2());
				request.setOEZWTPPESSSACD(pgtoVTIBSaida.getOEZWTPPESSSACDDDAS2());
				request.setOEZWNRDCMSACD(pgtoVTIBSaida.getOEZWNRDCMSACDDDAS2());
			} else {
				request.setOEZWTPPESSCEDE(pgtoVTIBSaida.getOEZWTPPESSCEDES1());
				request.setOEZWNRDCMCEDE(pgtoVTIBSaida.getOEZWNRDCMCEDES1());
				request.setOEZWNMCEDE(pgtoVTIBSaida.getOEZWNMCEDES1());
				request.setOEZWNMSACD(pgtoVTIBSaida.getOEZWNMSACDS1());
				request.setOEZWTPPESSSACD(pgtoVTIBSaida.getOEZWTPPESSSACDS1());
				request.setOEZWNRDCMSACD(pgtoVTIBSaida.getOEZWNRDCMSACDS1());
			}
		}
		request.setOEZWTPTITU(pgtoVTIBSaida.getOEZWTPTITS2());
		request.setOEZWINDPGTCHQ("N");
		request.setOEZWCHAVETY(pgtoVTIBSaida.getOEZWCHAVETY());
		request.setOEZWTITNOVACOBRANCA(pgtoVTIBSaida.getOEZWTITNOVACOBRANCA());
		request.setOEZWTITDDA(pgtoVTIBSaida.getOEZWTITDDA());
		request.setOEZWTITCONVIVENCIA(pgtoVTIBSaida.getOEZWTITCONVIVENCIA());

		request.setOEZWVLNOMINALTITUS2(pgtoVTIBSaida.getOEZWVLNOMINALTITUS2());
		request.setOEZWTPPESSPAGFS2(pgtoVTIBSaida.getOEZWTPPESSPAGFS2());
		request.setOEZWNRCPFCNPJPAGFS2(pgtoVTIBSaida.getOEZWNRCPFCNPJPAGFS2());
		request.setOEZWNMRAZAOPAGFS2(pgtoVTIBSaida.getOEZWNMRAZAOPAGFS2());

		if ("S".equals(pgtoVTIBSaida.getOEZWTITNOVACOBRANCAS1())) {
			request.setOEZWVLENCARS2(pgtoVTIBSaida.getOEZWVLENCARS2());
			request.setOEZWVLDESS2(pgtoVTIBSaida.getOEZWVLDESS2());
		} else {
			request.setOEZWVLENCARS2(leftPad(String.valueOf(Integer.valueOf(pgtoVTIBSaida.getOEZWVLMULS2()) + Integer.valueOf(pgtoVTIBSaida.getOEZWVLJURS2())), 17, "0"));
			request.setOEZWVLDESS2(leftPad(String.valueOf(Integer.valueOf(pgtoVTIBSaida.getOEZWVLDESS2()) + Integer.valueOf(pgtoVTIBSaida.getOEZWVLABATS2())), 17, "0"));
		}
		
		return request;
	}

	public static PgtoTitulosVTIBEntradaDTO montaRequestPagamentoTitulosVTIB(String opcao,
																			 AtributosDaSessao atributosDaSessao, ObterTentativasConsultaCIPEntradaDTO cipEntrada,
																			 ObterTentativasConsultaCIPSaidaDTO cipSaida, String codBarra, CartaoDTO cartaoDTO, String formaPgto) {
		PgtoTitulosVTIBEntradaDTO request = new PgtoTitulosVTIBEntradaDTO();
		request.setStrBanco(atributosDaSessao.getBanco());
		request.setStrAgencia(atributosDaSessao.getAgencia());
		request.setStrConta(atributosDaSessao.getConta());
		request.setStrTipoPessoa(atributosDaSessao.getTipoPessoa());
		request.setStrlngIDConexao("1");
		request.setStrIDUsuario(atributosDaSessao.getCodigoUsuario());
		request.setStrIDCanal(String.valueOf(atributosDaSessao.getCanal()));
		request.setStrIDCanalLimite(String.valueOf(atributosDaSessao.getCanalLimite()));
		request.setStrIDContrato(atributosDaSessao.getContrato());
		request.setStrIPAddrCliente(atributosDaSessao.getClientIP());
		request.setStrIPAddrServer(atributosDaSessao.getServerIP());
		request.setStrCodBarras(codBarra);
		request.setStrCNPJSacado(atributosDaSessao.getCnpj());
		request.setStrOpcao(opcao);
		request.setStrChave23("");
		request.setStrChave23SemCript("");
		request.setStrGerouPendencia("");

		// quebra do codigo de barras
		String p1 = codBarra.substring(0, 3);
		String p2 = codBarra.substring(3, 4);
		String p3 = codBarra.substring(4, 9);
		String p4 = codBarra.substring(9, 10);
		String p5 = codBarra.substring(10, 20);
		String p6 = codBarra.substring(20, 21);
		String p7 = codBarra.substring(21, 31);
		String p8 = codBarra.substring(31, 32);
		String p9 = codBarra.substring(32, 33);
		String p10 = codBarra.substring(33, 47);
		request.setOEZWCDBANCDEST(p1);
		request.setOEZWCDMOED(p2);
		request.setOEZWNRCODIBARR1(p3);
		request.setOEZWNRDIGICODIBAR1(p4);
		request.setOEZWNRCODIBARR2(p5);
		request.setOEZWNRDIGICODIBAR2(p6);
		request.setOEZWNRCODIBARR3(p7);
		request.setOEZWNRDIGICODIBAR3(p8);
		request.setOEZWNRDIGICODIBARR(p9);
		request.setOEZWNRBLOCOFIM(p10);

		// dados ASP - AS-IS
		request.setOEZWCHAVEAMARRACAO(leftPad("", 23, " "));
		request.setOEZWINDCLIENTE(atributosDaSessao.getTipoPessoa());
		request.setOEZWINDFORMPGTO(formaPgto);
		request.setOEZWDATAAGENDAMENTO(leftPad("", 8, " "));
		StringBuilder sb = new StringBuilder();
		sb.append("0").append(codBarra);
		request.setOEZWLINDIGITAVELSR(sb.toString());
		request.setOEZWVLRECB(leftPad("", 12, "0"));
		request.setOEZWDTVENCTITU(leftPad("", 8, "0"));
		request.setOEZWTPTITU("T");
		request.setOEZWCHAVETY(cipSaida.getStrChaveRequisicao());
		request.setOEZWTITNOVACOBRANCA(cipSaida.getStrIndNovaCobranca());
		request.setOEZWTITDDA(cipSaida.getStrIndDDA());
		request.setOEZWTITCONVIVENCIA(cipSaida.getStrIndConvivencia());
		
		if (PGTO_CARTAO.equals(formaPgto)) {
			request.setOEZWPAN(cartaoDTO.getNumero());
			request.setOEZWCARTAOBANCO(cartaoDTO.getBanco());
			request.setOEZWCARTAOAGENCIA(cartaoDTO.getAgencia());
			request.setOEZWCARTAOCONTRATO(cartaoDTO.getContrato().toString());
			request.setStrtxtBandeira(cartaoDTO.getCodBandeira());
			request.setStrtxtTipo(cartaoDTO.getCodTipo());
		}

		return request;
	}

	public static ConsultaDadosTitulosYKEntradaDTO montarRequestConsultivaNovaCobranca(AtributosDaSessao atributosDaSessao,
																					   ValidaCodigoBarrasResponseDTO validaCodigoBarrasResponseDTO, CartaoDTO cartaoDto, Date dataAgendamento) {

		String codBarra = validaCodigoBarrasResponseDTO.getMethodResult().getCodBarras();
		String hashConexao = Integer.toString(Math.abs(atributosDaSessao.getIdConexao().hashCode()));
		ConsultaDadosTitulosYKEntradaDTO requestConsultivaNovaCobrancaYK = new ConsultaDadosTitulosYKEntradaDTO();
		requestConsultivaNovaCobrancaYK.setStrIDCanal(atributosDaSessao.getCanalLimite());
		requestConsultivaNovaCobrancaYK
				.setStrBanco(WSFormat.getFormatString(atributosDaSessao.getBanco(), 4, "0", Position.RIGHT));
		requestConsultivaNovaCobrancaYK
				.setStrAgencia(WSFormat.getFormatString(atributosDaSessao.getAgencia(), 4, "0", Position.RIGHT));
		requestConsultivaNovaCobrancaYK
				.setStrConta(WSFormat.getFormatString(atributosDaSessao.getConta(), 10, "0", Position.RIGHT));
		requestConsultivaNovaCobrancaYK.setLngIDConexao(hashConexao);
		requestConsultivaNovaCobrancaYK.setStrIDUsuario(atributosDaSessao.getCodigoUsuario());
		requestConsultivaNovaCobrancaYK.setStrTipoPessoa(atributosDaSessao.getTipoPessoa());
		requestConsultivaNovaCobrancaYK.setStrIPAddrCliente(atributosDaSessao.getClientIP());
		requestConsultivaNovaCobrancaYK.setStrIPAddrServer(atributosDaSessao.getServerIP());

		requestConsultivaNovaCobrancaYK.setOEZUINDFORMPGTO(PGTO_CC);
		requestConsultivaNovaCobrancaYK.setStrCodBarras(codBarra);
		requestConsultivaNovaCobrancaYK.setStrChave23SemCript("");
		requestConsultivaNovaCobrancaYK.setStrChave23("");

		requestConsultivaNovaCobrancaYK.setOEZUINDCLIENTE("J");

//		if (PGTO_CARTAO.equals(fixedRSBarraDTO.getOESCINDFORMPGTO()) && cartaoDto != null) {
//			requestConsultivaNovaCobrancaYK.setOEZUPAN(cartaoDto.getNumeroFormatado());
//			requestConsultivaNovaCobrancaYK.setOEZUCARTAOBANCO(cartaoDto.getBanco());
//			requestConsultivaNovaCobrancaYK.setOEZUCARTAOAGENCIA(cartaoDto.getAgencia());
//			requestConsultivaNovaCobrancaYK.setOEZUCARTAOCONTRATO(cartaoDto.getContrato().toString());
//		}

		requestConsultivaNovaCobrancaYK.setOEZUVLRECB(leftPad("", 12, "0"));
		requestConsultivaNovaCobrancaYK.setOEZUDTVENCTITU(leftPad("", 8, "0"));
		if (dataAgendamento != null) {
			requestConsultivaNovaCobrancaYK.setOEZUDATAAGENDAMENTO(UtilFunction.dateToStringPattern(dataAgendamento, FormatoData.YYYYMMDD));
		} else {
			requestConsultivaNovaCobrancaYK.setOEZUDATAAGENDAMENTO("");
		}
		requestConsultivaNovaCobrancaYK.setStrOpcao("B");
		requestConsultivaNovaCobrancaYK.setOEZUCDCPTU("T");
		requestConsultivaNovaCobrancaYK.setOEZUCHAVEAMARRACAO(leftPad("", 23, " "));

		// ArrayOfStringDTO arrBoletoVR = new ArrayOfStringDTO();
		// List<String> boletoVR = new ArrayList<String>();
		// boletoVR.add(0,
		// (UtilFunction.isNotBlankOrNull(request.getTipoPessoaFavorecido()) ?
		// request.getTipoPessoaFavorecido(): ""));
		// boletoVR.add(1,
		// (UtilFunction.isNotBlankOrNull(request.getDocFavorecido()) ?
		// request.getDocFavorecido().replaceAll("[^0-9]", ""): ""));
		// boletoVR.add(2,
		// (UtilFunction.isNotBlankOrNull(request.getTipoPessoaCliente()) ?
		// request.getTipoPessoaCliente(): ""));
		// boletoVR.add(3,
		// (UtilFunction.isNotBlankOrNull(request.getDocCliente()) ?
		// request.getDocCliente().replaceAll("[^0-9]", ""): ""));
		// boletoVR.add(4, "");
		// boletoVR.add(5, "");
		// boletoVR.add(6, "");
		// arrBoletoVR.setBOLETOVR(boletoVR);
		// requestDTO.setArrBoletoVR(arrBoletoVR);
		// requestDTO.setStrNomeCedente(request.getNomeCedente());
		// requestDTO.setStrNomeSacado(request.getNomeSacado());

		String p1 = codBarra.substring(0, 3);
		String p2 = codBarra.substring(3, 4);
		String p3 = codBarra.substring(4, 9);
		String p4 = codBarra.substring(9, 10);
		String p5 = codBarra.substring(10, 20);
		String p6 = codBarra.substring(20, 21);
		String p7 = codBarra.substring(21, 31);
		String p8 = codBarra.substring(31, 32);
		String p9 = codBarra.substring(32, 33);
		String p10 = codBarra.substring(33, 47);
		requestConsultivaNovaCobrancaYK.setOEZUCDBANCDEST(p1);
		requestConsultivaNovaCobrancaYK.setOEZUCDMOED(p2);
		requestConsultivaNovaCobrancaYK.setOEZUNRCODIBARR1(p3);
		requestConsultivaNovaCobrancaYK.setOEZUNRDIGICODIBAR1(p4);
		requestConsultivaNovaCobrancaYK.setOEZUNRCODIBARR2(p5);
		requestConsultivaNovaCobrancaYK.setOEZUNRDIGICODIBAR2(p6);
		requestConsultivaNovaCobrancaYK.setOEZUNRCODIBARR3(p7);
		requestConsultivaNovaCobrancaYK.setOEZUNRDIGICODIBAR3(p8);
		requestConsultivaNovaCobrancaYK.setOEZUNRDIGICODIBARR(p9);
		requestConsultivaNovaCobrancaYK.setOEZUVLTITU(p10);

		return requestConsultivaNovaCobrancaYK;
	}

	public static EfetivaPgtoTitulosYKOEEntradaDTO montarRequestImperativaNovaCobranca(
			ValidaCodigoBarrasResponseDTO validaCodigoBarrasResponseDTO,
			ConsultaDadosTitulosYKSaidaDTO responseConsultivaNovaCobrancaYK,
			EfetivaPgtoTitulosYKOESaidaDTO responseImperativaNovaCobrancaYKOE,
			AtributosDaSessao atributosDaSessao,
			ConsultaDadosTitulosYKEntradaDTO requestConsultivaNovaCobrancaYK,
			BigDecimal valorTotalPagoNoBoleto,
			CartaoDTO cartaoDTO,
			String formaPgto,
			String opcao) {

		EfetivaPgtoTitulosYKOEEntradaDTO requestImperativaNovaCobrancaYKOE = new EfetivaPgtoTitulosYKOEEntradaDTO();
		requestImperativaNovaCobrancaYKOE
				.setStrCodBarras(validaCodigoBarrasResponseDTO.getMethodResult().getCodBarras());
		requestImperativaNovaCobrancaYKOE
				.setStrChave23SemCript(responseConsultivaNovaCobrancaYK.getStrChave23SemCript());
		requestImperativaNovaCobrancaYKOE
				.setOEZVCHAVEAMARRACAO(responseConsultivaNovaCobrancaYK.getStrChave23SemCript());
		requestImperativaNovaCobrancaYKOE.setStrIDUsuario(atributosDaSessao.getIdUsuarioLogin());

		requestImperativaNovaCobrancaYKOE.setStrChave23(responseConsultivaNovaCobrancaYK.getStrChave23());
		requestImperativaNovaCobrancaYKOE.setStrBanco(requestConsultivaNovaCobrancaYK.getStrBanco());
		requestImperativaNovaCobrancaYKOE.setStrAgencia(requestConsultivaNovaCobrancaYK.getStrAgencia());
		requestImperativaNovaCobrancaYKOE.setStrConta(requestConsultivaNovaCobrancaYK.getStrConta());
		requestImperativaNovaCobrancaYKOE.setStrIDCanal(requestConsultivaNovaCobrancaYK.getStrIDCanal());
		requestImperativaNovaCobrancaYKOE.setStrTipoPessoa(requestConsultivaNovaCobrancaYK.getStrTipoPessoa());
		requestImperativaNovaCobrancaYKOE.setStrlngIDConexao(requestConsultivaNovaCobrancaYK.getLngIDConexao());
		requestImperativaNovaCobrancaYKOE.setStrIDContrato(atributosDaSessao.getContrato());
		requestImperativaNovaCobrancaYKOE.setStrIPAddrCliente(atributosDaSessao.getClientIP());
		requestImperativaNovaCobrancaYKOE.setStrIPAddrServer(atributosDaSessao.getServerIP());
		requestImperativaNovaCobrancaYKOE.setStrOpcao(opcao);
		requestImperativaNovaCobrancaYKOE.setOEZVINDCLIENTE(requestConsultivaNovaCobrancaYK.getOEZUINDCLIENTE());

		requestImperativaNovaCobrancaYKOE.setOEZVCARTAOBANCO(requestConsultivaNovaCobrancaYK.getOEZUCARTAOBANCO());
		requestImperativaNovaCobrancaYKOE.setOEZVCARTAOAGENCIA(requestConsultivaNovaCobrancaYK.getOEZUCARTAOAGENCIA());
		requestImperativaNovaCobrancaYKOE
				.setOEZVCARTAOCONTRATO(requestConsultivaNovaCobrancaYK.getOEZUCARTAOCONTRATO());
		requestImperativaNovaCobrancaYKOE.setOEZVPENUMPER(atributosDaSessao.getPernumper());
		requestImperativaNovaCobrancaYKOE.setOEZVCDBANCDEST(responseConsultivaNovaCobrancaYK.getOEZUCDBANCDESTS());
		requestImperativaNovaCobrancaYKOE.setOEZVCDMOED(responseConsultivaNovaCobrancaYK.getOEZUCDMOEDS());
		requestImperativaNovaCobrancaYKOE.setOEZVNRCODIBARR1(responseConsultivaNovaCobrancaYK.getOEZUNRCODIBARR1S());
		requestImperativaNovaCobrancaYKOE
				.setOEZVNRDIGICODIBAR1(responseConsultivaNovaCobrancaYK.getOEZUNRDIGICODIBAR1S());
		requestImperativaNovaCobrancaYKOE.setOEZVNRCODIBARR2(responseConsultivaNovaCobrancaYK.getOEZUNRCODIBARR2S());
		requestImperativaNovaCobrancaYKOE
				.setOEZVNRDIGICODIBAR2(responseConsultivaNovaCobrancaYK.getOEZUNRDIGICODIBAR2S());
		requestImperativaNovaCobrancaYKOE.setOEZVNRCODIBARR3(responseConsultivaNovaCobrancaYK.getOEZUNRCODIBARR3S());
		requestImperativaNovaCobrancaYKOE
				.setOEZVNRDIGICODIBAR3(responseConsultivaNovaCobrancaYK.getOEZUNRDIGICODIBAR3S());
		requestImperativaNovaCobrancaYKOE
				.setOEZVNRDIGICODIBARR(responseConsultivaNovaCobrancaYK.getOEZUNRDIGICODIBARRS());
		requestImperativaNovaCobrancaYKOE.setOEZVVLTITU(responseConsultivaNovaCobrancaYK.getOEZUVLTITUS());
		requestImperativaNovaCobrancaYKOE
				.setOEZVLINHADIGITAVELSR(leftPad(requestImperativaNovaCobrancaYKOE.getStrCodBarras(), 48, "0"));
		requestImperativaNovaCobrancaYKOE.setOEZVCDCPTU("T");
		requestImperativaNovaCobrancaYKOE
				.setOEZVDATAAGENDAMENTO(requestConsultivaNovaCobrancaYK.getOEZUDATAAGENDAMENTO());
		if (requestImperativaNovaCobrancaYKOE.getOEZVDATAAGENDAMENTO().equals("00000000")) {
			requestImperativaNovaCobrancaYKOE.setOEZVDATAAGENDAMENTO(null);
		}
		
		//define o valor que esta sendo pago do boleto
		requestImperativaNovaCobrancaYKOE.setOEZVVLRECB(leftPad(UtilFunction
				.removeCaracteresEspeciais(UtilFunction.converterBigDecimalToString(valorTotalPagoNoBoleto)), 12, "0"));
		
		requestImperativaNovaCobrancaYKOE.setStrInstFinac(StringUtils.trim(responseConsultivaNovaCobrancaYK.getOEZUNMIFBENEFI()));
		requestImperativaNovaCobrancaYKOE.setStrCodigoISPB(responseConsultivaNovaCobrancaYK.getOEZUCDBANCDESTS());
		requestImperativaNovaCobrancaYKOE.setOEZVDTVENCTITU(responseConsultivaNovaCobrancaYK.getOEZUDTVENCTITUS());
		requestImperativaNovaCobrancaYKOE.setOEZVDTPGTOTITU(responseConsultivaNovaCobrancaYK.getOEZUDTPGTOTITUS());
		requestImperativaNovaCobrancaYKOE.setOEZVNOMCED(responseConsultivaNovaCobrancaYK.getOEZUNMCEDE());
		requestImperativaNovaCobrancaYKOE.setOEZVNOMSAC(responseConsultivaNovaCobrancaYK.getOEZUNMSACD());
		requestImperativaNovaCobrancaYKOE.setOEZVTPTIT(responseConsultivaNovaCobrancaYK.getOEZUTPTIT());
		requestImperativaNovaCobrancaYKOE.setOEZVCDCED(responseConsultivaNovaCobrancaYK.getOEZUCDCED());
		requestImperativaNovaCobrancaYKOE.setOEZVCDNOSNUM(responseConsultivaNovaCobrancaYK.getOEZUCDNOSNUM());
		requestImperativaNovaCobrancaYKOE.setOEZVVLDESC(responseConsultivaNovaCobrancaYK.getOEZUVLDESC());
		requestImperativaNovaCobrancaYKOE.setOEZVVLENCA(responseConsultivaNovaCobrancaYK.getOEZUVLENCA());
		requestImperativaNovaCobrancaYKOE.setOEZVVLIOF(responseConsultivaNovaCobrancaYK.getOEZUVLIOF());
		requestImperativaNovaCobrancaYKOE.setOEZVVLTOTAL(responseConsultivaNovaCobrancaYK.getOEZUVLTOTAL());
		requestImperativaNovaCobrancaYKOE.setOEZVVLTITUREG(responseConsultivaNovaCobrancaYK.getOEZUVLTITUREG());
		requestImperativaNovaCobrancaYKOE.setOEZVIDCARTORIO(responseConsultivaNovaCobrancaYK.getOEZUIDCARTORIO());
		requestImperativaNovaCobrancaYKOE.setOEZVTPDOCTCEDE(responseConsultivaNovaCobrancaYK.getOEZUTPDOCTCEDE());
		requestImperativaNovaCobrancaYKOE.setOEZVNRCPFCNPJCEDE(responseConsultivaNovaCobrancaYK.getOEZUNRCPFCNPJCEDE());
		requestImperativaNovaCobrancaYKOE.setOEZVTPPGTOTITU(responseConsultivaNovaCobrancaYK.getOEZUTPPGTOTITU());
		requestImperativaNovaCobrancaYKOE.setOEZVINVLABERTO(responseConsultivaNovaCobrancaYK.getOEZUFLABERFECH());
		requestImperativaNovaCobrancaYKOE.setOEZVVLMINIMO(responseConsultivaNovaCobrancaYK.getOEZUVLMINIPGTO());
		requestImperativaNovaCobrancaYKOE.setOEZVVLMAXIMO(responseConsultivaNovaCobrancaYK.getOEZUVLMAXIPGTO());
		requestImperativaNovaCobrancaYKOE.setOEZVTPDOCTPGADS2(responseConsultivaNovaCobrancaYK.getOEZUTPDOCTPGAD());
		requestImperativaNovaCobrancaYKOE
				.setOEZVNRCPFCNPJPGADS2(responseConsultivaNovaCobrancaYK.getOEZUNRCPFCNPJPGAD());
		requestImperativaNovaCobrancaYKOE.setOEZVNMPGADTITUS2(responseConsultivaNovaCobrancaYK.getOEZUNMPGADTITU());
		requestImperativaNovaCobrancaYKOE.setOEZVTPDOCTSACDS2(responseConsultivaNovaCobrancaYK.getOEZUTPDOCTSACD());
		requestImperativaNovaCobrancaYKOE
				.setOEZVNRCPFCNPJSACDS2(responseConsultivaNovaCobrancaYK.getOEZUNRCPFCNPJSACD());
		requestImperativaNovaCobrancaYKOE.setOEZVNMSACDS2(responseConsultivaNovaCobrancaYK.getOEZUNMSACD());
		requestImperativaNovaCobrancaYKOE.setOEZVINDFORMPGTO(formaPgto);
		
		if (responseImperativaNovaCobrancaYKOE != null) {
			requestImperativaNovaCobrancaYKOE.setOEZVTARIFAVALOR(responseImperativaNovaCobrancaYKOE.getOEZVTARIFAVALOR());
		}

		// Sacador Avalista
		requestImperativaNovaCobrancaYKOE.setOEZVTPDOCTAVALS2(responseConsultivaNovaCobrancaYK.getOEZUTPDOCTAVAL());
		requestImperativaNovaCobrancaYKOE.setOEZVNRCPFCNPJAVALS2(responseConsultivaNovaCobrancaYK.getOEZUNRCPFCNPJAVAL());
		requestImperativaNovaCobrancaYKOE.setOEZVNMAVALTITUS2(responseConsultivaNovaCobrancaYK.getOEZUNMAVALTITU());
		requestImperativaNovaCobrancaYKOE.setOEZVNMFANTAVALTITUS2(responseConsultivaNovaCobrancaYK.getOEZUNMFANTAVALTITU());
		
		
		if (PGTO_CARTAO.equals(formaPgto)) {
			requestImperativaNovaCobrancaYKOE.setOEZVPAN(cartaoDTO.getNumero());
			requestImperativaNovaCobrancaYKOE.setOEZVCARTAOBANCO(cartaoDTO.getBanco());
			requestImperativaNovaCobrancaYKOE.setOEZVCARTAOAGENCIA(cartaoDTO.getAgencia());
			requestImperativaNovaCobrancaYKOE.setOEZVCARTAOCONTRATO(cartaoDTO.getContrato().toString());
			requestImperativaNovaCobrancaYKOE.setStrtxtBandeira(cartaoDTO.getCodBandeira());
			requestImperativaNovaCobrancaYKOE.setStrtxtTipo(cartaoDTO.getCodTipo());
		}

		return requestImperativaNovaCobrancaYKOE;
	}

}