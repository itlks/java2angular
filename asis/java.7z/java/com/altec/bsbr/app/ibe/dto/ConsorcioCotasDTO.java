package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.List;
	
public class ConsorcioCotasDTO implements Serializable{
	
	private static final long serialVersionUID = -6392864469880204125L;
	
	private String cliente;
	private String bem;
	private String cnpj;
	private String cota;
	private String grupo;
	
	private List<ListaCotasDTO> listaCotas;

	/**
	 * @return the cliente
	 */
	public String getCliente() {
		return cliente;
	}

	/**
	 * @param cliente the cliente to set
	 */
	public void setCliente(String cliente) {
		this.cliente = cliente;
	}

	/**
	 * @return the bem
	 */
	public String getBem() {
		return bem;
	}

	/**
	 * @param bem the bem to set
	 */
	public void setBem(String bem) {
		this.bem = bem;
	}

	/**
	 * @return the cnpj
	 */
	public String getCnpj() {
		return cnpj;
	}

	/**
	 * @param cnpj the cnpj to set
	 */
	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	/**
	 * @return the cota
	 */
	public String getCota() {
		return cota;
	}

	/**
	 * @param cota the cota to set
	 */
	public void setCota(String cota) {
		this.cota = cota;
	}

	/**
	 * @return the grupo
	 */
	public String getGrupo() {
		return grupo;
	}

	/**
	 * @param grupo the grupo to set
	 */
	public void setGrupo(String grupo) {
		this.grupo = grupo;
	}

	/**
	 * @return the listaCotas
	 */
	public List<ListaCotasDTO> getListaCotas() {
		return listaCotas;
	}

	/**
	 * @param listaCotas the listaCotas to set
	 */
	public void setListaCotas(List<ListaCotasDTO> listaCotas) {
		this.listaCotas = listaCotas;
	}
	
	
}
