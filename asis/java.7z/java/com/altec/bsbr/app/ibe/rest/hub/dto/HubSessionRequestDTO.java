package com.altec.bsbr.app.ibe.rest.hub.dto;

import java.io.Serializable;
import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public class HubSessionRequestDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Map<String, String> fields;

	public Map<String, String> getFields() {
		return fields;
	}

	public void setFields(Map<String, String> fields) {
		this.fields = fields;
	}

}
