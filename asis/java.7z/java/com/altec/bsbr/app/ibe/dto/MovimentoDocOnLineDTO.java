package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class MovimentoDocOnLineDTO implements Serializable{
	private static final long serialVersionUID = 2932118260496635006L;
	private Date fecha;
	private String nomeFavorecido;
	private BigDecimal importe;
	private String tipoTransferencia;
	private String situacion;
	private String codigoCanalOrigen;
	private String cpfCnpjRemetente;
	private String nomeRemetente;
	private String tipoCuentaDestino;
	private String cpfCnpjDestino;
	private String descripcionFinalidade;
	private String numIdentificacionDoc;
	private String empresaContratoRemetente;
	private String sucursalContratoRemetente;
	private Long numCuentaContratoRemetente;
	private String descTipoCuentaRemetente;
	private String empresaContratoDestino;
	private String sucursalContratoDestino;
	private String digVerifContratoDestino;
	private Long numCuentaContratoDestino;
	private Boolean isCredito;
	
	/**
	 * @return the isCredito
	 */
	public Boolean getIsCredito() {
		return isCredito;
	}
	/**
	 * @param isCredito the isCredito to set
	 */
	public void setIsCredito(Boolean isCredito) {
		this.isCredito = isCredito;
	}
	/**
	 * @return the fecha
	 */
	public Date getFecha() {
		return fecha;
	}
	/**
	 * @param fecha the fecha to set
	 */
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	/**
	 * @return the nomeFavorecido
	 */
	public String getNomeFavorecido() {
		return nomeFavorecido;
	}
	/**
	 * @param nomeFavorecido the nomeFavorecido to set
	 */
	public void setNomeFavorecido(String nomeFavorecido) {
		this.nomeFavorecido = nomeFavorecido;
	}
	/**
	 * @return the importe
	 */
	public BigDecimal getImporte() {
		return importe;
	}
	/**
	 * @param importe the importe to set
	 */
	public void setImporte(BigDecimal importe) {
		this.importe = importe;
	}
	/**
	 * @return the tipoTransferencia
	 */
	public String getTipoTransferencia() {
		return tipoTransferencia;
	}
	/**
	 * @param tipoTransferencia the tipoTransferencia to set
	 */
	public void setTipoTransferencia(String tipoTransferencia) {
		this.tipoTransferencia = tipoTransferencia;
	}
	/**
	 * @return the situacion
	 */
	public String getSituacion() {
		return situacion;
	}
	/**
	 * @param situacion the situacion to set
	 */
	public void setSituacion(String situacion) {
		this.situacion = situacion;
	}
	/**
	 * @return the codigoCanalOrigen
	 */
	public String getCodigoCanalOrigen() {
		return codigoCanalOrigen;
	}
	/**
	 * @param codigoCanalOrigen the codigoCanalOrigen to set
	 */
	public void setCodigoCanalOrigen(String codigoCanalOrigen) {
		this.codigoCanalOrigen = codigoCanalOrigen;
	}
	/**
	 * @return the cpfCnpjRemetente
	 */
	public String getCpfCnpjRemetente() {
		return cpfCnpjRemetente;
	}
	/**
	 * @param cpfCnpjRemetente the cpfCnpjRemetente to set
	 */
	public void setCpfCnpjRemetente(String cpfCnpjRemetente) {
		this.cpfCnpjRemetente = cpfCnpjRemetente;
	}
	/**
	 * @return the nomeRemetente
	 */
	public String getNomeRemetente() {
		return nomeRemetente;
	}
	/**
	 * @param nomeRemetente the nomeRemetente to set
	 */
	public void setNomeRemetente(String nomeRemetente) {
		this.nomeRemetente = nomeRemetente;
	}
	/**
	 * @return the tipoCuentaDestino
	 */
	public String getTipoCuentaDestino() {
		return tipoCuentaDestino;
	}
	/**
	 * @param tipoCuentaDestino the tipoCuentaDestino to set
	 */
	public void setTipoCuentaDestino(String tipoCuentaDestino) {
		this.tipoCuentaDestino = tipoCuentaDestino;
	}
	/**
	 * @return the cpfCnpjDestino
	 */
	public String getCpfCnpjDestino() {
		return cpfCnpjDestino;
	}
	/**
	 * @param cpfCnpjDestino the cpfCnpjDestino to set
	 */
	public void setCpfCnpjDestino(String cpfCnpjDestino) {
		this.cpfCnpjDestino = cpfCnpjDestino;
	}
	/**
	 * @return the descripcionFinalidade
	 */
	public String getDescripcionFinalidade() {
		return descripcionFinalidade;
	}
	/**
	 * @param descripcionFinalidade the descripcionFinalidade to set
	 */
	public void setDescripcionFinalidade(String descripcionFinalidade) {
		this.descripcionFinalidade = descripcionFinalidade;
	}
	/**
	 * @return the numIdentificacionDoc
	 */
	public String getNumIdentificacionDoc() {
		return numIdentificacionDoc;
	}
	/**
	 * @param numIdentificacionDoc the numIdentificacionDoc to set
	 */
	public void setNumIdentificacionDoc(String numIdentificacionDoc) {
		this.numIdentificacionDoc = numIdentificacionDoc;
	}
	/**
	 * @return the empresaContratoRemetente
	 */
	public String getEmpresaContratoRemetente() {
		return empresaContratoRemetente;
	}
	/**
	 * @param empresaContratoRemetente the empresaContratoRemetente to set
	 */
	public void setEmpresaContratoRemetente(String empresaContratoRemetente) {
		this.empresaContratoRemetente = empresaContratoRemetente;
	}
	/**
	 * @return the sucursalContratoRemetente
	 */
	public String getSucursalContratoRemetente() {
		return sucursalContratoRemetente;
	}
	/**
	 * @param sucursalContratoRemetente the sucursalContratoRemetente to set
	 */
	public void setSucursalContratoRemetente(String sucursalContratoRemetente) {
		this.sucursalContratoRemetente = sucursalContratoRemetente;
	}
	/**
	 * @return the numCuentaContratoRemetente
	 */
	public Long getNumCuentaContratoRemetente() {
		return numCuentaContratoRemetente;
	}
	/**
	 * @param numCuentaContratoRemetente the numCuentaContratoRemetente to set
	 */
	public void setNumCuentaContratoRemetente(Long numCuentaContratoRemetente) {
		this.numCuentaContratoRemetente = numCuentaContratoRemetente;
	}
	/**
	 * @return the descTipoCuentaRemetente
	 */
	public String getDescTipoCuentaRemetente() {
		return descTipoCuentaRemetente;
	}
	/**
	 * @param descTipoCuentaRemetente the descTipoCuentaRemetente to set
	 */
	public void setDescTipoCuentaRemetente(String descTipoCuentaRemetente) {
		this.descTipoCuentaRemetente = descTipoCuentaRemetente;
	}
	/**
	 * @return the empresaContratoDestino
	 */
	public String getEmpresaContratoDestino() {
		return empresaContratoDestino;
	}
	/**
	 * @param empresaContratoDestino the empresaContratoDestino to set
	 */
	public void setEmpresaContratoDestino(String empresaContratoDestino) {
		this.empresaContratoDestino = empresaContratoDestino;
	}
	/**
	 * @return the sucursalContratoDestino
	 */
	public String getSucursalContratoDestino() {
		return sucursalContratoDestino;
	}
	/**
	 * @param sucursalContratoDestino the sucursalContratoDestino to set
	 */
	public void setSucursalContratoDestino(String sucursalContratoDestino) {
		this.sucursalContratoDestino = sucursalContratoDestino;
	}
	/**
	 * @return the digVerifContratoDestino
	 */
	public String getDigVerifContratoDestino() {
		return digVerifContratoDestino;
	}
	/**
	 * @param digVerifContratoDestino the digVerifContratoDestino to set
	 */
	public void setDigVerifContratoDestino(String digVerifContratoDestino) {
		this.digVerifContratoDestino = digVerifContratoDestino;
	}
	/**
	 * @return the numCuentaContratoDestino
	 */
	public Long getNumCuentaContratoDestino() {
		return numCuentaContratoDestino;
	}
	/**
	 * @param numCuentaContratoDestino the numCuentaContratoDestino to set
	 */
	public void setNumCuentaContratoDestino(Long numCuentaContratoDestino) {
		this.numCuentaContratoDestino = numCuentaContratoDestino;
	}
	
}
