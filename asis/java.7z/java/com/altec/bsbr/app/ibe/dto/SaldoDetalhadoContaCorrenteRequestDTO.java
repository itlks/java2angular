package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class SaldoDetalhadoContaCorrenteRequestDTO implements Serializable
{

    private String logLevel;
    private String legacyProgramCode;
    private String areaSize;
    private String responseQueueName;
    private String messageType;
    private String processType;
    private String channelCode;
    private String transactionName;
    private String altairUserAcronym;
    private String cicsUserAcronym;
    private String messageFormatCode;
    private String financialEntity;
    private String accountingBranch;
    private String transaction;
    private String operationType;
    private String accountingDate;
    private String channel;
    private String operationReference;
    private String paymentInstrumentCode;
    private String transactionKey;
    private String operationReversalReference;
    private String originDate;
    private String originTime;
    private String clientCodeType;
    private String scheduleIndicator;
    private String authenticationNumber;
    private String moduleType;
    private String terminalType;
    private String pabNumber;
    private String channelVersion;
    private String terminalNumber;
    private String userAcronym;
    private String operatorNumber;
    private String operatorRegistration;
    private String supervisorNumber;
    private String supervisorRegistration;
    private String messageMAC;
    private String cryptographedPAN;
    private String cryptographedPANContinuation;
    private String accountEntity;
    private String accountBranch;
    private String accountNumber;
    private String accountType;
    private String channelData;
    private String requestType;
    private String responseIndicator;
    private final static long serialVersionUID = -937605715005346328L;

    /**
     * No args constructor for use in serialization
     * 
     */
    public SaldoDetalhadoContaCorrenteRequestDTO() {
    }

    /**
     * 
     * @param legacyProgramCode
     * @param supervisorNumber
     * @param terminalNumber
     * @param channelData
     * @param cryptographedPAN
     * @param cryptographedPANContinuation
     * @param channel
     * @param scheduleIndicator
     * @param transactionName
     * @param accountEntity
     * @param userAcronym
     * @param operatorRegistration
     * @param logLevel
     * @param messageType
     * @param pabNumber
     * @param transactionKey
     * @param channelVersion
     * @param processType
     * @param responseQueueName
     * @param operationReversalReference
     * @param areaSize
     * @param cicsUserAcronym
     * @param originDate
     * @param channelCode
     * @param clientCodeType
     * @param accountingDate
     * @param originTime
     * @param moduleType
     * @param requestType
     * @param accountType
     * @param messageFormatCode
     * @param responseIndicator
     * @param operatorNumber
     * @param accountNumber
     * @param accountingBranch
     * @param terminalType
     * @param altairUserAcronym
     * @param messageMAC
     * @param paymentInstrumentCode
     * @param operationType
     * @param operationReference
     * @param supervisorRegistration
     * @param transaction
     * @param authenticationNumber
     * @param financialEntity
     * @param accountBranch
     */
    public SaldoDetalhadoContaCorrenteRequestDTO(String logLevel, String legacyProgramCode, String areaSize, String responseQueueName, String messageType, String processType, String channelCode, String transactionName, String altairUserAcronym, String cicsUserAcronym, String messageFormatCode, String financialEntity, String accountingBranch, String transaction, String operationType, String accountingDate, String channel, String operationReference, String paymentInstrumentCode, String transactionKey, String operationReversalReference, String originDate, String originTime, String clientCodeType, String scheduleIndicator, String authenticationNumber, String moduleType, String terminalType, String pabNumber, String channelVersion, String terminalNumber, String userAcronym, String operatorNumber, String operatorRegistration, String supervisorNumber, String supervisorRegistration, String messageMAC, String cryptographedPAN, String cryptographedPANContinuation, String accountEntity, String accountBranch, String accountNumber, String accountType, String channelData, String requestType, String responseIndicator) {
        super();
        this.logLevel = logLevel;
        this.legacyProgramCode = legacyProgramCode;
        this.areaSize = areaSize;
        this.responseQueueName = responseQueueName;
        this.messageType = messageType;
        this.processType = processType;
        this.channelCode = channelCode;
        this.transactionName = transactionName;
        this.altairUserAcronym = altairUserAcronym;
        this.cicsUserAcronym = cicsUserAcronym;
        this.messageFormatCode = messageFormatCode;
        this.financialEntity = financialEntity;
        this.accountingBranch = accountingBranch;
        this.transaction = transaction;
        this.operationType = operationType;
        this.accountingDate = accountingDate;
        this.channel = channel;
        this.operationReference = operationReference;
        this.paymentInstrumentCode = paymentInstrumentCode;
        this.transactionKey = transactionKey;
        this.operationReversalReference = operationReversalReference;
        this.originDate = originDate;
        this.originTime = originTime;
        this.clientCodeType = clientCodeType;
        this.scheduleIndicator = scheduleIndicator;
        this.authenticationNumber = authenticationNumber;
        this.moduleType = moduleType;
        this.terminalType = terminalType;
        this.pabNumber = pabNumber;
        this.channelVersion = channelVersion;
        this.terminalNumber = terminalNumber;
        this.userAcronym = userAcronym;
        this.operatorNumber = operatorNumber;
        this.operatorRegistration = operatorRegistration;
        this.supervisorNumber = supervisorNumber;
        this.supervisorRegistration = supervisorRegistration;
        this.messageMAC = messageMAC;
        this.cryptographedPAN = cryptographedPAN;
        this.cryptographedPANContinuation = cryptographedPANContinuation;
        this.accountEntity = accountEntity;
        this.accountBranch = accountBranch;
        this.accountNumber = accountNumber;
        this.accountType = accountType;
        this.channelData = channelData;
        this.requestType = requestType;
        this.responseIndicator = responseIndicator;
    }

    public String getLogLevel() {
        return logLevel;
    }

    public void setLogLevel(String logLevel) {
        this.logLevel = logLevel;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withLogLevel(String logLevel) {
        this.logLevel = logLevel;
        return this;
    }

    public String getLegacyProgramCode() {
        return legacyProgramCode;
    }

    public void setLegacyProgramCode(String legacyProgramCode) {
        this.legacyProgramCode = legacyProgramCode;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withLegacyProgramCode(String legacyProgramCode) {
        this.legacyProgramCode = legacyProgramCode;
        return this;
    }

    public String getAreaSize() {
        return areaSize;
    }

    public void setAreaSize(String areaSize) {
        this.areaSize = areaSize;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withAreaSize(String areaSize) {
        this.areaSize = areaSize;
        return this;
    }

    public String getResponseQueueName() {
        return responseQueueName;
    }

    public void setResponseQueueName(String responseQueueName) {
        this.responseQueueName = responseQueueName;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withResponseQueueName(String responseQueueName) {
        this.responseQueueName = responseQueueName;
        return this;
    }

    public String getMessageType() {
        return messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withMessageType(String messageType) {
        this.messageType = messageType;
        return this;
    }

    public String getProcessType() {
        return processType;
    }

    public void setProcessType(String processType) {
        this.processType = processType;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withProcessType(String processType) {
        this.processType = processType;
        return this;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withChannelCode(String channelCode) {
        this.channelCode = channelCode;
        return this;
    }

    public String getTransactionName() {
        return transactionName;
    }

    public void setTransactionName(String transactionName) {
        this.transactionName = transactionName;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withTransactionName(String transactionName) {
        this.transactionName = transactionName;
        return this;
    }

    public String getAltairUserAcronym() {
        return altairUserAcronym;
    }

    public void setAltairUserAcronym(String altairUserAcronym) {
        this.altairUserAcronym = altairUserAcronym;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withAltairUserAcronym(String altairUserAcronym) {
        this.altairUserAcronym = altairUserAcronym;
        return this;
    }

    public String getCicsUserAcronym() {
        return cicsUserAcronym;
    }

    public void setCicsUserAcronym(String cicsUserAcronym) {
        this.cicsUserAcronym = cicsUserAcronym;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withCicsUserAcronym(String cicsUserAcronym) {
        this.cicsUserAcronym = cicsUserAcronym;
        return this;
    }

    public String getMessageFormatCode() {
        return messageFormatCode;
    }

    public void setMessageFormatCode(String messageFormatCode) {
        this.messageFormatCode = messageFormatCode;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withMessageFormatCode(String messageFormatCode) {
        this.messageFormatCode = messageFormatCode;
        return this;
    }

    public String getFinancialEntity() {
        return financialEntity;
    }

    public void setFinancialEntity(String financialEntity) {
        this.financialEntity = financialEntity;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withFinancialEntity(String financialEntity) {
        this.financialEntity = financialEntity;
        return this;
    }

    public String getAccountingBranch() {
        return accountingBranch;
    }

    public void setAccountingBranch(String accountingBranch) {
        this.accountingBranch = accountingBranch;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withAccountingBranch(String accountingBranch) {
        this.accountingBranch = accountingBranch;
        return this;
    }

    public String getTransaction() {
        return transaction;
    }

    public void setTransaction(String transaction) {
        this.transaction = transaction;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withTransaction(String transaction) {
        this.transaction = transaction;
        return this;
    }

    public String getOperationType() {
        return operationType;
    }

    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withOperationType(String operationType) {
        this.operationType = operationType;
        return this;
    }

    public String getAccountingDate() {
        return accountingDate;
    }

    public void setAccountingDate(String accountingDate) {
        this.accountingDate = accountingDate;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withAccountingDate(String accountingDate) {
        this.accountingDate = accountingDate;
        return this;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withChannel(String channel) {
        this.channel = channel;
        return this;
    }

    public String getOperationReference() {
        return operationReference;
    }

    public void setOperationReference(String operationReference) {
        this.operationReference = operationReference;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withOperationReference(String operationReference) {
        this.operationReference = operationReference;
        return this;
    }

    public String getPaymentInstrumentCode() {
        return paymentInstrumentCode;
    }

    public void setPaymentInstrumentCode(String paymentInstrumentCode) {
        this.paymentInstrumentCode = paymentInstrumentCode;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withPaymentInstrumentCode(String paymentInstrumentCode) {
        this.paymentInstrumentCode = paymentInstrumentCode;
        return this;
    }

    public String getTransactionKey() {
        return transactionKey;
    }

    public void setTransactionKey(String transactionKey) {
        this.transactionKey = transactionKey;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withTransactionKey(String transactionKey) {
        this.transactionKey = transactionKey;
        return this;
    }

    public String getOperationReversalReference() {
        return operationReversalReference;
    }

    public void setOperationReversalReference(String operationReversalReference) {
        this.operationReversalReference = operationReversalReference;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withOperationReversalReference(String operationReversalReference) {
        this.operationReversalReference = operationReversalReference;
        return this;
    }

    public String getOriginDate() {
        return originDate;
    }

    public void setOriginDate(String originDate) {
        this.originDate = originDate;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withOriginDate(String originDate) {
        this.originDate = originDate;
        return this;
    }

    public String getOriginTime() {
        return originTime;
    }

    public void setOriginTime(String originTime) {
        this.originTime = originTime;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withOriginTime(String originTime) {
        this.originTime = originTime;
        return this;
    }

    public String getClientCodeType() {
        return clientCodeType;
    }

    public void setClientCodeType(String clientCodeType) {
        this.clientCodeType = clientCodeType;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withClientCodeType(String clientCodeType) {
        this.clientCodeType = clientCodeType;
        return this;
    }

    public String getScheduleIndicator() {
        return scheduleIndicator;
    }

    public void setScheduleIndicator(String scheduleIndicator) {
        this.scheduleIndicator = scheduleIndicator;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withScheduleIndicator(String scheduleIndicator) {
        this.scheduleIndicator = scheduleIndicator;
        return this;
    }

    public String getAuthenticationNumber() {
        return authenticationNumber;
    }

    public void setAuthenticationNumber(String authenticationNumber) {
        this.authenticationNumber = authenticationNumber;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withAuthenticationNumber(String authenticationNumber) {
        this.authenticationNumber = authenticationNumber;
        return this;
    }

    public String getModuleType() {
        return moduleType;
    }

    public void setModuleType(String moduleType) {
        this.moduleType = moduleType;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withModuleType(String moduleType) {
        this.moduleType = moduleType;
        return this;
    }

    public String getTerminalType() {
        return terminalType;
    }

    public void setTerminalType(String terminalType) {
        this.terminalType = terminalType;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withTerminalType(String terminalType) {
        this.terminalType = terminalType;
        return this;
    }

    public String getPabNumber() {
        return pabNumber;
    }

    public void setPabNumber(String pabNumber) {
        this.pabNumber = pabNumber;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withPabNumber(String pabNumber) {
        this.pabNumber = pabNumber;
        return this;
    }

    public String getChannelVersion() {
        return channelVersion;
    }

    public void setChannelVersion(String channelVersion) {
        this.channelVersion = channelVersion;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withChannelVersion(String channelVersion) {
        this.channelVersion = channelVersion;
        return this;
    }

    public String getTerminalNumber() {
        return terminalNumber;
    }

    public void setTerminalNumber(String terminalNumber) {
        this.terminalNumber = terminalNumber;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withTerminalNumber(String terminalNumber) {
        this.terminalNumber = terminalNumber;
        return this;
    }

    public String getUserAcronym() {
        return userAcronym;
    }

    public void setUserAcronym(String userAcronym) {
        this.userAcronym = userAcronym;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withUserAcronym(String userAcronym) {
        this.userAcronym = userAcronym;
        return this;
    }

    public String getOperatorNumber() {
        return operatorNumber;
    }

    public void setOperatorNumber(String operatorNumber) {
        this.operatorNumber = operatorNumber;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withOperatorNumber(String operatorNumber) {
        this.operatorNumber = operatorNumber;
        return this;
    }

    public String getOperatorRegistration() {
        return operatorRegistration;
    }

    public void setOperatorRegistration(String operatorRegistration) {
        this.operatorRegistration = operatorRegistration;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withOperatorRegistration(String operatorRegistration) {
        this.operatorRegistration = operatorRegistration;
        return this;
    }

    public String getSupervisorNumber() {
        return supervisorNumber;
    }

    public void setSupervisorNumber(String supervisorNumber) {
        this.supervisorNumber = supervisorNumber;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withSupervisorNumber(String supervisorNumber) {
        this.supervisorNumber = supervisorNumber;
        return this;
    }

    public String getSupervisorRegistration() {
        return supervisorRegistration;
    }

    public void setSupervisorRegistration(String supervisorRegistration) {
        this.supervisorRegistration = supervisorRegistration;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withSupervisorRegistration(String supervisorRegistration) {
        this.supervisorRegistration = supervisorRegistration;
        return this;
    }

    public String getMessageMAC() {
        return messageMAC;
    }

    public void setMessageMAC(String messageMAC) {
        this.messageMAC = messageMAC;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withMessageMAC(String messageMAC) {
        this.messageMAC = messageMAC;
        return this;
    }

    public String getCryptographedPAN() {
        return cryptographedPAN;
    }

    public void setCryptographedPAN(String cryptographedPAN) {
        this.cryptographedPAN = cryptographedPAN;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withCryptographedPAN(String cryptographedPAN) {
        this.cryptographedPAN = cryptographedPAN;
        return this;
    }

    public String getCryptographedPANContinuation() {
        return cryptographedPANContinuation;
    }

    public void setCryptographedPANContinuation(String cryptographedPANContinuation) {
        this.cryptographedPANContinuation = cryptographedPANContinuation;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withCryptographedPANContinuation(String cryptographedPANContinuation) {
        this.cryptographedPANContinuation = cryptographedPANContinuation;
        return this;
    }

    public String getAccountEntity() {
        return accountEntity;
    }

    public void setAccountEntity(String accountEntity) {
        this.accountEntity = accountEntity;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withAccountEntity(String accountEntity) {
        this.accountEntity = accountEntity;
        return this;
    }

    public String getAccountBranch() {
        return accountBranch;
    }

    public void setAccountBranch(String accountBranch) {
        this.accountBranch = accountBranch;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withAccountBranch(String accountBranch) {
        this.accountBranch = accountBranch;
        return this;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
        return this;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withAccountType(String accountType) {
        this.accountType = accountType;
        return this;
    }

    public String getChannelData() {
        return channelData;
    }

    public void setChannelData(String channelData) {
        this.channelData = channelData;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withChannelData(String channelData) {
        this.channelData = channelData;
        return this;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withRequestType(String requestType) {
        this.requestType = requestType;
        return this;
    }

    public String getResponseIndicator() {
        return responseIndicator;
    }

    public void setResponseIndicator(String responseIndicator) {
        this.responseIndicator = responseIndicator;
    }

    public SaldoDetalhadoContaCorrenteRequestDTO withResponseIndicator(String responseIndicator) {
        this.responseIndicator = responseIndicator;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(logLevel).append(legacyProgramCode).append(areaSize).append(responseQueueName).append(messageType).append(processType).append(channelCode).append(transactionName).append(altairUserAcronym).append(cicsUserAcronym).append(messageFormatCode).append(financialEntity).append(accountingBranch).append(transaction).append(operationType).append(accountingDate).append(channel).append(operationReference).append(paymentInstrumentCode).append(transactionKey).append(operationReversalReference).append(originDate).append(originTime).append(clientCodeType).append(scheduleIndicator).append(authenticationNumber).append(moduleType).append(terminalType).append(pabNumber).append(channelVersion).append(terminalNumber).append(userAcronym).append(operatorNumber).append(operatorRegistration).append(supervisorNumber).append(supervisorRegistration).append(messageMAC).append(cryptographedPAN).append(cryptographedPANContinuation).append(accountEntity).append(accountBranch).append(accountNumber).append(accountType).append(channelData).append(requestType).append(responseIndicator).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof SaldoDetalhadoContaCorrenteRequestDTO) == false) {
            return false;
        }
        SaldoDetalhadoContaCorrenteRequestDTO rhs = ((SaldoDetalhadoContaCorrenteRequestDTO) other);
        return new EqualsBuilder().append(logLevel, rhs.logLevel).append(legacyProgramCode, rhs.legacyProgramCode).append(areaSize, rhs.areaSize).append(responseQueueName, rhs.responseQueueName).append(messageType, rhs.messageType).append(processType, rhs.processType).append(channelCode, rhs.channelCode).append(transactionName, rhs.transactionName).append(altairUserAcronym, rhs.altairUserAcronym).append(cicsUserAcronym, rhs.cicsUserAcronym).append(messageFormatCode, rhs.messageFormatCode).append(financialEntity, rhs.financialEntity).append(accountingBranch, rhs.accountingBranch).append(transaction, rhs.transaction).append(operationType, rhs.operationType).append(accountingDate, rhs.accountingDate).append(channel, rhs.channel).append(operationReference, rhs.operationReference).append(paymentInstrumentCode, rhs.paymentInstrumentCode).append(transactionKey, rhs.transactionKey).append(operationReversalReference, rhs.operationReversalReference).append(originDate, rhs.originDate).append(originTime, rhs.originTime).append(clientCodeType, rhs.clientCodeType).append(scheduleIndicator, rhs.scheduleIndicator).append(authenticationNumber, rhs.authenticationNumber).append(moduleType, rhs.moduleType).append(terminalType, rhs.terminalType).append(pabNumber, rhs.pabNumber).append(channelVersion, rhs.channelVersion).append(terminalNumber, rhs.terminalNumber).append(userAcronym, rhs.userAcronym).append(operatorNumber, rhs.operatorNumber).append(operatorRegistration, rhs.operatorRegistration).append(supervisorNumber, rhs.supervisorNumber).append(supervisorRegistration, rhs.supervisorRegistration).append(messageMAC, rhs.messageMAC).append(cryptographedPAN, rhs.cryptographedPAN).append(cryptographedPANContinuation, rhs.cryptographedPANContinuation).append(accountEntity, rhs.accountEntity).append(accountBranch, rhs.accountBranch).append(accountNumber, rhs.accountNumber).append(accountType, rhs.accountType).append(channelData, rhs.channelData).append(requestType, rhs.requestType).append(responseIndicator, rhs.responseIndicator).isEquals();
    }

}
