package com.altec.bsbr.app.ibe.dto;
 
public class DadosEntradaLimitesDTO {

	private String subTituloYA;
	private String codProdutoYA;
	private String codServicoYA;
	private String transacaoYA;
    private String indMesmaTit;

	public DadosEntradaLimitesDTO(String subTituloYA, String codProdutoYA, String codServicoYA, String transacaoYA, String indMesmaTit) {
		this.subTituloYA = subTituloYA;
		this.codProdutoYA = codProdutoYA;
		this.codServicoYA = codServicoYA;
		this.transacaoYA = transacaoYA;
		this.indMesmaTit = indMesmaTit;
	}

	public String getCodProdutoYA() {
		return codProdutoYA;
	}

	public void setCodProdutoYA(String codProdutoYA) {
		this.codProdutoYA = codProdutoYA;
	}

	public String getCodServicoYA() {
		return codServicoYA;
	}

	public void setCodServicoYA(String codServicoYA) {
		this.codServicoYA = codServicoYA;
	}

	public String getTransacaoYA() {
		return transacaoYA;
	}

	public void setTransacaoYA(String transacaoYA) {
		this.transacaoYA = transacaoYA;
	}

	public String getSubTituloYA() {
		return subTituloYA;
	}

	public void setSubTituloYA(String subTituloYA) {
		this.subTituloYA = subTituloYA;
	}

	public String getIndMesmaTit() {
		return indMesmaTit;
	}

	public void setIndMesmaTit(String indMesmaTit) {
		this.indMesmaTit = indMesmaTit;
	}
	
}
