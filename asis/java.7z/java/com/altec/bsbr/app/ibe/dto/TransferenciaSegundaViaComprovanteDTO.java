package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class TransferenciaSegundaViaComprovanteDTO implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	private String tipoTransferencia;
	private String ano;
	private String mes;
	private String periodoEspecificoDoc;
	private String periodoEspecificoTed;
	private String dataInicial;
	private String dataFinal;
	
	private String dataContabil;
	private String valorRemessa;
	private String idSessao;
	private String chave23;
	private String chave;
	private Integer canal;
	
	private String codigoParticipante;
	private String idConexao;
	private String banco;
	private String agencia;
	private String conta;
	private String nomeUsuario;
	private String codigoUsuario;
	private String clienteIP;
	private String serverIP;
	private String tipPesquisa;
	private String idLancamento;
	private String nomeTitularConta;
	
	
	
	/**
	 * @return the tipoTransferencia
	 */
	public String getTipoTransferencia() {
		return tipoTransferencia;
	}

	/**
	 * @param tipoTransferencia
	 *            the tipoTransferencia to set
	 */
	public void setTipoTransferencia(String tipoTransferencia) {
		this.tipoTransferencia = tipoTransferencia;
	}

	/**
	 * @return the ano
	 */
	public String getAno() {
		return ano;
	}

	/**
	 * @param ano
	 *            the ano to set
	 */
	public void setAno(String ano) {
		this.ano = ano;
	}

	/**
	 * @return the mes
	 */
	public String getMes() {
		return mes;
	}

	/**
	 * @param mes
	 *            the mes to set
	 */
	public void setMes(String mes) {
		this.mes = mes;
	}

	/**
	 * @return the periodoEspecificoDoc
	 */
	public String getPeriodoEspecificoDoc() {
		return periodoEspecificoDoc;
	}

	/**
	 * @param periodoEspecificoDoc
	 *            the periodoEspecificoDoc to set
	 */
	public void setPeriodoEspecificoDoc(String periodoEspecificoDoc) {
		this.periodoEspecificoDoc = periodoEspecificoDoc;
	}

	/**
	 * @return the periodoEspecificoTed
	 */
	public String getPeriodoEspecificoTed() {
		return periodoEspecificoTed;
	}

	/**
	 * @param periodoEspecificoTed
	 *            the periodoEspecificoTed to set
	 */
	public void setPeriodoEspecificoTed(String periodoEspecificoTed) {
		this.periodoEspecificoTed = periodoEspecificoTed;
	}

	/**
	 * @return the dataInicial
	 */
	public String getDataInicial() {
		return dataInicial;
	}

	/**
	 * @param dataInicial
	 *            the dataInicial to set
	 */
	public void setDataInicial(String dataInicial) {
		this.dataInicial = dataInicial;
	}

	/**
	 * @return the dataFinal
	 */
	public String getDataFinal() {
		return dataFinal;
	}

	/**
	 * @param dataFinal
	 *            the dataFinal to set
	 */
	public void setDataFinal(String dataFinal) {
		this.dataFinal = dataFinal;
	}

	/**
	 * @return the codigoParticipante
	 */
	public String getCodigoParticipante() {
		return codigoParticipante;
	}

	/**
	 * @param codigoParticipante
	 *            the codigoParticipante to set
	 */
	public void setCodigoParticipante(String codigoParticipante) {
		this.codigoParticipante = codigoParticipante;
	}

	/**
	 * @return the idConexao
	 */
	public String getIdConexao() {
		return idConexao;
	}

	/**
	 * @param idConexao
	 *            the idConexao to set
	 */
	public void setIdConexao(String idConexao) {
		this.idConexao = idConexao;
	}

	/**
	 * @return the banco
	 */
	public String getBanco() {
		return banco;
	}

	/**
	 * @param banco
	 *            the banco to set
	 */
	public void setBanco(String banco) {
		this.banco = banco;
	}

	/**
	 * @return the agencia
	 */
	public String getAgencia() {
		return agencia;
	}

	/**
	 * @param agencia
	 *            the agencia to set
	 */
	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	/**
	 * @return the conta
	 */
	public String getConta() {
		return conta;
	}

	/**
	 * @param conta
	 *            the conta to set
	 */
	public void setConta(String conta) {
		this.conta = conta;
	}

	/**
	 * @return the nomeUsuario
	 */
	public String getNomeUsuario() {
		return nomeUsuario;
	}

	/**
	 * @param nomeUsuario
	 *            the nomeUsuario to set
	 */
	public void setNomeUsuario(String nomeUsuario) {
		this.nomeUsuario = nomeUsuario;
	}

	/**
	 * @return the codigoUsuario
	 */
	public String getCodigoUsuario() {
		return codigoUsuario;
	}

	/**
	 * @param codigoUsuario
	 *            the codigoUsuario to set
	 */
	public void setCodigoUsuario(String codigoUsuario) {
		this.codigoUsuario = codigoUsuario;
	}

	/**
	 * @return the clienteIP
	 */
	public String getClienteIP() {
		return clienteIP;
	}

	/**
	 * @param clienteIP
	 *            the clienteIP to set
	 */
	public void setClienteIP(String clienteIP) {
		this.clienteIP = clienteIP;
	}

	/**
	 * @return the serverIP
	 */
	public String getServerIP() {
		return serverIP;
	}

	/**
	 * @param serverIP
	 *            the serverIP to set
	 */
	public void setServerIP(String serverIP) {
		this.serverIP = serverIP;
	}
	

	/**
	 * @return the dataContabil
	 */
	public String getDataContabil() {
		return dataContabil;
	}

	/**
	 * @param dataContabil the dataContabil to set
	 */
	public void setDataContabil(String dataContabil) {
		this.dataContabil = dataContabil;
	}

	/**
	 * @return the valorRemessa
	 */
	public String getValorRemessa() {
		return valorRemessa;
	}

	/**
	 * @param valorRemessa the valorRemessa to set
	 */
	public void setValorRemessa(String valorRemessa) {
		this.valorRemessa = valorRemessa;
	}

	/**
	 * @return the idSessao
	 */
	public String getIdSessao() {
		return idSessao;
	}

	/**
	 * @param idSessao the idSessao to set
	 */
	public void setIdSessao(String idSessao) {
		this.idSessao = idSessao;
	}

	/**
	 * @return the chave23
	 */
	public String getChave23() {
		return chave23;
	}

	/**
	 * @param chave23 the chave23 to set
	 */
	public void setChave23(String chave23) {
		this.chave23 = chave23;
	}

	/**
	 * @return the chave
	 */
	public String getChave() {
		return chave;
	}

	/**
	 * @param chave the chave to set
	 */
	public void setChave(String chave) {
		this.chave = chave;
	}
	

	public Integer getCanal() {
		return canal;
	}

	public void setCanal(Integer canal) {
		this.canal = canal;
	}
	

	public String getTipPesquisa() {
		return tipPesquisa;
	}

	public void setTipPesquisa(String tipPesquisa) {
		this.tipPesquisa = tipPesquisa;
	}

	

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((agencia == null) ? 0 : agencia.hashCode());
		result = prime * result + ((ano == null) ? 0 : ano.hashCode());
		result = prime * result + ((banco == null) ? 0 : banco.hashCode());
		result = prime * result + ((clienteIP == null) ? 0 : clienteIP.hashCode());
		result = prime * result + ((codigoParticipante == null) ? 0 : codigoParticipante.hashCode());
		result = prime * result + ((codigoUsuario == null) ? 0 : codigoUsuario.hashCode());
		result = prime * result + ((conta == null) ? 0 : conta.hashCode());
		result = prime * result + ((dataFinal == null) ? 0 : dataFinal.hashCode());
		result = prime * result + ((dataInicial == null) ? 0 : dataInicial.hashCode());
		result = prime * result + ((idConexao == null) ? 0 : idConexao.hashCode());
		result = prime * result + ((serverIP == null) ? 0 : serverIP.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TransferenciaSegundaViaComprovanteDTO other = (TransferenciaSegundaViaComprovanteDTO) obj;
		if (agencia == null) {
			if (other.agencia != null)
				return false;
		} else if (!agencia.equals(other.agencia))
			return false;
		if (ano == null) {
			if (other.ano != null)
				return false;
		} else if (!ano.equals(other.ano))
			return false;
		if (banco == null) {
			if (other.banco != null)
				return false;
		} else if (!banco.equals(other.banco))
			return false;
		if (clienteIP == null) {
			if (other.clienteIP != null)
				return false;
		} else if (!clienteIP.equals(other.clienteIP))
			return false;
		if (codigoParticipante == null) {
			if (other.codigoParticipante != null)
				return false;
		} else if (!codigoParticipante.equals(other.codigoParticipante))
			return false;
		if (codigoUsuario == null) {
			if (other.codigoUsuario != null)
				return false;
		} else if (!codigoUsuario.equals(other.codigoUsuario))
			return false;
		if (conta == null) {
			if (other.conta != null)
				return false;
		} else if (!conta.equals(other.conta))
			return false;
		if (dataFinal == null) {
			if (other.dataFinal != null)
				return false;
		} else if (!dataFinal.equals(other.dataFinal))
			return false;
		if (dataInicial == null) {
			if (other.dataInicial != null)
				return false;
		} else if (!dataInicial.equals(other.dataInicial))
			return false;
		if (idConexao == null) {
			if (other.idConexao != null)
				return false;
		} else if (!idConexao.equals(other.idConexao))
			return false;
		if (serverIP == null) {
			if (other.serverIP != null)
				return false;
		} else if (!serverIP.equals(other.serverIP))
			return false;
		return true;
	}

	public String getIdLancamento() {
		return idLancamento;
	}

	public void setIdLancamento(String idLancamento) {
		this.idLancamento = idLancamento;
	}

	public String getNomeTitularConta() {
		return nomeTitularConta;
	}

	public void setNomeTitularConta(String nomeTitularConta) {
		this.nomeTitularConta = nomeTitularConta;
	}
	

}