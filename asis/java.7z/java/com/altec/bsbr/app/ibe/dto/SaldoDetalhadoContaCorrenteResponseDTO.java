package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class SaldoDetalhadoContaCorrenteResponseDTO implements Serializable
{

    private String investimentBank;
    private String investimentBranchCode;
    private String investimentAccountNumber;
    private String bankDestinationAcccount;
    private String branchDestinationBranch;
    private String destinationAccountNumber;
    private String checkingAccountBalance;
    private String maxAccountBalance;
    private String checkingAccountBalancePlusMax;
    private String hoursBlockValue24;
    private String hoursBlockValue48;
    private String unlimitedTimeBlockValue;
    private String totalBlockValue;
    private String tedBlockValue;
    private String overdraftCheckingAccountValue;
    private String checkingAccountBalanceAvailableValue;
    private String savingsBalanceValueInRelease;
    private String checkingInvestmentAccountBalanceValue;
    private String investmentAccount24HoursBlockValue;
    private String investmentAccount48HoursBlockValue;
    private String investmentAccountUnlimitedBlockValue;
    private String investmentAccountTotalBlockValue;
    private String investmentAccountTEDBlockValue;
    private String investmentAccountAvailableBalanceValue;
    private String investmentAccountPlusCheckingAccountValue;
    private String investmentAccountBalancePlusCheckningAccountPlusMaxValue;
    private String investimentAccountPlustCheckingAccountPlusMaxPlusAutomaticRedemptionValue;
    private String totalBlockedBalanceValue;
    private String automaticRedemptionBalanceValue;
    private String totalAvailableBalanceValue;
    private String accumulatedCPMFBalanceValue;
    private String monthlyInterestedRate;
    private String monthlyInsolvencyRate;
    private String contractDueDate;
    private String accumulatedInterestedValue;
    private String interestedBillingDate;
    private String accumulatedIOFValue;
    private String iofbillingdate;
    private String maxAccountIndicator;
    private String blockedCheckbookIndicator;
    private String superCheckbookIndicator;
    private String coverageCCIIndicator;
    private String fundsAccountBalanceIndicator;
    private String automaticRedemptionAccountIndicator;
    private String lastMoveDate;
    private String availableCreditValue;
    private String cpmfBillingIndicator;
    private String ndiasDaysQuantity;
    private String notChargedInterestedValue;
    private String balanceSignal;
    private String dailyBlockBalance;
    private String judicialBlockBalance;
    private String provisionedTotalBalance;
    private String accumulatedInterestedsValues;
    private String accumulatedIOFEndDateValue;
    private String accumulatedCPMFValue;
    private String availableBalanceValue;
    private String lastOverdraftUsageDate;
    private String availableOverdraftValue;
    private String usedOverdraftValue;
    private String investmentOverdraftAvailableValue;
    private String investmentOverdraftAvailableUsed;
    private String investmentOverdraftDueDate;
    private String investmentOverdraftInterestRate;
    private String investmentOverdraftValue;
    private String availableSantanderOverdraftValue;
    private String santanderDebitDay;
    private String santanderInstallmentsQuantity;
    private String checkingAccountBlockedBalanceValuePlustInvestmentAccountPlusJudicialBlock;
    private String provisionedCreditPostingValue;
    private String provisionedDebitPostingValue;
    private String firstAndSecondOverdraftDescription;
    private String checkingAccountJudicialBlockBalanceValue;
    private String investimentAccountJudicialBlockBalanceValue;
    private String overdraftLenderInsuranceValue;
    private String aea;
    private final static long serialVersionUID = -8900107733028820478L;

    /**
     * No args constructor for use in serialization
     * 
     */
    public SaldoDetalhadoContaCorrenteResponseDTO() {
    }

    /**
     * 
     * @param investimentAccountNumber
     * @param accumulatedCPMFValue
     * @param tedBlockValue
     * @param overdraftCheckingAccountValue
     * @param accumulatedCPMFBalanceValue
     * @param blockedCheckbookIndicator
     * @param checkingAccountBlockedBalanceValuePlustInvestmentAccountPlusJudicialBlock
     * @param checkingAccountJudicialBlockBalanceValue
     * @param investmentOverdraftInterestRate
     * @param checkingAccountBalance
     * @param judicialBlockBalance
     * @param hoursBlockValue48
     * @param santanderInstallmentsQuantity
     * @param notChargedInterestedValue
     * @param provisionedDebitPostingValue
     * @param provisionedTotalBalance
     * @param checkingInvestmentAccountBalanceValue
     * @param totalBlockValue
     * @param investmentAccountTEDBlockValue
     * @param availableCreditValue
     * @param dailyBlockBalance
     * @param totalAvailableBalanceValue
     * @param balanceSignal
     * @param investmentAccountAvailableBalanceValue
     * @param superCheckbookIndicator
     * @param accumulatedIOFEndDateValue
     * @param bankDestinationAcccount
     * @param savingsBalanceValueInRelease
     * @param accumulatedInterestedValue
     * @param overdraftLenderInsuranceValue
     * @param investmentAccount48HoursBlockValue
     * @param unlimitedTimeBlockValue
     * @param ndiasDaysQuantity
     * @param investimentAccountJudicialBlockBalanceValue
     * @param checkingAccountBalanceAvailableValue
     * @param accumulatedIOFValue
     * @param coverageCCIIndicator
     * @param contractDueDate
     * @param investmentAccountBalancePlusCheckningAccountPlusMaxValue
     * @param investimentAccountPlustCheckingAccountPlusMaxPlusAutomaticRedemptionValue
     * @param investmentAccountTotalBlockValue
     * @param hoursBlockValue24
     * @param iofbillingdate
     * @param maxAccountBalance
     * @param accumulatedInterestedsValues
     * @param investimentBank
     * @param firstAndSecondOverdraftDescription
     * @param investmentAccountUnlimitedBlockValue
     * @param aea
     * @param automaticRedemptionBalanceValue
     * @param availableOverdraftValue
     * @param fundsAccountBalanceIndicator
     * @param maxAccountIndicator
     * @param cpmfBillingIndicator
     * @param investmentAccountPlusCheckingAccountValue
     * @param automaticRedemptionAccountIndicator
     * @param monthlyInterestedRate
     * @param investmentOverdraftAvailableUsed
     * @param provisionedCreditPostingValue
     * @param investmentOverdraftValue
     * @param lastMoveDate
     * @param santanderDebitDay
     * @param investmentOverdraftAvailableValue
     * @param usedOverdraftValue
     * @param interestedBillingDate
     * @param checkingAccountBalancePlusMax
     * @param investimentBranchCode
     * @param availableBalanceValue
     * @param branchDestinationBranch
     * @param destinationAccountNumber
     * @param lastOverdraftUsageDate
     * @param availableSantanderOverdraftValue
     * @param totalBlockedBalanceValue
     * @param investmentAccount24HoursBlockValue
     * @param investmentOverdraftDueDate
     * @param monthlyInsolvencyRate
     */
    public SaldoDetalhadoContaCorrenteResponseDTO(String investimentBank, String investimentBranchCode, String investimentAccountNumber, String bankDestinationAcccount, String branchDestinationBranch, String destinationAccountNumber, String checkingAccountBalance, String maxAccountBalance, String checkingAccountBalancePlusMax, String hoursBlockValue24, String hoursBlockValue48, String unlimitedTimeBlockValue, String totalBlockValue, String tedBlockValue, String overdraftCheckingAccountValue, String checkingAccountBalanceAvailableValue, String savingsBalanceValueInRelease, String checkingInvestmentAccountBalanceValue, String investmentAccount24HoursBlockValue, String investmentAccount48HoursBlockValue, String investmentAccountUnlimitedBlockValue, String investmentAccountTotalBlockValue, String investmentAccountTEDBlockValue, String investmentAccountAvailableBalanceValue, String investmentAccountPlusCheckingAccountValue, String investmentAccountBalancePlusCheckningAccountPlusMaxValue, String investimentAccountPlustCheckingAccountPlusMaxPlusAutomaticRedemptionValue, String totalBlockedBalanceValue, String automaticRedemptionBalanceValue, String totalAvailableBalanceValue, String accumulatedCPMFBalanceValue, String monthlyInterestedRate, String monthlyInsolvencyRate, String contractDueDate, String accumulatedInterestedValue, String interestedBillingDate, String accumulatedIOFValue, String iofbillingdate, String maxAccountIndicator, String blockedCheckbookIndicator, String superCheckbookIndicator, String coverageCCIIndicator, String fundsAccountBalanceIndicator, String automaticRedemptionAccountIndicator, String lastMoveDate, String availableCreditValue, String cpmfBillingIndicator, String ndiasDaysQuantity, String notChargedInterestedValue, String balanceSignal, String dailyBlockBalance, String judicialBlockBalance, String provisionedTotalBalance, String accumulatedInterestedsValues, String accumulatedIOFEndDateValue, String accumulatedCPMFValue, String availableBalanceValue, String lastOverdraftUsageDate, String availableOverdraftValue, String usedOverdraftValue, String investmentOverdraftAvailableValue, String investmentOverdraftAvailableUsed, String investmentOverdraftDueDate, String investmentOverdraftInterestRate, String investmentOverdraftValue, String availableSantanderOverdraftValue, String santanderDebitDay, String santanderInstallmentsQuantity, String checkingAccountBlockedBalanceValuePlustInvestmentAccountPlusJudicialBlock, String provisionedCreditPostingValue, String provisionedDebitPostingValue, String firstAndSecondOverdraftDescription, String checkingAccountJudicialBlockBalanceValue, String investimentAccountJudicialBlockBalanceValue, String overdraftLenderInsuranceValue, String aea) {
        super();
        this.investimentBank = investimentBank;
        this.investimentBranchCode = investimentBranchCode;
        this.investimentAccountNumber = investimentAccountNumber;
        this.bankDestinationAcccount = bankDestinationAcccount;
        this.branchDestinationBranch = branchDestinationBranch;
        this.destinationAccountNumber = destinationAccountNumber;
        this.checkingAccountBalance = checkingAccountBalance;
        this.maxAccountBalance = maxAccountBalance;
        this.checkingAccountBalancePlusMax = checkingAccountBalancePlusMax;
        this.hoursBlockValue24 = hoursBlockValue24;
        this.hoursBlockValue48 = hoursBlockValue48;
        this.unlimitedTimeBlockValue = unlimitedTimeBlockValue;
        this.totalBlockValue = totalBlockValue;
        this.tedBlockValue = tedBlockValue;
        this.overdraftCheckingAccountValue = overdraftCheckingAccountValue;
        this.checkingAccountBalanceAvailableValue = checkingAccountBalanceAvailableValue;
        this.savingsBalanceValueInRelease = savingsBalanceValueInRelease;
        this.checkingInvestmentAccountBalanceValue = checkingInvestmentAccountBalanceValue;
        this.investmentAccount24HoursBlockValue = investmentAccount24HoursBlockValue;
        this.investmentAccount48HoursBlockValue = investmentAccount48HoursBlockValue;
        this.investmentAccountUnlimitedBlockValue = investmentAccountUnlimitedBlockValue;
        this.investmentAccountTotalBlockValue = investmentAccountTotalBlockValue;
        this.investmentAccountTEDBlockValue = investmentAccountTEDBlockValue;
        this.investmentAccountAvailableBalanceValue = investmentAccountAvailableBalanceValue;
        this.investmentAccountPlusCheckingAccountValue = investmentAccountPlusCheckingAccountValue;
        this.investmentAccountBalancePlusCheckningAccountPlusMaxValue = investmentAccountBalancePlusCheckningAccountPlusMaxValue;
        this.investimentAccountPlustCheckingAccountPlusMaxPlusAutomaticRedemptionValue = investimentAccountPlustCheckingAccountPlusMaxPlusAutomaticRedemptionValue;
        this.totalBlockedBalanceValue = totalBlockedBalanceValue;
        this.automaticRedemptionBalanceValue = automaticRedemptionBalanceValue;
        this.totalAvailableBalanceValue = totalAvailableBalanceValue;
        this.accumulatedCPMFBalanceValue = accumulatedCPMFBalanceValue;
        this.monthlyInterestedRate = monthlyInterestedRate;
        this.monthlyInsolvencyRate = monthlyInsolvencyRate;
        this.contractDueDate = contractDueDate;
        this.accumulatedInterestedValue = accumulatedInterestedValue;
        this.interestedBillingDate = interestedBillingDate;
        this.accumulatedIOFValue = accumulatedIOFValue;
        this.iofbillingdate = iofbillingdate;
        this.maxAccountIndicator = maxAccountIndicator;
        this.blockedCheckbookIndicator = blockedCheckbookIndicator;
        this.superCheckbookIndicator = superCheckbookIndicator;
        this.coverageCCIIndicator = coverageCCIIndicator;
        this.fundsAccountBalanceIndicator = fundsAccountBalanceIndicator;
        this.automaticRedemptionAccountIndicator = automaticRedemptionAccountIndicator;
        this.lastMoveDate = lastMoveDate;
        this.availableCreditValue = availableCreditValue;
        this.cpmfBillingIndicator = cpmfBillingIndicator;
        this.ndiasDaysQuantity = ndiasDaysQuantity;
        this.notChargedInterestedValue = notChargedInterestedValue;
        this.balanceSignal = balanceSignal;
        this.dailyBlockBalance = dailyBlockBalance;
        this.judicialBlockBalance = judicialBlockBalance;
        this.provisionedTotalBalance = provisionedTotalBalance;
        this.accumulatedInterestedsValues = accumulatedInterestedsValues;
        this.accumulatedIOFEndDateValue = accumulatedIOFEndDateValue;
        this.accumulatedCPMFValue = accumulatedCPMFValue;
        this.availableBalanceValue = availableBalanceValue;
        this.lastOverdraftUsageDate = lastOverdraftUsageDate;
        this.availableOverdraftValue = availableOverdraftValue;
        this.usedOverdraftValue = usedOverdraftValue;
        this.investmentOverdraftAvailableValue = investmentOverdraftAvailableValue;
        this.investmentOverdraftAvailableUsed = investmentOverdraftAvailableUsed;
        this.investmentOverdraftDueDate = investmentOverdraftDueDate;
        this.investmentOverdraftInterestRate = investmentOverdraftInterestRate;
        this.investmentOverdraftValue = investmentOverdraftValue;
        this.availableSantanderOverdraftValue = availableSantanderOverdraftValue;
        this.santanderDebitDay = santanderDebitDay;
        this.santanderInstallmentsQuantity = santanderInstallmentsQuantity;
        this.checkingAccountBlockedBalanceValuePlustInvestmentAccountPlusJudicialBlock = checkingAccountBlockedBalanceValuePlustInvestmentAccountPlusJudicialBlock;
        this.provisionedCreditPostingValue = provisionedCreditPostingValue;
        this.provisionedDebitPostingValue = provisionedDebitPostingValue;
        this.firstAndSecondOverdraftDescription = firstAndSecondOverdraftDescription;
        this.checkingAccountJudicialBlockBalanceValue = checkingAccountJudicialBlockBalanceValue;
        this.investimentAccountJudicialBlockBalanceValue = investimentAccountJudicialBlockBalanceValue;
        this.overdraftLenderInsuranceValue = overdraftLenderInsuranceValue;
        this.aea = aea;
    }

    public String getInvestimentBank() {
        return investimentBank;
    }

    public void setInvestimentBank(String investimentBank) {
        this.investimentBank = investimentBank;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withInvestimentBank(String investimentBank) {
        this.investimentBank = investimentBank;
        return this;
    }

    public String getInvestimentBranchCode() {
        return investimentBranchCode;
    }

    public void setInvestimentBranchCode(String investimentBranchCode) {
        this.investimentBranchCode = investimentBranchCode;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withInvestimentBranchCode(String investimentBranchCode) {
        this.investimentBranchCode = investimentBranchCode;
        return this;
    }

    public String getInvestimentAccountNumber() {
        return investimentAccountNumber;
    }

    public void setInvestimentAccountNumber(String investimentAccountNumber) {
        this.investimentAccountNumber = investimentAccountNumber;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withInvestimentAccountNumber(String investimentAccountNumber) {
        this.investimentAccountNumber = investimentAccountNumber;
        return this;
    }

    public String getBankDestinationAcccount() {
        return bankDestinationAcccount;
    }

    public void setBankDestinationAcccount(String bankDestinationAcccount) {
        this.bankDestinationAcccount = bankDestinationAcccount;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withBankDestinationAcccount(String bankDestinationAcccount) {
        this.bankDestinationAcccount = bankDestinationAcccount;
        return this;
    }

    public String getBranchDestinationBranch() {
        return branchDestinationBranch;
    }

    public void setBranchDestinationBranch(String branchDestinationBranch) {
        this.branchDestinationBranch = branchDestinationBranch;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withBranchDestinationBranch(String branchDestinationBranch) {
        this.branchDestinationBranch = branchDestinationBranch;
        return this;
    }

    public String getDestinationAccountNumber() {
        return destinationAccountNumber;
    }

    public void setDestinationAccountNumber(String destinationAccountNumber) {
        this.destinationAccountNumber = destinationAccountNumber;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withDestinationAccountNumber(String destinationAccountNumber) {
        this.destinationAccountNumber = destinationAccountNumber;
        return this;
    }

    public String getCheckingAccountBalance() {
        return checkingAccountBalance;
    }

    public void setCheckingAccountBalance(String checkingAccountBalance) {
        this.checkingAccountBalance = checkingAccountBalance;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withCheckingAccountBalance(String checkingAccountBalance) {
        this.checkingAccountBalance = checkingAccountBalance;
        return this;
    }

    public String getMaxAccountBalance() {
        return maxAccountBalance;
    }

    public void setMaxAccountBalance(String maxAccountBalance) {
        this.maxAccountBalance = maxAccountBalance;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withMaxAccountBalance(String maxAccountBalance) {
        this.maxAccountBalance = maxAccountBalance;
        return this;
    }

    public String getCheckingAccountBalancePlusMax() {
        return checkingAccountBalancePlusMax;
    }

    public void setCheckingAccountBalancePlusMax(String checkingAccountBalancePlusMax) {
        this.checkingAccountBalancePlusMax = checkingAccountBalancePlusMax;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withCheckingAccountBalancePlusMax(String checkingAccountBalancePlusMax) {
        this.checkingAccountBalancePlusMax = checkingAccountBalancePlusMax;
        return this;
    }

    public String getHoursBlockValue24() {
        return hoursBlockValue24;
    }

    public void setHoursBlockValue24(String hoursBlockValue24) {
        this.hoursBlockValue24 = hoursBlockValue24;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withHoursBlockValue24(String hoursBlockValue24) {
        this.hoursBlockValue24 = hoursBlockValue24;
        return this;
    }

    public String getHoursBlockValue48() {
        return hoursBlockValue48;
    }

    public void setHoursBlockValue48(String hoursBlockValue48) {
        this.hoursBlockValue48 = hoursBlockValue48;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withHoursBlockValue48(String hoursBlockValue48) {
        this.hoursBlockValue48 = hoursBlockValue48;
        return this;
    }

    public String getUnlimitedTimeBlockValue() {
        return unlimitedTimeBlockValue;
    }

    public void setUnlimitedTimeBlockValue(String unlimitedTimeBlockValue) {
        this.unlimitedTimeBlockValue = unlimitedTimeBlockValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withUnlimitedTimeBlockValue(String unlimitedTimeBlockValue) {
        this.unlimitedTimeBlockValue = unlimitedTimeBlockValue;
        return this;
    }

    public String getTotalBlockValue() {
        return totalBlockValue;
    }

    public void setTotalBlockValue(String totalBlockValue) {
        this.totalBlockValue = totalBlockValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withTotalBlockValue(String totalBlockValue) {
        this.totalBlockValue = totalBlockValue;
        return this;
    }

    public String getTedBlockValue() {
        return tedBlockValue;
    }

    public void setTedBlockValue(String tedBlockValue) {
        this.tedBlockValue = tedBlockValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withTedBlockValue(String tedBlockValue) {
        this.tedBlockValue = tedBlockValue;
        return this;
    }

    public String getOverdraftCheckingAccountValue() {
        return overdraftCheckingAccountValue;
    }

    public void setOverdraftCheckingAccountValue(String overdraftCheckingAccountValue) {
        this.overdraftCheckingAccountValue = overdraftCheckingAccountValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withOverdraftCheckingAccountValue(String overdraftCheckingAccountValue) {
        this.overdraftCheckingAccountValue = overdraftCheckingAccountValue;
        return this;
    }

    public String getCheckingAccountBalanceAvailableValue() {
        return checkingAccountBalanceAvailableValue;
    }

    public void setCheckingAccountBalanceAvailableValue(String checkingAccountBalanceAvailableValue) {
        this.checkingAccountBalanceAvailableValue = checkingAccountBalanceAvailableValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withCheckingAccountBalanceAvailableValue(String checkingAccountBalanceAvailableValue) {
        this.checkingAccountBalanceAvailableValue = checkingAccountBalanceAvailableValue;
        return this;
    }

    public String getSavingsBalanceValueInRelease() {
        return savingsBalanceValueInRelease;
    }

    public void setSavingsBalanceValueInRelease(String savingsBalanceValueInRelease) {
        this.savingsBalanceValueInRelease = savingsBalanceValueInRelease;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withSavingsBalanceValueInRelease(String savingsBalanceValueInRelease) {
        this.savingsBalanceValueInRelease = savingsBalanceValueInRelease;
        return this;
    }

    public String getCheckingInvestmentAccountBalanceValue() {
        return checkingInvestmentAccountBalanceValue;
    }

    public void setCheckingInvestmentAccountBalanceValue(String checkingInvestmentAccountBalanceValue) {
        this.checkingInvestmentAccountBalanceValue = checkingInvestmentAccountBalanceValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withCheckingInvestmentAccountBalanceValue(String checkingInvestmentAccountBalanceValue) {
        this.checkingInvestmentAccountBalanceValue = checkingInvestmentAccountBalanceValue;
        return this;
    }

    public String getInvestmentAccount24HoursBlockValue() {
        return investmentAccount24HoursBlockValue;
    }

    public void setInvestmentAccount24HoursBlockValue(String investmentAccount24HoursBlockValue) {
        this.investmentAccount24HoursBlockValue = investmentAccount24HoursBlockValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withInvestmentAccount24HoursBlockValue(String investmentAccount24HoursBlockValue) {
        this.investmentAccount24HoursBlockValue = investmentAccount24HoursBlockValue;
        return this;
    }

    public String getInvestmentAccount48HoursBlockValue() {
        return investmentAccount48HoursBlockValue;
    }

    public void setInvestmentAccount48HoursBlockValue(String investmentAccount48HoursBlockValue) {
        this.investmentAccount48HoursBlockValue = investmentAccount48HoursBlockValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withInvestmentAccount48HoursBlockValue(String investmentAccount48HoursBlockValue) {
        this.investmentAccount48HoursBlockValue = investmentAccount48HoursBlockValue;
        return this;
    }

    public String getInvestmentAccountUnlimitedBlockValue() {
        return investmentAccountUnlimitedBlockValue;
    }

    public void setInvestmentAccountUnlimitedBlockValue(String investmentAccountUnlimitedBlockValue) {
        this.investmentAccountUnlimitedBlockValue = investmentAccountUnlimitedBlockValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withInvestmentAccountUnlimitedBlockValue(String investmentAccountUnlimitedBlockValue) {
        this.investmentAccountUnlimitedBlockValue = investmentAccountUnlimitedBlockValue;
        return this;
    }

    public String getInvestmentAccountTotalBlockValue() {
        return investmentAccountTotalBlockValue;
    }

    public void setInvestmentAccountTotalBlockValue(String investmentAccountTotalBlockValue) {
        this.investmentAccountTotalBlockValue = investmentAccountTotalBlockValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withInvestmentAccountTotalBlockValue(String investmentAccountTotalBlockValue) {
        this.investmentAccountTotalBlockValue = investmentAccountTotalBlockValue;
        return this;
    }

    public String getInvestmentAccountTEDBlockValue() {
        return investmentAccountTEDBlockValue;
    }

    public void setInvestmentAccountTEDBlockValue(String investmentAccountTEDBlockValue) {
        this.investmentAccountTEDBlockValue = investmentAccountTEDBlockValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withInvestmentAccountTEDBlockValue(String investmentAccountTEDBlockValue) {
        this.investmentAccountTEDBlockValue = investmentAccountTEDBlockValue;
        return this;
    }

    public String getInvestmentAccountAvailableBalanceValue() {
        return investmentAccountAvailableBalanceValue;
    }

    public void setInvestmentAccountAvailableBalanceValue(String investmentAccountAvailableBalanceValue) {
        this.investmentAccountAvailableBalanceValue = investmentAccountAvailableBalanceValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withInvestmentAccountAvailableBalanceValue(String investmentAccountAvailableBalanceValue) {
        this.investmentAccountAvailableBalanceValue = investmentAccountAvailableBalanceValue;
        return this;
    }

    public String getInvestmentAccountPlusCheckingAccountValue() {
        return investmentAccountPlusCheckingAccountValue;
    }

    public void setInvestmentAccountPlusCheckingAccountValue(String investmentAccountPlusCheckingAccountValue) {
        this.investmentAccountPlusCheckingAccountValue = investmentAccountPlusCheckingAccountValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withInvestmentAccountPlusCheckingAccountValue(String investmentAccountPlusCheckingAccountValue) {
        this.investmentAccountPlusCheckingAccountValue = investmentAccountPlusCheckingAccountValue;
        return this;
    }

    public String getInvestmentAccountBalancePlusCheckningAccountPlusMaxValue() {
        return investmentAccountBalancePlusCheckningAccountPlusMaxValue;
    }

    public void setInvestmentAccountBalancePlusCheckningAccountPlusMaxValue(String investmentAccountBalancePlusCheckningAccountPlusMaxValue) {
        this.investmentAccountBalancePlusCheckningAccountPlusMaxValue = investmentAccountBalancePlusCheckningAccountPlusMaxValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withInvestmentAccountBalancePlusCheckningAccountPlusMaxValue(String investmentAccountBalancePlusCheckningAccountPlusMaxValue) {
        this.investmentAccountBalancePlusCheckningAccountPlusMaxValue = investmentAccountBalancePlusCheckningAccountPlusMaxValue;
        return this;
    }

    public String getInvestimentAccountPlustCheckingAccountPlusMaxPlusAutomaticRedemptionValue() {
        return investimentAccountPlustCheckingAccountPlusMaxPlusAutomaticRedemptionValue;
    }

    public void setInvestimentAccountPlustCheckingAccountPlusMaxPlusAutomaticRedemptionValue(String investimentAccountPlustCheckingAccountPlusMaxPlusAutomaticRedemptionValue) {
        this.investimentAccountPlustCheckingAccountPlusMaxPlusAutomaticRedemptionValue = investimentAccountPlustCheckingAccountPlusMaxPlusAutomaticRedemptionValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withInvestimentAccountPlustCheckingAccountPlusMaxPlusAutomaticRedemptionValue(String investimentAccountPlustCheckingAccountPlusMaxPlusAutomaticRedemptionValue) {
        this.investimentAccountPlustCheckingAccountPlusMaxPlusAutomaticRedemptionValue = investimentAccountPlustCheckingAccountPlusMaxPlusAutomaticRedemptionValue;
        return this;
    }

    public String getTotalBlockedBalanceValue() {
        return totalBlockedBalanceValue;
    }

    public void setTotalBlockedBalanceValue(String totalBlockedBalanceValue) {
        this.totalBlockedBalanceValue = totalBlockedBalanceValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withTotalBlockedBalanceValue(String totalBlockedBalanceValue) {
        this.totalBlockedBalanceValue = totalBlockedBalanceValue;
        return this;
    }

    public String getAutomaticRedemptionBalanceValue() {
        return automaticRedemptionBalanceValue;
    }

    public void setAutomaticRedemptionBalanceValue(String automaticRedemptionBalanceValue) {
        this.automaticRedemptionBalanceValue = automaticRedemptionBalanceValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withAutomaticRedemptionBalanceValue(String automaticRedemptionBalanceValue) {
        this.automaticRedemptionBalanceValue = automaticRedemptionBalanceValue;
        return this;
    }

    public String getTotalAvailableBalanceValue() {
        return totalAvailableBalanceValue;
    }

    public void setTotalAvailableBalanceValue(String totalAvailableBalanceValue) {
        this.totalAvailableBalanceValue = totalAvailableBalanceValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withTotalAvailableBalanceValue(String totalAvailableBalanceValue) {
        this.totalAvailableBalanceValue = totalAvailableBalanceValue;
        return this;
    }

    public String getAccumulatedCPMFBalanceValue() {
        return accumulatedCPMFBalanceValue;
    }

    public void setAccumulatedCPMFBalanceValue(String accumulatedCPMFBalanceValue) {
        this.accumulatedCPMFBalanceValue = accumulatedCPMFBalanceValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withAccumulatedCPMFBalanceValue(String accumulatedCPMFBalanceValue) {
        this.accumulatedCPMFBalanceValue = accumulatedCPMFBalanceValue;
        return this;
    }

    public String getMonthlyInterestedRate() {
        return monthlyInterestedRate;
    }

    public void setMonthlyInterestedRate(String monthlyInterestedRate) {
        this.monthlyInterestedRate = monthlyInterestedRate;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withMonthlyInterestedRate(String monthlyInterestedRate) {
        this.monthlyInterestedRate = monthlyInterestedRate;
        return this;
    }

    public String getMonthlyInsolvencyRate() {
        return monthlyInsolvencyRate;
    }

    public void setMonthlyInsolvencyRate(String monthlyInsolvencyRate) {
        this.monthlyInsolvencyRate = monthlyInsolvencyRate;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withMonthlyInsolvencyRate(String monthlyInsolvencyRate) {
        this.monthlyInsolvencyRate = monthlyInsolvencyRate;
        return this;
    }

    public String getContractDueDate() {
        return contractDueDate;
    }

    public void setContractDueDate(String contractDueDate) {
        this.contractDueDate = contractDueDate;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withContractDueDate(String contractDueDate) {
        this.contractDueDate = contractDueDate;
        return this;
    }

    public String getAccumulatedInterestedValue() {
        return accumulatedInterestedValue;
    }

    public void setAccumulatedInterestedValue(String accumulatedInterestedValue) {
        this.accumulatedInterestedValue = accumulatedInterestedValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withAccumulatedInterestedValue(String accumulatedInterestedValue) {
        this.accumulatedInterestedValue = accumulatedInterestedValue;
        return this;
    }

    public String getInterestedBillingDate() {
        return interestedBillingDate;
    }

    public void setInterestedBillingDate(String interestedBillingDate) {
        this.interestedBillingDate = interestedBillingDate;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withInterestedBillingDate(String interestedBillingDate) {
        this.interestedBillingDate = interestedBillingDate;
        return this;
    }

    public String getAccumulatedIOFValue() {
        return accumulatedIOFValue;
    }

    public void setAccumulatedIOFValue(String accumulatedIOFValue) {
        this.accumulatedIOFValue = accumulatedIOFValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withAccumulatedIOFValue(String accumulatedIOFValue) {
        this.accumulatedIOFValue = accumulatedIOFValue;
        return this;
    }

    public String getIofbillingdate() {
        return iofbillingdate;
    }

    public void setIofbillingdate(String iofbillingdate) {
        this.iofbillingdate = iofbillingdate;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withIofbillingdate(String iofbillingdate) {
        this.iofbillingdate = iofbillingdate;
        return this;
    }

    public String getMaxAccountIndicator() {
        return maxAccountIndicator;
    }

    public void setMaxAccountIndicator(String maxAccountIndicator) {
        this.maxAccountIndicator = maxAccountIndicator;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withMaxAccountIndicator(String maxAccountIndicator) {
        this.maxAccountIndicator = maxAccountIndicator;
        return this;
    }

    public String getBlockedCheckbookIndicator() {
        return blockedCheckbookIndicator;
    }

    public void setBlockedCheckbookIndicator(String blockedCheckbookIndicator) {
        this.blockedCheckbookIndicator = blockedCheckbookIndicator;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withBlockedCheckbookIndicator(String blockedCheckbookIndicator) {
        this.blockedCheckbookIndicator = blockedCheckbookIndicator;
        return this;
    }

    public String getSuperCheckbookIndicator() {
        return superCheckbookIndicator;
    }

    public void setSuperCheckbookIndicator(String superCheckbookIndicator) {
        this.superCheckbookIndicator = superCheckbookIndicator;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withSuperCheckbookIndicator(String superCheckbookIndicator) {
        this.superCheckbookIndicator = superCheckbookIndicator;
        return this;
    }

    public String getCoverageCCIIndicator() {
        return coverageCCIIndicator;
    }

    public void setCoverageCCIIndicator(String coverageCCIIndicator) {
        this.coverageCCIIndicator = coverageCCIIndicator;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withCoverageCCIIndicator(String coverageCCIIndicator) {
        this.coverageCCIIndicator = coverageCCIIndicator;
        return this;
    }

    public String getFundsAccountBalanceIndicator() {
        return fundsAccountBalanceIndicator;
    }

    public void setFundsAccountBalanceIndicator(String fundsAccountBalanceIndicator) {
        this.fundsAccountBalanceIndicator = fundsAccountBalanceIndicator;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withFundsAccountBalanceIndicator(String fundsAccountBalanceIndicator) {
        this.fundsAccountBalanceIndicator = fundsAccountBalanceIndicator;
        return this;
    }

    public String getAutomaticRedemptionAccountIndicator() {
        return automaticRedemptionAccountIndicator;
    }

    public void setAutomaticRedemptionAccountIndicator(String automaticRedemptionAccountIndicator) {
        this.automaticRedemptionAccountIndicator = automaticRedemptionAccountIndicator;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withAutomaticRedemptionAccountIndicator(String automaticRedemptionAccountIndicator) {
        this.automaticRedemptionAccountIndicator = automaticRedemptionAccountIndicator;
        return this;
    }

    public String getLastMoveDate() {
        return lastMoveDate;
    }

    public void setLastMoveDate(String lastMoveDate) {
        this.lastMoveDate = lastMoveDate;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withLastMoveDate(String lastMoveDate) {
        this.lastMoveDate = lastMoveDate;
        return this;
    }

    public String getAvailableCreditValue() {
        return availableCreditValue;
    }

    public void setAvailableCreditValue(String availableCreditValue) {
        this.availableCreditValue = availableCreditValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withAvailableCreditValue(String availableCreditValue) {
        this.availableCreditValue = availableCreditValue;
        return this;
    }

    public String getCpmfBillingIndicator() {
        return cpmfBillingIndicator;
    }

    public void setCpmfBillingIndicator(String cpmfBillingIndicator) {
        this.cpmfBillingIndicator = cpmfBillingIndicator;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withCpmfBillingIndicator(String cpmfBillingIndicator) {
        this.cpmfBillingIndicator = cpmfBillingIndicator;
        return this;
    }

    public String getNdiasDaysQuantity() {
        return ndiasDaysQuantity;
    }

    public void setNdiasDaysQuantity(String ndiasDaysQuantity) {
        this.ndiasDaysQuantity = ndiasDaysQuantity;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withNdiasDaysQuantity(String ndiasDaysQuantity) {
        this.ndiasDaysQuantity = ndiasDaysQuantity;
        return this;
    }

    public String getNotChargedInterestedValue() {
        return notChargedInterestedValue;
    }

    public void setNotChargedInterestedValue(String notChargedInterestedValue) {
        this.notChargedInterestedValue = notChargedInterestedValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withNotChargedInterestedValue(String notChargedInterestedValue) {
        this.notChargedInterestedValue = notChargedInterestedValue;
        return this;
    }

    public String getBalanceSignal() {
        return balanceSignal;
    }

    public void setBalanceSignal(String balanceSignal) {
        this.balanceSignal = balanceSignal;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withBalanceSignal(String balanceSignal) {
        this.balanceSignal = balanceSignal;
        return this;
    }

    public String getDailyBlockBalance() {
        return dailyBlockBalance;
    }

    public void setDailyBlockBalance(String dailyBlockBalance) {
        this.dailyBlockBalance = dailyBlockBalance;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withDailyBlockBalance(String dailyBlockBalance) {
        this.dailyBlockBalance = dailyBlockBalance;
        return this;
    }

    public String getJudicialBlockBalance() {
        return judicialBlockBalance;
    }

    public void setJudicialBlockBalance(String judicialBlockBalance) {
        this.judicialBlockBalance = judicialBlockBalance;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withJudicialBlockBalance(String judicialBlockBalance) {
        this.judicialBlockBalance = judicialBlockBalance;
        return this;
    }

    public String getProvisionedTotalBalance() {
        return provisionedTotalBalance;
    }

    public void setProvisionedTotalBalance(String provisionedTotalBalance) {
        this.provisionedTotalBalance = provisionedTotalBalance;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withProvisionedTotalBalance(String provisionedTotalBalance) {
        this.provisionedTotalBalance = provisionedTotalBalance;
        return this;
    }

    public String getAccumulatedInterestedsValues() {
        return accumulatedInterestedsValues;
    }

    public void setAccumulatedInterestedsValues(String accumulatedInterestedsValues) {
        this.accumulatedInterestedsValues = accumulatedInterestedsValues;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withAccumulatedInterestedsValues(String accumulatedInterestedsValues) {
        this.accumulatedInterestedsValues = accumulatedInterestedsValues;
        return this;
    }

    public String getAccumulatedIOFEndDateValue() {
        return accumulatedIOFEndDateValue;
    }

    public void setAccumulatedIOFEndDateValue(String accumulatedIOFEndDateValue) {
        this.accumulatedIOFEndDateValue = accumulatedIOFEndDateValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withAccumulatedIOFEndDateValue(String accumulatedIOFEndDateValue) {
        this.accumulatedIOFEndDateValue = accumulatedIOFEndDateValue;
        return this;
    }

    public String getAccumulatedCPMFValue() {
        return accumulatedCPMFValue;
    }

    public void setAccumulatedCPMFValue(String accumulatedCPMFValue) {
        this.accumulatedCPMFValue = accumulatedCPMFValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withAccumulatedCPMFValue(String accumulatedCPMFValue) {
        this.accumulatedCPMFValue = accumulatedCPMFValue;
        return this;
    }

    public String getAvailableBalanceValue() {
        return availableBalanceValue;
    }

    public void setAvailableBalanceValue(String availableBalanceValue) {
        this.availableBalanceValue = availableBalanceValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withAvailableBalanceValue(String availableBalanceValue) {
        this.availableBalanceValue = availableBalanceValue;
        return this;
    }

    public String getLastOverdraftUsageDate() {
        return lastOverdraftUsageDate;
    }

    public void setLastOverdraftUsageDate(String lastOverdraftUsageDate) {
        this.lastOverdraftUsageDate = lastOverdraftUsageDate;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withLastOverdraftUsageDate(String lastOverdraftUsageDate) {
        this.lastOverdraftUsageDate = lastOverdraftUsageDate;
        return this;
    }

    public String getAvailableOverdraftValue() {
        return availableOverdraftValue;
    }

    public void setAvailableOverdraftValue(String availableOverdraftValue) {
        this.availableOverdraftValue = availableOverdraftValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withAvailableOverdraftValue(String availableOverdraftValue) {
        this.availableOverdraftValue = availableOverdraftValue;
        return this;
    }

    public String getUsedOverdraftValue() {
        return usedOverdraftValue;
    }

    public void setUsedOverdraftValue(String usedOverdraftValue) {
        this.usedOverdraftValue = usedOverdraftValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withUsedOverdraftValue(String usedOverdraftValue) {
        this.usedOverdraftValue = usedOverdraftValue;
        return this;
    }

    public String getInvestmentOverdraftAvailableValue() {
        return investmentOverdraftAvailableValue;
    }

    public void setInvestmentOverdraftAvailableValue(String investmentOverdraftAvailableValue) {
        this.investmentOverdraftAvailableValue = investmentOverdraftAvailableValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withInvestmentOverdraftAvailableValue(String investmentOverdraftAvailableValue) {
        this.investmentOverdraftAvailableValue = investmentOverdraftAvailableValue;
        return this;
    }

    public String getInvestmentOverdraftAvailableUsed() {
        return investmentOverdraftAvailableUsed;
    }

    public void setInvestmentOverdraftAvailableUsed(String investmentOverdraftAvailableUsed) {
        this.investmentOverdraftAvailableUsed = investmentOverdraftAvailableUsed;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withInvestmentOverdraftAvailableUsed(String investmentOverdraftAvailableUsed) {
        this.investmentOverdraftAvailableUsed = investmentOverdraftAvailableUsed;
        return this;
    }

    public String getInvestmentOverdraftDueDate() {
        return investmentOverdraftDueDate;
    }

    public void setInvestmentOverdraftDueDate(String investmentOverdraftDueDate) {
        this.investmentOverdraftDueDate = investmentOverdraftDueDate;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withInvestmentOverdraftDueDate(String investmentOverdraftDueDate) {
        this.investmentOverdraftDueDate = investmentOverdraftDueDate;
        return this;
    }

    public String getInvestmentOverdraftInterestRate() {
        return investmentOverdraftInterestRate;
    }

    public void setInvestmentOverdraftInterestRate(String investmentOverdraftInterestRate) {
        this.investmentOverdraftInterestRate = investmentOverdraftInterestRate;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withInvestmentOverdraftInterestRate(String investmentOverdraftInterestRate) {
        this.investmentOverdraftInterestRate = investmentOverdraftInterestRate;
        return this;
    }

    public String getInvestmentOverdraftValue() {
        return investmentOverdraftValue;
    }

    public void setInvestmentOverdraftValue(String investmentOverdraftValue) {
        this.investmentOverdraftValue = investmentOverdraftValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withInvestmentOverdraftValue(String investmentOverdraftValue) {
        this.investmentOverdraftValue = investmentOverdraftValue;
        return this;
    }

    public String getAvailableSantanderOverdraftValue() {
        return availableSantanderOverdraftValue;
    }

    public void setAvailableSantanderOverdraftValue(String availableSantanderOverdraftValue) {
        this.availableSantanderOverdraftValue = availableSantanderOverdraftValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withAvailableSantanderOverdraftValue(String availableSantanderOverdraftValue) {
        this.availableSantanderOverdraftValue = availableSantanderOverdraftValue;
        return this;
    }

    public String getSantanderDebitDay() {
        return santanderDebitDay;
    }

    public void setSantanderDebitDay(String santanderDebitDay) {
        this.santanderDebitDay = santanderDebitDay;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withSantanderDebitDay(String santanderDebitDay) {
        this.santanderDebitDay = santanderDebitDay;
        return this;
    }

    public String getSantanderInstallmentsQuantity() {
        return santanderInstallmentsQuantity;
    }

    public void setSantanderInstallmentsQuantity(String santanderInstallmentsQuantity) {
        this.santanderInstallmentsQuantity = santanderInstallmentsQuantity;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withSantanderInstallmentsQuantity(String santanderInstallmentsQuantity) {
        this.santanderInstallmentsQuantity = santanderInstallmentsQuantity;
        return this;
    }

    public String getCheckingAccountBlockedBalanceValuePlustInvestmentAccountPlusJudicialBlock() {
        return checkingAccountBlockedBalanceValuePlustInvestmentAccountPlusJudicialBlock;
    }

    public void setCheckingAccountBlockedBalanceValuePlustInvestmentAccountPlusJudicialBlock(String checkingAccountBlockedBalanceValuePlustInvestmentAccountPlusJudicialBlock) {
        this.checkingAccountBlockedBalanceValuePlustInvestmentAccountPlusJudicialBlock = checkingAccountBlockedBalanceValuePlustInvestmentAccountPlusJudicialBlock;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withCheckingAccountBlockedBalanceValuePlustInvestmentAccountPlusJudicialBlock(String checkingAccountBlockedBalanceValuePlustInvestmentAccountPlusJudicialBlock) {
        this.checkingAccountBlockedBalanceValuePlustInvestmentAccountPlusJudicialBlock = checkingAccountBlockedBalanceValuePlustInvestmentAccountPlusJudicialBlock;
        return this;
    }

    public String getProvisionedCreditPostingValue() {
        return provisionedCreditPostingValue;
    }

    public void setProvisionedCreditPostingValue(String provisionedCreditPostingValue) {
        this.provisionedCreditPostingValue = provisionedCreditPostingValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withProvisionedCreditPostingValue(String provisionedCreditPostingValue) {
        this.provisionedCreditPostingValue = provisionedCreditPostingValue;
        return this;
    }

    public String getProvisionedDebitPostingValue() {
        return provisionedDebitPostingValue;
    }

    public void setProvisionedDebitPostingValue(String provisionedDebitPostingValue) {
        this.provisionedDebitPostingValue = provisionedDebitPostingValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withProvisionedDebitPostingValue(String provisionedDebitPostingValue) {
        this.provisionedDebitPostingValue = provisionedDebitPostingValue;
        return this;
    }

    public String getFirstAndSecondOverdraftDescription() {
        return firstAndSecondOverdraftDescription;
    }

    public void setFirstAndSecondOverdraftDescription(String firstAndSecondOverdraftDescription) {
        this.firstAndSecondOverdraftDescription = firstAndSecondOverdraftDescription;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withFirstAndSecondOverdraftDescription(String firstAndSecondOverdraftDescription) {
        this.firstAndSecondOverdraftDescription = firstAndSecondOverdraftDescription;
        return this;
    }

    public String getCheckingAccountJudicialBlockBalanceValue() {
        return checkingAccountJudicialBlockBalanceValue;
    }

    public void setCheckingAccountJudicialBlockBalanceValue(String checkingAccountJudicialBlockBalanceValue) {
        this.checkingAccountJudicialBlockBalanceValue = checkingAccountJudicialBlockBalanceValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withCheckingAccountJudicialBlockBalanceValue(String checkingAccountJudicialBlockBalanceValue) {
        this.checkingAccountJudicialBlockBalanceValue = checkingAccountJudicialBlockBalanceValue;
        return this;
    }

    public String getInvestimentAccountJudicialBlockBalanceValue() {
        return investimentAccountJudicialBlockBalanceValue;
    }

    public void setInvestimentAccountJudicialBlockBalanceValue(String investimentAccountJudicialBlockBalanceValue) {
        this.investimentAccountJudicialBlockBalanceValue = investimentAccountJudicialBlockBalanceValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withInvestimentAccountJudicialBlockBalanceValue(String investimentAccountJudicialBlockBalanceValue) {
        this.investimentAccountJudicialBlockBalanceValue = investimentAccountJudicialBlockBalanceValue;
        return this;
    }

    public String getOverdraftLenderInsuranceValue() {
        return overdraftLenderInsuranceValue;
    }

    public void setOverdraftLenderInsuranceValue(String overdraftLenderInsuranceValue) {
        this.overdraftLenderInsuranceValue = overdraftLenderInsuranceValue;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withOverdraftLenderInsuranceValue(String overdraftLenderInsuranceValue) {
        this.overdraftLenderInsuranceValue = overdraftLenderInsuranceValue;
        return this;
    }

    public String getAea() {
        return aea;
    }

    public void setAea(String aea) {
        this.aea = aea;
    }

    public SaldoDetalhadoContaCorrenteResponseDTO withAea(String aea) {
        this.aea = aea;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(investimentBank).append(investimentBranchCode).append(investimentAccountNumber).append(bankDestinationAcccount).append(branchDestinationBranch).append(destinationAccountNumber).append(checkingAccountBalance).append(maxAccountBalance).append(checkingAccountBalancePlusMax).append(hoursBlockValue24).append(hoursBlockValue48).append(unlimitedTimeBlockValue).append(totalBlockValue).append(tedBlockValue).append(overdraftCheckingAccountValue).append(checkingAccountBalanceAvailableValue).append(savingsBalanceValueInRelease).append(checkingInvestmentAccountBalanceValue).append(investmentAccount24HoursBlockValue).append(investmentAccount48HoursBlockValue).append(investmentAccountUnlimitedBlockValue).append(investmentAccountTotalBlockValue).append(investmentAccountTEDBlockValue).append(investmentAccountAvailableBalanceValue).append(investmentAccountPlusCheckingAccountValue).append(investmentAccountBalancePlusCheckningAccountPlusMaxValue).append(investimentAccountPlustCheckingAccountPlusMaxPlusAutomaticRedemptionValue).append(totalBlockedBalanceValue).append(automaticRedemptionBalanceValue).append(totalAvailableBalanceValue).append(accumulatedCPMFBalanceValue).append(monthlyInterestedRate).append(monthlyInsolvencyRate).append(contractDueDate).append(accumulatedInterestedValue).append(interestedBillingDate).append(accumulatedIOFValue).append(iofbillingdate).append(maxAccountIndicator).append(blockedCheckbookIndicator).append(superCheckbookIndicator).append(coverageCCIIndicator).append(fundsAccountBalanceIndicator).append(automaticRedemptionAccountIndicator).append(lastMoveDate).append(availableCreditValue).append(cpmfBillingIndicator).append(ndiasDaysQuantity).append(notChargedInterestedValue).append(balanceSignal).append(dailyBlockBalance).append(judicialBlockBalance).append(provisionedTotalBalance).append(accumulatedInterestedsValues).append(accumulatedIOFEndDateValue).append(accumulatedCPMFValue).append(availableBalanceValue).append(lastOverdraftUsageDate).append(availableOverdraftValue).append(usedOverdraftValue).append(investmentOverdraftAvailableValue).append(investmentOverdraftAvailableUsed).append(investmentOverdraftDueDate).append(investmentOverdraftInterestRate).append(investmentOverdraftValue).append(availableSantanderOverdraftValue).append(santanderDebitDay).append(santanderInstallmentsQuantity).append(checkingAccountBlockedBalanceValuePlustInvestmentAccountPlusJudicialBlock).append(provisionedCreditPostingValue).append(provisionedDebitPostingValue).append(firstAndSecondOverdraftDescription).append(checkingAccountJudicialBlockBalanceValue).append(investimentAccountJudicialBlockBalanceValue).append(overdraftLenderInsuranceValue).append(aea).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof SaldoDetalhadoContaCorrenteResponseDTO) == false) {
            return false;
        }
        SaldoDetalhadoContaCorrenteResponseDTO rhs = ((SaldoDetalhadoContaCorrenteResponseDTO) other);
        return new EqualsBuilder().append(investimentBank, rhs.investimentBank).append(investimentBranchCode, rhs.investimentBranchCode).append(investimentAccountNumber, rhs.investimentAccountNumber).append(bankDestinationAcccount, rhs.bankDestinationAcccount).append(branchDestinationBranch, rhs.branchDestinationBranch).append(destinationAccountNumber, rhs.destinationAccountNumber).append(checkingAccountBalance, rhs.checkingAccountBalance).append(maxAccountBalance, rhs.maxAccountBalance).append(checkingAccountBalancePlusMax, rhs.checkingAccountBalancePlusMax).append(hoursBlockValue24, rhs.hoursBlockValue24).append(hoursBlockValue48, rhs.hoursBlockValue48).append(unlimitedTimeBlockValue, rhs.unlimitedTimeBlockValue).append(totalBlockValue, rhs.totalBlockValue).append(tedBlockValue, rhs.tedBlockValue).append(overdraftCheckingAccountValue, rhs.overdraftCheckingAccountValue).append(checkingAccountBalanceAvailableValue, rhs.checkingAccountBalanceAvailableValue).append(savingsBalanceValueInRelease, rhs.savingsBalanceValueInRelease).append(checkingInvestmentAccountBalanceValue, rhs.checkingInvestmentAccountBalanceValue).append(investmentAccount24HoursBlockValue, rhs.investmentAccount24HoursBlockValue).append(investmentAccount48HoursBlockValue, rhs.investmentAccount48HoursBlockValue).append(investmentAccountUnlimitedBlockValue, rhs.investmentAccountUnlimitedBlockValue).append(investmentAccountTotalBlockValue, rhs.investmentAccountTotalBlockValue).append(investmentAccountTEDBlockValue, rhs.investmentAccountTEDBlockValue).append(investmentAccountAvailableBalanceValue, rhs.investmentAccountAvailableBalanceValue).append(investmentAccountPlusCheckingAccountValue, rhs.investmentAccountPlusCheckingAccountValue).append(investmentAccountBalancePlusCheckningAccountPlusMaxValue, rhs.investmentAccountBalancePlusCheckningAccountPlusMaxValue).append(investimentAccountPlustCheckingAccountPlusMaxPlusAutomaticRedemptionValue, rhs.investimentAccountPlustCheckingAccountPlusMaxPlusAutomaticRedemptionValue).append(totalBlockedBalanceValue, rhs.totalBlockedBalanceValue).append(automaticRedemptionBalanceValue, rhs.automaticRedemptionBalanceValue).append(totalAvailableBalanceValue, rhs.totalAvailableBalanceValue).append(accumulatedCPMFBalanceValue, rhs.accumulatedCPMFBalanceValue).append(monthlyInterestedRate, rhs.monthlyInterestedRate).append(monthlyInsolvencyRate, rhs.monthlyInsolvencyRate).append(contractDueDate, rhs.contractDueDate).append(accumulatedInterestedValue, rhs.accumulatedInterestedValue).append(interestedBillingDate, rhs.interestedBillingDate).append(accumulatedIOFValue, rhs.accumulatedIOFValue).append(iofbillingdate, rhs.iofbillingdate).append(maxAccountIndicator, rhs.maxAccountIndicator).append(blockedCheckbookIndicator, rhs.blockedCheckbookIndicator).append(superCheckbookIndicator, rhs.superCheckbookIndicator).append(coverageCCIIndicator, rhs.coverageCCIIndicator).append(fundsAccountBalanceIndicator, rhs.fundsAccountBalanceIndicator).append(automaticRedemptionAccountIndicator, rhs.automaticRedemptionAccountIndicator).append(lastMoveDate, rhs.lastMoveDate).append(availableCreditValue, rhs.availableCreditValue).append(cpmfBillingIndicator, rhs.cpmfBillingIndicator).append(ndiasDaysQuantity, rhs.ndiasDaysQuantity).append(notChargedInterestedValue, rhs.notChargedInterestedValue).append(balanceSignal, rhs.balanceSignal).append(dailyBlockBalance, rhs.dailyBlockBalance).append(judicialBlockBalance, rhs.judicialBlockBalance).append(provisionedTotalBalance, rhs.provisionedTotalBalance).append(accumulatedInterestedsValues, rhs.accumulatedInterestedsValues).append(accumulatedIOFEndDateValue, rhs.accumulatedIOFEndDateValue).append(accumulatedCPMFValue, rhs.accumulatedCPMFValue).append(availableBalanceValue, rhs.availableBalanceValue).append(lastOverdraftUsageDate, rhs.lastOverdraftUsageDate).append(availableOverdraftValue, rhs.availableOverdraftValue).append(usedOverdraftValue, rhs.usedOverdraftValue).append(investmentOverdraftAvailableValue, rhs.investmentOverdraftAvailableValue).append(investmentOverdraftAvailableUsed, rhs.investmentOverdraftAvailableUsed).append(investmentOverdraftDueDate, rhs.investmentOverdraftDueDate).append(investmentOverdraftInterestRate, rhs.investmentOverdraftInterestRate).append(investmentOverdraftValue, rhs.investmentOverdraftValue).append(availableSantanderOverdraftValue, rhs.availableSantanderOverdraftValue).append(santanderDebitDay, rhs.santanderDebitDay).append(santanderInstallmentsQuantity, rhs.santanderInstallmentsQuantity).append(checkingAccountBlockedBalanceValuePlustInvestmentAccountPlusJudicialBlock, rhs.checkingAccountBlockedBalanceValuePlustInvestmentAccountPlusJudicialBlock).append(provisionedCreditPostingValue, rhs.provisionedCreditPostingValue).append(provisionedDebitPostingValue, rhs.provisionedDebitPostingValue).append(firstAndSecondOverdraftDescription, rhs.firstAndSecondOverdraftDescription).append(checkingAccountJudicialBlockBalanceValue, rhs.checkingAccountJudicialBlockBalanceValue).append(investimentAccountJudicialBlockBalanceValue, rhs.investimentAccountJudicialBlockBalanceValue).append(overdraftLenderInsuranceValue, rhs.overdraftLenderInsuranceValue).append(aea, rhs.aea).isEquals();
    }

}