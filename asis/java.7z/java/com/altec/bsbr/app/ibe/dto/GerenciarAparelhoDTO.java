package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class GerenciarAparelhoDTO  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4726232007633755531L;
	
	
	

}
