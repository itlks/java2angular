package com.altec.bsbr.app.ibe.dto.agendamentos;

public class FaturaDTO {

	
	private String numeroDoCartao;
	private String contaCorrenteDebito;
	
	
	public String getNumeroDoCartao() {
		return numeroDoCartao;
	}
	public void setNumeroDoCartao(String numeroDoCartao) {
		this.numeroDoCartao = numeroDoCartao;
	}
	public String getContaCorrenteDebito() {
		return contaCorrenteDebito;
	}
	public void setContaCorrenteDebito(String contaCorrenteDebito) {
		this.contaCorrenteDebito = contaCorrenteDebito;
	}
}
