package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class LancamentosPendentesOuFuturosDTO implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 9186142143978657494L;
	private String banco;
	private String agencia; 
	private String conta;
	private String canal;
	private String dataAtual; 
	private String dataLimite;
	private String horaAtual;
	private String quantidadeDias;
	private String NSU;
	private String numeroDDDLlamada;
	private String numeroTelefonoLlamada;
	private String paginacaoDataMovimento;
	private String paginacaoNumeroMovimento;
	private List<LancamentoDTO> listaLancamento = new ArrayList<LancamentoDTO>();
	
	public String getBanco() {
		return banco;
	}
	public void setBanco(String banco) {
		this.banco = banco;
	}
	public String getAgencia() {
		return agencia;
	}
	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getConta() {
		return conta;
	}
	public void setConta(String conta) {
		this.conta = conta;
	}
	public String getCanal() {
		return canal;
	}
	public void setCanal(String canal) {
		this.canal = canal;
	}
	public String getDataAtual() {
		return dataAtual;
	}
	public void setDataAtual(String dataAtual) {
		this.dataAtual = dataAtual;
	}
	public String getQuantidadeDias() {
		return quantidadeDias;
	}
	public void setQuantidadeDias(String quantidadeDias) {
		this.quantidadeDias = quantidadeDias;
	}
	public String getNSU() {
		return NSU;
	}
	public void setNSU(String nSU) {
		NSU = nSU;
	}
	public String getNumeroDDDLlamada() {
		return numeroDDDLlamada;
	}
	public void setNumeroDDDLlamada(String numeroDDDLlamada) {
		this.numeroDDDLlamada = numeroDDDLlamada;
	}
	public String getNumeroTelefonoLlamada() {
		return numeroTelefonoLlamada;
	}
	public void setNumeroTelefonoLlamada(String numeroTelefonoLlamada) {
		this.numeroTelefonoLlamada = numeroTelefonoLlamada;
	}
	public String getPaginacaoDataMovimento() {
		return paginacaoDataMovimento;
	}
	public void setPaginacaoDataMovimento(String paginacaoDataMovimento) {
		this.paginacaoDataMovimento = paginacaoDataMovimento;
	}
	public String getPaginacaoNumeroMovimento() {
		return paginacaoNumeroMovimento;
	}
	public void setPaginacaoNumeroMovimento(String paginacaoNumeroMovimento) {
		this.paginacaoNumeroMovimento = paginacaoNumeroMovimento;
	}
	/**
	 * @return the listaLancamento
	 */
	public List<LancamentoDTO> getListaLancamento() {
		return listaLancamento;
	}
	/**
	 * @param listaLancamento the listaLancamento to set
	 */
	public void setListaLancamento(List<LancamentoDTO> listaLancamento) {
		this.listaLancamento = listaLancamento;
	}
	/**
	 * @return the dataLimite
	 */
	public String getDataLimite() {
		return dataLimite;
	}
	/**
	 * @param dataLimite the dataLimite to set
	 */
	public void setDataLimite(String dataLimite) {
		this.dataLimite = dataLimite;
	}
	/**
	 * @return the horaAtual
	 */
	public String getHoraAtual() {
		return horaAtual;
	}
	/**
	 * @param horaAtual the horaAtual to set
	 */
	public void setHoraAtual(String horaAtual) {
		this.horaAtual = horaAtual;
	}

}
