package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class DetalheHistoricoAssinatura implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	private String autorizador;
	private String tipoRegistro;
	private String tipoAcesso;
	private Integer seqAutorizacao;
	private String tipoUsuario;
	private String idUsuario;
	private String data;
	private String situacaoAssinatura;
	private String motivoCancAss;
	private String canal;
	private String hora;
	private String evento;
	

	
	/**
	 * @return the tipoRegistro
	 */
	public String getTipoRegistro() {
		return tipoRegistro;
	}

	/**
	 * @param tipoRegistro
	 *            the tipoRegistro to set
	 */
	public void setTipoRegistro(String tipoRegistro) {
		this.tipoRegistro = tipoRegistro;
	}

	/**
	 * @return the tipoAcesso
	 */
	public String getTipoAcesso() {
		return tipoAcesso;
	}

	/**
	 * @param tipoAcesso
	 *            the tipoAcesso to set
	 */
	public void setTipoAcesso(String tipoAcesso) {
		this.tipoAcesso = tipoAcesso;
	}

	/**
	 * @return the seqAutorizacao
	 */
	public Integer getSeqAutorizacao() {
		return seqAutorizacao;
	}

	/**
	 * @param seqAutorizacao
	 *            the seqAutorizacao to set
	 */
	public void setSeqAutorizacao(Integer seqAutorizacao) {
		this.seqAutorizacao = seqAutorizacao;
	}

	/**
	 * @return the tipoUsuario
	 */
	public String getTipoUsuario() {
		return tipoUsuario;
	}

	/**
	 * @param tipoUsuario
	 *            the tipoUsuario to set
	 */
	public void setTipoUsuario(String tipoUsuario) {
		this.tipoUsuario = tipoUsuario;
	}

	/**
	 * @return the idUsuario
	 */
	public String getIdUsuario() {
		return idUsuario;
	}

	/**
	 * @param idUsuario
	 *            the idUsuario to set
	 */
	public void setIdUsuario(String idUsuario) {
		this.idUsuario = idUsuario;
	}

	/**
	 * @return the data
	 */
	public String getData() {
		return data;
	}

	/**
	 * @param data
	 *            the data to set
	 */
	public void setData(String data) {
		this.data = data;
	}

	/**
	 * @return the situacaoAssinatura
	 */
	public String getSituacaoAssinatura() {
		return "CANCL".equals(situacaoAssinatura)?"Cancelado":"Autorizada";
	}

	/**
	 * @param situacaoAssinatura
	 *            the situacaoAssinatura to set
	 */
	public void setSituacaoAssinatura(String situacaoAssinatura) {
		this.situacaoAssinatura = situacaoAssinatura;
	}

	/**
	 * @return the motivoCancAss
	 */
	public String getMotivoCancAss() {
		return motivoCancAss;
	}

	/**
	 * @param motivoCancAss
	 *            the motivoCancAss to set
	 */
	public void setMotivoCancAss(String motivoCancAss) {
		this.motivoCancAss = motivoCancAss;
	}

	/**
	 * @return the canal
	 */
	public String getCanal() {
		return "37".equals(canal)?"Mobile":"Internet Banking";
	}

	/**
	 * @param canal
	 *            the canal to set
	 */
	public void setCanal(String canal) {
		this.canal = canal;
	}

	/**
	 * @return the hora
	 */
	public String getHora() {
		return hora;
	}

	/**
	 * @param hora
	 *            the hora to set
	 */
	public void setHora(String hora) {
		this.hora = hora;
	}

	/**
	 * @return the autorizador
	 */
	public String getAutorizador() {
		return autorizador;
	}

	/**
	 * @param autorizador the autorizador to set
	 */
	public void setAutorizador(String autorizador) {
		this.autorizador = autorizador;
	}

	public String getEvento() {
		return evento;
	}

	public void setEvento(String evento) {
		this.evento = evento;
	}
	
}