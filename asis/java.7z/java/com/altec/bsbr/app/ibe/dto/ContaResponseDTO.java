package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;


public class ContaResponseDTO implements Serializable {
	
	private static final long serialVersionUID = 7996509720138713707L;
	
	private String bancoEntidadBr;
	private String bancoSecursalBr;
	private String bancoNroCuentaBr;
    private String nomconv;
    private String utizcmp;
    private String penumpe;
    private String tipdoc;
    private String numdoc;
    private String indpral;
    private String entDebEntidadBr;
    private String entDebSucursalBr;
    private String entDebNroCuentaBr;
    private String convrea;
    
    public ContaResponseDTO(){
    	
    }

	public String getBancoEntidadBr() {
		return bancoEntidadBr;
	}

	public void setBancoEntidadBr(String bancoEntidadBr) {
		this.bancoEntidadBr = bancoEntidadBr;
	}

	public String getBancoSecursalBr() {
		return bancoSecursalBr;
	}

	public void setBancoSecursalBr(String bancoSecursalBr) {
		this.bancoSecursalBr = bancoSecursalBr;
	}

	public String getBancoNroCuentaBr() {
		return bancoNroCuentaBr;
	}

	public void setBancoNroCuentaBr(String bancoNroCuentaBr) {
		this.bancoNroCuentaBr = bancoNroCuentaBr;
	}

	public String getNomconv() {
		return nomconv;
	}

	public void setNomconv(String nomconv) {
		this.nomconv = nomconv;
	}

	public String getUtizcmp() {
		return utizcmp;
	}

	public void setUtizcmp(String utizcmp) {
		this.utizcmp = utizcmp;
	}

	public String getPenumpe() {
		return penumpe;
	}

	public void setPenumpe(String penumpe) {
		this.penumpe = penumpe;
	}

	public String getTipdoc() {
		return tipdoc;
	}

	public void setTipdoc(String tipdoc) {
		this.tipdoc = tipdoc;
	}

	public String getNumdoc() {
		return numdoc;
	}

	public void setNumdoc(String numdoc) {
		this.numdoc = numdoc;
	}

	public String getIndpral() {
		return indpral;
	}

	public void setIndpral(String indpral) {
		this.indpral = indpral;
	}

	public String getEntDebEntidadBr() {
		return entDebEntidadBr;
	}

	public void setEntDebEntidadBr(String entDebEntidadBr) {
		this.entDebEntidadBr = entDebEntidadBr;
	}

	public String getEntDebSucursalBr() {
		return entDebSucursalBr;
	}

	public void setEntDebSucursalBr(String entDebSucursalBr) {
		this.entDebSucursalBr = entDebSucursalBr;
	}

	public String getEntDebNroCuentaBr() {
		return entDebNroCuentaBr;
	}

	public void setEntDebNroCuentaBr(String entDebNroCuentaBr) {
		this.entDebNroCuentaBr = entDebNroCuentaBr;
	}

	public String getConvrea() {
		return convrea;
	}

	public void setConvrea(String convrea) {
		this.convrea = convrea;
	}
	
	public String getNomeConcatenado() {
		if (getNomconv() != null) {
			StringBuilder nomeContatenado = new StringBuilder();
			nomeContatenado.append(getNomconv().substring(0, 4));
			nomeContatenado.append("-");
			nomeContatenado.append(getNomconv().substring(4, 8));
			nomeContatenado.append("-");
			nomeContatenado.append(getNomconv().substring(8, 20));
			return nomeContatenado.toString();
		} else {
			return "";
		}
	}

}
