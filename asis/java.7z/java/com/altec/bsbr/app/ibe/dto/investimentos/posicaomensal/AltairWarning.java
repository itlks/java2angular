
package com.altec.bsbr.app.ibe.dto.investimentos.posicaomensal;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class AltairWarning implements Serializable
{

    private String warningCode;
    private String warningMessage;
    private final static long serialVersionUID = 6936806738536773621L;

    /**
     * No args constructor for use in serialization
     * 
     */
    public AltairWarning() {
    }

    /**
     * 
     * @param warningCode
     * @param warningMessage
     */
    public AltairWarning(String warningCode, String warningMessage) {
        super();
        this.warningCode = warningCode;
        this.warningMessage = warningMessage;
    }

    public String getWarningCode() {
        return warningCode;
    }

    public void setWarningCode(String warningCode) {
        this.warningCode = warningCode;
    }

    public AltairWarning withWarningCode(String warningCode) {
        this.warningCode = warningCode;
        return this;
    }

    public String getWarningMessage() {
        return warningMessage;
    }

    public void setWarningMessage(String warningMessage) {
        this.warningMessage = warningMessage;
    }

    public AltairWarning withWarningMessage(String warningMessage) {
        this.warningMessage = warningMessage;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(warningCode).append(warningMessage).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof AltairWarning) == false) {
            return false;
        }
        AltairWarning rhs = ((AltairWarning) other);
        return new EqualsBuilder().append(warningCode, rhs.warningCode).append(warningMessage, rhs.warningMessage).isEquals();
    }

}
