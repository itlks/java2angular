package com.altec.bsbr.app.ibe.dto;

import com.altec.bsbr.app.ibe.anotation.Hash;

public class PagamentosTributosMunicipaisIptuSpPreenchimentoEhtDTO {

	@Hash(position=1)
	private String numContribuinte;
	@Hash(position=2)
	private Integer anoExercicio;
	
	public String getNumContribuinte() {
		return numContribuinte;
	}
	public void setNumContribuinte(String numContribuinte) {
		this.numContribuinte = numContribuinte;
	}
	public Integer getAnoExercicio() {
		return anoExercicio;
	}
	public void setAnoExercicio(Integer anoExercicio) {
		this.anoExercicio = anoExercicio;
	}
}