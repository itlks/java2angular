package com.altec.bsbr.app.ibe.dto;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.NumberFormat;

public class DetalheCabecalhoDTO {

	private String cliente;
	private String usuario;
	private String produto;
	private String transacao;
	private String data;
	private String dataPagamento;
	private String convenio;
	private String permiteAcesso;
	private String ContaDebito;
	private String operacao;
	private BigDecimal valorDaOperacao;

	/**
	 * @return the cliente
	 */
	public String getCliente() {
		return cliente;
	}

	/**
	 * @param cliente
	 *            the cliente to set
	 */
	public void setCliente(String cliente) {
		this.cliente = cliente;
	}

	/**
	 * @return the usuario
	 */
	public String getUsuario() {
		return usuario;
	}

	/**
	 * @param usuario
	 *            the usuario to set
	 */
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	/**
	 * @return the produto
	 */
	public String getProduto() {
		return produto;
	}

	/**
	 * @param produto
	 *            the produto to set
	 */
	public void setProduto(String produto) {
		this.produto = produto;
	}

	/**
	 * @return the transacao
	 */
	public String getTransacao() {
		return transacao;
	}

	/**
	 * @param transacao
	 *            the transacao to set
	 */
	public void setTransacao(String transacao) {
		this.transacao = transacao;
	}

	/**
	 * @return the data
	 */
	public String getData() {
		return data;
	}

	/**
	 * @param data
	 *            the data to set
	 */
	public void setData(String data) {
		this.data = data;
	}

	/**
	 * @return the convenio
	 */
	public String getConvenio() {
		return convenio;
	}

	/**
	 * @param convenio the convenio to set
	 */
	public void setConvenio(String convenio) {
		this.convenio = convenio;
	}

	/**
	 * @return the permiteAcesso
	 */
	public String getPermiteAcesso() {
		return permiteAcesso;
	}

	/**
	 * @param permiteAcesso the permiteAcesso to set
	 */
	public void setPermiteAcesso(String permiteAcesso) {
		this.permiteAcesso = permiteAcesso;
	}

	public String getDataPagamento() {
		return dataPagamento;
	}

	public void setDataPagamento(String dataPagamento) {
		this.dataPagamento = dataPagamento;
	}

	public String getContaDebito() {
		return ContaDebito;
	}

	public void setContaDebito(String contaDebito) {
		ContaDebito = contaDebito;
	}

	public String getValorDaOperacao() {
		if (valorDaOperacao != null) {
			return NumberFormat.getCurrencyInstance().format(valorDaOperacao);
		}
		return "0,00";
	}

	public void setValorDaOperacao(BigDecimal valorDaOperacao) {
		this.valorDaOperacao = valorDaOperacao;
	}

	public String getOperacao() {
		return operacao;
	}

	public void setOperacao(String operacao) {
		this.operacao = operacao;
	}
}
