package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.Date;

import com.altec.bsbr.app.ibe.anotation.Hash;

public class ConsultaCorrespondenciaDTO implements Serializable {
	
	private static final long serialVersionUID = 7100132261275809L;
	
	private String penumpe; //penumpe
	private String cpfCnpjCliente; //Cpfcnpj
	private String segmentoPrincipal; //sgmtpri
	private String descricaoTangivel; //tangive
	private Date dataProcessamento; //dtproce
	@Hash(position = 1)
	private String codigoRastreamento; //cdrastr
	private Date dataPostagem; //dtposta
	private Date dataDevolucao; //dtdevol
	private String motivoDevolucao; // motdevo
	private String enderecoEmissao;//enderec
	private String sistemaRespEmissao; //sisresp
	private String detalheTangivel; //dettang
	private String meioPostagem; //meiopos
	private String statusPostagem; //stposta
	private String sequenciaEndereco; //seqend
	private String courrier; //courier
	private String statusEntrega; //staentr
	private String codigo; //info.codigo
	
	/**
	 * @return the penumpe
	 */
	public String getPenumpe() {
		return penumpe;
	}
	/**
	 * @param penumpe the penumpe to set
	 */
	public void setPenumpe(String penumpe) {
		this.penumpe = penumpe;
	}
	/**
	 * @return the cpfCnpjCliente
	 */
	public String getCpfCnpjCliente() {
		return cpfCnpjCliente;
	}
	/**
	 * @param cpfCnpjCliente the cpfCnpjCliente to set
	 */
	public void setCpfCnpjCliente(String cpfCnpjCliente) {
		this.cpfCnpjCliente = cpfCnpjCliente;
	}
	/**
	 * @return the segmentoPrincipal
	 */
	public String getSegmentoPrincipal() {
		return segmentoPrincipal;
	}
	/**
	 * @param segmentoPrincipal the segmentoPrincipal to set
	 */
	public void setSegmentoPrincipal(String segmentoPrincipal) {
		this.segmentoPrincipal = segmentoPrincipal;
	}
	/**
	 * @return the descricaoTangivel
	 */
	public String getDescricaoTangivel() {
		return descricaoTangivel;
	}
	/**
	 * @param descricaoTangivel the descricaoTangivel to set
	 */
	public void setDescricaoTangivel(String descricaoTangivel) {
		this.descricaoTangivel = descricaoTangivel;
	}
	/**
	 * @return the dataProcessamento
	 */
	public Date getDataProcessamento() {
		return dataProcessamento;
	}
	/**
	 * @param dataProcessamento the dataProcessamento to set
	 */
	public void setDataProcessamento(Date dataProcessamento) {
		this.dataProcessamento = dataProcessamento;
	}
	/**
	 * @return the codigoRastreamento
	 */
	public String getCodigoRastreamento() {
		return codigoRastreamento;
	}
	/**
	 * @param codigoRastreamento the codigoRastreamento to set
	 */
	public void setCodigoRastreamento(String codigoRastreamento) {
		this.codigoRastreamento = codigoRastreamento;
	}
	/**
	 * @return the dataPostagem
	 */
	public Date getDataPostagem() {
		return dataPostagem;
	}
	/**
	 * @param dataPostagem the dataPostagem to set
	 */
	public void setDataPostagem(Date dataPostagem) {
		this.dataPostagem = dataPostagem;
	}
	/**
	 * @return the dataDevolucao
	 */
	public Date getDataDevolucao() {
		return dataDevolucao;
	}
	/**
	 * @param dataDevolucao the dataDevolucao to set
	 */
	public void setDataDevolucao(Date dataDevolucao) {
		this.dataDevolucao = dataDevolucao;
	}
	/**
	 * @return the motivoDevolucao
	 */
	public String getMotivoDevolucao() {
		return motivoDevolucao;
	}
	/**
	 * @param motivoDevolucao the motivoDevolucao to set
	 */
	public void setMotivoDevolucao(String motivoDevolucao) {
		this.motivoDevolucao = motivoDevolucao;
	}
	/**
	 * @return the enderecoEmissao
	 */
	public String getEnderecoEmissao() {
		return enderecoEmissao;
	}
	/**
	 * @param enderecoEmissao the enderecoEmissao to set
	 */
	public void setEnderecoEmissao(String enderecoEmissao) {
		this.enderecoEmissao = enderecoEmissao;
	}
	/**
	 * @return the sistemaRespEmissao
	 */
	public String getSistemaRespEmissao() {
		return sistemaRespEmissao;
	}
	/**
	 * @param sistemaRespEmissao the sistemaRespEmissao to set
	 */
	public void setSistemaRespEmissao(String sistemaRespEmissao) {
		this.sistemaRespEmissao = sistemaRespEmissao;
	}
	/**
	 * @return the detalheTangivel
	 */
	public String getDetalheTangivel() {
		return detalheTangivel;
	}
	/**
	 * @param detalheTangivel the detalheTangivel to set
	 */
	public void setDetalheTangivel(String detalheTangivel) {
		this.detalheTangivel = detalheTangivel;
	}
	/**
	 * @return the meioPostagem
	 */
	public String getMeioPostagem() {
		return meioPostagem;
	}
	/**
	 * @param meioPostagem the meioPostagem to set
	 */
	public void setMeioPostagem(String meioPostagem) {
		this.meioPostagem = meioPostagem;
	}
	/**
	 * @return the statusPostagem
	 */
	public String getStatusPostagem() {
		return statusPostagem;
	}
	/**
	 * @param statusPostagem the statusPostagem to set
	 */
	public void setStatusPostagem(String statusPostagem) {
		this.statusPostagem = statusPostagem;
	}
	/**
	 * @return the sequenciaEndereco
	 */
	public String getSequenciaEndereco() {
		return sequenciaEndereco;
	}
	/**
	 * @param sequenciaEndereco the sequenciaEndereco to set
	 */
	public void setSequenciaEndereco(String sequenciaEndereco) {
		this.sequenciaEndereco = sequenciaEndereco;
	}
	/**
	 * @return the courrier
	 */
	public String getCourrier() {
		return courrier;
	}
	/**
	 * @param courrier the courrier to set
	 */
	public void setCourrier(String courrier) {
		this.courrier = courrier;
	}
	/**
	 * @return the statusEntrega
	 */
	public String getStatusEntrega() {
		return statusEntrega;
	}
	/**
	 * @param statusEntrega the statusEntrega to set
	 */
	public void setStatusEntrega(String statusEntrega) {
		this.statusEntrega = statusEntrega;
	}
	/**
	 * @return the codigo
	 */
	public String getCodigo() {
		return codigo;
	}
	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	/**
	 * @return the descripcion
	 */
	public String getDescripcion() {
		return descripcion;
	}
	/**
	 * @param descripcion the descripcion to set
	 */
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	private String descripcion; //info.descripcion

}
