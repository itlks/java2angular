package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.List;

public class AutoriazacaoRenavanDTO implements Serializable {

	private static final long serialVersionUID = 6802269750432351244L;

	private String codigoMensagemOk;
	private List<DadosAutorizacaoRenavanDTO> dados;
	private String nomeEmpresa;
	private String agencia;
	private String contaCorrente;
	private String data;

	public String getCodigoMensagemOk() {
		return codigoMensagemOk;
	}

	public List<DadosAutorizacaoRenavanDTO> getDados() {
		return dados;
	}

	public void setDados(List<DadosAutorizacaoRenavanDTO> dados) {
		this.dados = dados;
	}

	public void setCodigoMensagemOk(String codigoMensagemOk) {
		this.codigoMensagemOk = codigoMensagemOk;
	}

	public String getNomeEmpresa() {
		return nomeEmpresa;
	}

	public void setNomeEmpresa(String nomeEmpresa) {
		this.nomeEmpresa = nomeEmpresa;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getContaCorrente() {
		return contaCorrente;
	}

	public void setContaCorrente(String contaCorrente) {
		this.contaCorrente = contaCorrente;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

}
