package com.altec.bsbr.app.ibe.rest.service;

import java.io.Serializable;

import com.altec.bsbr.app.ibe.web.jsf.attributes.AtributosDaSessao;
import com.altec.bsbr.fw.BusinessException;

public interface SeguroPrestamistaChequeEmpresaRestService extends Serializable {

	public void confirmarAdesao(final AtributosDaSessao session) throws BusinessException;

}