package com.altec.bsbr.app.ibe.exception;

import com.altec.bsbr.fw.BusinessException;

public class ValidacaoTelaException extends BusinessException {

	private static final long serialVersionUID = 4313525349854645478L;

	private String idComponenteValidacao;

	public ValidacaoTelaException(String mesage, String idComponenteValidacao) {
		super(mesage);
		this.idComponenteValidacao = idComponenteValidacao;
	}

	public String getIdComponenteValidacao() {
		return idComponenteValidacao;
	}

	public void setIdComponenteValidacao(String idComponenteValidacao) {
		this.idComponenteValidacao = idComponenteValidacao;
	}

}
