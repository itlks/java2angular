package com.altec.bsbr.app.ibe.dto;

public class SacadoDTO {
	private String dataDebito;
	private String identificadorConsumidor;
	private String situacao;
	private String formaPagamento;
	private String empresaConveniada;
	private String valor;
	
	public SacadoDTO(){
		super();
	}
	
	public SacadoDTO(String dataDebito, String identificadorConsumidor, String situacao, String formaPagamento,
			String empresaConveniada, String valor) {
		super();
		this.dataDebito = dataDebito;
		this.identificadorConsumidor = identificadorConsumidor;
		this.situacao = situacao;
		this.formaPagamento = formaPagamento;
		this.empresaConveniada = empresaConveniada;
		this.valor = valor;
	}

	public String getDataDebito() {
		return dataDebito;
	}

	public void setDataDebito(String dataDebito) {
		this.dataDebito = dataDebito;
	}

	public String getIdentificadorConsumidor() {
		return identificadorConsumidor;
	}

	public void setIdentificadorConsumidor(String identificadorConsumidor) {
		this.identificadorConsumidor = identificadorConsumidor;
	}

	public String getSituacao() {
		return situacao;
	}

	public void setSituacao(String situacao) {
		this.situacao = situacao;
	}

	public String getFormaPagamento() {
		return formaPagamento;
	}

	public void setFormaPagamento(String formaPagamento) {
		this.formaPagamento = formaPagamento;
	}

	public String getEmpresaConveniada() {
		return empresaConveniada;
	}

	public void setEmpresaConveniada(String empresaConveniada) {
		this.empresaConveniada = empresaConveniada;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}
	
	
}
