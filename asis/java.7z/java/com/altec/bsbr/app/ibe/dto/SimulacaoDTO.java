package com.altec.bsbr.app.ibe.dto;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Pattern;

public class SimulacaoDTO {
	
	private String codProd_0;
	private String codSProd_1;
	private String codFluxo_2;
	private String inSolic_3;
	private String dtSolic_4;
	private String hrSolic_5;
	private String inVend_6;
	private String inVendPoSi_7;
	private String codBancCntr_8;
	private String codAgenCntr_9;
	private String nrCntr_10;
	private String codTran_11;
	private String vlLimiRiSc_12;
	private String vlSaldLiqu_13;
	private String vlTrocoMini_14;
	private String vlTrocoMaxi_15;
	private String vlTroco_16;
	private String vlDeSejado_17;
	private String vlMiniOper_18;
	private String vlMiniParc_19;
	private String inNovoPraz_20;
	private String dtOfer_21;
	private String dtAprvLimi_22;
	private String dtContabil_23;
	private String diaDebt_24;
	private String nrControle_25;
	private String tpSegu_26;
	private String vlCobertSegu_27;
	private String idadeMiniSegu_28;
	private String idadeMaxiSegu_29;
	private String codEven_30;
	private String codTari_31;
	private String txJuroMeS_32;
	private String txJuroAno_33;
	private String cetMeS_34;
	private String cetAno_35;
	private String dtPrimVcto_36;
	private String dtUltiVcto_37;
	private String qtdParc_38;
	private String vlCpmf_39;
	private String vlDeSp_40;
	private String txMora_41;
	private String txInad_42;
	private String tpTaxa_43;
	private String qtdPrazMini_44;
	private String qtdPrazMaxi_45;
	private String vlCdl_46;
	private String vlPremSegu_47;
	private String vlIOF_48;
	private String vlIOFSemSegu_49;
	private String vlTariCntr_50;
	private String vlTotaFinan_51;
	private String vlTotaFinanSemSegu_52;
	private String vlParc_53;
	private String vlParcSemSegu_54;
	private String vlTme_55;
	private String vlTmeSemSegu_56;
	private String vlTotaEncarg_57;
	private String vlEmpr_58;
	private String codCondalte_59;
	private String tipoCondalte_60;
	private String vlLancamento_61;
	private String dtContratacao_62;
	private String dtTransacao_63;
	private String hrTransacao_64;
	private String autenticacao_65;
	
	public String getCodProd_0() {
		return codProd_0;
	}
	
	public void setCodProd_0(final String codProd_0) {
		this.codProd_0 = codProd_0;
	}
	
	public String getCodSProd_1() {
		return codSProd_1;
	}
	
	public void setCodSProd_1(final String codSProd_1) {
		this.codSProd_1 = codSProd_1;
	}
	
	public String getCodFluxo_2() {
		return codFluxo_2;
	}
	
	public void setCodFluxo_2(final String codFluxo_2) {
		this.codFluxo_2 = codFluxo_2;
	}
	
	public String getInSolic_3() {
		return inSolic_3;
	}
	
	public void setInSolic_3(final String inSolic_3) {
		this.inSolic_3 = inSolic_3;
	}
	
	public String getDtSolic_4() {
		return dtSolic_4;
	}
	
	public void setDtSolic_4(final String dtSolic_4) {
		this.dtSolic_4 = dtSolic_4;
	}
	
	public String getHrSolic_5() {
		return hrSolic_5;
	}
	
	public void setHrSolic_5(final String hrSolic_5) {
		this.hrSolic_5 = hrSolic_5;
	}
	
	public String getInVend_6() {
		return inVend_6;
	}
	
	public void setInVend_6(final String inVend_6) {
		this.inVend_6 = inVend_6;
	}
	
	public String getInVendPoSi_7() {
		return inVendPoSi_7;
	}
	
	public void setInVendPoSi_7(final String inVendPoSi_7) {
		this.inVendPoSi_7 = inVendPoSi_7;
	}
	
	public String getCodBancCntr_8() {
		return codBancCntr_8;
	}
	
	public void setCodBancCntr_8(final String codBancCntr_8) {
		this.codBancCntr_8 = codBancCntr_8;
	}
	
	public String getCodAgenCntr_9() {
		return codAgenCntr_9;
	}
	
	public void setCodAgenCntr_9(final String codAgenCntr_9) {
		this.codAgenCntr_9 = codAgenCntr_9;
	}
	
	public String getNrCntr_10() {
		return nrCntr_10;
	}
	
	public void setNrCntr_10(final String nrCntr_10) {
		this.nrCntr_10 = nrCntr_10;
	}
	
	public String getCodTran_11() {
		return codTran_11;
	}
	
	public void setCodTran_11(final String codTran_11) {
		this.codTran_11 = codTran_11;
	}
	
	public String getVlLimiRiSc_12() {
		return vlLimiRiSc_12;
	}
	
	public void setVlLimiRiSc_12(final String vlLimiRiSc_12) {
		this.vlLimiRiSc_12 = vlLimiRiSc_12;
	}
	
	public String getVlSaldLiqu_13() {
		return vlSaldLiqu_13;
	}
	
	public void setVlSaldLiqu_13(final String vlSaldLiqu_13) {
		this.vlSaldLiqu_13 = vlSaldLiqu_13;
	}
	
	public String getVlTrocoMini_14() {
		return vlTrocoMini_14;
	}
	
	public void setVlTrocoMini_14(final String vlTrocoMini_14) {
		this.vlTrocoMini_14 = vlTrocoMini_14;
	}
	
	public String getVlTrocoMaxi_15() {
		return vlTrocoMaxi_15;
	}
	
	public void setVlTrocoMaxi_15(final String vlTrocoMaxi_15) {
		this.vlTrocoMaxi_15 = vlTrocoMaxi_15;
	}
	
	public String getVlTroco_16() {
		return vlTroco_16;
	}
	
	public void setVlTroco_16(final String vlTroco_16) {
		this.vlTroco_16 = vlTroco_16;
	}
	
	public String getVlDeSejado_17() {
		return vlDeSejado_17;
	}
	
	public void setVlDeSejado_17(final String vlDeSejado_17) {
		this.vlDeSejado_17 = vlDeSejado_17;
	}
	
	public String getVlMiniOper_18() {
		return vlMiniOper_18;
	}
	
	public void setVlMiniOper_18(final String vlMiniOper_18) {
		this.vlMiniOper_18 = vlMiniOper_18;
	}
	
	public String getVlMiniParc_19() {
		return vlMiniParc_19;
	}
	
	public void setVlMiniParc_19(final String vlMiniParc_19) {
		this.vlMiniParc_19 = vlMiniParc_19;
	}
	
	public String getInNovoPraz_20() {
		return inNovoPraz_20;
	}
	
	public void setInNovoPraz_20(final String inNovoPraz_20) {
		this.inNovoPraz_20 = inNovoPraz_20;
	}
	
	public String getDtOfer_21() {
		return dtOfer_21;
	}
	
	public void setDtOfer_21(final String dtOfer_21) {
		this.dtOfer_21 = dtOfer_21;
	}
	
	public String getDtAprvLimi_22() {
		return dtAprvLimi_22;
	}
	
	public void setDtAprvLimi_22(final String dtAprvLimi_22) {
		this.dtAprvLimi_22 = dtAprvLimi_22;
	}
	
	public String getDtContabil_23() {
		return dtContabil_23;
	}
	
	public void setDtContabil_23(final String dtContabil_23) {
		this.dtContabil_23 = dtContabil_23;
	}
	
	public String getDiaDebt_24() {
		return diaDebt_24;
	}
	
	public void setDiaDebt_24(final String diaDebt_24) {
		this.diaDebt_24 = diaDebt_24;
	}
	
	public String getNrControle_25() {
		return nrControle_25;
	}
	
	public void setNrControle_25(final String nrControle_25) {
		this.nrControle_25 = nrControle_25;
	}
	
	public String getTpSegu_26() {
		return tpSegu_26;
	}
	
	public void setTpSegu_26(final String tpSegu_26) {
		this.tpSegu_26 = tpSegu_26;
	}
	
	public String getVlCobertSegu_27() {
		return vlCobertSegu_27;
	}
	
	public void setVlCobertSegu_27(final String vlCobertSegu_27) {
		this.vlCobertSegu_27 = vlCobertSegu_27;
	}
	
	public String getIdadeMiniSegu_28() {
		return idadeMiniSegu_28;
	}
	
	public void setIdadeMiniSegu_28(final String idadeMiniSegu_28) {
		this.idadeMiniSegu_28 = idadeMiniSegu_28;
	}
	
	public String getIdadeMaxiSegu_29() {
		return idadeMaxiSegu_29;
	}
	
	public void setIdadeMaxiSegu_29(final String idadeMaxiSegu_29) {
		this.idadeMaxiSegu_29 = idadeMaxiSegu_29;
	}
	
	public String getCodEven_30() {
		return codEven_30;
	}
	
	public void setCodEven_30(final String codEven_30) {
		this.codEven_30 = codEven_30;
	}
	
	public String getCodTari_31() {
		return codTari_31;
	}
	
	public void setCodTari_31(final String codTari_31) {
		this.codTari_31 = codTari_31;
	}
	
	public String getTxJuroMeS_32() {
		return txJuroMeS_32;
	}
	
	public void setTxJuroMeS_32(final String txJuroMeS_32) {
		this.txJuroMeS_32 = txJuroMeS_32;
	}
	
	public String getTxJuroAno_33() {
		return txJuroAno_33;
	}
	
	public void setTxJuroAno_33(final String txJuroAno_33) {
		this.txJuroAno_33 = txJuroAno_33;
	}
	
	public String getCetMeS_34() {
		return cetMeS_34;
	}
	
	public void setCetMeS_34(final String cetMeS_34) {
		this.cetMeS_34 = cetMeS_34;
	}
	
	public String getCetAno_35() {
		return cetAno_35;
	}
	
	public void setCetAno_35(final String cetAno_35) {
		this.cetAno_35 = cetAno_35;
	}
	
	public String getDtPrimVcto_36() {
		return dtPrimVcto_36;
	}
	
	public void setDtPrimVcto_36(final String dtPrimVcto_36) {
		this.dtPrimVcto_36 = dtPrimVcto_36;
	}
	
	public String getDtUltiVcto_37() {
		return dtUltiVcto_37;
	}
	
	public void setDtUltiVcto_37(final String dtUltiVcto_37) {
		this.dtUltiVcto_37 = dtUltiVcto_37;
	}
	
	public String getQtdParc_38() {
		return qtdParc_38;
	}
	
	public void setQtdParc_38(final String qtdParc_38) {
		this.qtdParc_38 = qtdParc_38;
	}
	
	public String getVlCpmf_39() {
		return vlCpmf_39;
	}
	
	public void setVlCpmf_39(final String vlCpmf_39) {
		this.vlCpmf_39 = vlCpmf_39;
	}
	
	public String getVlDeSp_40() {
		return vlDeSp_40;
	}
	
	public void setVlDeSp_40(final String vlDeSp_40) {
		this.vlDeSp_40 = vlDeSp_40;
	}
	
	public String getTxMora_41() {
		return txMora_41;
	}
	
	public void setTxMora_41(final String txMora_41) {
		this.txMora_41 = txMora_41;
	}
	
	public String getTxInad_42() {
		return txInad_42;
	}
	
	public void setTxInad_42(final String txInad_42) {
		this.txInad_42 = txInad_42;
	}
	
	public String getTpTaxa_43() {
		return tpTaxa_43;
	}
	
	public void setTpTaxa_43(final String tpTaxa_43) {
		this.tpTaxa_43 = tpTaxa_43;
	}
	
	public String getQtdPrazMini_44() {
		return qtdPrazMini_44;
	}
	
	public void setQtdPrazMini_44(final String qtdPrazMini_44) {
		this.qtdPrazMini_44 = qtdPrazMini_44;
	}
	
	public String getQtdPrazMaxi_45() {
		return qtdPrazMaxi_45;
	}
	
	public void setQtdPrazMaxi_45(final String qtdPrazMaxi_45) {
		this.qtdPrazMaxi_45 = qtdPrazMaxi_45;
	}
	
	public String getVlCdl_46() {
		return vlCdl_46;
	}
	
	public void setVlCdl_46(final String vlCdl_46) {
		this.vlCdl_46 = vlCdl_46;
	}
	
	public String getVlPremSegu_47() {
		return vlPremSegu_47;
	}
	
	public void setVlPremSegu_47(final String vlPremSegu_47) {
		this.vlPremSegu_47 = vlPremSegu_47;
	}
	
	public String getVlIOF_48() {
		return vlIOF_48;
	}
	
	public void setVlIOF_48(final String vlIOF_48) {
		this.vlIOF_48 = vlIOF_48;
	}
	
	public String getVlIOFSemSegu_49() {
		return vlIOFSemSegu_49;
	}
	
	public void setVlIOFSemSegu_49(final String vlIOFSemSegu_49) {
		this.vlIOFSemSegu_49 = vlIOFSemSegu_49;
	}
	
	public String getVlTariCntr_50() {
		return vlTariCntr_50;
	}
	
	public void setVlTariCntr_50(final String vlTariCntr_50) {
		this.vlTariCntr_50 = vlTariCntr_50;
	}
	
	public String getVlTotaFinan_51() {
		return vlTotaFinan_51;
	}
	
	public void setVlTotaFinan_51(final String vlTotaFinan_51) {
		this.vlTotaFinan_51 = vlTotaFinan_51;
	}
	
	public String getVlTotaFinanSemSegu_52() {
		return vlTotaFinanSemSegu_52;
	}
	
	public void setVlTotaFinanSemSegu_52(final String vlTotaFinanSemSegu_52) {
		this.vlTotaFinanSemSegu_52 = vlTotaFinanSemSegu_52;
	}
	
	public String getVlParc_53() {
		return vlParc_53;
	}
	
	public void setVlParc_53(final String vlParc_53) {
		this.vlParc_53 = vlParc_53;
	}
	
	public String getVlParcSemSegu_54() {
		return vlParcSemSegu_54;
	}
	
	public void setVlParcSemSegu_54(final String vlParcSemSegu_54) {
		this.vlParcSemSegu_54 = vlParcSemSegu_54;
	}
	
	public String getVlTme_55() {
		return vlTme_55;
	}
	
	public void setVlTme_55(final String vlTme_55) {
		this.vlTme_55 = vlTme_55;
	}
	
	public String getVlTmeSemSegu_56() {
		return vlTmeSemSegu_56;
	}
	
	public void setVlTmeSemSegu_56(final String vlTmeSemSegu_56) {
		this.vlTmeSemSegu_56 = vlTmeSemSegu_56;
	}
	
	public String getVlTotaEncarg_57() {
		return vlTotaEncarg_57;
	}
	
	public void setVlTotaEncarg_57(final String vlTotaEncarg_57) {
		this.vlTotaEncarg_57 = vlTotaEncarg_57;
	}
	
	public String getVlEmpr_58() {
		return vlEmpr_58;
	}
	
	public void setVlEmpr_58(final String vlEmpr_58) {
		this.vlEmpr_58 = vlEmpr_58;
	}
	
	public String getCodCondalte_59() {
		return codCondalte_59;
	}
	
	public void setCodCondalte_59(final String codCondalte_59) {
		this.codCondalte_59 = codCondalte_59;
	}
	
	public String getTipoCondalte_60() {
		return tipoCondalte_60;
	}
	
	public void setTipoCondalte_60(final String tipoCondalte_60) {
		this.tipoCondalte_60 = tipoCondalte_60;
	}
	
	public String getVlLancamento_61() {
		return vlLancamento_61;
	}
	
	public void setVlLancamento_61(final String vlLancamento_61) {
		this.vlLancamento_61 = vlLancamento_61;
	}
	
	public String getDtContratacao_62() {
		return dtContratacao_62;
	}
	
	public void setDtContratacao_62(final String dtContratacao_62) {
		this.dtContratacao_62 = dtContratacao_62;
	}
	
	public String getDtTransacao_63() {
		return dtTransacao_63;
	}
	
	public void setDtTransacao_63(final String dtTransacao_63) {
		this.dtTransacao_63 = dtTransacao_63;
	}
	
	public String getHrTransacao_64() {
		return hrTransacao_64;
	}
	
	public void setHrTransacao_64(final String hrTransacao_64) {
		this.hrTransacao_64 = hrTransacao_64;
	}
	
	public String getAutenticacao_65() {
		return autenticacao_65;
	}
	
	public void setAutenticacao_65(final String autenticacao_65) {
		this.autenticacao_65 = autenticacao_65;
	}
	
	public String geraStrCamposByDto() {
		final String PIPE = "||";
		final StringBuffer retorno = new StringBuffer();
		//obtem todos atributos da instancia inclusive vazios
		final Field[] camposDaInstancia = this.getClass().getDeclaredFields();
		//ordenas os atributos levando em conta o numero que est� apos o underline "_"
		final List<Field> listaOrdenada = Arrays.asList(camposDaInstancia);
		Collections.sort(listaOrdenada, new Comparator<Field>() {
			
			@Override
			public int compare(final Field atributoUm, final Field atributoDois) {
				return Integer.valueOf(atributoUm.getName().substring(atributoUm.getName().indexOf("_") + 1))
						.compareTo(Integer.valueOf(atributoDois.getName().substring(atributoDois.getName().indexOf("_") + 1)));
			}
		});
		
		//adiciona na string de retorno ela mesma  mais o valor que vem no atributo mais dois pipes
		//(string = string + valor + ||)
		for (final Field field : listaOrdenada) {
			field.setAccessible(true);
			try {
				//field.get(dto) serve para obter valor(value) que esta setado no atributo(field)
				retorno.append(field.get(this) == null ? "" : field.get(this));
			} catch (final IllegalArgumentException e) {
				return "";
			} catch (final IllegalAccessException e) {
				return "";
			}
			retorno.append(PIPE);
		}
		return retorno.toString();
	}
	
	public SimulacaoDTO geraDtoByStrCampos(final String strCampos) {
		final SimulacaoDTO retorno = new SimulacaoDTO();
		final String[] values = strCampos.split(Pattern.quote("||"));
		//obtem todos atributos do dto
		final Field[] camposDoDto = retorno.getClass().getDeclaredFields();
		
		for (final Field field : camposDoDto) {
			final Integer index = Integer.valueOf(field.getName().substring(field.getName().indexOf("_") + 1));
			field.setAccessible(true);
			if (index < values.length) {
				try {
					field.set(retorno, values[index]);
				} catch (final IllegalArgumentException e) {
					return null;
				} catch (final IllegalAccessException e) {
					return null;
				}
			}
		}
		return retorno;
	}
}