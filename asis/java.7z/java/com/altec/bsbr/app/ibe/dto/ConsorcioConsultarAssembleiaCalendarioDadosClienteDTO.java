package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class ConsorcioConsultarAssembleiaCalendarioDadosClienteDTO implements Serializable {
	
	private static final long serialVersionUID = 4825550711964029682L;
	
	private String nome;
	private String cpfCnpj;
	private String labelCpfCnpj;

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCpfCnpj() {
		return cpfCnpj;
	}

	public void setCpfCnpj(String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}
	public String getLabelCpfCnpj() {
		return labelCpfCnpj;
	}
	public void setLabelCpfCnpj(String labelCpfCnpj) {
		this.labelCpfCnpj = labelCpfCnpj;
	}
}
