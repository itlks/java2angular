package com.altec.bsbr.app.ibe.dto;

import java.util.ArrayList;
import java.util.List;

public class ProdutosContratadosResponseDTO {

	private List<ProdutosContratadosDTO> listaProdutosCadastrados = new ArrayList<ProdutosContratadosDTO>();
	private String retCode;
	private String erro;
	private String erroTecnica;

	public List<ProdutosContratadosDTO> getListaProdutosCadastrados() {
		return listaProdutosCadastrados;
	}

	public void setListaProdutosCadastrados(List<ProdutosContratadosDTO> listaProdutosCadastrados) {
		this.listaProdutosCadastrados = listaProdutosCadastrados;
	}

	public String getRetCode() {
		return retCode;
	}

	public void setRetCode(String retCode) {
		this.retCode = retCode;
	}

	public String getErro() {
		return erro;
	}

	public void setErro(String erro) {
		this.erro = erro;
	}

	public String getErroTecnica() {
		return erroTecnica;
	}

	public void setErroTecnica(String erroTecnica) {
		this.erroTecnica = erroTecnica;
	}

}
