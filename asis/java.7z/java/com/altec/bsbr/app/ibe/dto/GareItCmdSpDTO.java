package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.altec.bsbr.app.ibe.anotation.Hash;
import com.altec.bsbr.app.ibe.dto.apelido.ApelidoDTO;

public class GareItCmdSpDTO implements Serializable {
	
	private static final long serialVersionUID = -1209860703825686316L;
	
	private String ufFavorecida;
	private String contribuinte;
	private String endereco;
	private String municipio;
	private String uf;
	private String telefone;
	private String cep;
	private String observacao;
	private String dataVencimento;
	private String codigoReceita;
	private String numeroDeclaracao;
	private String inscricaoDividaAtiva;
	private String aiim;
	private BigDecimal valorReceita;
	private BigDecimal jurosMora;
	private BigDecimal multaMora;
	private BigDecimal acrescimoFinanceiro;
	private BigDecimal honorarios;
	private BigDecimal valorTotal;
	private String inscricao;
	private int codigoMunicipio;
	private String dataHoraTransacao;
	private String dataPagamento;
	private boolean pendencias;
	private String apelido;
	private boolean cadastrarApelido;
	private String autenticacaoBancaria;
	private String autenticacaoDigital;
	private String codigoBanco;
	private boolean usarApelido = false;
	private String dataVencimentoConvertida;
	
	private List<ApelidoDTO> listaApelidos = new ArrayList<ApelidoDTO>();
	
	@Hash(position=1)
	private String cnpjCpf;

	/**
	 * @return the contribuinte
	 */
	public String getContribuinte() {
		return contribuinte;
	}

	/**
	 * @param contribuinte the contribuinte to set
	 */
	public void setContribuinte(String contribuinte) {
		this.contribuinte = contribuinte;
	}

	/**
	 * @return the endereco
	 */
	public String getEndereco() {
		return endereco;
	}

	/**
	 * @param endereco the endereco to set
	 */
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	/**
	 * @return the municipio
	 */
	public String getMunicipio() {
		return municipio;
	}

	/**
	 * @param municipio the municipio to set
	 */
	public void setMunicipio(String municipio) {
		this.municipio = municipio;
	}

	/**
	 * @return the uf
	 */
	public String getUf() {
		return uf;
	}

	/**
	 * @param uf the uf to set
	 */
	public void setUf(String uf) {
		this.uf = uf;
	}

	/**
	 * @return the telefone
	 */
	public String getTelefone() {
		return telefone;
	}

	/**
	 * @param telefone the telefone to set
	 */
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	/**
	 * @return the cep
	 */
	public String getCep() {
		return cep;
	}

	/**
	 * @param cep the cep to set
	 */
	public void setCep(String cep) {
		this.cep = cep;
	}

	/**
	 * @return the observacao
	 */
	public String getObservacao() {
		return observacao;
	}

	/**
	 * @param observacao the observacao to set
	 */
	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}

	/**
	 * @return the dataVencimento
	 */
	public String getDataVencimento() {
		return dataVencimento;
	}

	/**
	 * @param dataVencimento the dataVencimento to set
	 */
	public void setDataVencimento(String dataVencimento) {
		this.dataVencimento = dataVencimento;
	}

	/**
	 * @return the codigoReceita
	 */
	public String getCodigoReceita() {
		return codigoReceita;
	}

	/**
	 * @param codigoReceita the codigoReceita to set
	 */
	public void setCodigoReceita(String codigoReceita) {
		this.codigoReceita = codigoReceita;
	}

	/**
	 * @return the numeroDeclaracao
	 */
	public String getNumeroDeclaracao() {
		return numeroDeclaracao;
	}

	/**
	 * @param numeroDeclaracao the numeroDeclaracao to set
	 */
	public void setNumeroDeclaracao(String numeroDeclaracao) {
		this.numeroDeclaracao = numeroDeclaracao;
	}

	/**
	 * @return the inscricaoDividaAtiva
	 */
	public String getInscricaoDividaAtiva() {
		return inscricaoDividaAtiva;
	}

	/**
	 * @param inscricaoDividaAtiva the inscricaoDividaAtiva to set
	 */
	public void setInscricaoDividaAtiva(String inscricaoDividaAtiva) {
		this.inscricaoDividaAtiva = inscricaoDividaAtiva;
	}

	/**
	 * @return the aiim
	 */
	public String getAiim() {
		return aiim;
	}

	/**
	 * @param aiim the aiim to set
	 */
	public void setAiim(String aiim) {
		this.aiim = aiim;
	}

	/**
	 * @return the valorReceita
	 */
	public BigDecimal getValorReceita() {
		return valorReceita;
	}

	/**
	 * @param valorReceita the valorReceita to set
	 */
	public void setValorReceita(BigDecimal valorReceita) {
		this.valorReceita = valorReceita;
	}

	/**
	 * @return the jurosMora
	 */
	public BigDecimal getJurosMora() {
		return jurosMora;
	}

	/**
	 * @param jurosMora the jurosMora to set
	 */
	public void setJurosMora(BigDecimal jurosMora) {
		this.jurosMora = jurosMora;
	}

	/**
	 * @return the multaMora
	 */
	public BigDecimal getMultaMora() {
		return multaMora;
	}

	/**
	 * @param multaMora the multaMora to set
	 */
	public void setMultaMora(BigDecimal multaMora) {
		this.multaMora = multaMora;
	}

	/**
	 * @return the acrescimoFinanceiro
	 */
	public BigDecimal getAcrescimoFinanceiro() {
		return acrescimoFinanceiro;
	}

	/**
	 * @param acrescimoFinanceiro the acrescimoFinanceiro to set
	 */
	public void setAcrescimoFinanceiro(BigDecimal acrescimoFinanceiro) {
		this.acrescimoFinanceiro = acrescimoFinanceiro;
	}

	/**
	 * @return the honorarios
	 */
	public BigDecimal getHonorarios() {
		return honorarios;
	}

	/**
	 * @param honorarios the honorarios to set
	 */
	public void setHonorarios(BigDecimal honorarios) {
		this.honorarios = honorarios;
	}

	/**
	 * @return the valorTotal
	 */
	public BigDecimal getValorTotal() {
		return valorTotal;
	}

	/**
	 * @param valorTotal the valorTotal to set
	 */
	public void setValorTotal(BigDecimal valorTotal) {
		this.valorTotal = valorTotal;
	}

	/**
	 * @return the apelido
	 */
	public String getApelido() {
		return apelido;
	}

	/**
	 * @param apelido the apelido to set
	 */
	public void setApelido(String apelido) {
		this.apelido = apelido;
	}

	/**
	 * @return the cnpjCpf
	 */
	public String getCnpjCpf() {
		return cnpjCpf;
	}

	/**
	 * @param cnpjCpf the cnpjCpf to set
	 */
	public void setCnpjCpf(String cnpjCpf) {
		this.cnpjCpf = cnpjCpf;
	}

	/**
	 * @return the autenticacaoBancaria
	 */
	public String getAutenticacaoBancaria() {
		return autenticacaoBancaria;
	}

	/**
	 * @param autenticacaoBancaria the autenticacaoBancaria to set
	 */
	public void setAutenticacaoBancaria(String autenticacaoBancaria) {
		this.autenticacaoBancaria = autenticacaoBancaria;
	}

	/**
	 * @return the autenticacaoDigital
	 */
	public String getAutenticacaoDigital() {
		return autenticacaoDigital;
	}

	/**
	 * @param autenticacaoDigital the autenticacaoDigital to set
	 */
	public void setAutenticacaoDigital(String autenticacaoDigital) {
		this.autenticacaoDigital = autenticacaoDigital;
	}

	/**
	 * @return the dataHoraTransacao
	 */
	public String getDataHoraTransacao() {
		return dataHoraTransacao;
	}

	/**
	 * @param dataHoraTransacao the dataHoraTransacao to set
	 */
	public void setDataHoraTransacao(String dataHoraTransacao) {
		this.dataHoraTransacao = dataHoraTransacao;
	}

	/**
	 * @return the pendencias
	 */
	public boolean isPendencias() {
		return pendencias;
	}

	/**
	 * @param pendencias the pendencias to set
	 */
	public void setPendencias(boolean pendencias) {
		this.pendencias = pendencias;
	}

	/**
	 * @return the ufFavorecida
	 */
	public String getUfFavorecida() {
		return ufFavorecida;
	}

	/**
	 * @param ufFavorecida the ufFavorecida to set
	 */
	public void setUfFavorecida(String ufFavorecida) {
		this.ufFavorecida = ufFavorecida;
	}

	/**
	 * @return the inscricao
	 */
	public String getInscricao() {
		return inscricao;
	}

	/**
	 * @param inscricao the inscricao to set
	 */
	public void setInscricao(String inscricao) {
		this.inscricao = inscricao;
	}

	public boolean isCadastrarApelido() {
		return cadastrarApelido;
	}

	public void setCadastrarApelido(boolean cadastrarApelido) {
		this.cadastrarApelido = cadastrarApelido;
	}

	public int getCodigoMunicipio() {
		return codigoMunicipio;
	}

	public void setCodigoMunicipio(int codigoMunicipio) {
		this.codigoMunicipio = codigoMunicipio;
	}

	public List<ApelidoDTO> getListaApelidos() {
		return listaApelidos;
	}

	public void setListaApelidos(List<ApelidoDTO> listaApelidos) {
		this.listaApelidos = listaApelidos;
	}

	public String getCodigoBanco() {
		return codigoBanco;
	}

	public void setCodigoBanco(String codigoBanco) {
		this.codigoBanco = codigoBanco;
	}
	/**
	 * @return the dataPagamento
	 */
	public String getDataPagamento() {
		return dataPagamento;
	}

	/**
	 * @param dataPagamento the dataPagamento to set
	 */
	public void setDataPagamento(String dataPagamento) {
		this.dataPagamento = dataPagamento;
	}

	public boolean isUsarApelido() {
		return usarApelido;
	}

	public void setUsarApelido(boolean usarApelido) {
		this.usarApelido = usarApelido;
	}

	public String getDataVencimentoConvertida() {
		return dataVencimentoConvertida;
	}

	public void setDataVencimentoConvertida(String dataVencimentoConvertida) {
		this.dataVencimentoConvertida = dataVencimentoConvertida;
	}
	
}
