package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

import com.altec.bsbr.app.ibe.util.UtilFunction;

public class TelefoneCadastradoDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2142471212794146111L;
	private Integer celular;
	private Integer ddd;
	private String operadora;
	private String apelido;

	public String getOperadora() {
		return operadora;
	}

	public void setOperadora(String operadora) {
		this.operadora = operadora;
	}

	public Integer getCelular() {
		return celular;
	}

	public void setCelular(Integer celular) {
		this.celular = celular;
	}

	public Integer getDdd() {
		return ddd;
	}

	public void setDdd(Integer ddd) {
		this.ddd = ddd;
	}

	public String getCelularFormatado() {
		return UtilFunction.formataTelefoneInibido(this.ddd, this.celular);
	}

	public String getApelido() {
		return apelido;
	}

	public void setApelido(String apelido) {
		this.apelido = apelido;
	}
	
	
	
	

}
