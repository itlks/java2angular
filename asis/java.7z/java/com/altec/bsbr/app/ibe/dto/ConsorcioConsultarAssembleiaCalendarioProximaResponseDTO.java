package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.List;

public class ConsorcioConsultarAssembleiaCalendarioProximaResponseDTO implements Serializable{
	
	private static final long serialVersionUID = -166004653406481134L;
	
	private String nomeLocalAssembleia;
	private String nomeEnderecoAssembleia;
	private String bairroAssembleia;
	private String cidadeAssembleia;
	private String estadoAssembleia;
	private String cepAssembleia;
	private String complementoAssembleia;
	private String msgErro;
	
	private List<ItemConsorcioConsultarAssembleiaCalendarioListaResponseDTO> listaDeAssembleias;

	public String getNomeLocalAssembleia() {
		return nomeLocalAssembleia;
	}

	public void setNomeLocalAssembleia(String nomeLocalAssembleia) {
		this.nomeLocalAssembleia = nomeLocalAssembleia;
	}

	public String getNomeEnderecoAssembleia() {
		return nomeEnderecoAssembleia;
	}

	public void setNomeEnderecoAssembleia(String nomeEnderecoAssembleia) {
		this.nomeEnderecoAssembleia = nomeEnderecoAssembleia;
	}

	public String getBairroAssembleia() {
		return bairroAssembleia;
	}

	public void setBairroAssembleia(String bairroAssembleia) {
		this.bairroAssembleia = bairroAssembleia;
	}

	public String getCidadeAssembleia() {
		return cidadeAssembleia;
	}

	public void setCidadeAssembleia(String cidadeAssembleia) {
		this.cidadeAssembleia = cidadeAssembleia;
	}

	public String getEstadoAssembleia() {
		return estadoAssembleia;
	}

	public void setEstadoAssembleia(String estadoAssembleia) {
		this.estadoAssembleia = estadoAssembleia;
	}

	public String getCepAssembleia() {
		return cepAssembleia;
	}

	public void setCepAssembleia(String cepAssembleia) {
		this.cepAssembleia = cepAssembleia;
	}

	/**
	 * @return the listaDeAssembleias
	 */
	public List<ItemConsorcioConsultarAssembleiaCalendarioListaResponseDTO> getListaDeAssembleias() {
		return listaDeAssembleias;
	}

	/**
	 * @param listaDeAssembleias the listaDeAssembleias to set
	 */
	public void setListaDeAssembleias(List<ItemConsorcioConsultarAssembleiaCalendarioListaResponseDTO> listaDeAssembleias) {
		this.listaDeAssembleias = listaDeAssembleias;
	}

	public String getComplementoAssembleia() {
		return complementoAssembleia;
	}

	public void setComplementoAssembleia(String complemento) {
		this.complementoAssembleia = complemento;
	}

	public String getMsgErro() {
		return msgErro;
	}

	public void setMsgErro(String msgErro) {
		this.msgErro = msgErro;
	}

}
