package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Calendar;

public class GpsDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6856592216888524591L;

	private String nomeOuRazaoSocial;
	private Calendar dataDoPagamento;
	private Boolean apelidoGps;
	private String codigoPagamento;

	private String competancia;
	private String identificador;
	private String valorInss;
	private String valorOutrasEntidade;
	private String atmMultaeJuros;
	private BigDecimal valroTotal;
	private Long codigoUsuario;
	private String codServico;

	/**
	 * @return the nomeOuRazaoSocial
	 */
	public String getNomeOuRazaoSocial() {
		return nomeOuRazaoSocial;
	}

	/**
	 * @param nomeOuRazaoSocial
	 *            the nomeOuRazaoSocial to set
	 */
	public void setNomeOuRazaoSocial(String nomeOuRazaoSocial) {
		this.nomeOuRazaoSocial = nomeOuRazaoSocial;
	}

	/**
	 * @return the dataDoPagamento
	 */
	public Calendar getDataDoPagamento() {
		return dataDoPagamento;
	}

	/**
	 * @param dataDoPagamento
	 *            the dataDoPagamento to set
	 */
	public void setDataDoPagamento(Calendar dataDoPagamento) {
		this.dataDoPagamento = dataDoPagamento;
	}

	/**
	 * @return the apelidoGps
	 */
	public Boolean getApelidoGps() {
		return apelidoGps;
	}

	/**
	 * @param apelidoGps
	 *            the apelidoGps to set
	 */
	public void setApelidoGps(Boolean apelidoGps) {
		this.apelidoGps = apelidoGps;
	}

	/**
	 * @return the codigoPagamento
	 */
	public String getCodigoPagamento() {
		return codigoPagamento;
	}

	/**
	 * @param codigoPagamento
	 *            the codigoPagamento to set
	 */
	public void setCodigoPagamento(String codigoPagamento) {
		this.codigoPagamento = codigoPagamento;
	}

	/**
	 * @return the competancia
	 */
	public String getCompetancia() {
		return competancia;
	}

	/**
	 * @param competancia
	 *            the competancia to set
	 */
	public void setCompetancia(String competancia) {
		this.competancia = competancia;
	}

	/**
	 * @return the identificador
	 */
	public String getIdentificador() {
		return identificador;
	}

	/**
	 * @param identificador
	 *            the identificador to set
	 */
	public void setIdentificador(String identificador) {
		this.identificador = identificador;
	}

	/**
	 * @return the valorInss
	 */
	public String getValorInss() {
		return valorInss;
	}

	/**
	 * @param valorInss
	 *            the valorInss to set
	 */
	public void setValorInss(String valorInss) {
		this.valorInss = valorInss;
	}

	/**
	 * @return the valorOutrasEntidade
	 */
	public String getValorOutrasEntidade() {
		return valorOutrasEntidade;
	}

	/**
	 * @param valorOutrasEntidade
	 *            the valorOutrasEntidade to set
	 */
	public void setValorOutrasEntidade(String valorOutrasEntidade) {
		this.valorOutrasEntidade = valorOutrasEntidade;
	}

	/**
	 * @return the atmMultaeJuros
	 */
	public String getAtmMultaeJuros() {
		return atmMultaeJuros;
	}

	/**
	 * @param atmMultaeJuros
	 *            the atmMultaeJuros to set
	 */
	public void setAtmMultaeJuros(String atmMultaeJuros) {
		this.atmMultaeJuros = atmMultaeJuros;
	}

	/**
	 * @return the valroTotal
	 */
	public BigDecimal getValroTotal() {
		return valroTotal;
	}

	/**
	 * @param valroTotal
	 *            the valroTotal to set
	 */
	public void setValroTotal(BigDecimal valroTotal) {
		this.valroTotal = valroTotal;
	}

	/**
	 * @return the codigoUsuario
	 */
	public Long getCodigoUsuario() {
		return codigoUsuario;
	}

	/**
	 * @param codigoUsuario
	 *            the codigoUsuario to set
	 */
	public void setCodigoUsuario(Long codigoUsuario) {
		this.codigoUsuario = codigoUsuario;
	}

	/**
	 * @return the codServico
	 */
	public String getCodServico() {
		return codServico;
	}

	/**
	 * @param codServico
	 *            the codServico to set
	 */
	public void setCodServico(String codServico) {
		this.codServico = codServico;
	}

}
