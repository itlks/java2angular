package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class RecargaProgamacaoDTO implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5694106217211499991L;
	private String numProtocolo;
	private String dtagendamento;
	private String hragendamento;
	/**
	 * @return the numProtocolo
	 */
	public String getNumProtocolo() {
		return numProtocolo;
	}
	/**
	 * @param numProtocolo the numProtocolo to set
	 */
	public void setNumProtocolo(String numProtocolo) {
		this.numProtocolo = numProtocolo;
	}
	/**
	 * @return the dtagendamento
	 */
	public String getDtagendamento() {
		return dtagendamento;
	}
	/**
	 * @param dtagendamento the dtagendamento to set
	 */
	public void setDtagendamento(String dtagendamento) {
		this.dtagendamento = dtagendamento;
	}
	/**
	 * @return the hragendamento
	 */
	public String getHragendamento() {
		return hragendamento;
	}
	/**
	 * @param hragendamento the hragendamento to set
	 */
	public void setHragendamento(String hragendamento) {
		this.hragendamento = hragendamento;
	}

	
}
