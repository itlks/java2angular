package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.altec.bsbr.app.ibe.dto.pagamentocodigobarra.CBAvisoDTO;

public class PagamentoCodigoBarrasResponseDTO  implements Serializable {

	private static final long serialVersionUID = 1772436721112122707L;
	
	private String transacaoProduto;
	private String codBarras;
	private String indLeitura;
	private Date fecVencimiento;
	private BigDecimal importe;
	private String nombreConvenio;
	private String indicadorSolicitaValor;
	private Integer tamanoIdentificador;
	private String codMenu;
	private String indicadorVRBoleto;
	private Date horarioLimitePagamento;
	private BigDecimal valorReferenciaVRBoleto;
	private String codLinx;
	private CBAvisoDTO aviso;
	private Date dataAgendamento;
	
	public String getTransacaoProduto() {
		return transacaoProduto;
	}
	public void setTransacaoProduto(String transacaoProduto) {
		this.transacaoProduto = transacaoProduto;
	}
	public String getCodBarras() {
		return codBarras;
	}
	public void setCodBarras(String codBarras) {
		this.codBarras = codBarras;
	}
	public String getIndLeitura() {
		return indLeitura;
	}
	public void setIndLeitura(String indLeitura) {
		this.indLeitura = indLeitura;
	}
	public Date getFecVencimiento() {
		return fecVencimiento;
	}
	public void setFecVencimiento(Date fecVencimiento) {
		this.fecVencimiento = fecVencimiento;
	}
	public BigDecimal getImporte() {
		return importe;
	}
	public void setImporte(BigDecimal importe) {
		this.importe = importe;
	}
	public String getNombreConvenio() {
		return nombreConvenio;
	}
	public void setNombreConvenio(String nombreConvenio) {
		this.nombreConvenio = nombreConvenio;
	}
	public String getIndicadorSolicitaValor() {
		return indicadorSolicitaValor;
	}
	public void setIndicadorSolicitaValor(String indicadorSolicitaValor) {
		this.indicadorSolicitaValor = indicadorSolicitaValor;
	}
	public Integer getTamanoIdentificador() {
		return tamanoIdentificador;
	}
	public void setTamanoIdentificador(Integer tamanoIdentificador) {
		this.tamanoIdentificador = tamanoIdentificador;
	}
	public String getCodMenu() {
		return codMenu;
	}
	public void setCodMenu(String codMenu) {
		this.codMenu = codMenu;
	}
	public String getIndicadorVRBoleto() {
		return indicadorVRBoleto;
	}
	public void setIndicadorVRBoleto(String indicadorVRBoleto) {
		this.indicadorVRBoleto = indicadorVRBoleto;
	}
	public Date getHorarioLimitePagamento() {
		return horarioLimitePagamento;
	}
	public void setHorarioLimitePagamento(Date horarioLimitePagamento) {
		this.horarioLimitePagamento = horarioLimitePagamento;
	}
	public BigDecimal getValorReferenciaVRBoleto() {
		return valorReferenciaVRBoleto;
	}
	public void setValorReferenciaVRBoleto(BigDecimal valorReferenciaVRBoleto) {
		this.valorReferenciaVRBoleto = valorReferenciaVRBoleto;
	}
	public String getCodLinx() {
		return codLinx;
	}
	public void setCodLinx(String codLinx) {
		this.codLinx = codLinx;
	}
	public CBAvisoDTO getAviso() {
		return aviso;
	}
	public void setAviso(CBAvisoDTO aviso) {
		this.aviso = aviso;
	}
	public Date getDataAgendamento() {
		return dataAgendamento;
	}
	public void setDataAgendamento(Date dataAgendamento) {
		this.dataAgendamento = dataAgendamento;
	}
	
}
