package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.List;

public class TransfValoresDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6390828457725420164L;
	
	private String saida;
	private String lngRetCode;
	private String strErro;
	private String strErroTecnica;
	private String strGerouPendencia;
	private String linhasRet;
	private List<ListaTransfValoresDTO> rsRetorno;
	private String strFinalidade;
	private String strErroMQS;
	private String strChaveAutenticacao;
	private String strChave23SemCript;
	
	public String getSaida() {
		return saida;
	}
	public void setSaida(String saida) {
		this.saida = saida;
	}
	public String getStrGerouPendencia() {
		return strGerouPendencia;
	}
	public void setStrGerouPendencia(String strGerouPendencia) {
		this.strGerouPendencia = strGerouPendencia;
	}
	public String getLinhasRet() {
		return linhasRet;
	}
	public void setLinhasRet(String linhasRet) {
		this.linhasRet = linhasRet;
	}
	public List<ListaTransfValoresDTO> getRsRetorno() {
		return rsRetorno;
	}
	public void setRsRetorno(List<ListaTransfValoresDTO> rsRetorno) {
		this.rsRetorno = rsRetorno;
	}
	public String getStrFinalidade() {
		return strFinalidade;
	}
	public void setStrFinalidade(String strFinalidade) {
		this.strFinalidade = strFinalidade;
	}
	public String getStrErroMQS() {
		return strErroMQS;
	}
	public void setStrErroMQS(String strErroMQS) {
		this.strErroMQS = strErroMQS;
	}
	public String getStrChaveAutenticacao() {
		return strChaveAutenticacao;
	}
	public void setStrChaveAutenticacao(String strChaveAutenticacao) {
		this.strChaveAutenticacao = strChaveAutenticacao;
	}
	public String getStrChave23SemCript() {
		return strChave23SemCript;
	}
	public void setStrChave23SemCript(String strChave23SemCript) {
		this.strChave23SemCript = strChave23SemCript;
	}
	public String getLngRetCode() {
		return lngRetCode;
	}
	public void setLngRetCode(String lngRetCode) {
		this.lngRetCode = lngRetCode;
	}
	public String getStrErro() {
		return strErro;
	}
	public void setStrErro(String strErro) {
		this.strErro = strErro;
	}
	public String getStrErroTecnica() {
		return strErroTecnica;
	}
	public void setStrErroTecnica(String strErroTecnica) {
		this.strErroTecnica = strErroTecnica;
	}
}
