package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ComprovanteConsultaListSegViaSefazDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8112868021061310582L;

	private List<SegViaSefazDTO> segViaSefazDTOs = new ArrayList<SegViaSefazDTO>();
	private SegViaSefazDTO segViaSefazSelecionado = new SegViaSefazDTO();
	private String codigoErro;
	private String mensagemRetornoCliente;
	private String mensagemRetornoProduto;

	public List<SegViaSefazDTO> getSegViaSefazDTOs() {
		return segViaSefazDTOs;
	}

	public void setSegViaSefazDTOs(List<SegViaSefazDTO> segViaSefazDTOs) {
		this.segViaSefazDTOs = segViaSefazDTOs;
	}
	
	public String getCodigoErro() {
		return codigoErro;
	}

	public void setCodigoErro(String codigoErro) {
		this.codigoErro = codigoErro;
	}

	public String getMensagemRetornoCliente() {
		return mensagemRetornoCliente;
	}

	public void setMensagemRetornoCliente(String mensagemRetornoCliente) {
		this.mensagemRetornoCliente = mensagemRetornoCliente;
	}

	public String getMensagemRetornoProduto() {
		return mensagemRetornoProduto;
	}

	public void setMensagemRetornoProduto(String mensagemRetornoProduto) {
		this.mensagemRetornoProduto = mensagemRetornoProduto;
	}

	public SegViaSefazDTO getSegViaSefazSelecionado() {
		return segViaSefazSelecionado;
	}

	public void setSegViaSefazSelecionado(SegViaSefazDTO segViaSefazSelecionado) {
		this.segViaSefazSelecionado = segViaSefazSelecionado;
	}

	
	
	
	

}
