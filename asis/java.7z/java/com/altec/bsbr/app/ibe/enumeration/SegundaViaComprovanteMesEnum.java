package com.altec.bsbr.app.ibe.enumeration;

public enum SegundaViaComprovanteMesEnum {
	
	JANEIRO(0, "Janeiro"),
	FEVEREIRO(1, "Fevereiro"),
	MARCO(2, "Mar�o"),
	ABRIL(3, "Abril"),
	MAIO(4, "Maio"),
	JUNHO(5, "Junho"),
	JULHO(6, "Julho"),
	AGOSTO(7, "Agosto"),
	SETEMBRO(8, "Setembro"),
	OUTUBRO(9, "Outubro"),
	NOVEMBRO(10, "Novembro"),
	DEZEMBRO(11, "Dezembro");
	
	private int valor;
	private String descricao;
	
	private SegundaViaComprovanteMesEnum(int valor, String descricao) {
		this.valor = valor;
		this.descricao = descricao;
	}
	
	public int getValor() {
		return valor;
	}

	public String getDescricao() {
		return descricao;
	}

	
}
