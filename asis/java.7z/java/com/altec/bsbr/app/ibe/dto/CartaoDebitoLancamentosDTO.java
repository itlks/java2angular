package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.altec.bsbr.app.ibe.util.WSFormat;

@SuppressWarnings("unused")
public class CartaoDebitoLancamentosDTO implements Serializable {

	private static final long serialVersionUID = 8843145121948620569L;

	private List<CartaoDebitoLancamentosCartaoDTO> cartoes;
	private List<LancamentoDebitoTelaDTO> lancamentos;
	private List<CartaoDebitoLancamentosCnpjDTO> cnpjs;
	private List<CartaoDebitoLancamentosContratoDTO> contratos;
	
	private CartaoDebitoLancamentosContratoDTO contratoSelecionado;
	private CartaoDebitoLancamentosCnpjDTO cnpjSelecionado;
	private CartaoDebitoLancamentosCartaoDTO cartaoSelecionado;

	private Date dataInicialDate;
	private Date dataFinalDate;
	private String dataInicial;
	private String dataFinal;
	/**
	 * @return the cartoes
	 */
	public List<CartaoDebitoLancamentosCartaoDTO> getCartoes() {
		return cartoes;
	}
	/**
	 * @param cartoes the cartoes to set
	 */
	public void setCartoes(List<CartaoDebitoLancamentosCartaoDTO> cartoes) {
		this.cartoes = cartoes;
	}
	/**
	 * @return the lancamentos
	 */
	public List<LancamentoDebitoTelaDTO> getLancamentos() {
		if(lancamentos == null){
			lancamentos = new ArrayList<LancamentoDebitoTelaDTO>();
		}
		return lancamentos;
	}
	/**
	 * @param lancamentos the lancamentos to set
	 */
	public void setLancamentos(List<LancamentoDebitoTelaDTO> lancamentos) {
		this.lancamentos = lancamentos;
	}
	/**
	 * @return the cnpjSelecionado
	 */
	public CartaoDebitoLancamentosCnpjDTO getCnpjSelecionado() {
		return cnpjSelecionado;
	}
	/**
	 * @param cnpjSelecionado the cnpjSelecionado to set
	 */
	public void setCnpjSelecionado(CartaoDebitoLancamentosCnpjDTO cnpjSelecionado) {
		this.cnpjSelecionado = cnpjSelecionado;
	}
	/**
	 * @return the cartaoSelecionado
	 */
	public CartaoDebitoLancamentosCartaoDTO getCartaoSelecionado() {
		if(cartaoSelecionado == null){
			cartaoSelecionado = new CartaoDebitoLancamentosCartaoDTO();
		}
		return cartaoSelecionado;
	}
	/**
	 * @param cartaoSelecionado the cartaoSelecionado to set
	 */
	public void setCartaoSelecionado(CartaoDebitoLancamentosCartaoDTO cartaoSelecionado) {
		this.cartaoSelecionado = cartaoSelecionado;
	}
	/**
	 * @return the dataInicialDate
	 */
	public Date getDataInicialDate() {
		return dataInicialDate = null != getDataInicial() ? WSFormat.getDateDD_MM_YYYY(getDataInicial()) : null;
	}
	/**
	 * @param dataInicialDate the dataInicialDate to set
	 */
	public void setDataInicialDate(Date dataInicialDate) {
		this.dataInicialDate = dataInicialDate;
	}
	/**
	 * @return the dataFinalDate
	 */
	public Date getDataFinalDate() {
		return dataFinalDate = null != getDataFinal() ? WSFormat.getDateDD_MM_YYYY(getDataFinal()) : null;
	}
	/**
	 * @param dataFinalDate the dataFinalDate to set
	 */
	public void setDataFinalDate(Date dataFinalDate) {
		this.dataFinalDate = dataFinalDate;
	}
	/**
	 * @return the dataInicial
	 */
	public String getDataInicial() {
		return dataInicial;
	}
	/**
	 * @param dataInicial the dataInicial to set
	 */
	public void setDataInicial(String dataInicial) {
		this.dataInicial = dataInicial;
	}
	/**
	 * @return the dataFinal
	 */
	public String getDataFinal() {
		return dataFinal;
	}
	/**
	 * @param dataFinal the dataFinal to set
	 */
	public void setDataFinal(String dataFinal) {
		this.dataFinal = dataFinal;
	}
	public List<CartaoDebitoLancamentosCnpjDTO> getCnpjs() {
		return cnpjs;
	}
	public void setCnpjs(List<CartaoDebitoLancamentosCnpjDTO> cnpjs) {
		this.cnpjs = cnpjs;
	}
	public List<CartaoDebitoLancamentosContratoDTO> getContratos() {
		return contratos == null? contratos = new ArrayList <CartaoDebitoLancamentosContratoDTO>() : contratos;
	}
	public void setContratos(List<CartaoDebitoLancamentosContratoDTO> contratos) {
		this.contratos = contratos;
	}
	public CartaoDebitoLancamentosContratoDTO getContratoSelecionado() {
		return contratoSelecionado;
	}
	public void setContratoSelecionado(CartaoDebitoLancamentosContratoDTO contratoSelecionado) {
		this.contratoSelecionado = contratoSelecionado;
	}

}
