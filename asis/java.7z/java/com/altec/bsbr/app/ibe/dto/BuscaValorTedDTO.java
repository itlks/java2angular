package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;

import com.altec.bsbr.app.ibe.dto.ted_pz.ErrosDTO;

public class BuscaValorTedDTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1712832786720904884L;
	
	private String saida;
	private ErrosDTO erros;
	private Long lngVigeDoc;
	private BigDecimal dblMiniDoc;
	private BigDecimal dblMaxiDoc;
	private Long lngVigeTed;
	private BigDecimal dblMiniTed;
	private BigDecimal dblMaxiTed;
	private BigDecimal dblMiniDocTed;
	private BigDecimal dblMaxiDocTed;
	private Long lngRetCode;
	private String strErro;
	private String strErroTecnica;
	private String strChaveAutenticacao;
	public String getSaida() {
		return saida;
	}
	public void setSaida(String saida) {
		this.saida = saida;
	}
	public ErrosDTO getErros() {
		return erros;
	}
	public void setErros(ErrosDTO erros) {
		this.erros = erros;
	}
	public Long getLngVigeDoc() {
		return lngVigeDoc;
	}
	public void setLngVigeDoc(Long lngVigeDoc) {
		this.lngVigeDoc = lngVigeDoc;
	}
	public BigDecimal getDblMiniDoc() {
		return dblMiniDoc;
	}
	public void setDblMiniDoc(BigDecimal dblMiniDoc) {
		this.dblMiniDoc = dblMiniDoc;
	}
	public BigDecimal getDblMaxiDoc() {
		return dblMaxiDoc;
	}
	public void setDblMaxiDoc(BigDecimal dblMaxiDoc) {
		this.dblMaxiDoc = dblMaxiDoc;
	}
	public Long getLngVigeTed() {
		return lngVigeTed;
	}
	public void setLngVigeTed(Long lngVigeTed) {
		this.lngVigeTed = lngVigeTed;
	}
	public BigDecimal getDblMiniTed() {
		return dblMiniTed;
	}
	public void setDblMiniTed(BigDecimal dblMiniTed) {
		this.dblMiniTed = dblMiniTed;
	}
	public BigDecimal getDblMaxiTed() {
		return dblMaxiTed;
	}
	public void setDblMaxiTed(BigDecimal dblMaxiTed) {
		this.dblMaxiTed = dblMaxiTed;
	}
	public BigDecimal getDblMiniDocTed() {
		return dblMiniDocTed;
	}
	public void setDblMiniDocTed(BigDecimal dblMiniDocTed) {
		this.dblMiniDocTed = dblMiniDocTed;
	}
	public BigDecimal getDblMaxiDocTed() {
		return dblMaxiDocTed;
	}
	public void setDblMaxiDocTed(BigDecimal dblMaxiDocTed) {
		this.dblMaxiDocTed = dblMaxiDocTed;
	}
	public Long getLngRetCode() {
		return lngRetCode;
	}
	public void setLngRetCode(Long lngRetCode) {
		this.lngRetCode = lngRetCode;
	}
	public String getStrErro() {
		return strErro;
	}
	public void setStrErro(String strErro) {
		this.strErro = strErro;
	}
	public String getStrErroTecnica() {
		return strErroTecnica;
	}
	public void setStrErroTecnica(String strErroTecnica) {
		this.strErroTecnica = strErroTecnica;
	}
	public String getStrChaveAutenticacao() {
		return strChaveAutenticacao;
	}
	public void setStrChaveAutenticacao(String strChaveAutenticacao) {
		this.strChaveAutenticacao = strChaveAutenticacao;
	}
	
	

}
