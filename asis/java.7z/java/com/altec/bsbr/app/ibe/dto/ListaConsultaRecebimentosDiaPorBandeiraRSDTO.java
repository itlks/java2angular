package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;

public class ListaConsultaRecebimentosDiaPorBandeiraRSDTO implements Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = 849369535582712971L;
	private java.lang.String TSOESZCODREG;
	private java.lang.String TSOESZNOMCREDDESC;
	private java.lang.String TSOESZCODBAND;
	private java.lang.String TSOESZTPOVEND;
	private java.lang.String TSOESZVALOR;
	
	private BigDecimal valorFormatado;

	public java.lang.String getTSOESZCODREG() {
		return TSOESZCODREG;
	}
	public void setTSOESZCODREG(java.lang.String tSOESZCODREG) {
		TSOESZCODREG = tSOESZCODREG;
	}
	public java.lang.String getTSOESZNOMCREDDESC() {
		return TSOESZNOMCREDDESC;
	}
	public void setTSOESZNOMCREDDESC(java.lang.String tSOESZNOMCREDDESC) {
		TSOESZNOMCREDDESC = tSOESZNOMCREDDESC;
	}
	public java.lang.String getTSOESZCODBAND() {
		return TSOESZCODBAND;
	}
	public void setTSOESZCODBAND(java.lang.String tSOESZCODBAND) {
		TSOESZCODBAND = tSOESZCODBAND;
	}
	public java.lang.String getTSOESZTPOVEND() {
		return TSOESZTPOVEND;
	}
	public void setTSOESZTPOVEND(java.lang.String tSOESZTPOVEND) {
		TSOESZTPOVEND = tSOESZTPOVEND;
	}
	public java.lang.String getTSOESZVALOR() {
		return TSOESZVALOR;
	}
	public void setTSOESZVALOR(java.lang.String tSOESZVALOR) {
		TSOESZVALOR = tSOESZVALOR;
	}
	public BigDecimal getValorFormatado() {
		return valorFormatado;
	}
	public void setValorFormatado(BigDecimal valorFormatado) {
		this.valorFormatado = valorFormatado;
	}
	
	
	
	
	

}
