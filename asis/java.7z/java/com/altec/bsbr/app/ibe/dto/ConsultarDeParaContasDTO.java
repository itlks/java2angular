package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.List;

import com.altec.bsbr.app.ibe.dto.deparacontas.ErrosDTO;

public class ConsultarDeParaContasDTO  implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4506705284192775913L;
	private String saida;
	private List<DeParaContasDTO> rsContas;
	private ErrosDTO erros;
	
	public String getSaida() {
		return saida;
	}
	public void setSaida(String saida) {
		this.saida = saida;
	}
	public List<DeParaContasDTO> getRsContas() {
		return rsContas;
	}
	public void setRsContas(List<DeParaContasDTO> rsContas) {
		this.rsContas = rsContas;
	}
	public ErrosDTO getErros() {
		return erros;
	}
	public void setErros(ErrosDTO erros) {
		this.erros = erros;
	}
	
	

}
