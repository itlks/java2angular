package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

import com.altec.bsbr.app.ibe.util.WSFormat;

public class UsuarioSecundarioIncluirPerfilDTO implements Serializable {

  private static final long serialVersionUID = 8327157684860147106L;

  private String banco;
  private String agencia;
  private String numeroConta;
  private String perfilAcesso;
  private String perfilAutorizacao;
  private String descricaoPerfilAcesso;
  private String descricaoPerfilAutorizacao;

  public String getDescricaoPerfilAcesso() {
    return descricaoPerfilAcesso;
  }

  public void setDescricaoPerfilAcesso(String descricao) {
    this.descricaoPerfilAcesso = descricao;
  }

  public UsuarioSecundarioIncluirPerfilDTO() {

  }

  public String getAgencia() {
    return agencia;
  }

  public void setAgencia(String agencia) {
    this.agencia = WSFormat.formatarRetornoAgencia(agencia);
  }

  public String getNumeroConta() {
    return numeroConta;
  }

  public void setNumeroConta(String numeroConta) {
    this.numeroConta = numeroConta;
  }

  public String getPerfilAcesso() {
    return perfilAcesso;
  }

  public void setPerfilAcesso(String perfilAcesso) {
    this.perfilAcesso = perfilAcesso;
  }

  public String getPerfilAutorizacao() {
    return perfilAutorizacao;
  }

  public void setPerfilAutorizacao(String perfilAutorizacao) {
    this.perfilAutorizacao = perfilAutorizacao;
  }

  public String getBanco() {
    return banco;
  }

  public void setBanco(String banco) {
    this.banco = banco;
  }

  public String getDescricaoPerfilAutorizacao() {
    return descricaoPerfilAutorizacao;
  }

  public void setDescricaoPerfilAutorizacao(String descricaoPerfilAutorizacao) {
    this.descricaoPerfilAutorizacao = descricaoPerfilAutorizacao;
  }

}
