package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class GetnetConsultarExtratoListaDTO implements Serializable {

	private static final long serialVersionUID = 1413482038719930698L;
	/**
	 * Atributos ordenados por p�gina
	 */
	
	private String codBandeira;
	private String descricaoBandeira;
	private String cnpjEstabelecimento;
	private String codEstabelecimento;
	private String idMovimento;
	private String dataLancamento;
	private String parcela;
	private String quantidadeTransacoes;
	private String rubrica;
	private String siglaMoeda;
	private String valorBruto;
	private String sinalBruto;
	private String valorLiquido;
	private String sinalLiquido;
	private String codEcVenda;

	/**
	 * Getters e Setters respectivos 
	 */
	public String getCodBandeira() {
		return codBandeira;
	}
	public void setCodBandeira(String codBandeira) {
		this.codBandeira = codBandeira;
	}
	public String getDescricaoBandeira() {
		return descricaoBandeira;
	}
	public void setDescricaoBandeira(String descricaoBandeira) {
		this.descricaoBandeira = descricaoBandeira;
	}
	public String getCnpjEstabelecimento() {
		return cnpjEstabelecimento;
	}
	public void setCnpjEstabelecimento(String cnpjEstabelecimento) {
		this.cnpjEstabelecimento = cnpjEstabelecimento;
	}
	public String getCodEstabelecimento() {
		return codEstabelecimento;
	}
	public void setCodEstabelecimento(String codEstabelecimento) {
		this.codEstabelecimento = codEstabelecimento;
	}
	public String getIdMovimento() {
		return idMovimento;
	}
	public void setIdMovimento(String idMovimento) {
		this.idMovimento = idMovimento;
	}
	public String getDataLancamento() {
		return dataLancamento;
	}
	public void setDataLancamento(String dataLancamento) {
		this.dataLancamento = dataLancamento;
	}
	public String getParcela() {
		return parcela;
	}
	public void setParcela(String parcela) {
		this.parcela = parcela;
	}
	public String getQuantidadeTransacoes() {
		return quantidadeTransacoes;
	}
	public void setQuantidadeTransacoes(String quantidadeTransacoes) {
		this.quantidadeTransacoes = quantidadeTransacoes;
	}
	public String getRubrica() {
		return rubrica;
	}
	public void setRubrica(String rubrica) {
		this.rubrica = rubrica;
	}
	public String getSiglaMoeda() {
		return siglaMoeda;
	}
	public void setSiglaMoeda(String siglaMoeda) {
		this.siglaMoeda = siglaMoeda;
	}
	public String getValorBruto() {
		return valorBruto;
	}
	public void setValorBruto(String valorBruto) {
		this.valorBruto = valorBruto;
	}
	public String getSinalBruto() {
		return sinalBruto;
	}
	public void setSinalBruto(String sinalBruto) {
		this.sinalBruto = sinalBruto;
	}
	public String getValorLiquido() {
		return valorLiquido;
	}
	public void setValorLiquido(String valorLiquido) {
		this.valorLiquido = valorLiquido;
	}
	public String getSinalLiquido() {
		return sinalLiquido;
	}
	public void setSinalLiquido(String sinalLiquido) {
		this.sinalLiquido = sinalLiquido;
	}
	public String getCodEcVenda() {
		return codEcVenda;
	}
	public void setCodEcVenda(String codEcVenda) {
		this.codEcVenda = codEcVenda;
	}
}
