package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

import com.altec.bsbr.app.ibe.dto.titulos.ErrosDTO;

public class EfetivaPgtoTitulosResponseDTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4427344028611957571L;
	private String strGerouPendencia;
	private String linhasRet;
	private String strChave23;
	private String strChave23SemCript;
	private String strOEFKCHAVEAMARRACAO;
	private String strOEFKDTACONTAB;
	private String strOEFKDTPGTOTITU;
	private String strOEFKDTAVCTO;
	private String strOEFKDTAAGD;
	private String strOEFKNOMECEDENTE;
	private String strOEFKNOMESACADO;
	private String strOEFKVLRDIGICLIE;
	private String strOEFKVLRTOTALTITU;
	private String strOEFKVLRBASELEGADO;
	private String strOEFKTPCAPBAR;
	private String strOEFKCODBARRAS;
	private String strOEFKTIPOTITU;
	private String strOEFKCODCEDENTE;
	private String strOEFKCODNOSNUM;
	private String strOEFKCODSEUNUM;
	private String strOEFKVLRDESCTITU;
	private String strOEFKVLRABATTITU;
	private String strOEFKVLRJURTITU;
	private String strOEFKVLRMULTATITU;
	private String strOEFKVLRIOFTITU;
	private String strOEFKDATARECIBO;
	private String strOEFKHORARECIBO;
	private String strOEFKINDFORMPGTO;
	private String strOEFKPAN;
	private String strOEFKCARTAOBANCO;
	private String strOEFKCARTAOAGENCIA;
	private String strOEFKCARTAOCONTRATO;
	private String strNomeCedente;
	private String strNomeSacado;
	private String strErro;
	private String strErroTecnica;
	private String lngRetCode;
	private java.lang.Object saida;
	private ErrosDTO erros;
	public String getStrGerouPendencia() {
		return strGerouPendencia;
	}
	public void setStrGerouPendencia(String strGerouPendencia) {
		this.strGerouPendencia = strGerouPendencia;
	}
	public String getLinhasRet() {
		return linhasRet;
	}
	public void setLinhasRet(String linhasRet) {
		this.linhasRet = linhasRet;
	}
	public String getStrChave23() {
		return strChave23;
	}
	public void setStrChave23(String strChave23) {
		this.strChave23 = strChave23;
	}
	public String getStrChave23SemCript() {
		return strChave23SemCript;
	}
	public void setStrChave23SemCript(String strChave23SemCript) {
		this.strChave23SemCript = strChave23SemCript;
	}
	public String getStrOEFKCHAVEAMARRACAO() {
		return strOEFKCHAVEAMARRACAO;
	}
	public void setStrOEFKCHAVEAMARRACAO(String strOEFKCHAVEAMARRACAO) {
		this.strOEFKCHAVEAMARRACAO = strOEFKCHAVEAMARRACAO;
	}
	public String getStrOEFKDTACONTAB() {
		return strOEFKDTACONTAB;
	}
	public void setStrOEFKDTACONTAB(String strOEFKDTACONTAB) {
		this.strOEFKDTACONTAB = strOEFKDTACONTAB;
	}
	public String getStrOEFKDTPGTOTITU() {
		return strOEFKDTPGTOTITU;
	}
	public void setStrOEFKDTPGTOTITU(String strOEFKDTPGTOTITU) {
		this.strOEFKDTPGTOTITU = strOEFKDTPGTOTITU;
	}
	public String getStrOEFKDTAVCTO() {
		return strOEFKDTAVCTO;
	}
	public void setStrOEFKDTAVCTO(String strOEFKDTAVCTO) {
		this.strOEFKDTAVCTO = strOEFKDTAVCTO;
	}
	public String getStrOEFKDTAAGD() {
		return strOEFKDTAAGD;
	}
	public void setStrOEFKDTAAGD(String strOEFKDTAAGD) {
		this.strOEFKDTAAGD = strOEFKDTAAGD;
	}
	public String getStrOEFKNOMECEDENTE() {
		return strOEFKNOMECEDENTE;
	}
	public void setStrOEFKNOMECEDENTE(String strOEFKNOMECEDENTE) {
		this.strOEFKNOMECEDENTE = strOEFKNOMECEDENTE;
	}
	public String getStrOEFKNOMESACADO() {
		return strOEFKNOMESACADO;
	}
	public void setStrOEFKNOMESACADO(String strOEFKNOMESACADO) {
		this.strOEFKNOMESACADO = strOEFKNOMESACADO;
	}
	public String getStrOEFKVLRDIGICLIE() {
		return strOEFKVLRDIGICLIE;
	}
	public void setStrOEFKVLRDIGICLIE(String strOEFKVLRDIGICLIE) {
		this.strOEFKVLRDIGICLIE = strOEFKVLRDIGICLIE;
	}
	public String getStrOEFKVLRTOTALTITU() {
		return strOEFKVLRTOTALTITU;
	}
	public void setStrOEFKVLRTOTALTITU(String strOEFKVLRTOTALTITU) {
		this.strOEFKVLRTOTALTITU = strOEFKVLRTOTALTITU;
	}
	public String getStrOEFKVLRBASELEGADO() {
		return strOEFKVLRBASELEGADO;
	}
	public void setStrOEFKVLRBASELEGADO(String strOEFKVLRBASELEGADO) {
		this.strOEFKVLRBASELEGADO = strOEFKVLRBASELEGADO;
	}
	public String getStrOEFKTPCAPBAR() {
		return strOEFKTPCAPBAR;
	}
	public void setStrOEFKTPCAPBAR(String strOEFKTPCAPBAR) {
		this.strOEFKTPCAPBAR = strOEFKTPCAPBAR;
	}
	public String getStrOEFKCODBARRAS() {
		return strOEFKCODBARRAS;
	}
	public void setStrOEFKCODBARRAS(String strOEFKCODBARRAS) {
		this.strOEFKCODBARRAS = strOEFKCODBARRAS;
	}
	public String getStrOEFKTIPOTITU() {
		return strOEFKTIPOTITU;
	}
	public void setStrOEFKTIPOTITU(String strOEFKTIPOTITU) {
		this.strOEFKTIPOTITU = strOEFKTIPOTITU;
	}
	public String getStrOEFKCODCEDENTE() {
		return strOEFKCODCEDENTE;
	}
	public void setStrOEFKCODCEDENTE(String strOEFKCODCEDENTE) {
		this.strOEFKCODCEDENTE = strOEFKCODCEDENTE;
	}
	public String getStrOEFKCODNOSNUM() {
		return strOEFKCODNOSNUM;
	}
	public void setStrOEFKCODNOSNUM(String strOEFKCODNOSNUM) {
		this.strOEFKCODNOSNUM = strOEFKCODNOSNUM;
	}
	public String getStrOEFKCODSEUNUM() {
		return strOEFKCODSEUNUM;
	}
	public void setStrOEFKCODSEUNUM(String strOEFKCODSEUNUM) {
		this.strOEFKCODSEUNUM = strOEFKCODSEUNUM;
	}
	public String getStrOEFKVLRDESCTITU() {
		return strOEFKVLRDESCTITU;
	}
	public void setStrOEFKVLRDESCTITU(String strOEFKVLRDESCTITU) {
		this.strOEFKVLRDESCTITU = strOEFKVLRDESCTITU;
	}
	public String getStrOEFKVLRABATTITU() {
		return strOEFKVLRABATTITU;
	}
	public void setStrOEFKVLRABATTITU(String strOEFKVLRABATTITU) {
		this.strOEFKVLRABATTITU = strOEFKVLRABATTITU;
	}
	public String getStrOEFKVLRJURTITU() {
		return strOEFKVLRJURTITU;
	}
	public void setStrOEFKVLRJURTITU(String strOEFKVLRJURTITU) {
		this.strOEFKVLRJURTITU = strOEFKVLRJURTITU;
	}
	public String getStrOEFKVLRMULTATITU() {
		return strOEFKVLRMULTATITU;
	}
	public void setStrOEFKVLRMULTATITU(String strOEFKVLRMULTATITU) {
		this.strOEFKVLRMULTATITU = strOEFKVLRMULTATITU;
	}
	public String getStrOEFKVLRIOFTITU() {
		return strOEFKVLRIOFTITU;
	}
	public void setStrOEFKVLRIOFTITU(String strOEFKVLRIOFTITU) {
		this.strOEFKVLRIOFTITU = strOEFKVLRIOFTITU;
	}
	public String getStrOEFKDATARECIBO() {
		return strOEFKDATARECIBO;
	}
	public void setStrOEFKDATARECIBO(String strOEFKDATARECIBO) {
		this.strOEFKDATARECIBO = strOEFKDATARECIBO;
	}
	public String getStrOEFKHORARECIBO() {
		return strOEFKHORARECIBO;
	}
	public void setStrOEFKHORARECIBO(String strOEFKHORARECIBO) {
		this.strOEFKHORARECIBO = strOEFKHORARECIBO;
	}
	public String getStrOEFKINDFORMPGTO() {
		return strOEFKINDFORMPGTO;
	}
	public void setStrOEFKINDFORMPGTO(String strOEFKINDFORMPGTO) {
		this.strOEFKINDFORMPGTO = strOEFKINDFORMPGTO;
	}
	public String getStrOEFKPAN() {
		return strOEFKPAN;
	}
	public void setStrOEFKPAN(String strOEFKPAN) {
		this.strOEFKPAN = strOEFKPAN;
	}
	public String getStrOEFKCARTAOBANCO() {
		return strOEFKCARTAOBANCO;
	}
	public void setStrOEFKCARTAOBANCO(String strOEFKCARTAOBANCO) {
		this.strOEFKCARTAOBANCO = strOEFKCARTAOBANCO;
	}
	public String getStrOEFKCARTAOAGENCIA() {
		return strOEFKCARTAOAGENCIA;
	}
	public void setStrOEFKCARTAOAGENCIA(String strOEFKCARTAOAGENCIA) {
		this.strOEFKCARTAOAGENCIA = strOEFKCARTAOAGENCIA;
	}
	public String getStrOEFKCARTAOCONTRATO() {
		return strOEFKCARTAOCONTRATO;
	}
	public void setStrOEFKCARTAOCONTRATO(String strOEFKCARTAOCONTRATO) {
		this.strOEFKCARTAOCONTRATO = strOEFKCARTAOCONTRATO;
	}
	public String getStrNomeCedente() {
		return strNomeCedente;
	}
	public void setStrNomeCedente(String strNomeCedente) {
		this.strNomeCedente = strNomeCedente;
	}
	public String getStrNomeSacado() {
		return strNomeSacado;
	}
	public void setStrNomeSacado(String strNomeSacado) {
		this.strNomeSacado = strNomeSacado;
	}
	public String getStrErro() {
		return strErro;
	}
	public void setStrErro(String strErro) {
		this.strErro = strErro;
	}
	public String getStrErroTecnica() {
		return strErroTecnica;
	}
	public void setStrErroTecnica(String strErroTecnica) {
		this.strErroTecnica = strErroTecnica;
	}
	public String getLngRetCode() {
		return lngRetCode;
	}
	public void setLngRetCode(String lngRetCode) {
		this.lngRetCode = lngRetCode;
	}
	public java.lang.Object getSaida() {
		return saida;
	}
	public void setSaida(java.lang.Object saida) {
		this.saida = saida;
	}
	public ErrosDTO getErros() {
		return erros;
	}
	public void setErros(ErrosDTO erros) {
		this.erros = erros;
	}

	
}
