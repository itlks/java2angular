package com.altec.bsbr.app.ibe.enumeration;

public enum TransacaoOrquestradorEnum {
    
	LOGIN															("1", "Transacao de Login"), 
	TRIBUTOS_BOLETO_BANCARIO_MESMO_BANCO		                    ("29", "Tributos - Boleto banc�rio (mesmo banco)" ),
	TRIBUTOS_BOLETO_BANCARIO_OUTROS_BANCOS		                    ("29", "Tributos - Boleto banc�rio (outros bancos)" ),
	TRIBUTO_ESTADUAIS_GARE_ICMS_IMP_SP								("4", "Tributo Estaduais - GARE ICMS Imp SP" ),
	TRIBUTO_ESTADUAIS_GNRE											("5", "Tributo Estaduais - GNRE" ),
	TRIBUTO_ESTADUAIS_DARE_TRIB_OUTROS_ESTADOS						("6", "Tributo Estaduais - DARE / Trib Outros Estados" ),
	TRANSFERENCIAS_DOC												("7", "Transfer�ncias - DOC" ),
	TRANSFERENCIAS_TED												("8", "Transfer�ncias - TED" ),
	TRANSFERENCIAS_ENTRE_CONTAS										("9", "Transfer�ncias - Entre Contas" ),
	COMPROMISSOS_TRANSFERENCIA_DOC									("10", "Compromissos - Transferencia - DOC" ),
	COMPROMISSOS_TRANSFERENCIA_CC									("11", "Compromissos - Transferencia - CC" ),
	COMPROMISSOS_TRANSFERENCIA_POU									("12", "Compromissos - Transferencia - POU" ),
	COMPROMISSOS_TRANSFERENCIA_CIP									("13", "Compromissos - Transferencia - CIP" ),
	COMPROMISSOS_TRANSFERENCIA_STR									("14", "Compromissos - Transferencia - STR" ),
	FOLHA_DE_PAGAMENTO_TRANSFERENCIA_DOC							("15", "Folha de Pagamento - Transferencia - DOC" ),
	FOLHA_DE_PAGAMENTO_TRANSFERENCIA_CC								("16", "Folha de Pagamento - Transferencia - CC" ),
	FOLHA_DE_PAGAMENTO_TRANSFERENCIA_POU							("17", "Folha de Pagamento - Transferencia - POU" ),
	FOLHA_DE_PAGAMENTO_TRANSFERENCIA_OP								("18", "Folha de Pagamento - Transferencia - OP" ),
	FOLHA_DE_PAGAMENTO_TRANSFERENCIA_TED_STR						("19", "Folha de Pagamento - Transferencia - TED STR" ),
	FOLHA_DE_PAGAMENTO_TRANSFERENCIA_TED_CIP						("20", "Folha de Pagamento - Transferencia - TED CIP" ),
	
	BUSCADISP      													("1001", "Busca Dispositivo Orquestrador" ), 
	AUTTKNOTP      													("1002", "Autentica Token OTP" ), 
	AUTMOBTKN      													("1003", "Autentica Mobile Token" ), 
	AUTQRTKN       													("1004", "Autentica QR Token ou Novo Mobile Token" ), 
	DESCONHECIDA 													("-1", "Transacao desconhecida" ),
	TRIBUTO_ESTADUAIS_GARE_DR_SP									("1001", "Tributo Estaduais - GARE DR SP" ),
	TRIBUTO_DARF													("1001", "Tributo Federais - DARF" ),
	SEGUNDA_VIA_LICENCIAMENTO										("1001", "Segunda Via Licenciamento" ),
	SEGUNDA_VIA_TRANSFERENCIA										("1001", "Segunda Via Transferencia" ),
	AUTORIZACAO_PENDENCIA											("1001", "Autorizacao Pendencia" ),
	PACOTE_SERVICOS_ALTERACAO										("1001", "Pacote de Servicos - Alterar" ),
	RECOLHIMENTO_IPVA												("1001", "Recolhimento IPVA" ),
	RECOLHIMENTO_DPVAT												("1001", "Recolhimento DPVAT" ),
	RECOLHIMENTO_MULTAS_SAOPAULO									("1001", "Recolhimento Multas S�o Paulo" ),
	RECOLHIMENTO_MULTAS_INTERESTADUAIS								("1001", "Recolhimento Multas Interestaduais" ),
	DEBITO_SUSPENSAO_INCLUIR										("1001", "Debito automatico - Suspens�o" ),
	DEBITO_LANCAMENTO_DESBLOQUEIO									("1001", "Debito automatico - Desbloqueio" ),
	TRANSFERENCIA_AGENDAMENTO										("1001", "Transfer�ncias - Agendamentos" ),
	TRANSFERENCIAS_DE_VEICULOS										("1001", "Veiculos - Transferencias" ),
	DEBITO_SUSPENSAO_EXCLUIR										("1001", "Debito automatico suspens�o - Excluir" ),
	CADASTRAR_CELULAR										        ("1001", "Cadastrar Celular" ),
	MULTAS_SP														("1001", "Multas de Transito SP"),
	RECARGA_PROGRAMADA_INCLUIR										("1001", "Recarga Programada - Incluir" ),
	RECARGA_PROGRAMADA_ALTERAR										("1001", "Recarga Programada - Alterar" ),
	RECARGA_PROGRAMADA_EXCLUIR										("1001", "Recarga Programada - Excluir" ),
	RECARGA_PRE_PAGO												("1001", "Recarga Pre Pago" ),
	ADESAO_DOC_ONLINE										        ("1001", "Ades�o de Doc Online" ),
	RECARGA_CONFIRMAR_ALTERACAO										("1001", "Recarga Consultar Alteracao" ),
	RECARGA_CONFIRMAR_EXCLUSAO										("1001", "Recarga Consultar Exclusao" ),
	LICENCIAMENTO_DE_VEICULOS										("1001", "Licenciamento de Veiculos" ),
	BLOQUEIO_INFORMACOES_ATM										("1001", "Bloqueio de Informa��es no ATM" ),
	TERMO_DE_ADESAO_RECEBIVEIS										("1001", "Termo de Ades�o Recebiveis" ),
	SOLICITACAO_ANTECIPACAO_EMPRESTIMOS								("1001", "Solicita��o de Antecipa��o de Empr�stimos Receb�veis" ),
	PAG_COD_BARRA_CONCESSIONARIA_AGUA                               ("21",   "CONTAS DE �GUA" ),
	PAG_COD_BARRA_CONCESSIONARIA_LUZ                                ("22",   "CONTAS DE LUZ" ), 
	PAG_COD_BARRA_CONCESSIONARIA_GAS                                ("23",   "CONTAS DE G�S" ),
	PAG_COD_BARRA_CONCESSIONARIA_TELEFONE                           ("24",   "CONTAS DE TELEFONE" ),
	PAG_COD_BARRA_DEMAIS_DOCUMENTOS                                 ("25",   "DEMAIS DOCUMENTOS" ),
	PAG_COD_BARRA_DARF                                              ("70", "DARF" ),
	PAG_COD_BARRA_GPS                                               ("62",   "GPS" ),
	PAG_COD_BARRA_FGTS                                              ("72", "FGTS" ) , 
	PAG_COD_BARRA_SIMPLES_NACIONAL                                  ("74", "SIMPLES NACIONAL" ),
	PAG_COD_BARRA_GARE_ICMS_IMP_SP                                  ("67", "GARE ICMS Importa��o SP" ),
	PAG_COD_BARRA_GNRE                                              ("68", "GNRE" ),
	PAG_COD_BARRA_DARE_DAE_TRIBUTOS_ESTADUAIS                       ("69", "DARE / DAE / TRIBUTOS ESTADUAIS" ),
	PAG_COD_BARRA_IPTU_SP                                           ("64", "IPTU PMSP" ),
	PAG_COD_BARRA_TRIBUTOS_OUTRAS_PREFEITURAS                       ("65", "TRIBUTOS E TAXAS MUNICIPAIS" ),
	PAG_COD_BARRA_TRIBUTO_PMSP                                      ("66", "TRIBUTO PMSP" ),
	PAG_COD_BARRA_IPVA_SP                                           ("75", "IPVA SP" ),
	PAG_COD_BARRA_DPVAT_SP                                          ("76", "DPVAT SP" ),
	PAG_COD_BARRA_IPVA_MG                                           ("77", "IPVA MG" ),
	PAG_COD_BARRA_DPVAT_MG                                          ("78", "DPVAT MG" ), 
	PAG_COD_BARRA_MULTAS_TRANSITO                                   ("79", "MULTAS DE TRANSITO" ),
	PAG_COD_BARRA_DPVAT_OUTROS                                      ("80", "DPVAT DE OUTROS ESTADOS" );
	
	private String nome;
	private String chave;

	TransacaoOrquestradorEnum(String chave, String nome) {
		this.nome = nome;
		this.chave = chave;
	}

	public String getChave() {
		return chave;
	}

	public String getNome() {
		return nome;
	}

	public static TransacaoOrquestradorEnum getPorChave(String chave) {
		for (TransacaoOrquestradorEnum e : values()) {
			if (e.chave == chave) {
				return e;
			}
		}
		return TransacaoOrquestradorEnum.DESCONHECIDA;
	}

}

