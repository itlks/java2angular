package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.altec.bsbr.app.ibe.enumeration.TipoPagamentoCotaEnum;

public class ExercicioDTO implements Serializable, Comparable<ExercicioDTO> {
	
	private static final long serialVersionUID = 4861869539983657363L;

	private Integer exercicio;
	private Double valorTotal;
	private String vencimento;
	private boolean parcelaUnicaDesconto;
	private boolean exercicioAtual;
	private boolean selected;
	public String icoTuni;
	private List<CotaDTO> cotas;

	public ExercicioDTO() {
		this.cotas = new ArrayList<CotaDTO>();
	}

	public boolean isParcelaUnicaDesconto() {
		return parcelaUnicaDesconto;
	}

	public void setParcelaUnicaDesconto(boolean parcelaUnicaDesconto) {
		this.parcelaUnicaDesconto = parcelaUnicaDesconto;
	}

	public Integer getExercicio() {
		return exercicio;
	}

	public void setExercicio(Integer exercicio) {
		this.exercicio = exercicio;
	}

	public Double getValorTotal() {
		return valorTotal;
	}

	public void setValorTotal(Double valorTotal) {
		this.valorTotal = valorTotal;
	}

	public String getVencimento() {
		if (!this.exercicioAtual) {
			return "vencida";
		}
		return vencimento;
	}

	public void setVencimento(String vencimento) {
		this.vencimento = vencimento;
	}

	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	public List<CotaDTO> getCotas() {
		return cotas;
	}
	
	public void setCotas(List<CotaDTO> cotas) {
		this.cotas = cotas;
	}

	public void addCota(CotaDTO cotaDTO) {
		this.cotas.add(cotaDTO);
	}

	public String getIcoTuni() {
		return icoTuni;
	}

	public void setIcoTuni(String icoTuni) {
		this.icoTuni = icoTuni;
	}

	public String getIcoTuniDescricao() {
		String retorno="";
		if (!this.exercicioAtual) {
			retorno = " �nica";
		}
		else {
			if (this.icoTuni!=null) {
				TipoPagamentoCotaEnum enumCota = TipoPagamentoCotaEnum.buscarPorIndicador(this.icoTuni);
				return (enumCota == null ? "" : enumCota.getDescricao());
			}
		}
		return retorno;				
	}

	public boolean isExercicioAtual() {
		return exercicioAtual;
	}

	public void setExercicioAtual(boolean exercicioAtual) {
		this.exercicioAtual = exercicioAtual;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;		
		result = prime * result + exercicio;
		result = prime * result + ((icoTuni == null) ? 0 : icoTuni.hashCode());
		result = prime * result + (parcelaUnicaDesconto ? 1231 : 1237);		
		long temp;
		temp = Double.doubleToLongBits(valorTotal);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((vencimento == null) ? 0 : vencimento.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (obj == null) {
			return false;
		}

		if (!(obj instanceof ExercicioDTO)) {
			return this.isEqualsCotaDTO(obj);
		}

		ExercicioDTO other = (ExercicioDTO) obj;
		if (exercicio != other.exercicio) {
			return false;
		}

		if (icoTuni == null) {
			if (other.icoTuni != null) {
				return false;
			}
		} else if (!icoTuni.equals(other.icoTuni)) {
			return false;
		}

		if (parcelaUnicaDesconto != other.parcelaUnicaDesconto) {
			return false;
		}

		if (Double.doubleToLongBits(valorTotal) != Double.doubleToLongBits(other.valorTotal)) {
			return false;
		}

		if (vencimento == null) {
			if (other.vencimento != null) {
				return false;
			}
		} else if (!vencimento.equals(other.vencimento)) {
			return false;
		}
		return true;
	}
	
	/*
	 * Metodo utilizado para verificacao de igualdade nos itens do <p:selectOneRadio>
	 * na pagina veiculosIpvaConsultaOnline.xhtml, pois o primeiro item da lista e do
	 * tipo ExercicioDTO e o objeto gerado pelo CotaDTOIpvaRadioConverter.java e do tipo
	 * CotaDTO.
	 */
	private boolean isEqualsCotaDTO(Object obj) {
		if (obj instanceof CotaDTO) {
			CotaDTO other = (CotaDTO) obj;
			if (vencimento == null) {
				if (other.getDataVencimento() != null) {
					return false;
				}
			} else if (!vencimento.equals(other.getDataVencimento())) {
				return false;
			}

			if (other.getParcela() == null) {
				return false;
			} else if (other.getParcela() != 0) {
				return false;
			}

			if (valorTotal == null) {
				if (other.getValor() != null) {
					return false;
				}
			} else if (!valorTotal.equals(other.getValor())) {
				return false;
			}

			return true;

		} else {
			return false;
		}
	}

	@Override
	public int compareTo(ExercicioDTO o) {
		return this.exercicio.compareTo(o.getExercicio());
	}
}