package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;



public class ConsultarConveniosEspecificoDTO implements Serializable {
	
	/**
	 * Serializa 
	 */
	private static final long serialVersionUID = -5933838639556775795L;
	
	
	private String suprodu;
	
		/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

		public String getSuprodu() {
			return suprodu;
		}

		public void setSuprodu(String suprodu) {
			this.suprodu = suprodu;
		}
}
    

