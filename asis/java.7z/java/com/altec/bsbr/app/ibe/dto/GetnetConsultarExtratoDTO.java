package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.altec.bsbr.app.ibe.anotation.Hash;

public class GetnetConsultarExtratoDTO implements Serializable {

	private static final long serialVersionUID = 5832291212377107250L;

	/**
	 * Atributos ordenados por p�gina
	 */
	// Consulta
	private String tipoBandeiraSelecionada;
	private String idTipoBandeira;
	private String tipoPeriodoSelecionada;
	private String idTipoPeriodo;
	private String codigoEstabelecimento;
	private Boolean habilitarConsulta;
	private Date dataInicio;
	private Date dataFim;
	private String periodoExtrado;
	@Hash(position = 1)
	private String estabelecimento;
	private String nome;
	private String cnpj;
	private String dataHoraConsulta;
	private String totalTransacoes;
	private String totalBruto;
	private String totalLiquido;
	private String dataInicioConsultar;
	private String dataFimConsultar;

	private String emptyMessage = "";
	
	private List<GetnetConsultarExtratoListaDTO> listaExtrato;
	private List<GetnetConsultarExtratoListaDTO> listaExcel;
	/**
	 * Getters e Setters respectivos 
	 */
	public String getTipoBandeiraSelecionada() {
		return tipoBandeiraSelecionada;
	}
	public void setTipoBandeiraSelecionada(String tipoBandeiraSelecionada) {
		this.tipoBandeiraSelecionada = tipoBandeiraSelecionada;
	}
	public String getIdTipoBandeira() {
		return idTipoBandeira;
	}
	public void setIdTipoBandeira(String idTipoBandeira) {
		this.idTipoBandeira = idTipoBandeira;
	}
	public String getTipoPeriodoSelecionada() {
		return tipoPeriodoSelecionada;
	}
	public void setTipoPeriodoSelecionada(String tipoPeriodoSelecionada) {
		this.tipoPeriodoSelecionada = tipoPeriodoSelecionada;
	}
	public String getIdTipoPeriodo() {
		return idTipoPeriodo;
	}
	public void setIdTipoPeriodo(String idTipoPeriodo) {
		this.idTipoPeriodo = idTipoPeriodo;
	}
	public String getCodigoEstabelecimento() {
		return codigoEstabelecimento;
	}
	public void setCodigoEstabelecimento(String codigoEstabelecimento) {
		this.codigoEstabelecimento = codigoEstabelecimento;
	}
	public Boolean getHabilitarConsulta() {
		return habilitarConsulta;
	}
	public void setHabilitarConsulta(Boolean habilitarConsulta) {
		this.habilitarConsulta = habilitarConsulta;
	}
	public Date getDataInicio() {
		return dataInicio;
	}
	public void setDataInicio(Date dataInicio) {
		this.dataInicio = dataInicio;
	}
	public Date getDataFim() {
		return dataFim;
	}
	public void setDataFim(Date dataFim) {
		this.dataFim = dataFim;
	}
	public String getPeriodoExtrado() {
		return periodoExtrado;
	}
	public void setPeriodoExtrado(String periodoExtrado) {
		this.periodoExtrado = periodoExtrado;
	}
	public String getEstabelecimento() {
		return estabelecimento;
	}
	public void setEstabelecimento(String estabelecimento) {
		this.estabelecimento = estabelecimento;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCnpj() {
		return cnpj;
	}
	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}
	public String getDataHoraConsulta() {
		return dataHoraConsulta;
	}
	public void setDataHoraConsulta(String dataHoraConsulta) {
		this.dataHoraConsulta = dataHoraConsulta;
	}
	public String getTotalTransacoes() {
		return totalTransacoes;
	}
	public void setTotalTransacoes(String totalTransacoes) {
		this.totalTransacoes = totalTransacoes;
	}
	public String getTotalBruto() {
		return totalBruto;
	}
	public void setTotalBruto(String totalBruto) {
		this.totalBruto = totalBruto;
	}
	public String getTotalLiquido() {
		return totalLiquido;
	}
	public void setTotalLiquido(String totalLiquido) {
		this.totalLiquido = totalLiquido;
	}
	public String getDataInicioConsultar() {
		return dataInicioConsultar;
	}
	public void setDataInicioConsultar(String dataInicioConsultar) {
		this.dataInicioConsultar = dataInicioConsultar;
	}
	public String getDataFimConsultar() {
		return dataFimConsultar;
	}
	public void setDataFimConsultar(String dataFimConsultar) {
		this.dataFimConsultar = dataFimConsultar;
	}
	public String getEmptyMessage() {
		return emptyMessage;
	}
	public void setEmptyMessage(String emptyMessage) {
		this.emptyMessage = emptyMessage;
	}
	public List<GetnetConsultarExtratoListaDTO> getListaExtrato() {
		return listaExtrato;
	}
	public void setListaExtrato(List<GetnetConsultarExtratoListaDTO> listaExtrato) {
		this.listaExtrato = listaExtrato;
	}
	public List<GetnetConsultarExtratoListaDTO> getListaExcel() {
		return listaExcel;
	}
	public void setListaExcel(List<GetnetConsultarExtratoListaDTO> listaExcel) {
		this.listaExcel = listaExcel;
	}



}
