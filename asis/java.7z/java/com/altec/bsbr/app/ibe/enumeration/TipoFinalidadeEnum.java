package com.altec.bsbr.app.ibe.enumeration;

import com.altec.bsbr.app.ibe.util.UtilFunction;

public enum TipoFinalidadeEnum {

	PAGAMENTO_A_CONCESSIONARIA("Pagamento � Concession�rias de Servi�o P�blico","02"),
    CREDITO_CONTA_CORRENTE("Cr�dito em Conta Corrente","10"),
    PAGAMENTO_DE_IMPOSTOS("Pagamento de Impostos, Tributos e Taxas","01"),
    PAGAMENTO_DE_DIVIDENDOS("Pagamento de Dividendos","03"),
    PAGAMENTO_DE_SALARIOS("Pagamento de Sal�rios","04"),
    PAGAMENTO_DE_FORNECEDORES("Pagamento de Fornecedores","05"),
    PAGAMENTO_DE_HONORARIOS("Pagamento de Honor�rios","06"),
    PAGAMENTO_DE_ALUGUEIS("Pagamento de Alugu�is e Taxas de Condom�nio","07"),
    PAGAMENTO_DE_DUPLECADAS("Pagamento de Duplicatas e T�tulos","08"),
    PAGAMENTO_DE_MENSALIDADE("Pagamento de Mensalidade Escolar","09"),
    CREDITO_EM_CONTA_POUPANCA("Cr�dito em Conta Poupan�a","11"),
    PATROCINIO_LEI_ROUANET("Patroc�nio Lei Rouanet","43"),
    DOACAO_LEI_ROUANET("Doa��o Lei Rouanet","44"),
    PENSAO_ALIMENTICIA("Pens�o Aliment�cia","101"),
    AJUSTE_POSICAO_MERCADO("Ajuste Posi��o Mercado Futuro","201"),
    OPERACOES_COMPRA_E_VENDA_DE_ACOES("Opera��es Compra e Venda de A��es - BV/BMB","204"),
    CONTRATOS_REFERENCIADOS_ACOES("Contratos Referenciados A��es/Indices A��es - BV/BMF","205"),
    INTERMEDIACAO_DE_OPERACOES("Intermedia��o de Opera��es de Renda Fixa","207"),
    RESTITUICAO_DE_IMPOSTO_DE_RENDA("Restitui��o de Imposto de Renda","300"),
    OUTROS_TED("OUTROS","99999"),
    TRANSFERENCIA_ENTRE_CONTAS_MESMA_TITULARIDADE("Transfer�ncia entre contas de mesma titularidade","110"),
    RESGATE_DE_APLICACAO_FINANCEIRA_DE_CLIENTE_PARA_CONTA_DE_SUA_TITULARIDADE("Resgate de aplica��o financeira de cliente para conta de sua titularidade","111"),
    APLICACAO_FINANCEIRA_EM_NOME_DO_CLIENTE_REMETENTE("Aplica��o financeira em nome do cliente remetente","112"),
    CREDITO_EM_CONTA_CORRENTE("Cr�dito em Conta Corrente","01"),
    PAGAMENTO_DE_ALUGUEL_CONDOMINIO("Pagto de Aluguel/Condom�nio","02"),
    PAGAMENTO_DE_DUPLICATAS("Pagto de Duplicatas/T�tulos","03"),
    PAGAMENTO_DE_DIVIDENDOS_DOC("Pagto de Dividendos","04"),
    PAGAMENTO_DE_MENSALIDADE_ESCOLAR("Pagto de Mensalidade Escolar","05"),
    PAGAMENTO_DE_SALARIO("Pagto de Sal�rio","06"),
    PAGAMENTO_DE_FORNECEDORES_HONORARIOS("Pagto de Fornecedores/Honor�rios","07"),
    PAGAMENTO_DE_CAMBIO_FUNDOS_BOLSA_DE_VALORES("C�mbio/Fundos/Bolsa de Valores","08"),
    REPASSE_DE_ARRECADACOES_TRIBUTOS("Repasse de Arrecada��es/Tributos","09"),
    TRANSFERENCIA_INTERNACIONAL("Transf.Internacional em R$","10"),
    DOC_PARA_POUPANCA("DOC para a Poupan�a","11"),
    DOC_PARA_DEPOSITO_JUDICIAL("DOC para Dep�sito Judicial","12"),
    PENSAO_ALIMENTICIA_DOC("Pens�o Aliment�cia","13"),
    DOACAO_COM_INCENTIVO_FISCAL("Doa��o com Incentivo Fiscal","20"),
    PATROCINIO_COM_INCENTIVO_FISCAL("Patroc�nio com Incentivo Fiscal","21"),
    OPERACOES_COMPRA_E_VENDA_DE_ACOES_BV_BMB("Opera��es Compra e Venda de A��es - BV/BMB","204"),
    CONTRATOS_REFERENCIADOS_ACOES_INDICES("Contratos Referenciados A��es/Indices A��es - BV/BMF","205"),
    OUTROS_DOC("OUTRAS","99"),
    OUTROS_TRANSFERENCIA("OUTROS","14");
	
	private String descricao;
	private String codigo;

	private TipoFinalidadeEnum(String descricao, String codigo) {
		this.descricao = descricao;
		this.codigo = codigo;
	}

	public static TipoFinalidadeEnum findByCodigo(String codigo) {
		TipoFinalidadeEnum retorno = null;

		if (UtilFunction.isBlankOrNull(codigo))
			retorno = null;

		int codigoInt = Integer.parseInt(codigo);
		
		for (TipoFinalidadeEnum item : values()) {
			int codigoItemInt = Integer.parseInt(item.getCodigo());
			if (codigoItemInt == codigoInt) {
				retorno = item;
				break;
			}
		}
		return retorno;
	}

	public String getDescricao() {
		return descricao;
	}

	public String getCodigo() {
		return codigo;
	}

	@Override
	public String toString() {
		return getDescricao();
	}

}
