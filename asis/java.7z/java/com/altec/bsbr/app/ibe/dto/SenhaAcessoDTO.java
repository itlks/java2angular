package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class SenhaAcessoDTO implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4451392312155456531L;
	private String senhaAtual;
	private String senhaNova;
	private String senhaConfirmacao;
	
	private String msgErroJavaStript;
	
	public String getSenhaAtual() {
		return senhaAtual;
	}
	
	public void setSenhaAtual(String senhaAtual) {
		this.senhaAtual = senhaAtual;
	}
	
	public String getSenhaNova() {
		return senhaNova;
	}
	
	public void setSenhaNova(String senhaNova) {
		this.senhaNova = senhaNova;
	}
	
	public String getSenhaConfirmacao() {
		return senhaConfirmacao;
	}
	
	public void setSenhaConfirmacao(String senhaConfirmacao) {
		this.senhaConfirmacao = senhaConfirmacao;
	}

	public String getMsgErroJavaStript() {
		return msgErroJavaStript;
	}

	public void setMsgErroJavaStript(String msgErroJavaStript) {
		this.msgErroJavaStript = msgErroJavaStript;
	}
	
}
