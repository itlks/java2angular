package com.altec.bsbr.app.ibe.enumeration;

public enum RecargaProgramadaEnum {
	
	SELECIONE("Selecione", 0), 
	ULT_3("Pr�ximos 3 dias ", 3), 
	ULT_5("Pr�ximos 5 dias ", 5), 
	ULT_7("Pr�ximos 7 dias ", 7), 
	ULT_30("Pr�ximos 30 dias", 30), 
	ULT_60("Pr�ximos 60 dias", 60), 
	ULT_90("Pr�ximos 90 dias", 90);

	String descricao;
	int quantidadeDias;

	private RecargaProgramadaEnum(String descricao, int quantidadeDias) {
		this.descricao = descricao;
		this.quantidadeDias = quantidadeDias;
	}

	public String getDescricao() {
		return descricao;
	}

	public int getQuantidadeDias() {
		return quantidadeDias;
	}

}