package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.List;

public class ConveniosProdutoDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private List<ItemConvenioProdutoDTO> convenios;
	private List<ItemConvenioProdutoDTO> conveniosSelecionados;
	
		
	public List<ItemConvenioProdutoDTO> getConveniosSelecionados() {
		return conveniosSelecionados;
	}

	public void setConveniosSelecionados(List<ItemConvenioProdutoDTO> conveniosSelecionados) {
		this.conveniosSelecionados = conveniosSelecionados;
	}

	/**
	 * @return the convenios
	 */
	public List<ItemConvenioProdutoDTO> getConvenios() {
		return convenios;
	}

	/**
	 * @param convenios the convenios to set
	 */
	public void setConvenios(List<ItemConvenioProdutoDTO> convenios) {
		this.convenios = convenios;
	}
	
	

}
