package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @since 2017-01-17
 * @author x187169 - Julio Leme
 *
 */
public class FormalizaFluxoCartoesSaidaWebDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String numeroOperacao;
	private String nomeCliente;
	private String tipoDocumento;
	private String numeroDocumento;
	private String numeroContratoMae;
	private Date dataContratoMae;
	private Date dataOperacao;
	private String nomeAgencia;
	private String numeroContaCorrente;
	private BigDecimal valorTotalBruto;
	private BigDecimal valorTotalLiquido;
	private String taxaJurosDevedor;
	private String taxaJurosAoAno;
	private BigDecimal tarifaContratacao;
	private String taxaJurosMensal;
	private String taxaJurosAnual;
	private String taxaJurosRemunMensal;
	private String taxaJurosRemunAnual;
	private String longRetCode;
	private String perNumperR;
	private String strPrazoMedioR;
	private String strDtUltVecto;
	private String strTarifaOper;
	private String strTaxaNominalOper;
	private String strVlrBruto;
	private String strVlrIoc;
	private String strJrsDev;
	private String strVlrLiquido;
	private String strDataProcess;
	private String strHoraProcess;
	private String strAutenticacao;

	/**********************************************
	 * getters and setters
	 */

	public String getperNumperR() {
		return perNumperR;
	}

	public void setperNumperR(String numeroContratoMae) {
		this.perNumperR = numeroContratoMae;
	}

	public String getlongRetCode() {
		return longRetCode;
	}

	public void setlongRetCode(String numeroContratoMae) {
		this.longRetCode = numeroContratoMae;
	}

	public String getstrPrazoMedioR() {
		return strPrazoMedioR;
	}

	public void setstrPrazoMedioR(String numeroContratoMae) {
		this.strPrazoMedioR = numeroContratoMae;
	}

	public String getstrDtUltVecto() {
		return strDtUltVecto;
	}

	public void setstrDtUltVecto(String numeroContratoMae) {
		this.strDtUltVecto = numeroContratoMae;
	}

	public String getstrTarifaOper() {
		return strTarifaOper;
	}

	public void setstrTarifaOper(String numeroContratoMae) {
		this.strTarifaOper = numeroContratoMae;
	}

	public String getstrTaxaNominalOper() {
		return strTaxaNominalOper;
	}

	public void setstrTaxaNominalOper(String numeroContratoMae) {
		this.strTaxaNominalOper = numeroContratoMae;
	}

	public String getstrVlrBruto() {
		return strVlrBruto;
	}

	public void setstrVlrBruto(String numeroContratoMae) {
		this.strVlrBruto = numeroContratoMae;
	}

	public String getstrVlrIoc() {
		return strVlrIoc;
	}

	public void setstrVlrIoc(String numeroContratoMae) {
		this.strVlrIoc = numeroContratoMae;
	}

	public String getstrJrsDev() {
		return strJrsDev;
	}

	public void setstrJrsDev(String numeroContratoMae) {
		this.strJrsDev = numeroContratoMae;
	}

	public String getstrVlrLiquido() {
		return strVlrLiquido;
	}

	public void setstrVlrLiquido(String numeroContratoMae) {
		this.strVlrLiquido = numeroContratoMae;
	}

	public String getstrDataProcess() {
		return strDataProcess;
	}

	public void setstrDataProcess(String numeroContratoMae) {
		this.strDataProcess = numeroContratoMae;
	}

	public String getstrHoraProcess() {
		return strHoraProcess;
	}

	public void setstrHoraProcess(String numeroContratoMae) {
		this.strHoraProcess = numeroContratoMae;
	}

	public String getstrAutenticacao() {
		return strAutenticacao;
	}

	public void setstrAutenticacao(String numeroContratoMae) {
		this.numeroContratoMae = numeroContratoMae;
	}

	public String getNumeroContratoMae() {
		return numeroContratoMae;
	}

	public void setNumeroContratoMae(String numeroContratoMae) {
		this.numeroContratoMae = numeroContratoMae;
	}

	public String getNumeroOperacao() {
		return numeroOperacao;
	}

	public void setNumeroOperacao(String numeroOperacao) {
		this.numeroOperacao = numeroOperacao;
	}

	public String getNomeCliente() {
		return nomeCliente;
	}

	public void setNomeCliente(String nomeCliente) {
		this.nomeCliente = nomeCliente;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public Date getDataContratoMae() {
		return dataContratoMae;
	}

	public void setDataContratoMae(Date dataContratoMae) {
		this.dataContratoMae = dataContratoMae;
	}

	public Date getDataOperacao() {
		return dataOperacao;
	}

	public void setDataOperacao(Date dataOperacao) {
		this.dataOperacao = dataOperacao;
	}

	public String getNomeAgencia() {
		return nomeAgencia;
	}

	public void setNomeAgencia(String nomeAgencia) {
		this.nomeAgencia = nomeAgencia;
	}

	public String getNumeroContaCorrente() {
		return numeroContaCorrente;
	}

	public void setNumeroContaCorrente(String numeroContaCorrente) {
		this.numeroContaCorrente = numeroContaCorrente;
	}

	public BigDecimal getValorTotalBruto() {
		return valorTotalBruto;
	}

	public void setValorTotalBruto(BigDecimal valorTotalBruto) {
		this.valorTotalBruto = valorTotalBruto;
	}

	public String getTaxaJurosDevedor() {
		return taxaJurosDevedor;
	}

	public void setTaxaJurosDevedor(String taxaJurosDevedor) {
		this.taxaJurosDevedor = taxaJurosDevedor;
	}

	public BigDecimal getTarifaContratacao() {
		return tarifaContratacao;
	}

	public void setTarifaContratacao(BigDecimal tarifaContratacao) {
		this.tarifaContratacao = tarifaContratacao;
	}

	public BigDecimal getValorTotalLiquido() {
		return valorTotalLiquido;
	}

	public void setValorTotalLiquido(BigDecimal valorTotalLiquido) {
		this.valorTotalLiquido = valorTotalLiquido;
	}

	public String getTaxaJurosMensal() {
		return taxaJurosMensal;
	}

	public void setTaxaJurosMensal(String taxaJurosMensal) {
		this.taxaJurosMensal = taxaJurosMensal;
	}

	public String getTaxaJurosAnual() {
		return taxaJurosAnual;
	}

	public void setTaxaJurosAnual(String taxaJurosAnual) {
		this.taxaJurosAnual = taxaJurosAnual;
	}

	public String getTaxaJurosRemunMensal() {
		return taxaJurosRemunMensal;
	}

	public void setTaxaJurosRemunMensal(String taxaJurosRemunMensal) {
		this.taxaJurosRemunMensal = taxaJurosRemunMensal;
	}

	public String getTaxaJurosRemunAnual() {
		return taxaJurosRemunAnual;
	}

	public void setTaxaJurosRemunAnual(String taxaJurosRemunAnual) {
		this.taxaJurosRemunAnual = taxaJurosRemunAnual;
	}

	public String getTaxaJurosAoAno() {
		return taxaJurosAoAno;
	}

	public void setTaxaJurosAoAno(String taxaJurosAoAno) {
		this.taxaJurosAoAno = taxaJurosAoAno;
	}

}
