package com.altec.bsbr.app.ibe.enumeration;

/**
 * @author X186801
 *
 */
public enum FinalidadesDocAgendamentoEnum {

	CODIGO_1	(1, "Pagamento de Impostos, Tributos e Taxas"),
	CODIGO_2	(2, "Pagamento � Concession�rias de Servi�o P�blico"),
	CODIGO_3	(3, "Pagamento de Dividendos"),
	CODIGO_4	(4, "Pagamento de Sal�rios"),
	CODIGO_5	(5, "Pagamento de Fornecedores"),
	CODIGO_6	(6, "Pagamento de Honor�rios"),
	CODIGO_7	(7, "Pagamento de Alugu�is e Taxas de Condom�nio"),
	CODIGO_8	(8, "Pagamento de Duplicatas e T�tulos"),
	CODIGO_9	(9, "Pagamento de Mensalidade Escolar"),
	CODIGO_10	(10, "Cr�dito em Conta Corrente"),
	CODIGO_11	(11, "Cr�dito em Conta Poupan�a"),
	CODIGO_16	(16, "Cr�dito em Conta Investimento"),
	CODIGO_32	(32, "Retirada de Recursos da Conta Investimento"),
	CODIGO_100	(100, "Dep�sito Judicial"),
	CODIGO_101	(101, "Pens�o Aliment�cia"),
	CODIGO_110	(110, "Transfer�ncia entre contas de mesma titularidade"),
	CODIGO_114	(114, "Resgate de aplica��o financeira de cliente para conta de sua titularidade"),
	CODIGO_117	(117, "Aplica��o financeira em nome do cliente remetente"),
	CODIGO_201	(201, "Ajuste Posi��o Mercado Futuro"),
	CODIGO_204	(204, "Opera��es Compra e Venda de A��es - BV/BMB"),
	CODIGO_205	(205, "Contratos Referenciados A��es/�ndices A��es - BV/BMF"),
	CODIGO_207	(207, "Intermedia��o de Opera��es de Renda Fixa"),
	CODIGO_300	(300, "Restitui��o de Imposto de Renda"),
	CODIGO_99	(99, "OUTROS");
	
	private Integer codigo;
	private String descricao;

	private FinalidadesDocAgendamentoEnum(Integer codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public static FinalidadesDocAgendamentoEnum findByCodigo(Integer codigo) {
		FinalidadesDocAgendamentoEnum retorno = null;

		for (FinalidadesDocAgendamentoEnum item : values()) {
			if (item.getCodigo().compareTo(codigo) == 0) {
				retorno = item;
				break;
			}
		}

		return retorno;
	}

	public Integer getCodigo() {
		return codigo;
	}

	public String getDescricao() {
		return descricao;
	}

}
