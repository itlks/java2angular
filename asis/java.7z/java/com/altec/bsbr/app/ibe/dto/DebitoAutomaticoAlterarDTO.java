package com.altec.bsbr.app.ibe.dto;

import java.util.Date;
import java.util.List;

import com.altec.bsbr.app.ibe.enumeration.FormaPagamentoEnum;
import com.altec.bsbr.app.ibe.message.Mensagem;
import com.altec.bsbr.app.ibe.web.util.ConverterUtil;

public class DebitoAutomaticoAlterarDTO {

	private EmpresaConveniadaDTO empresaConveniada;
	private FormaPagamentoEnum formaPagamentoSelecionado;
	private List<CartaoCreditoParceladoDTO> listaCartaoParcelado;
	private CartaoCreditoParceladoDTO cartaoSelecionado;
	private Date dataHoraTransacao;
	private String autenticacaoBancaria;
	@SuppressWarnings("unused")
	private String formaPagamentoSelecionadaFormatada;
	
	
	public EmpresaConveniadaDTO getEmpresaConveniada() {
		return empresaConveniada;
	}
	public void setEmpresaConveniada(EmpresaConveniadaDTO empresaConveniada) {
		this.empresaConveniada = empresaConveniada;
	}
	public FormaPagamentoEnum getFormaPagamentoSelecionado() {
		return formaPagamentoSelecionado;
	}
	public void setFormaPagamentoSelecionado(FormaPagamentoEnum formaPagamentoSelecionado) {
		this.formaPagamentoSelecionado = formaPagamentoSelecionado;
	}
	public CartaoCreditoParceladoDTO getCartaoSelecionado() {
		return cartaoSelecionado;
	}
	public void setCartaoSelecionado(CartaoCreditoParceladoDTO cartaoSelecionado) {
		this.cartaoSelecionado = cartaoSelecionado;
	}
	public Date getDataHoraTransacao() {
		return dataHoraTransacao;
	}
	public void setDataHoraTransacao(Date dataHoraTransacao) {
		this.dataHoraTransacao = dataHoraTransacao;
	}
	public String getAutenticacaoBancaria() {
		return autenticacaoBancaria;
	}
	public void setAutenticacaoBancaria(String autenticacaoBancaria) {
		this.autenticacaoBancaria = autenticacaoBancaria;
	}
	public List<CartaoCreditoParceladoDTO> getListaCartaoParcelado() {
		return listaCartaoParcelado;
	}
	public void setListaCartaoParcelado(List<CartaoCreditoParceladoDTO> listaCartaoParcelado) {
		this.listaCartaoParcelado = listaCartaoParcelado;
	}
	public String getFormaPagamentoSelecionadaFormatada() {
		String retorno = "";
		// Se retorno do servico para formaPagamento for iqual a N, exibe Conta Corrente
		if(this.getFormaPagamentoSelecionado() == FormaPagamentoEnum.CONTA_CORRENTE){
			retorno = Mensagem.getMensagem("pages.pagamento.debitoAutomatico.cadastro.alterar.selecionar.contaCorrente");
		} 
		// Senao, exibe Cartao de credito com XXXX.XXXX.XXXX. + ultimos 4 digitos do cartao
		else{
			StringBuilder sb = new StringBuilder();
			sb.append(Mensagem.getMensagem("pages.pagamento.debitoAutomatico.cadastro.alterar.selecionar.cartaoCredito"));
			sb.append(" XXXX.XXXX.XXXX.");
			sb.append(this.getCartaoSelecionado().getNumeroCartao().substring(this.getCartaoSelecionado().getNumeroCartao().length() - 4));
			retorno = sb.toString();
		}		
		return retorno;
	}
	public void setFormaPagamentoSelecionadaFormatada(String formaPagamentoSelecionadaFormatada) {
		this.formaPagamentoSelecionadaFormatada = formaPagamentoSelecionadaFormatada;
	}
	
	public String getDataHoraTransacaoFormatada(){
		return ConverterUtil.dateToString(getDataHoraTransacao(), "dd/MM/yyyy - HH:mm:ss");
	}
	
}
