package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class UsuarioAssociadoDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1565066482826273882L;

	private String nomeUsuario;
	private String agenciaUsuario;
	private String contaUsuario;

	public UsuarioAssociadoDTO() {
	}

	/**
	 * @return the nomeUsuario
	 */
	public String getNomeUsuario() {
		return nomeUsuario;
	}

	/**
	 * @param nomeUsuario
	 *            the nomeUsuario to set
	 */
	public void setNomeUsuario(String nomeUsuario) {
		this.nomeUsuario = nomeUsuario;
	}

	/**
	 * @return the agenciaUsuario
	 */
	public String getAgenciaUsuario() {
		return agenciaUsuario;
	}

	/**
	 * @param agenciaUsuario
	 *            the agenciaUsuario to set
	 */
	public void setAgenciaUsuario(String agenciaUsuario) {
		this.agenciaUsuario = agenciaUsuario;
	}

	/**
	 * @return the contaUsuario
	 */
	public String getContaUsuario() {
		return contaUsuario;
	}

	/**
	 * @param contaUsuario
	 *            the contaUsuario to set
	 */
	public void setContaUsuario(String contaUsuario) {
		this.contaUsuario = contaUsuario;
	}

}
