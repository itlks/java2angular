package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class CartaoDebitoLancamentosCnpjDTO implements Serializable{

	private static final long serialVersionUID = 7340272116924984457L;
	
	private String nomeEmpresa;
	private String cnpj;
	private String area;
	private String cnpjComMascara;
	
	/**
	 * @return the nomeEmpresa
	 */
	public String getNomeEmpresa() {
		return nomeEmpresa;
	}
	/**
	 * @param nomeEmpresa the nomeEmpresa to set
	 */
	public void setNomeEmpresa(String nomeEmpresa) {
		this.nomeEmpresa = nomeEmpresa;
	}
	/**
	 * @return the cnpj
	 */
	public String getCnpj() {
		return cnpj;
	}
	/**
	 * @param cnpj the cnpj to set
	 */
	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}
	/**
	 * @return the area
	 */
	public String getArea() {
		return area;
	}
	/**
	 * @param area the area to set
	 */
	public void setArea(String area) {
		this.area = area;
	}
	public String getCnpjComMascara() {
		return cnpjComMascara;
	}
	public void setCnpjComMascara(String cnpjComMascara) {
		this.cnpjComMascara = cnpjComMascara;
	}
	

}
