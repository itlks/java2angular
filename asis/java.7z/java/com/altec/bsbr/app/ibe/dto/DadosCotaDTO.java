package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class DadosCotaDTO implements Serializable{

	private static final long serialVersionUID = -6630552629836994713L;
	
	private String numeroContrato;
	private String dtVenda;
	private String dtAssembleiaEmissao;
	private String situacaoCobranca;
	private String prazoVenda;
	private String codPontoVenda;
	private String nomePontoVenda;
	private String porcentagemSeguro;
	private String dtAssembleia;
	private String numeroAssembleia;
	private String dtVencimento;
	private String porcentagemDiferenca;
	private String porcentagemFranquiaPlano;
	private String porcentagemTarifaPlano;
	private String porcentagemFCPago;
	private String porcentagemFCMensal;
	private String porcentagemFCAtraso;
	private String valorCredito;
	private String valorFCPago;
	private String valorAtraso;
	private String valorDiferenca;
	private String valorPrestacao;
	private String valorSaldoDevedor;
	private String quantidadeParcelasPagas;
	private String dtContemplacao;
	private String dtEntregaBem;
	private String codigoBancoDebAuto;
	private String nomeBancoDebAuto;
	private String numeroAgDebAuto;
	private String digitoAgDebAuto;
	private String numeroContaDebAuto;
	private String digitoContaDebAuto;
	
	public String getNumeroContrato() {
		return numeroContrato;
	}
	public void setNumeroContrato(String numeroContrato) {
		this.numeroContrato = numeroContrato;
	}
	public String getDtVenda() {
		return dtVenda;
	}
	public void setDtVenda(String dtVenda) {
		this.dtVenda = dtVenda;
	}
	public String getDtAssembleiaEmissao() {
		return dtAssembleiaEmissao;
	}
	public void setDtAssembleiaEmissao(String dtAssembleiaEmissao) {
		this.dtAssembleiaEmissao = dtAssembleiaEmissao;
	}
	public String getSituacaoCobranca() {
		return situacaoCobranca;
	}
	public void setSituacaoCobranca(String situacaoCobranca) {
		this.situacaoCobranca = situacaoCobranca;
	}
	public String getPrazoVenda() {
		return prazoVenda;
	}
	public void setPrazoVenda(String prazoVenda) {
		this.prazoVenda = prazoVenda;
	}
	public String getCodPontoVenda() {
		return codPontoVenda;
	}
	public void setCodPontoVenda(String codPontoVenda) {
		this.codPontoVenda = codPontoVenda;
	}
	public String getNomePontoVenda() {
		return nomePontoVenda;
	}
	public void setNomePontoVenda(String nomePontoVenda) {
		this.nomePontoVenda = nomePontoVenda;
	}
	public String getPorcentagemSeguro() {
		return porcentagemSeguro;
	}
	public void setPorcentagemSeguro(String porcentagemSeguro) {
		this.porcentagemSeguro = porcentagemSeguro;
	}
	public String getDtAssembleia() {
		return dtAssembleia;
	}
	public void setDtAssembleia(String dtAssembleia) {
		this.dtAssembleia = dtAssembleia;
	}
	public String getNumeroAssembleia() {
		return numeroAssembleia;
	}
	public void setNumeroAssembleia(String numeroAssembleia) {
		this.numeroAssembleia = numeroAssembleia;
	}
	public String getDtVencimento() {
		return dtVencimento;
	}
	public void setDtVencimento(String dtVencimento) {
		this.dtVencimento = dtVencimento;
	}
	public String getPorcentagemDiferenca() {
		return porcentagemDiferenca;
	}
	public void setPorcentagemDiferenca(String porcentagemDiferenca) {
		this.porcentagemDiferenca = porcentagemDiferenca;
	}
	public String getPorcentagemFranquiaPlano() {
		return porcentagemFranquiaPlano;
	}
	public void setPorcentagemFranquiaPlano(String porcentagemFranquiaPlano) {
		this.porcentagemFranquiaPlano = porcentagemFranquiaPlano;
	}
	public String getPorcentagemTarifaPlano() {
		return porcentagemTarifaPlano;
	}
	public void setPorcentagemTarifaPlano(String porcentagemTarifaPlano) {
		this.porcentagemTarifaPlano = porcentagemTarifaPlano;
	}
	public String getPorcentagemFCPago() {
		return porcentagemFCPago;
	}
	public void setPorcentagemFCPago(String porcentagemFCPago) {
		this.porcentagemFCPago = porcentagemFCPago;
	}
	public String getPorcentagemFCMensal() {
		return porcentagemFCMensal;
	}
	public void setPorcentagemFCMensal(String porcentagemFCMensal) {
		this.porcentagemFCMensal = porcentagemFCMensal;
	}
	public String getPorcentagemFCAtraso() {
		return porcentagemFCAtraso;
	}
	public void setPorcentagemFCAtraso(String porcentagemFCAtraso) {
		this.porcentagemFCAtraso = porcentagemFCAtraso;
	}
	public String getValorCredito() {
		return valorCredito;
	}
	public void setValorCredito(String valorCredito) {
		this.valorCredito = valorCredito;
	}
	public String getValorFCPago() {
		return valorFCPago;
	}
	public void setValorFCPago(String valorFCPago) {
		this.valorFCPago = valorFCPago;
	}
	public String getValorAtraso() {
		return valorAtraso;
	}
	public void setValorAtraso(String valorAtraso) {
		this.valorAtraso = valorAtraso;
	}
	public String getValorDiferenca() {
		return valorDiferenca;
	}
	public void setValorDiferenca(String valorDiferenca) {
		this.valorDiferenca = valorDiferenca;
	}
	public String getValorPrestacao() {
		return valorPrestacao;
	}
	public void setValorPrestacao(String valorPrestacao) {
		this.valorPrestacao = valorPrestacao;
	}
	public String getValorSaldoDevedor() {
		return valorSaldoDevedor;
	}
	public void setValorSaldoDevedor(String valorSaldoDevedor) {
		this.valorSaldoDevedor = valorSaldoDevedor;
	}
	public String getQuantidadeParcelasPagas() {
		return quantidadeParcelasPagas;
	}
	public void setQuantidadeParcelasPagas(String quantidadeParcelasPagas) {
		this.quantidadeParcelasPagas = quantidadeParcelasPagas;
	}
	public String getDtContemplacao() {
		return dtContemplacao;
	}
	public void setDtContemplacao(String dtContemplacao) {
		this.dtContemplacao = dtContemplacao;
	}
	public String getDtEntregaBem() {
		return dtEntregaBem;
	}
	public void setDtEntregaBem(String dtEntregaBem) {
		this.dtEntregaBem = dtEntregaBem;
	}
	public String getCodigoBancoDebAuto() {
		return codigoBancoDebAuto;
	}
	public void setCodigoBancoDebAuto(String codigoBancoDebAuto) {
		this.codigoBancoDebAuto = codigoBancoDebAuto;
	}
	public String getNomeBancoDebAuto() {
		return nomeBancoDebAuto;
	}
	public void setNomeBancoDebAuto(String nomeBancoDebAuto) {
		this.nomeBancoDebAuto = nomeBancoDebAuto;
	}
	public String getNumeroAgDebAuto() {
		return numeroAgDebAuto;
	}
	public void setNumeroAgDebAuto(String numeroAgDebAuto) {
		this.numeroAgDebAuto = numeroAgDebAuto;
	}
	public String getDigitoAgDebAuto() {
		return digitoAgDebAuto;
	}
	public void setDigitoAgDebAuto(String digitoAgDebAuto) {
		this.digitoAgDebAuto = digitoAgDebAuto;
	}
	public String getNumeroContaDebAuto() {
		return numeroContaDebAuto;
	}
	public void setNumeroContaDebAuto(String numeroContaDebAuto) {
		this.numeroContaDebAuto = numeroContaDebAuto;
	}
	public String getDigitoContaDebAuto() {
		return digitoContaDebAuto;
	}
	public void setDigitoContaDebAuto(String digitoContaDebAuto) {
		this.digitoContaDebAuto = digitoContaDebAuto;
	}
}
