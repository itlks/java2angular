package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.List;

public class DpvatDTO extends GenericDTO implements Serializable {
	
	private static final long serialVersionUID = 8340856092080385758L;
	
	private String codServ;
	private String numDocum;
	private int codMun;
	private int codFede;
	private String nomePro;
	private String siglaFede;
	private String dataVencCotaUni;
	private String valorCotaUni;
	private String banco;
	private String agencia;
	private String conta;
	private String anoExercicio;
	private float valor;
	private int pendentes;
	private String renavam;
	private String cpfCnpj;
	private String placaVeiculo;
	private String autBancaria;
	private String dataContabil;
	private String codigoDoCanal;
	private String referOper;
	private String dataAgendamento;
	private int cotaParcela;	
	private String dataHoraPagamento;	
	private Double valorTotal;
	private String produtoCodAlfa2;
	private String produtoCodAlfa4;
	private String numParcela;
	private String horaTransacao;
	private boolean habilitaAgendamento = false;
	private boolean geraPendencia = false;
	private List<ExercicioDTO> listaExercicio;
	private List<DadosMGDTO> dados;

	public String getDataContabil() {
		return dataContabil;
	}

	public void setDataContabil(String dataContabil) {
		this.dataContabil = dataContabil;
	}

	public String getRenavam() {
		return renavam;
	}

	public void setRenavam(String renavam) {
		this.renavam = renavam;
	}

	public String getCpfCnpj() {
		return cpfCnpj;
	}

	public void setCpfCnpj(String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}

	public String getPlacaVeiculo() {
		return placaVeiculo;
	}

	public void setPlacaVeiculo(String placaVeiculo) {
		this.placaVeiculo = placaVeiculo;
	}

	public String getAutBancaria() {
		return autBancaria;
	}

	public void setAutBancaria(String autBancaria) {
		this.autBancaria = autBancaria;
	}

	public String getDataHoraPagamento() {
		return dataHoraPagamento;
	}

	public void setDataHoraPagamento(String dataHoraPagamento) {
		this.dataHoraPagamento = dataHoraPagamento;
	}

	public List<ExercicioDTO> getListaExercicio() {
		return listaExercicio;
	}

	public void setListaExercicio(List<ExercicioDTO> listaExercicio) {
		this.listaExercicio = listaExercicio;
	}
	
	public List<DadosMGDTO> getDados() {
		return dados;
	}
	
	public void setDados(List<DadosMGDTO> dados) {
		this.dados = dados;
	}

	public String getCodServ() {
		return codServ;
	}

	public void setCodServ(String codServ) {
		this.codServ = codServ;
	}

	public String getNumDocum() {
		return numDocum;
	}

	public void setNumDocum(String numDocum) {
		this.numDocum = numDocum;
	}

	public int getCodMun() {
		return codMun;
	}

	public void setCodMun(int codMun) {
		this.codMun = codMun;
	}

	public int getCodFede() {
		return codFede;
	}

	public void setCodFede(int codFede) {
		this.codFede = codFede;
	}

	public String getNomePro() {
		return nomePro;
	}

	public void setNomePro(String nomePro) {
		this.nomePro = nomePro;
	}

	public String getSiglaFede() {
		return siglaFede;
	}

	public void setSiglaFede(String siglaFede) {
		this.siglaFede = siglaFede;
	}

	public String getDataVencCotaUni() {
		return dataVencCotaUni;
	}

	public void setDataVencCotaUni(String dataVencCotaUni) {
		this.dataVencCotaUni = dataVencCotaUni;
	}

	public String getValorCotaUni() {
		return valorCotaUni;
	}

	public void setValorCotaUni(String valorCotaUni) {
		this.valorCotaUni = valorCotaUni;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getConta() {
		return conta;
	}

	public void setConta(String conta) {
		this.conta = conta;
	}

	public String getAnoExercicio() {
		return anoExercicio;
	}
	
	public String getAnoExercicioByPosicao(int index) {
		if (index < this.listaExercicio.size()) {
			return this.listaExercicio.get(index) != null ? this.listaExercicio.get(index).getExercicio().toString() : "";
		}
		return "";
	}

	public void setAnoExercicio(String anoExercicio) {
		this.anoExercicio = anoExercicio;
	}

	public float getValor() {
		return valor;
	}

	public void setValor(float valor) {
		this.valor = valor;
	}

	public int getPendentes() {
		return pendentes;
	}

	public void setPendentes(int pendentes) {
		this.pendentes = pendentes;
	}

	public String getCodigoDoCanal() {
		return codigoDoCanal;
	}

	public void setCodigoDoCanal(String codigoDoCanal) {
		this.codigoDoCanal = codigoDoCanal;
	}

	public String getReferOper() {
		return referOper;
	}

	public void setReferOper(String referOper) {
		this.referOper = referOper;
	}

	public String getDataAgendamento() {
		return dataAgendamento;
	}

	public void setDataAgendamento(String dataAgendamento) {
		this.dataAgendamento = dataAgendamento;
	}

	public int getCotaParcela() {
		return cotaParcela;
	}

	public void setCotaParcela(int cotaParcela) {
		this.cotaParcela = cotaParcela;
	}

	public String getProdutoCodAlfa2() {
		return produtoCodAlfa2;
	}

	public void setProdutoCodAlfa2(String produtoCodAlfa2) {
		this.produtoCodAlfa2 = produtoCodAlfa2;
	}

	public String getProdutoCodAlfa4() {
		return produtoCodAlfa4;
	}

	public void setProdutoCodAlfa4(String produtoCodAlfa4) {
		this.produtoCodAlfa4 = produtoCodAlfa4;
	}

	public boolean isHabilitaAgendamento() {
		return habilitaAgendamento;
	}

	public void setHabilitaAgendamento(boolean habilitaAgendamento) {
		this.habilitaAgendamento = habilitaAgendamento;
	}

	public boolean isGeraPendencia() {
		return geraPendencia;
	}

	public void setGeraPendencia(boolean geraPendencia) {
		this.geraPendencia = geraPendencia;
	}

	public Double getValorTotal() {
		return valorTotal;
	}

	public void setValorTotal(Double valorTotal) {
		this.valorTotal = valorTotal;
	}

	public String getNumParcela() {
		return numParcela;
	}

	public void setNumParcela(String numParcela) {
		this.numParcela = numParcela;
	}
	
	public String getHoraTransacao() {
		return horaTransacao;
	}

	public void setHoraTransacao(String horaTransacao) {
		this.horaTransacao = horaTransacao;
	}

	public String getDadosInformacao1() {
		for (DadosMGDTO dado: dados) {
			if (dado.getTpLinha().equals("I")) {
				return dado.getValor();
			}
		}
		return null;
	}
	
	public String getDadosInformacao2() {
		int controle=0;
		for (DadosMGDTO dado: dados) {
			if (dado.getTpLinha().equals("I") && controle==0) {
				controle++;
			} else if (dado.getTpLinha().equals("I") && controle==1) {
				return dado.getValor();
			}
		}
		return null;
	}
}