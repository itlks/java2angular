package com.altec.bsbr.app.ibe.dto.agendamentos;

import java.io.Serializable;

public class IpvaDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6773764457538834742L;
	
	private String codigoMunicipio;
	private String renavam;
	private String nomeProprietario;
	private String placaVeiculo;
	private String cotaParcela;
	private String anoExercicio;
	private String numeroDocumento;
	private String codigoBarras;

	public String getRenavam() {
		return renavam;
	}

	public void setRenavam(String renavam) {
		this.renavam = renavam;
	}

	public String getNomeProprietario() {
		return nomeProprietario;
	}

	public void setNomeProprietario(String nomeProprietario) {
		this.nomeProprietario = nomeProprietario;
	}

	public String getPlacaVeiculo() {
		return placaVeiculo;
	}

	public void setPlacaVeiculo(String placaVeiculo) {
		this.placaVeiculo = placaVeiculo;
	}

	public String getCotaParcela() {
		return cotaParcela;
	}

	public void setCotaParcela(String cotaParcela) {
		this.cotaParcela = cotaParcela;
	}

	public String getAnoExercicio() {
		return anoExercicio;
	}

	public void setAnoExercicio(String anoExercicio) {
		this.anoExercicio = anoExercicio;
	}

	public String getCodigoMunicipio() {
		return codigoMunicipio;
	}

	public void setCodigoMunicipio(String codigoMunicipio) {
		this.codigoMunicipio = codigoMunicipio;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public String getCodigoBarras() {
		return codigoBarras;
	}

	public void setCodigoBarras(String codigoBarras) {
		this.codigoBarras = codigoBarras;
	}

}
