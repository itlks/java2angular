package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class ConsorcioConsultarAssembleiaCalendarioDadosGrupoCotaDTO implements Serializable{

	private static final long serialVersionUID = 2488521110219000576L;
	
	private String nome;
	private String cnpj;
	private String grupo;
	private String bem;
	private String cota;
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCnpj() {
		return cnpj;
	}
	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}
	public String getGrupo() {
		return grupo;
	}
	public void setGrupo(String grupo) {
		this.grupo = grupo;
	}
	
	public String getCota() {
		return cota;
	}
	public void setCota(String cota) {
		this.cota = cota;
	}
	public String getBem() {
		return bem;
	}
	public void setBem(String bem) {
		this.bem = bem;
	}

		
}
