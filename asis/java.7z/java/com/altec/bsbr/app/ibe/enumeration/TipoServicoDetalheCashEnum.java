package com.altec.bsbr.app.ibe.enumeration;

import org.apache.commons.lang3.StringUtils;

public enum TipoServicoDetalheCashEnum {
	
	DIVIDENDOS 			("10", "Pagamento Dividendos"),
	FORNECEDOR 			("20", "Pagamento Fornecedor"),
	SALARIOS 			("30", "Pagamento Sal�rios"),
	SINISTROS 			("50", "Pagamento Sinistros Segurados"),
	TRANSITO 			("60", "Pagamento Despesas Viajante em Tr�nsito"),
	AUTORIZADO 			("70", "Pagamento Autorizado"),
	REPRESENTANTES 		("80", "Pagamento Representantes / Vendedores Autorizados"),
	BENEFICIOS 			("90", "Pagamento Pagamento Benef�cios"),
	DIVERSOS 			("98", "Pagamento Diversos"),
	TRIBUTOS 			("22", "Pagamento de Contas, Tributos e Impostos");
		
	private String codigo;
	private String descricao;

	private TipoServicoDetalheCashEnum(String codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}
	
	public static String findDescricaoByCodigo(String codigo, String descServico) {
		String descricao = "";
		if (StringUtils.isNotBlank(codigo) ) {
			for (TipoServicoDetalheCashEnum item : values()) {
				if (item.codigo.equals(codigo)) {
					return item.descricao;
				}
			}
		}
		if(StringUtils.isNotBlank(descServico)){
			descricao = descServico.trim().substring(5);
		}
		return descricao;
	}
}