package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class ItemRecargaProgramadaHistoricoDTO implements Serializable, Comparable<ItemRecargaProgramadaHistoricoDTO> {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private String numProtocolo;
    private Date dtAgendamento;
    private Date dtInicioProgramacao;
    private Date dtFimProgramacao;
    private Date dtEfetivacao;
    private Date dtProxProgramacao;
    private BancoDTO banco;
    private BigDecimal valorProgramacao;
    private String codCanalProgramacao;
    private Integer situProgramacao;
    private String indProgrAgendamento;
    private Date dtCancelProgramacao;
    private String motivoCancelamento;
    private String descrRecarga;
    private String numDDDcelular;
    private String numFoneCelular;
    private String nomOperadora;
    private String flgMais;
    private String situacao;
    private String transacao;
    
    
	/**
	 * @return the situacao
	 */
	public String getSituacao() {
		return situacao;
	}
	/**
	 * @param situacao the situacao to set
	 */
	public void setSituacao(String situacao) {
		this.situacao = situacao;
	}
	/**
	 * @return the numProtocolo
	 */
	public String getNumProtocolo() {
		return numProtocolo;
	}
	/**
	 * @param numProtocolo the numProtocolo to set
	 */
	public void setNumProtocolo(String numProtocolo) {
		this.numProtocolo = numProtocolo;
	}
	/**
	 * @return the dtagendamento
	 */
	public Date getDtagendamento() {
		return dtAgendamento;
	}
	/**
	 * @param dtagendamento the dtagendamento to set
	 */
	public void setDtagendamento(Date dtagendamento) {
		this.dtAgendamento = dtagendamento;
	}
	/**
	 * @return the dtInicioProgramacao
	 */
	public Date getDtInicioProgramacao() {
		return dtInicioProgramacao;
	}
	/**
	 * @param dtInicioProgramacao the dtInicioProgramacao to set
	 */
	public void setDtInicioProgramacao(Date dtInicioProgramacao) {
		this.dtInicioProgramacao = dtInicioProgramacao;
	}
	/**
	 * @return the dtFimProgramacao
	 */
	public Date getDtFimProgramacao() {
		return dtFimProgramacao;
	}
	/**
	 * @param dtFimProgramacao the dtFimProgramacao to set
	 */
	public void setDtFimProgramacao(Date dtFimProgramacao) {
		this.dtFimProgramacao = dtFimProgramacao;
	}
	/**
	 * @return the banco
	 */
	public BancoDTO getBanco() {
		return banco;
	}
	/**
	 * @param banco the banco to set
	 */
	public void setBanco(BancoDTO banco) {
		this.banco = banco;
	}
	/**
	 * @return the valorProgramacao
	 */
	public BigDecimal getValorProgramacao() {
		return valorProgramacao;
	}
	/**
	 * @param valorProgramacao the valorProgramacao to set
	 */
	public void setValorProgramacao(BigDecimal valorProgramacao) {
		this.valorProgramacao = valorProgramacao;
	}
	/**
	 * @return the codCanalProgramacao
	 */
	public String getCodCanalProgramacao() {
		return codCanalProgramacao;
	}
	/**
	 * @param codCanalProgramacao the codCanalProgramacao to set
	 */
	public void setCodCanalProgramacao(String codCanalProgramacao) {
		this.codCanalProgramacao = codCanalProgramacao;
	}
	/**
	 * @return the situProgramacao
	 */
	public Integer getSituProgramacao() {
		return situProgramacao;
	}
	/**
	 * @param situProgramacao the situProgramacao to set
	 */
	public void setSituProgramacao(Integer situProgramacao) {
		this.situProgramacao = situProgramacao;
	}
	/**
	 * @return the indProgrAgendamento
	 */
	public String getIndProgrAgendamento() {
		return indProgrAgendamento;
	}
	/**
	 * @param indProgrAgendamento the indProgrAgendamento to set
	 */
	public void setIndProgrAgendamento(String indProgrAgendamento) {
		this.indProgrAgendamento = indProgrAgendamento;
	}
	
	/**
	 * @return the dtCancelProgramacao
	 */
	public Date getDtCancelProgramacao() {
		return dtCancelProgramacao;
	}
	/**
	 * @param dtCancelProgramacao the dtCancelProgramacao to set
	 */
	public void setDtCancelProgramacao(Date dtCancelProgramacao) {
		this.dtCancelProgramacao = dtCancelProgramacao;
	}
	/**
	 * @return the motivoCancelamento
	 */
	public String getMotivoCancelamento() {
		return motivoCancelamento;
	}
	/**
	 * @param motivoCancelamento the motivoCancelamento to set
	 */
	public void setMotivoCancelamento(String motivoCancelamento) {
		this.motivoCancelamento = motivoCancelamento;
	}
	/**
	 * @return the descrRecarga
	 */
	public String getDescrRecarga() {
		return descrRecarga;
	}
	/**
	 * @param descrRecarga the descrRecarga to set
	 */
	public void setDescrRecarga(String descrRecarga) {
		this.descrRecarga = descrRecarga;
	}
	/**
	 * @return the numDDDcelular
	 */
	public String getNumDDDcelular() {
		return numDDDcelular;
	}
	/**
	 * @param numDDDcelular the numDDDcelular to set
	 */
	public void setNumDDDcelular(String numDDDcelular) {
		this.numDDDcelular = numDDDcelular;
	}
	/**
	 * @return the numFoneCelular
	 */
	public String getNumFoneCelular() {
		return numFoneCelular;
	}
	/**
	 * @param numFoneCelular the numFoneCelular to set
	 */
	public void setNumFoneCelular(String numFoneCelular) {
		this.numFoneCelular = numFoneCelular;
	}
	/**
	 * @return the nomOperadora
	 */
	public String getNomOperadora() {
		return nomOperadora;
	}
	/**
	 * @param nomOperadora the nomOperadora to set
	 */
	public void setNomOperadora(String nomOperadora) {
		this.nomOperadora = nomOperadora;
	}
	/**
	 * @return the flgMais
	 */
	public String getFlgMais() {
		return flgMais;
	}
	/**
	 * @param flgMais the flgMais to set
	 */
	public void setFlgMais(String flgMais) {
		this.flgMais = flgMais;
	}
	public String getTransacao() {
		return transacao;
	}
	public void setTransacao(String transacao) {
		this.transacao = transacao;
	}
			
//	public Date getDtAgendamento() {
//		return dtAgendamento;
//	}
//	public void setDtAgendamento(Date dtAgendamento) {
//		this.dtAgendamento = dtAgendamento;
//	}
	public Date getDtEfetivacao() {
		return dtEfetivacao;
	}
	public void setDtEfetivacao(Date dtEfetivacao) {
		this.dtEfetivacao = dtEfetivacao;
	}
	public Date getDtProxProgramacao() {
		return dtProxProgramacao;
	}
	public void setDtProxProgramacao(Date dtProxProgramacao) {
		this.dtProxProgramacao = dtProxProgramacao;
	}
	@Override
	public int compareTo(ItemRecargaProgramadaHistoricoDTO dtoCompara) {
		int compare = dtoCompara.getDtInicioProgramacao().compareTo(this.getDtInicioProgramacao());
		if (compare == 0)
			compare = dtoCompara.getDtFimProgramacao().compareTo(this.getDtFimProgramacao());
		
		return compare;
	}
	    
}
