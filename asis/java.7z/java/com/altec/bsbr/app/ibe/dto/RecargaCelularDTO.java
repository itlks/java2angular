package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;

import com.altec.bsbr.app.ibe.anotation.Hash;

public class RecargaCelularDTO extends GenericDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4770407323020347301L;
	private BigDecimal valorRecarga;
	@Hash(position = 1)
	private String valorRecargaFormatado;
	private String indicadorSms;
	@Hash(position = 2)
	private String dataTransacao;
	private String horaTransacao;

	public BigDecimal getValorRecarga() {
		return valorRecarga;
	}

	public void setValorRecarga(BigDecimal valorRecarga) {
		this.valorRecarga = valorRecarga;
	}

	public String getValorRecargaFormatado() {
		return valorRecargaFormatado;
	}

	public void setValorRecargaFormatado(String valorRecargaFormatado) {
		this.valorRecargaFormatado = valorRecargaFormatado;
	}

	public String getDataTransacao() {
		return dataTransacao;
	}

	public void setDataTransacao(String dataTransacao) {
		this.dataTransacao = dataTransacao;
	}

	public String getHoraTransacao() {
		return horaTransacao;
	}

	public void setHoraTransacao(String horaTransacao) {
		this.horaTransacao = horaTransacao;
	}

	public String getIndicadorSms() {
		return indicadorSms;
	}

	public void setIndicadorSms(String indicadorSms) {
		this.indicadorSms = indicadorSms;
	}

}
