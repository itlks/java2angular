package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class OperacoesRealizadaTransacaoDTO implements Serializable {

	private static final long serialVersionUID = 2506639159283192145L;
	
	private String cd_autentica; 


	public String getCd_autentica(){
		return this.cd_autentica;
	} 

	public void setCd_autentica(String cd_autentica){
		this.cd_autentica = cd_autentica;
	} 




}
