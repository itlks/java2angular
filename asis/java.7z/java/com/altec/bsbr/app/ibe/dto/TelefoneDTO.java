/**
 * 
 */
package com.altec.bsbr.app.ibe.dto;

/**
 * @author c.de.sa.oliveira
 *
 */
public class TelefoneDTO {
	
	
	private String celular;
	private String ddd;
	private String celularFormatado;
	
	public String getCelular() {
		return celular;
	}
	public void setCelular(String celular) {
		this.celular = celular;
	}
	public String getDdd() {
		return ddd;
	}
	public void setDdd(String ddd) {
		this.ddd = ddd;
	}
	public String getCelularFormatado() {
		return celularFormatado;
	}
	public void setCelularFormatado(String celularFormatado) {
		this.celularFormatado = celularFormatado;
	}
	
	
	
}
