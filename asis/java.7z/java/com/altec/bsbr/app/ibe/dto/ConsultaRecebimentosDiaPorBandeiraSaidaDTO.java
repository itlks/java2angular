package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.altec.bsbr.app.ibe.dto.clsfinancashvisa.ErrosDTO;

public class ConsultaRecebimentosDiaPorBandeiraSaidaDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8583985958496037149L;

	private ErrosDTO erros;
	private String lngRetCode;
	private String strErro;
	private String strErroTecnica;
	private String strErroMQS;
	private String strIPAddrCliente;
	private List<ListaConsultaRecebimentosDiaPorBandeiraRSDTO> listaConsultaRecebimentosDiaPorBandeira = new ArrayList<ListaConsultaRecebimentosDiaPorBandeiraRSDTO>();
	
	
	
	public ErrosDTO getErros() {
		return erros;
	}
	public void setErros(ErrosDTO erros) {
		this.erros = erros;
	}
	public String getLngRetCode() {
		return lngRetCode;
	}
	public void setLngRetCode(String lngRetCode) {
		this.lngRetCode = lngRetCode;
	}
	public String getStrErro() {
		return strErro;
	}
	public void setStrErro(String strErro) {
		this.strErro = strErro;
	}
	public String getStrErroTecnica() {
		return strErroTecnica;
	}
	public void setStrErroTecnica(String strErroTecnica) {
		this.strErroTecnica = strErroTecnica;
	}
	public String getStrErroMQS() {
		return strErroMQS;
	}
	public void setStrErroMQS(String strErroMQS) {
		this.strErroMQS = strErroMQS;
	}
	public String getStrIPAddrCliente() {
		return strIPAddrCliente;
	}
	public void setStrIPAddrCliente(String strIPAddrCliente) {
		this.strIPAddrCliente = strIPAddrCliente;
	}
	public List<ListaConsultaRecebimentosDiaPorBandeiraRSDTO> getListaConsultaRecebimentosDiaPorBandeira() {
		return listaConsultaRecebimentosDiaPorBandeira;
	}
	public void setListaConsultaRecebimentosDiaPorBandeira(
			List<ListaConsultaRecebimentosDiaPorBandeiraRSDTO> listaConsultaRecebimentosDiaPorBandeira) {
		this.listaConsultaRecebimentosDiaPorBandeira = listaConsultaRecebimentosDiaPorBandeira;
	}
	
	
	
	
	
	
}
