package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class UsuarioLogadoDTO implements Serializable{
	
	private static final long serialVersionUID = 7964888124254696719L;
	
	private String titular;
	private String agencia;
	private String conta;
	private String senha;
	private String msg;	
	
	
	public UsuarioLogadoDTO() {
		super();
	}
	
	public UsuarioLogadoDTO(String titular, String agencia, String conta, String senha, String msg) {
		super();
		this.titular = titular;
		this.agencia = agencia;
		this.conta = conta;
		this.senha = senha;
		this.msg = msg;
	}	
	
	public UsuarioLogadoDTO(String agencia, String conta) {
		super();
		this.agencia = agencia;
		this.conta = conta;
	}
	
	public String getTitular() {
		return titular;
	}
	public void setTitular(String titular) {
		this.titular = titular;
	}
	public String getAgencia() {
		return agencia;
	}
	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}
	public String getConta() {
		return conta;
	}
	public void setConta(String conta) {
		this.conta = conta;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	
}
