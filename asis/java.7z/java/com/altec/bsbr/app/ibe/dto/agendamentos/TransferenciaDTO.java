package com.altec.bsbr.app.ibe.dto.agendamentos;

import java.io.Serializable;

public class TransferenciaDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -22190599881433580L;
	private String contaPoupancaDebito;
	private String contaPoupancaCredito;
	private String contaDebito;
	private String contaCredito;
	private String tipo;

	public String getContaDebito() {
		return contaDebito;
	}

	public void setContaDebito(String contaDebito) {
		this.contaDebito = contaDebito;
	}

	public String getContaCredito() {
		return contaCredito;
	}

	public void setContaCredito(String contaCredito) {
		this.contaCredito = contaCredito;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getContaPoupancaDebito() {
		return contaPoupancaDebito;
	}

	public void setContaPoupancaDebito(String contaPoupancaDebito) {
		this.contaPoupancaDebito = contaPoupancaDebito;
	}

	public String getContaPoupancaCredito() {
		return contaPoupancaCredito;
	}

	public void setContaPoupancaCredito(String contaPoupancaCredito) {
		this.contaPoupancaCredito = contaPoupancaCredito;
	}

}
