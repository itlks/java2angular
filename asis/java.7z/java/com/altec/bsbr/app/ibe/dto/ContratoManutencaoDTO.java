package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.List;

import com.altec.bsbr.app.ibe.anotation.Hash;

public class ContratoManutencaoDTO implements Serializable {

	private static final long serialVersionUID = -1861292646995803482L;
	
	@Hash(position = 1)
	private Integer codHash;
	private Integer qtAssinaturaUsuarioMaster;
	private List<ManutencaoUsuarioMasterDTO> usuarioMasterDTOList;
	private List<ConsultaContaCorrenteDTO> contaCorrenteList;
	
	public List<ManutencaoUsuarioMasterDTO> getUsuarioMasterDTOList() {
		return usuarioMasterDTOList;
	}
	public void setUsuarioMasterDTOList(List<ManutencaoUsuarioMasterDTO> usuarioMasterDTOList) {
		this.usuarioMasterDTOList = usuarioMasterDTOList;
	}
	public List<ConsultaContaCorrenteDTO> getContaCorrenteList() {
		return contaCorrenteList;
	}
	public void setContaCorrenteList(List<ConsultaContaCorrenteDTO> contaCorrenteList) {
		this.contaCorrenteList = contaCorrenteList;
	}
	public Integer getQtAssinaturaUsuarioMaster() {
		return qtAssinaturaUsuarioMaster;
	}
	public void setQtAssinaturaUsuarioMaster(Integer qtAssinaturaUsuarioMaster) {
		this.qtAssinaturaUsuarioMaster = qtAssinaturaUsuarioMaster;
	}
	public Integer getCodHash() {
		return codHash;
	}
	public void setCodHash(Integer codHash) {
		this.codHash = codHash;
	}
}
