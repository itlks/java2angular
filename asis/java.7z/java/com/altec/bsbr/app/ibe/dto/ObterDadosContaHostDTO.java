package com.altec.bsbr.app.ibe.dto;

import java.util.List;

import com.altec.bsbr.app.ibe.dto.contashost.ErrosDTO;

public class ObterDadosContaHostDTO {
	
	private String saida;
	private List<DadosContaHostDTO> rsFixed;
	private String lngRetCode;
	private String strErro;
	private String strErroTecnica;
	private String strErroMQS;
	private String strChaveAutenticacao;
	private ErrosDTO erros;
	
	public String getSaida() {
		return saida;
	}
	public void setSaida(String saida) {
		this.saida = saida;
	}
	public List<DadosContaHostDTO> getRsFixed() {
		return rsFixed;
	}
	public void setRsFixed(List<DadosContaHostDTO> rsFixed) {
		this.rsFixed = rsFixed;
	}
	public String getLngRetCode() {
		return lngRetCode;
	}
	public void setLngRetCode(String lngRetCode) {
		this.lngRetCode = lngRetCode;
	}
	public String getStrErro() {
		return strErro;
	}
	public void setStrErro(String strErro) {
		this.strErro = strErro;
	}
	public String getStrErroTecnica() {
		return strErroTecnica;
	}
	public void setStrErroTecnica(String strErroTecnica) {
		this.strErroTecnica = strErroTecnica;
	}
	public String getStrErroMQS() {
		return strErroMQS;
	}
	public void setStrErroMQS(String strErroMQS) {
		this.strErroMQS = strErroMQS;
	}
	public String getStrChaveAutenticacao() {
		return strChaveAutenticacao;
	}
	public void setStrChaveAutenticacao(String strChaveAutenticacao) {
		this.strChaveAutenticacao = strChaveAutenticacao;
	}
	public ErrosDTO getErros() {
		return erros;
	}
	public void setErros(ErrosDTO erros) {
		this.erros = erros;
	}
	
	

}
