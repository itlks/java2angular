package com.altec.bsbr.app.ibe.exception;

import com.altec.bsbr.fw.BusinessException;

public class HashException extends BusinessException {
	private static final long serialVersionUID = -1350374034132101850L;
	
	public HashException(String message) {
		super(message);
	}

	public HashException(String message, Exception e) {
		super(message, e);
	}
}
