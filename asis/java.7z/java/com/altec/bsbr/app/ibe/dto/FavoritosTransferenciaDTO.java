package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.List;

public class FavoritosTransferenciaDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2146806593404777099L;
	
	private String lngRetCode;
	private String strErro;
	private String strErroTecnica;
	private String strErroMQS;
	private String strChvAmarracao;
	private String saida;
	private List<FavoritoTransferenciaDTO> rsMultiple;

	public String getStrErroMQS() {
		return strErroMQS;
	}
	public void setStrErroMQS(String strErroMQS) {
		this.strErroMQS = strErroMQS;
	}
	public String getStrChvAmarracao() {
		return strChvAmarracao;
	}
	public void setStrChvAmarracao(String strChvAmarracao) {
		this.strChvAmarracao = strChvAmarracao;
	}
	public String getSaida() {
		return saida;
	}
	public void setSaida(String saida) {
		this.saida = saida;
	}
	public List<FavoritoTransferenciaDTO> getRsMultiple() {
		return rsMultiple;
	}
	public void setRsMultiple(List<FavoritoTransferenciaDTO> rsMultiple) {
		this.rsMultiple = rsMultiple;
	}
	public String getLngRetCode() {
		return lngRetCode;
	}
	public void setLngRetCode(String lngRetCode) {
		this.lngRetCode = lngRetCode;
	}
	public String getStrErro() {
		return strErro;
	}
	public void setStrErro(String strErro) {
		this.strErro = strErro;
	}
	public String getStrErroTecnica() {
		return strErroTecnica;
	}
	public void setStrErroTecnica(String strErroTecnica) {
		this.strErroTecnica = strErroTecnica;
	}
}
