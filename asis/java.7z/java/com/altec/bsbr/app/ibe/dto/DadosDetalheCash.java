package com.altec.bsbr.app.ibe.dto;

import static org.apache.commons.lang3.StringUtils.isNotBlank;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.NumberFormat;

import org.apache.commons.lang.StringUtils;

import com.altec.bsbr.app.ibe.enumeration.AvisoDetalheCashEnum;
import com.altec.bsbr.app.ibe.enumeration.CompromissoFolhaPagamentoDetalheCashEnum;
import com.altec.bsbr.app.ibe.enumeration.HistoricoCompromossoComplCashEnum;
import com.altec.bsbr.app.ibe.enumeration.SituacaoFolhaPagamentoEnum;
import com.altec.bsbr.app.ibe.enumeration.TipoFolhaPagamentoEnum;
import com.altec.bsbr.app.ibe.enumeration.TipoPagamentoDetalheCashEnum;
import com.altec.bsbr.app.ibe.enumeration.TipoPagamentoFolhaPagamentoEnum;
import com.altec.bsbr.app.ibe.enumeration.TipoServicoDetalheCashEnum;
import com.altec.bsbr.app.ibe.util.UtilFunction;

public class DadosDetalheCash implements Serializable {
	
	private static final long serialVersionUID = 67177163542124200L;
	
	private String YLW63PRODUTO;
	private String YLW63ENTIDAD;
	private String YLW63CENTROALTA;
	private String YLW63CUENTA;
	private String YLW63DIVISA;
	private String YLW63NOMECONV;
	private String YLW63REMESA;
	private String YLW63NUMCOMPRO;
	private String YLW63ENTIDADDEB;
	private String YLW63CENTROALTADEB;
	private String YLW63CUENTADEB;
	private String YLW63DIVISADEB;
	private String YLW63ENTIDADCRED;
	private String YLW63CENTROALTACRED;
	private String YLW63CUENTACRED;
	private String YLW63DIVISACRED;
	private String YLW63HORENVIOTED;
	private String YLW63CODFINAL;
	private String YLW63CODCAMCOMP;
	private String YLW63INDAVISOPAG;
	private String YLW63TIPOTRANSF;
	private String YLW63FORMPAG;
	private String YLW63CODHIST;
	private String YLW63CODTIPIDENT;
	private String YLW63CODFORNCONS;
	private String YLW63NOMEFAVORECIDO;
	private String YLW63IMPORTE;
	private String YLW63IMPINSS;
	private String YLW63IMPJUROS;
	private String YLW63IMPMULTA;
	private String YLW63INDCONF;
	private String YLW63IMPABATIMENTO;
	private String YLW63IMPNOMDOC;
	private String YLW63IMPMORA;
	private String YLW63IMPOUTENT;
	private String YLW63IMPACRESCTRIB;
	private String YLW63IMPHONTRIB;
	private String YLW63IMPRECBRUTA;
	private String YLW63PORCRECBRUTA;
	private String YLW63FECORIGCOMPR;
	private String YLW63NUMPARC;
	private String YLW63COMPTTRIB;
	private String YLW63CODRECPAG;
	private String YLW63PERIODAPURTRIB;
	private String YLW63CODBARRAS;
	private String YLW63NUMREFTRIB;
	private String YLW63INSCESTTRIB;
	private String YLW63DIVIDAATIVA;
	private String YLW63OBS1TRIB;
	private String YLW63OBS2TRIB;
	private String YLW63CODAUT;
	private String YLW63IMPOPER;
	private String YLW63NUMLOTE;
	private String YLW63FECVENC;
	private String YLW63COMPTIPODOC;
	private String YLW63COMPSEQ;
	private String YLW63FECPROCDEB;
	private String YLW63FECVALORDEB;
	private String YLW63FECVALORCRED;
	private String YLW63FECALTAAGEN;
	private String YLW63INDESTACOMP;
	private String YLW63TIPINCLUSION;
	private String YLW63NUMPROTOCOLO;
	private String YLW63NUMDOCTED;
	private String YLW63QTDCOMP;
	private String YLW63SITLIST;
	private String YLW63MOTBLOQ;
	private String YLW63INDCONTRSALD;
	private String YLW63CODDESCRERRO;
	private String YLW63NUMLISTADEB;
	private String YLW63SEUNUMERO;
	private String YLW63CODFGTS;
	private String YLW63NUMLACRE;
	private String YLW63DIGILACRE;
	private String YLW63ENTIDADCS;
	private String YLW63CENTROALTACS;
	private String YLW63CUENTACS;
	private String YLW63ENTIDADCM;
	private String YLW63CENTROALTACM;
	private String YLW63CUENTACM;
	private String YLW63FORMPAGCS;
	private String YLW63STATUSCOMPROR;
	private String YLW63INCPRODDA;
	private String YLW63CODFAV;
	private String YLW63TPSERV;
	private String YLW63DSCOMPSERV;
	private String YLW63UF;
	private String YLW63CIDADE;
	private String YLW63BAIRRO;
	private String YLW63LOGR;
	private String YLW63NUMLOGR;
	private String YLW63COMPLLOGR;
	private String YLW63CEP;
	private String YLW63COMPLCEP;
	private String YLW63DESCSERV;
	private String YLW63ANOBASE;
	private String YLW63RENAVAM;
	private String YLW63UFVEIC;
	private String YLW63CODMUN;
	private String YLW63PLACA;
	private String YLW63TPOPCAOPGTO;
	private String YLW63OPCAORETIR;
	private String YLW63TXLICTO;
	private String YLW63TXPOST;
	private String YLW63QTDDPVAT;
	private String YLW63VALTOTDPVAT;
	private String YLW63QTDIPVA;
	private String YLW63VALTOTIPVA;
	private String YLW63QTDMULTA;
	private String YLW63VALTOTMULTA;
	private String YLW63FILLER;
	private String YLW63INICMSIMP;
	private String YLW63NUMDIDSI;
	
	//tributos
	private String codigoBarrasTributos;
	
	// adicionais
	private String convenio;
	private String contaDebito;
	private String valorTotal;
	private String tipoDocumento;
	private boolean bolGRRF;
	
	//GAREICMS
	private String enderecoICMS;
	private String telefoneICMS;
	private String municipioICMS;
	private String cNAEICMS;
	
	//OCT
	private String vInFinOCT;
	private String vInConvenioOCT;
	private String vInRemetente;
	private String vInNumeroOCT;
	
	private String vInPI;
	
	// Endere�os - Gare
	private String enderecoGARE;
	private String telefoneGARE;
	private String cNAEGARE;
	private String municipioGARE;
	
	//Folha de Pagamento
	private String tipoPagamentoFP;
	private String descFinOrHist;
	private String situacaoFP;
	private String bancoFP;
	
	public String getYLW63PRODUTO() {
		return YLW63PRODUTO;
	}
	
	public void setYLW63PRODUTO(String yLW63PRODUTO) {
		YLW63PRODUTO = yLW63PRODUTO;
	}
	
	public String getYLW63ENTIDAD() {
		return YLW63ENTIDAD;
	}
	
	public void setYLW63ENTIDAD(String yLW63ENTIDAD) {
		YLW63ENTIDAD = yLW63ENTIDAD;
	}
	
	public String getYLW63CENTROALTA() {
		return YLW63CENTROALTA;
	}
	
	public void setYLW63CENTROALTA(String yLW63CENTROALTA) {
		YLW63CENTROALTA = yLW63CENTROALTA;
	}
	
	public String getYLW63CUENTA() {
		return YLW63CUENTA;
	}
	
	public void setYLW63CUENTA(String yLW63CUENTA) {
		YLW63CUENTA = yLW63CUENTA;
	}
	
	public String getYLW63DIVISA() {
		return YLW63DIVISA;
	}
	
	public void setYLW63DIVISA(String yLW63DIVISA) {
		YLW63DIVISA = yLW63DIVISA;
	}
	
	public String getYLW63NOMECONV() {
		return YLW63NOMECONV;
	}
	
	public void setYLW63NOMECONV(String yLW63NOMECONV) {
		YLW63NOMECONV = yLW63NOMECONV;
	}
	
	public String getYLW63REMESA() {
		return YLW63REMESA;
	}
	
	public void setYLW63REMESA(String yLW63REMESA) {
		YLW63REMESA = yLW63REMESA;
	}
	
	public String getYLW63NUMCOMPRO() {
		return YLW63NUMCOMPRO;
	}
	
	public void setYLW63NUMCOMPRO(String yLW63NUMCOMPRO) {
		YLW63NUMCOMPRO = yLW63NUMCOMPRO;
	}
	
	public String getYLW63ENTIDADDEB() {
		return YLW63ENTIDADDEB;
	}
	
	public void setYLW63ENTIDADDEB(String yLW63ENTIDADDEB) {
		YLW63ENTIDADDEB = yLW63ENTIDADDEB;
	}
	
	public String getYLW63CENTROALTADEB() {
		return YLW63CENTROALTADEB;
	}
	
	public void setYLW63CENTROALTADEB(String yLW63CENTROALTADEB) {
		YLW63CENTROALTADEB = yLW63CENTROALTADEB;
	}
	
	public String getYLW63CUENTADEB() {
		return YLW63CUENTADEB;
	}
	
	public void setYLW63CUENTADEB(String yLW63CUENTADEB) {
		YLW63CUENTADEB = yLW63CUENTADEB;
	}
	
	public String getYLW63DIVISADEB() {
		return YLW63DIVISADEB;
	}
	
	public void setYLW63DIVISADEB(String yLW63DIVISADEB) {
		YLW63DIVISADEB = yLW63DIVISADEB;
	}
	
	public String getYLW63ENTIDADCRED() {
		return YLW63ENTIDADCRED;
	}
	
	public void setYLW63ENTIDADCRED(String yLW63ENTIDADCRED) {
		YLW63ENTIDADCRED = yLW63ENTIDADCRED;
	}
	
	public String getYLW63CENTROALTACRED() {
		return YLW63CENTROALTACRED;
	}
	
	public void setYLW63CENTROALTACRED(String yLW63CENTROALTACRED) {
		YLW63CENTROALTACRED = yLW63CENTROALTACRED;
	}
	
	public String getYLW63CUENTACRED() {
		return YLW63CUENTACRED;
	}
	
	public void setYLW63CUENTACRED(String yLW63CUENTACRED) {
		YLW63CUENTACRED = yLW63CUENTACRED;
	}
	
	public String getYLW63DIVISACRED() {
		return YLW63DIVISACRED;
	}
	
	public void setYLW63DIVISACRED(String yLW63DIVISACRED) {
		YLW63DIVISACRED = yLW63DIVISACRED;
	}
	
	public String getYLW63HORENVIOTED() {
		return YLW63HORENVIOTED.replace(".", ",");
	}
	
	public void setYLW63HORENVIOTED(String yLW63HORENVIOTED) {
		YLW63HORENVIOTED = yLW63HORENVIOTED;
	}
	
	public String getYLW63CODFINAL() {
		return YLW63CODFINAL;
	}
	
	public void setYLW63CODFINAL(String yLW63CODFINAL) {
		YLW63CODFINAL = yLW63CODFINAL;
	}
	
	public String getYLW63CODCAMCOMP() {
		return YLW63CODCAMCOMP;
	}
	
	public void setYLW63CODCAMCOMP(String yLW63CODCAMCOMP) {
		YLW63CODCAMCOMP = yLW63CODCAMCOMP;
	}
	
	public String getYLW63INDAVISOPAG() {
		return AvisoDetalheCashEnum.findDescricaoByCodigo(YLW63INDAVISOPAG);
	}
	
	public void setYLW63INDAVISOPAG(String yLW63INDAVISOPAG) {
		YLW63INDAVISOPAG = yLW63INDAVISOPAG;
	}
	
	public String getYLW63TIPOTRANSF() {
		if ("E".equals(YLW63TIPOTRANSF))
			return "Outra Titularidade";
		else
			return "Mesma Titularidade";
	}
	
	public void setYLW63TIPOTRANSF(String yLW63TIPOTRANSF) {
		YLW63TIPOTRANSF = yLW63TIPOTRANSF;
	}
	
	public String getYLW63FORMPAG() {
		return YLW63FORMPAG;
	}
	
	public String getYLW63FORMPAGSTR() {
		return TipoPagamentoDetalheCashEnum.findByCodigo(YLW63FORMPAG).getDescricao();
	}
	
	public void setYLW63FORMPAG(String yLW63FORMPAG) {
		YLW63FORMPAG = yLW63FORMPAG;
	}
	
	public String getYLW63CODHIST() {
		return TipoPagamentoFolhaPagamentoEnum.finfByChave(YLW63CODHIST);
	}
	
	public String getYLW63CODHISTCOMP() {
		return HistoricoCompromossoComplCashEnum.findDescricaoByCodigo(YLW63CODHIST);
	}
	
	public void setYLW63CODHIST(String yLW63CODHIST) {
		YLW63CODHIST = yLW63CODHIST;
	}
	
	public String getYLW63CODTIPIDENT() {
		return YLW63CODTIPIDENT;
	}
	
	public void setYLW63CODTIPIDENT(String yLW63CODTIPIDENT) {
		YLW63CODTIPIDENT = yLW63CODTIPIDENT;
	}
	
	public String getYLW63CODFORNCONS() {
		return UtilFunction.formatarCpfCnpj(this.YLW63CODFORNCONS);
	}
	
	public void setYLW63CODFORNCONS(String yLW63CODFORNCONS) {
		YLW63CODFORNCONS = yLW63CODFORNCONS;
	}
	
	public String getYLW63NOMEFAVORECIDO() {
		return YLW63NOMEFAVORECIDO.replace("+", " ");
	}
	
	public void setYLW63NOMEFAVORECIDO(String yLW63NOMEFAVORECIDO) {
		YLW63NOMEFAVORECIDO = yLW63NOMEFAVORECIDO;
	}
	
	public String getYLW63IMPORTE() {
		return "R$ " + UtilFunction.convertStringToStringFormatoBR(YLW63IMPORTE);
	}
	
	public void setYLW63IMPORTE(String yLW63IMPORTE) {
		YLW63IMPORTE = yLW63IMPORTE;
	}
	
	public String getYLW63IMPINSS() {
		String value = new BigDecimal(YLW63IMPINSS).divide(new BigDecimal(100)).setScale(2, RoundingMode.HALF_UP).toString();
		return NumberFormat.getCurrencyInstance().format(Double.valueOf(value));
		
	}
	
	public void setYLW63IMPINSS(String yLW63IMPINSS) {
		YLW63IMPINSS = yLW63IMPINSS;
	}
	
	public String getYLW63IMPJUROS() {
		if (StringUtils.isNotBlank(YLW63IMPJUROS)) {
			String value = new BigDecimal(YLW63IMPJUROS).divide(new BigDecimal(100)).setScale(2, RoundingMode.HALF_UP).toString();
			return NumberFormat.getCurrencyInstance().format(Double.valueOf(value));
		}
		return "";
	}
	
	public void setYLW63IMPJUROS(String yLW63IMPJUROS) {
		YLW63IMPJUROS = yLW63IMPJUROS;
	}
	
	public String getYLW63IMPMULTA() {
		if (StringUtils.isNotBlank(YLW63IMPMULTA)) {
			String value = new BigDecimal(YLW63IMPMULTA).divide(new BigDecimal(100)).setScale(2, RoundingMode.HALF_UP).toString();
			return NumberFormat.getCurrencyInstance().format(Double.valueOf(value));
		}
		return "";
	}
	
	public void setYLW63IMPMULTA(String yLW63IMPMULTA) {
		YLW63IMPMULTA = yLW63IMPMULTA;
	}
	
	public String getYLW63INDCONF() {
		if ("N".equalsIgnoreCase(YLW63INDCONF)) {
			YLW63INDCONF = "N�o";
		} else {
			YLW63INDCONF = "Sim";
		}
		return YLW63INDCONF;
	}
	
	public void setYLW63INDCONF(String yLW63INDCONF) {
		YLW63INDCONF = yLW63INDCONF;
	}
	
	public String getYLW63IMPABATIMENTO() {
		if (YLW63IMPABATIMENTO == null)
			return "0";
		return YLW63IMPABATIMENTO;
	}
	
	public String getYLW63IMPABATIMENTOMONEY() {
		if (StringUtils.isNotBlank(YLW63IMPABATIMENTO)) {
			final String value = new BigDecimal(YLW63IMPABATIMENTO).divide(new BigDecimal(100))
					.setScale(2, RoundingMode.HALF_UP).toString();
			return NumberFormat.getCurrencyInstance().format(Double.valueOf(value));
		}
		return "";
	}
	
	public void setYLW63IMPABATIMENTO(String yLW63IMPABATIMENTO) {
		YLW63IMPABATIMENTO = yLW63IMPABATIMENTO;
	}
	
	public String getYLW63IMPNOMDOC() {
		if (YLW63IMPNOMDOC == null)
			return "0";
		return YLW63IMPNOMDOC;
	}
	
	public String getYLW63IMPNOMDOCMONEY() {
		if (isNotBlank(YLW63IMPNOMDOC)) {
			return "R$ " + YLW63IMPNOMDOC;
		}
		return "R$ 0,00";
	}
	
	public void setYLW63IMPNOMDOC(String yLW63IMPNOMDOC) {
		YLW63IMPNOMDOC = yLW63IMPNOMDOC;
	}
	
	public String getYLW63IMPMORA() {
		return YLW63IMPMORA;
	}
	
	public void setYLW63IMPMORA(String yLW63IMPMORA) {
		YLW63IMPMORA = yLW63IMPMORA;
	}
	
	public String getYLW63IMPOUTENT() {
		String value = new BigDecimal(YLW63IMPOUTENT).divide(new BigDecimal(100))
				.setScale(2, RoundingMode.HALF_UP).toString();
		return NumberFormat.getCurrencyInstance().format(Double.valueOf(value));
	}
	
	public void setYLW63IMPOUTENT(String yLW63IMPOUTENT) {
		YLW63IMPOUTENT = yLW63IMPOUTENT;
	}
	
	public String getYLW63IMPACRESCTRIB() {
		if (YLW63IMPACRESCTRIB == null)
			return NumberFormat.getCurrencyInstance().format(Double.valueOf("0"));
		return NumberFormat.getCurrencyInstance().format(Double.valueOf(YLW63IMPACRESCTRIB));
	}
	
	public void setYLW63IMPACRESCTRIB(String yLW63IMPACRESCTRIB) {
		YLW63IMPACRESCTRIB = yLW63IMPACRESCTRIB;
	}
	
	public String getYLW63IMPHONTRIB() {
		if (StringUtils.isNotBlank(YLW63IMPHONTRIB)) {
			String value = new BigDecimal(YLW63IMPHONTRIB).divide(new BigDecimal(100))
					.setScale(2, RoundingMode.HALF_UP).toString();
			return NumberFormat.getCurrencyInstance().format(Double.valueOf(value));
		}
		return "";
	}
	
	public void setYLW63IMPHONTRIB(String yLW63IMPHONTRIB) {
		YLW63IMPHONTRIB = yLW63IMPHONTRIB;
	}
	
	public String getYLW63IMPRECBRUTA() {
		if (StringUtils.isNotBlank(YLW63IMPRECBRUTA)) {
			String value = new BigDecimal(YLW63IMPRECBRUTA).divide(new BigDecimal(100))
					.setScale(2, RoundingMode.HALF_UP).toString();
			return NumberFormat.getCurrencyInstance().format(Double.valueOf(value));
		}
		return "";
	}
	
	public void setYLW63IMPRECBRUTA(String yLW63IMPRECBRUTA) {
		YLW63IMPRECBRUTA = yLW63IMPRECBRUTA;
	}
	
	public String getYLW63PORCRECBRUTA() {
		if (StringUtils.isNotBlank(YLW63PORCRECBRUTA)) {
			String value = new BigDecimal(YLW63PORCRECBRUTA).divide(new BigDecimal(100))
					.setScale(2, RoundingMode.HALF_UP).toString();
			return NumberFormat.getCurrencyInstance().format(Double.valueOf(value));
		}
		return "";
	}
	
	public void setYLW63PORCRECBRUTA(String yLW63PORCRECBRUTA) {
		YLW63PORCRECBRUTA = yLW63PORCRECBRUTA;
	}
	
	public String getYLW63FECORIGCOMPR() {
		return YLW63FECORIGCOMPR;
	}
	
	public void setYLW63FECORIGCOMPR(String yLW63FECORIGCOMPR) {
		YLW63FECORIGCOMPR = yLW63FECORIGCOMPR;
	}
	
	public String getYLW63NUMPARC() {
		if (Integer.parseInt(YLW63NUMPARC) == 0) {
			return "";
		}
		return YLW63NUMPARC;
	}
	
	public void setYLW63NUMPARC(String yLW63NUMPARC) {
		YLW63NUMPARC = yLW63NUMPARC;
	}
	
	public String getYLW63COMPTTRIB() {
		return YLW63COMPTTRIB;
	}
	
	public String getYLW63COMPTTRIBSTR() {
		return YLW63COMPTTRIB.substring(0, 2) + "/"+ YLW63COMPTTRIB.substring(2);
	}
	
	public void setYLW63COMPTTRIB(String yLW63COMPTTRIB) {
		YLW63COMPTTRIB = yLW63COMPTTRIB;
	}
	
	public String getYLW63CODRECPAG() {
		return YLW63CODRECPAG;
	}
	
	public void setYLW63CODRECPAG(String yLW63CODRECPAG) {
		YLW63CODRECPAG = yLW63CODRECPAG;
	}
	
	public String getYLW63PERIODAPURTRIB() {
		return YLW63PERIODAPURTRIB;
	}
	
	public void setYLW63PERIODAPURTRIB(String yLW63PERIODAPURTRIB) {
		YLW63PERIODAPURTRIB = yLW63PERIODAPURTRIB;
	}
	
	public String getYLW63CODBARRAS() {
		if (isNotBlank(YLW63CODBARRAS)) {
			return YLW63CODBARRAS.substring(0, 5).concat(YLW63CODBARRAS.substring(5, 10))
					.concat(YLW63CODBARRAS.substring(10, 15)).concat(YLW63CODBARRAS.substring(15, 20))
					.concat(YLW63CODBARRAS.substring(21, 26)).concat(YLW63CODBARRAS.substring(26, 32))
					.concat(" " + YLW63CODBARRAS.substring(33, 34) + " ").concat(YLW63CODBARRAS.substring(33));
		}
		return YLW63CODBARRAS;
	}
	
	public void setYLW63CODBARRAS(String yLW63CODBARRAS) {
		YLW63CODBARRAS = yLW63CODBARRAS;
	}
	
	public String getYLW63NUMREFTRIB() {
		return YLW63NUMREFTRIB;
	}
	
	public void setYLW63NUMREFTRIB(String yLW63NUMREFTRIB) {
		YLW63NUMREFTRIB = yLW63NUMREFTRIB;
	}
	
	public String getYLW63INSCESTTRIB() {
		return YLW63INSCESTTRIB;
	}
	
	public void setYLW63INSCESTTRIB(String yLW63INSCESTTRIB) {
		YLW63INSCESTTRIB = yLW63INSCESTTRIB;
	}
	
	public String getYLW63DIVIDAATIVA() {
		if (Integer.parseInt(YLW63DIVIDAATIVA) == 0) {
			return "";
		}
		return YLW63DIVIDAATIVA;
	}
	
	public void setYLW63DIVIDAATIVA(String yLW63DIVIDAATIVA) {
		YLW63DIVIDAATIVA = yLW63DIVIDAATIVA;
	}
	
	public String getYLW63OBS1TRIB() {
		return YLW63OBS1TRIB;
	}
	
	public void setYLW63OBS1TRIB(String yLW63OBS1TRIB) {
		YLW63OBS1TRIB = yLW63OBS1TRIB;
	}
	
	public String getYLW63OBS2TRIB() {
		return YLW63OBS2TRIB;
	}
	
	public void setYLW63OBS2TRIB(String yLW63OBS2TRIB) {
		if (StringUtils.isNotBlank(yLW63OBS2TRIB)) {
			if (!"".equalsIgnoreCase(yLW63OBS2TRIB)) {
				if (yLW63OBS2TRIB.length() >= 40) {
					this.setEnderecoGARE(yLW63OBS2TRIB.substring(0, 40));
				}
				if (yLW63OBS2TRIB.length() >= 50) {
					this.setTelefoneGARE(yLW63OBS2TRIB.substring(40, 50));
				}
				if (yLW63OBS2TRIB.length() >= 62) {
					this.setcNAEGARE(yLW63OBS2TRIB.substring(50, 62));
				}
				if (yLW63OBS2TRIB.length() >= 71) {
					this.setMunicipioGARE(yLW63OBS2TRIB.substring(62, 71));
				}
			}
		}
		YLW63OBS2TRIB = yLW63OBS2TRIB;
	}
	
	public String getYLW63CODAUT() {
		return YLW63CODAUT;
	}
	
	public void setYLW63CODAUT(String yLW63CODAUT) {
		YLW63CODAUT = yLW63CODAUT;
	}
	
	public String getYLW63IMPOPER() {
		return YLW63IMPOPER;
	}
	
	public void setYLW63IMPOPER(String yLW63IMPOPER) {
		YLW63IMPOPER = yLW63IMPOPER;
	}
	
	public String getYLW63NUMLOTE() {
		return YLW63NUMLOTE;
	}
	
	public void setYLW63NUMLOTE(String yLW63NUMLOTE) {
		YLW63NUMLOTE = yLW63NUMLOTE;
	}
	
	public String getYLW63FECVENC() {
		return YLW63FECVENC;
	}
	
	public void setYLW63FECVENC(String yLW63FECVENC) {
		YLW63FECVENC = yLW63FECVENC;
	}
	
	public String getYLW63COMPTIPODOC() {
		return YLW63COMPTIPODOC;
	}
	
	public void setYLW63COMPTIPODOC(String yLW63COMPTIPODOC) {
		YLW63COMPTIPODOC = yLW63COMPTIPODOC;
	}
	
	public String getYLW63COMPSEQ() {
		return YLW63COMPSEQ;
	}
	
	public void setYLW63COMPSEQ(String yLW63COMPSEQ) {
		YLW63COMPSEQ = yLW63COMPSEQ;
	}
	
	public String getYLW63FECPROCDEB() {
		return YLW63FECPROCDEB;
	}
	
	public void setYLW63FECPROCDEB(String yLW63FECPROCDEB) {
		YLW63FECPROCDEB = yLW63FECPROCDEB;
	}
	
	public String getYLW63FECVALORDEB() {
		return YLW63FECVALORDEB;
	}
	
	public void setYLW63FECVALORDEB(String yLW63FECVALORDEB) {
		YLW63FECVALORDEB = yLW63FECVALORDEB;
	}
	
	public String getYLW63FECVALORCRED() {
		return this.YLW63FECVALORCRED;
	}
	
	public void setYLW63FECVALORCRED(String yLW63FECVALORCRED) {
		YLW63FECVALORCRED = yLW63FECVALORCRED;
	}
	
	public String getYLW63FECALTAAGEN() {
		return YLW63FECALTAAGEN;
	}
	
	public void setYLW63FECALTAAGEN(String yLW63FECALTAAGEN) {
		YLW63FECALTAAGEN = yLW63FECALTAAGEN;
	}
	
	public String getYLW63INDESTACOMP() {
		return CompromissoFolhaPagamentoDetalheCashEnum.findDescricao(YLW63INDESTACOMP, YLW63MOTBLOQ);
	}
	
	public String getYLW63INDESTACOMPMOTBLOQREQ() {
		return CompromissoFolhaPagamentoDetalheCashEnum.findDescricao(YLW63INDESTACOMP, "");
	}
	
	public void setYLW63INDESTACOMP(String yLW63INDESTACOMP) {
		YLW63INDESTACOMP = yLW63INDESTACOMP;
	}
	
	public String getYLW63TIPINCLUSION() {
		return YLW63TIPINCLUSION;
	}
	
	public void setYLW63TIPINCLUSION(String yLW63TIPINCLUSION) {
		YLW63TIPINCLUSION = yLW63TIPINCLUSION;
	}
	
	public String getYLW63NUMPROTOCOLO() {
		return YLW63NUMPROTOCOLO;
	}
	
	public void setYLW63NUMPROTOCOLO(String yLW63NUMPROTOCOLO) {
		YLW63NUMPROTOCOLO = yLW63NUMPROTOCOLO;
	}
	
	public String getYLW63NUMDOCTED() {
		return YLW63NUMDOCTED;
	}
	
	public void setYLW63NUMDOCTED(String yLW63NUMDOCTED) {
		YLW63NUMDOCTED = yLW63NUMDOCTED;
	}
	
	public String getYLW63QTDCOMP() {
		return YLW63QTDCOMP;
	}
	
	public void setYLW63QTDCOMP(String yLW63QTDCOMP) {
		YLW63QTDCOMP = yLW63QTDCOMP;
	}
	
	public String getYLW63SITLIST() {
		return YLW63SITLIST;
	}
	
	public void setYLW63SITLIST(String yLW63SITLIST) {
		if (isNotBlank(yLW63SITLIST)) {
			this.setvInFinOCT(yLW63SITLIST.substring(41, 50));
			this.setvInConvenioOCT(yLW63SITLIST.substring(81, 90));
			this.setvInRemetente(yLW63SITLIST.substring(1, 41));
			this.setvInNumeroOCT(yLW63SITLIST.substring(91, 105));
			this.setvInPI(yLW63SITLIST.substring(105));
		}
		YLW63SITLIST = yLW63SITLIST;
	}
	
	public String getYLW63MOTBLOQ() {
		return YLW63MOTBLOQ;
	}
	
	public void setYLW63MOTBLOQ(String yLW63MOTBLOQ) {
		YLW63MOTBLOQ = yLW63MOTBLOQ;
	}
	
	public String getYLW63INDCONTRSALD() {
		return YLW63INDCONTRSALD;
	}
	
	public void setYLW63INDCONTRSALD(String yLW63INDCONTRSALD) {
		YLW63INDCONTRSALD = yLW63INDCONTRSALD;
	}
	
	public String getYLW63CODDESCRERRO() {
		return YLW63CODDESCRERRO;
	}
	
	public void setYLW63CODDESCRERRO(String yLW63CODDESCRERRO) {
		YLW63CODDESCRERRO = yLW63CODDESCRERRO;
	}
	
	public String getYLW63NUMLISTADEB() {
		if ("000000".equals(YLW63NUMLISTADEB))
			return "";
		return YLW63NUMLISTADEB;
	}
	
	public void setYLW63NUMLISTADEB(String yLW63NUMLISTADEB) {
		YLW63NUMLISTADEB = yLW63NUMLISTADEB;
	}
	
	public String getYLW63SEUNUMERO() {
		return YLW63SEUNUMERO;
	}
	
	public void setYLW63SEUNUMERO(String yLW63SEUNUMERO) {
		YLW63SEUNUMERO = yLW63SEUNUMERO;
	}
	
	public String getYLW63CODFGTS() {
		return YLW63CODFGTS;
	}
	
	public void setYLW63CODFGTS(String yLW63CODFGTS) {
		YLW63CODFGTS = yLW63CODFGTS;
	}
	
	public String getYLW63NUMLACRE() {
		return YLW63NUMLACRE;
	}
	
	public void setYLW63NUMLACRE(String yLW63NUMLACRE) {
		YLW63NUMLACRE = yLW63NUMLACRE;
	}
	
	public String getYLW63DIGILACRE() {
		return YLW63DIGILACRE;
	}
	
	public void setYLW63DIGILACRE(String yLW63DIGILACRE) {
		YLW63DIGILACRE = yLW63DIGILACRE;
	}
	
	public String getYLW63ENTIDADCS() {
		return YLW63ENTIDADCS;
	}
	
	public void setYLW63ENTIDADCS(String yLW63ENTIDADCS) {
		YLW63ENTIDADCS = yLW63ENTIDADCS;
	}
	
	public String getYLW63CENTROALTACS() {
		return YLW63CENTROALTACS;
	}
	
	public void setYLW63CENTROALTACS(String yLW63CENTROALTACS) {
		YLW63CENTROALTACS = yLW63CENTROALTACS;
	}
	
	public String getYLW63CUENTACS() {
		return YLW63CUENTACS;
	}
	
	public void setYLW63CUENTACS(String yLW63CUENTACS) {
		YLW63CUENTACS = yLW63CUENTACS;
	}
	
	public String getYLW63ENTIDADCM() {
		return YLW63ENTIDADCM;
	}
	
	public void setYLW63ENTIDADCM(String yLW63ENTIDADCM) {
		YLW63ENTIDADCM = yLW63ENTIDADCM;
	}
	
	public String getYLW63CENTROALTACM() {
		return YLW63CENTROALTACM;
	}
	
	public void setYLW63CENTROALTACM(String yLW63CENTROALTACM) {
		YLW63CENTROALTACM = yLW63CENTROALTACM;
	}
	
	public String getYLW63CUENTACM() {
		return YLW63CUENTACM;
	}
	
	public void setYLW63CUENTACM(String yLW63CUENTACM) {
		YLW63CUENTACM = yLW63CUENTACM;
	}
	
	public String getYLW63FORMPAGCS() {
		return YLW63FORMPAGCS;
	}
	
	public void setYLW63FORMPAGCS(String yLW63FORMPAGCS) {
		YLW63FORMPAGCS = yLW63FORMPAGCS;
	}
	
	public String getYLW63STATUSCOMPROR() {
		return YLW63STATUSCOMPROR;
	}
	
	public void setYLW63STATUSCOMPROR(String yLW63STATUSCOMPROR) {
		YLW63STATUSCOMPROR = yLW63STATUSCOMPROR;
	}
	
	public String getYLW63INCPRODDA() {
		return YLW63INCPRODDA;
	}
	
	public void setYLW63INCPRODDA(String yLW63INCPRODDA) {
		YLW63INCPRODDA = yLW63INCPRODDA;
	}
	
	public String getYLW63CODFAV() {
		return YLW63CODFAV;
	}
	
	public void setYLW63CODFAV(String yLW63CODFAV) {
		YLW63CODFAV = yLW63CODFAV;
	}
	
	public String getYLW63TPSERV() {
		return TipoServicoDetalheCashEnum.findDescricaoByCodigo(YLW63TPSERV, YLW63DESCSERV);
	}
	
	public void setYLW63TPSERV(String yLW63TPSERV) {
		YLW63TPSERV = yLW63TPSERV;
	}
	
	public String getYLW63DSCOMPSERV() {
		return YLW63DSCOMPSERV;
	}
	
	public void setYLW63DSCOMPSERV(String yLW63DSCOMPSERV) {
		YLW63DSCOMPSERV = yLW63DSCOMPSERV;
	}
	
	public String getYLW63UF() {
		return YLW63UF;
	}
	
	public void setYLW63UF(String yLW63UF) {
		YLW63UF = yLW63UF;
	}
	
	public String getYLW63CIDADE() {
		return YLW63CIDADE;
	}
	
	public void setYLW63CIDADE(String yLW63CIDADE) {
		YLW63CIDADE = yLW63CIDADE;
	}
	
	public String getYLW63BAIRRO() {
		return YLW63BAIRRO;
	}
	
	public void setYLW63BAIRRO(String yLW63BAIRRO) {
		YLW63BAIRRO = yLW63BAIRRO;
	}
	
	public String getYLW63LOGR() {
		return YLW63LOGR;
	}
	
	public void setYLW63LOGR(String yLW63LOGR) {
		YLW63LOGR = yLW63LOGR;
	}
	
	public String getYLW63NUMLOGR() {
		return YLW63NUMLOGR;
	}
	
	public void setYLW63NUMLOGR(String yLW63NUMLOGR) {
		YLW63NUMLOGR = yLW63NUMLOGR;
	}
	
	public String getYLW63COMPLLOGR() {
		return YLW63COMPLLOGR;
	}
	
	public void setYLW63COMPLLOGR(String yLW63COMPLLOGR) {
		YLW63COMPLLOGR = yLW63COMPLLOGR;
	}
	
	public String getYLW63CEP() {
		return YLW63CEP;
	}
	
	public void setYLW63CEP(String yLW63CEP) {
		YLW63CEP = yLW63CEP;
	}
	
	public String getYLW63COMPLCEP() {
		return YLW63COMPLCEP;
	}
	
	public void setYLW63COMPLCEP(String yLW63COMPLCEP) {
		YLW63COMPLCEP = yLW63COMPLCEP;
	}
	
	public String getYLW63DESCSERV() {
		return YLW63DESCSERV;
	}
	
	public void setYLW63DESCSERV(String yLW63DESCSERV) {
		YLW63DESCSERV = yLW63DESCSERV;
	}
	
	public String getYLW63ANOBASE() {
		return YLW63ANOBASE;
	}
	
	public void setYLW63ANOBASE(String yLW63ANOBASE) {
		YLW63ANOBASE = yLW63ANOBASE;
	}
	
	public String getYLW63RENAVAM() {
		return YLW63RENAVAM;
	}
	
	public void setYLW63RENAVAM(String yLW63RENAVAM) {
		YLW63RENAVAM = yLW63RENAVAM;
	}
	
	public String getYLW63UFVEIC() {
		return YLW63UFVEIC;
	}
	
	public void setYLW63UFVEIC(String yLW63UFVEIC) {
		YLW63UFVEIC = yLW63UFVEIC;
	}
	
	public String getYLW63CODMUN() {
		return YLW63CODMUN;
	}
	
	public void setYLW63CODMUN(String yLW63CODMUN) {
		YLW63CODMUN = yLW63CODMUN;
	}
	
	public String getYLW63PLACA() {
		return YLW63PLACA;
	}
	
	public void setYLW63PLACA(String yLW63PLACA) {
		YLW63PLACA = yLW63PLACA;
	}
	
	public String getYLW63TPOPCAOPGTO() {
		return YLW63TPOPCAOPGTO;
	}
	
	public void setYLW63TPOPCAOPGTO(String yLW63TPOPCAOPGTO) {
		YLW63TPOPCAOPGTO = yLW63TPOPCAOPGTO;
	}
	
	public String getYLW63OPCAORETIR() {
		return YLW63OPCAORETIR;
	}
	
	public void setYLW63OPCAORETIR(String yLW63OPCAORETIR) {
		YLW63OPCAORETIR = yLW63OPCAORETIR;
	}
	
	public String getYLW63TXLICTO() {
		if (StringUtils.isNotBlank(YLW63TXLICTO)) {
			String value = new BigDecimal(YLW63TXLICTO).divide(new BigDecimal(100))
					.setScale(2, RoundingMode.HALF_UP).toString();
			return NumberFormat.getCurrencyInstance().format(Double.valueOf(value));
		}
		return "";
	}
	
	public void setYLW63TXLICTO(String yLW63TXLICTO) {
		YLW63TXLICTO = yLW63TXLICTO;
	}
	
	public String getYLW63TXPOST() {
		if (StringUtils.isNotBlank(YLW63TXPOST)) {
			String value = new BigDecimal(YLW63TXPOST).divide(new BigDecimal(100))
					.setScale(2, RoundingMode.HALF_UP).toString();
			return NumberFormat.getCurrencyInstance().format(Double.valueOf(value));
		}
		return "";
	}
	
	public void setYLW63TXPOST(String yLW63TXPOST) {
		YLW63TXPOST = yLW63TXPOST;
	}
	
	public String getYLW63QTDDPVAT() {
		return YLW63QTDDPVAT;
	}
	
	public void setYLW63QTDDPVAT(String yLW63QTDDPVAT) {
		YLW63QTDDPVAT = yLW63QTDDPVAT;
	}
	
	public String getYLW63VALTOTDPVAT() {
		if (StringUtils.isNotBlank(YLW63VALTOTDPVAT)) {
			String value = new BigDecimal(YLW63VALTOTDPVAT).divide(new BigDecimal(100))
					.setScale(2, RoundingMode.HALF_UP).toString();
			return NumberFormat.getCurrencyInstance().format(Double.valueOf(value));
		}
		return "";
	}
	
	public void setYLW63VALTOTDPVAT(String yLW63VALTOTDPVAT) {
		YLW63VALTOTDPVAT = yLW63VALTOTDPVAT;
	}
	
	public String getYLW63QTDIPVA() {
		return YLW63QTDIPVA;
	}
	
	public void setYLW63QTDIPVA(String yLW63QTDIPVA) {
		YLW63QTDIPVA = yLW63QTDIPVA;
	}
	
	public String getYLW63VALTOTIPVA() {
		if (StringUtils.isNotBlank(YLW63VALTOTIPVA)) {
			String value = new BigDecimal(YLW63VALTOTIPVA).divide(new BigDecimal(100))
					.setScale(2, RoundingMode.HALF_UP).toString();
			return NumberFormat.getCurrencyInstance().format(Double.valueOf(value));
		}
		return "";
	}
	
	public void setYLW63VALTOTIPVA(String yLW63VALTOTIPVA) {
		YLW63VALTOTIPVA = yLW63VALTOTIPVA;
	}
	
	public String getYLW63QTDMULTA() {
		return YLW63QTDMULTA;
	}
	
	public void setYLW63QTDMULTA(String yLW63QTDMULTA) {
		YLW63QTDMULTA = yLW63QTDMULTA;
	}
	
	public String getYLW63VALTOTMULTA() {
		if (StringUtils.isNotBlank(YLW63VALTOTMULTA)) {
			String value = new BigDecimal(YLW63VALTOTMULTA).divide(new BigDecimal(100))
					.setScale(2, RoundingMode.HALF_UP).toString();
			return NumberFormat.getCurrencyInstance().format(Double.valueOf(value));
		}
		return "";
	}
	
	public void setYLW63VALTOTMULTA(String yLW63VALTOTMULTA) {
		YLW63VALTOTMULTA = yLW63VALTOTMULTA;
	}
	
	public String getYLW63FILLER() {
		return YLW63FILLER;
	}
	
	public void setYLW63FILLER(String yLW63FILLER) {
		YLW63FILLER = yLW63FILLER;
	}
	
	public String getYLW63INICMSIMP() {
		return YLW63INICMSIMP;
	}
	
	public void setYLW63INICMSIMP(String yLW63INICMSIMP) {
		YLW63INICMSIMP = yLW63INICMSIMP;
	}
	
	public String getYLW63NUMDIDSI() {
		return YLW63NUMDIDSI;
	}
	
	public void setYLW63NUMDIDSI(String yLW63NUMDIDSI) {
		YLW63NUMDIDSI = yLW63NUMDIDSI;
	}
	
	public String getConvenio() {
		return this.convenio;
	}
	
	public void setConvenio(String convenio) {
		this.convenio = convenio;
	}
	
	public String getContaDebito() {
		return contaDebito;
	}
	
	public void setContaDebito(String contaDebito) {
		this.contaDebito = contaDebito;
	}
	
	public String getValorTotal() {
		return "R$ " + valorTotal;
	}
	
	public void setValorTotal(String valorTotal) {
		this.valorTotal = valorTotal;
	}
	
	public String getTipoDocumento() {
		return tipoDocumento;
	}
	
	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}
	
	public boolean isBolGRRF() {
		return bolGRRF;
	}
	
	public void setBolGRRF(boolean bolGRRF) {
		this.bolGRRF = bolGRRF;
	}
	
	public String getContaDebitoSemEntidade() {
		return getYLW63CENTROALTA() + "-" + getYLW63CUENTADEB();
	}
	
	public String getvInFinOCT() {
		return vInFinOCT;
	}
	
	public void setvInFinOCT(String vInFinOCT) {
		this.vInFinOCT = vInFinOCT;
	}
	
	public String getvInConvenioOCT() {
		return vInConvenioOCT;
	}
	
	public void setvInConvenioOCT(String vInConvenioOCT) {
		this.vInConvenioOCT = vInConvenioOCT;
	}
	
	public String getvInRemetente() {
		return vInRemetente;
	}
	
	public void setvInRemetente(String vInRemetente) {
		this.vInRemetente = vInRemetente;
	}
	
	public String getvInNumeroOCT() {
		return vInNumeroOCT;
	}
	
	public void setvInNumeroOCT(String vInNumeroOCT) {
		this.vInNumeroOCT = vInNumeroOCT;
	}
	
	public String getvInPI() {
		
		if ("N".equalsIgnoreCase(vInPI)) {
			vInPI = "N�o";
		} else {
			vInPI = "Sim";
		}
		
		return vInPI;
	}
	
	public void setvInPI(String vInPI) {
		this.vInPI = vInPI;
	}
	
	public String getEnderecoGARE() {
		return enderecoGARE;
	}
	
	public void setEnderecoGARE(String enderecoGARE) {
		this.enderecoGARE = enderecoGARE;
	}
	
	public String getTelefoneGARE() {
		return telefoneGARE;
	}
	
	public void setTelefoneGARE(String telefoneGARE) {
		this.telefoneGARE = telefoneGARE;
	}
	
	public String getcNAEGARE() {
		return cNAEGARE;
	}
	
	public void setcNAEGARE(String cNAEGARE) {
		this.cNAEGARE = cNAEGARE;
	}
	
	public String getMunicipioGARE() {
		return municipioGARE;
	}
	
	public void setMunicipioGARE(String municipioGARE) {
		this.municipioGARE = municipioGARE;
	}
	
	public String getEnderecoICMS() {
		if(StringUtils.isNotBlank(YLW63OBS2TRIB) && YLW63OBS2TRIB.length() >= 39){
			return YLW63OBS2TRIB.substring(0, 39);
		}
		return YLW63OBS2TRIB;
	}
	
	public String getTelefoneICMS() {
		if(StringUtils.isNotBlank(YLW63OBS2TRIB) && YLW63OBS2TRIB.length() >= 48){
			return YLW63OBS2TRIB.substring(40, 48);
		}
		return YLW63OBS2TRIB;
	}
	
	public String getMunicipioICMS() {
		if(StringUtils.isNotBlank(YLW63OBS2TRIB) && YLW63OBS2TRIB.length() >= 71){
			return YLW63OBS2TRIB.substring(60, 71);
		}
		return YLW63OBS2TRIB;
	}
	
	public String getcNAEICMS() {
		return cNAEICMS;
	}
	
	public String getTipoPagamentoFP() {
		return TipoFolhaPagamentoEnum.findByChave(tipoPagamentoFP);
	}
	
	public String getDescFinOrHist() {
		
		if ("CARSA".equals(YLW63FORMPAG)
				|| "CC".equals(YLW63FORMPAG)
				|| "POU".equals(YLW63FORMPAG))
			return "Hist�rico";
		else
			return "Finalidade";
	}
	
	public String getSituacaoFP() {
		return SituacaoFolhaPagamentoEnum.findByChave(YLW63INDESTACOMP);
	}
	
	public String getBancoFP() {
		if ("0353".equalsIgnoreCase(YLW63ENTIDADCRED)
				&& "0008".equalsIgnoreCase(YLW63ENTIDADCRED)
				&& "0000".equalsIgnoreCase(YLW63ENTIDADCRED)
				&& "".equalsIgnoreCase(YLW63ENTIDADCRED))
			return "0033";
		
		return YLW63ENTIDADCRED;
	}
	
	public String getCodigoBarrasTributos() {
		return YLW63CODBARRAS;
	}
	
}
