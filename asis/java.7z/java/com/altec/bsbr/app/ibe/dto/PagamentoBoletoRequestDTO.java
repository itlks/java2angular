package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.altec.bsbr.app.ibe.enumeration.SituacaoDaTransacaoEnum;
import com.altec.bsbr.app.ibe.enumeration.TipoDocumentoEnum;

public class PagamentoBoletoRequestDTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3800065424252088087L;
	
	private Date dataVencimento;
	private Date dataAgendamento;
	private BigDecimal valorDigitado;
	private String nomeSacado;
	private String nomeCedente;
	private String nomeBeneficiario;
	private String codBeneficiario;
	private String codigoBarras;
	private SituacaoDaTransacaoEnum situacaoTransacao;
	private TipoDocumentoEnum tipoDocCedente;
	private String documentoCedente;
	private String formaPagamento;
	private String tipoPessoaFavorecido;
	private String docFavorecido;
	private String tipoPessoaCliente;
	private String docCliente;
	private ListaCartoesItemDTO cartao;
	
	public Date getDataVencimento() {
		return dataVencimento;
	}
	public void setDataVencimento(Date dataVencimento) {
		this.dataVencimento = dataVencimento;
	}
	public BigDecimal getValorDigitado() {
		return valorDigitado;
	}
	public void setValorDigitado(BigDecimal valorDigitado) {
		this.valorDigitado = valorDigitado;
	}
	public String getNomeSacado() {
		return nomeSacado;
	}
	public void setNomeSacado(String nomeSacado) {
		this.nomeSacado = nomeSacado;
	}
	public String getNomeCedente() {
		return nomeCedente;
	}
	public void setNomeCedente(String nomeCedente) {
		this.nomeCedente = nomeCedente;
	}
	public Date getDataAgendamento() {
		return dataAgendamento;
	}
	public void setDataAgendamento(Date dataAgendamento) {
		this.dataAgendamento = dataAgendamento;
	}
	public String getCodigoBarras() {
		return codigoBarras;
	}
	public void setCodigoBarras(String codigoBarras) {
		this.codigoBarras = codigoBarras;
	}
	public SituacaoDaTransacaoEnum getSituacaoTransacao() {
		return situacaoTransacao;
	}
	public void setSituacaoTransacao(SituacaoDaTransacaoEnum situacaoTransacao) {
		this.situacaoTransacao = situacaoTransacao;
	}
	public TipoDocumentoEnum getTipoDocCedente() {
		return tipoDocCedente;
	}
	public void setTipoDocCedente(TipoDocumentoEnum tipoDocCedente) {
		this.tipoDocCedente = tipoDocCedente;
	}
	public String getDocumentoCedente() {
		return documentoCedente;
	}
	public void setDocumentoCedente(String documentoCedente) {
		this.documentoCedente = documentoCedente;
	}
	public String getFormaPagamento() {
		return formaPagamento;
	}
	public void setFormaPagamento(String formaPagamento) {
		this.formaPagamento = formaPagamento;
	}
	public ListaCartoesItemDTO getCartao() {
		return cartao;
	}
	public void setCartao(ListaCartoesItemDTO cartao) {
		this.cartao = cartao;
	}
	public String getNomeBeneficiario() {
		return nomeBeneficiario;
	}
	public void setNomeBeneficiario(String nomeBeneficiario) {
		this.nomeBeneficiario = nomeBeneficiario;
	}
	public String getCodBeneficiario() {
		return codBeneficiario;
	}
	public void setCodBeneficiario(String codBeneficiario) {
		this.codBeneficiario = codBeneficiario;
	}
	public String getTipoPessoaFavorecido() {
		return tipoPessoaFavorecido;
	}
	public void setTipoPessoaFavorecido(String tipoPessoaFavorecido) {
		this.tipoPessoaFavorecido = tipoPessoaFavorecido;
	}
	public String getDocFavorecido() {
		return docFavorecido;
	}
	public void setDocFavorecido(String docFavorecido) {
		this.docFavorecido = docFavorecido;
	}
	public String getTipoPessoaCliente() {
		return tipoPessoaCliente;
	}
	public void setTipoPessoaCliente(String tipoPessoaCliente) {
		this.tipoPessoaCliente = tipoPessoaCliente;
	}
	public String getDocCliente() {
		return docCliente;
	}
	public void setDocCliente(String docCliente) {
		this.docCliente = docCliente;
	}
}
