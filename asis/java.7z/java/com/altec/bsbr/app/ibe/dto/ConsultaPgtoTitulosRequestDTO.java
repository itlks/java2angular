package com.altec.bsbr.app.ibe.dto;

public interface ConsultaPgtoTitulosRequestDTO {

}
