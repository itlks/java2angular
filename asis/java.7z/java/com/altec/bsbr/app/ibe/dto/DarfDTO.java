package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.altec.bsbr.app.ibe.anotation.Hash;
import com.altec.bsbr.app.ibe.dto.apelido.ApelidoDTO;

public class DarfDTO implements Serializable {

	private static final long serialVersionUID = 2205114183267437183L;

	// Token OTP
	private String tokenFisico;

	private String mobileToken;

	private String qrToken;

	private String assinaturaEletronica;

	// dados pagamento

	private String numeroControle;
	private String autenticacaoBancaria;
	private String autenticacaoDigital;
	private String autenticacao;
	private String dataHoraTransacao;
	private String dataQuitacao;

	private String nomeEmpresaTelefone;
	private String periodoApuracao;	

	@Hash(position=1)
	private String cpfCnpj;
	private String codigoReceita;
	private String numeroReferencia;
	private String receitaBruta;
	private String percentual;
	@Hash(position=2)
	private String valorPrincipal;
	@Hash(position=3)
	private String valorMulta;
	@Hash(position=4)
	private String valorJurosEncargos;
	@Hash(position=5)
	private String valorTotal;
	private boolean darfCadastrado;
	private String contaCorrente;
	private String dataVencimento;
	private String codNSU;

	// apelido
	private String apelido;
	private boolean gravaApelido;
	private List<ApelidoDTO> listaApelidos = new ArrayList<ApelidoDTO>();
	
	// pendencia
	private boolean pendente;
	
	
	/**
	 * @return the tokenFisico
	 */
	public String getTokenFisico() {
		return tokenFisico;
	}

	/**
	 * @param tokenFisico
	 *            the tokenFisico to set
	 */
	public void setTokenFisico(String tokenFisico) {
		this.tokenFisico = tokenFisico;
	}

	/**
	 * @return the mobileToken
	 */
	public String getMobileToken() {
		return mobileToken;
	}

	/**
	 * @param mobileToken
	 *            the mobileToken to set
	 */
	public void setMobileToken(String mobileToken) {
		this.mobileToken = mobileToken;
	}

	/**
	 * @return the qrToken
	 */
	public String getQrToken() {
		return qrToken;
	}

	/**
	 * @param qrToken
	 *            the qrToken to set
	 */
	public void setQrToken(String qrToken) {
		this.qrToken = qrToken;
	}

	/**
	 * @return the assinaturaEletronica
	 */
	public String getAssinaturaEletronica() {
		return assinaturaEletronica;
	}

	/**
	 * @param assinaturaEletronica
	 *            the assinaturaEletronica to set
	 */
	public void setAssinaturaEletronica(String assinaturaEletronica) {
		this.assinaturaEletronica = assinaturaEletronica;
	}

	/**
	 * @return the numeroControle
	 */
	public String getNumeroControle() {
		return numeroControle;
	}

	/**
	 * @param numeroControle
	 *            the numeroControle to set
	 */
	public void setNumeroControle(String numeroControle) {
		this.numeroControle = numeroControle;
	}

	/**
	 * @return the autenticacaoBancaria
	 */
	public String getAutenticacaoBancaria() {
		return autenticacaoBancaria;
	}

	/**
	 * @param autenticacaoBancaria
	 *            the autenticacaoBancaria to set
	 */
	public void setAutenticacaoBancaria(String autenticacaoBancaria) {
		this.autenticacaoBancaria = autenticacaoBancaria;
	}

	/**
	 * @return the autenticacaoDigital
	 */
	public String getAutenticacaoDigital() {
		return autenticacaoDigital;
	}

	/**
	 * @param autenticacaoDigital
	 *            the autenticacaoDigital to set
	 */
	public void setAutenticacaoDigital(String autenticacaoDigital) {
		this.autenticacaoDigital = autenticacaoDigital;
	}

	/**
	 * @return the autenticacao
	 */
	public String getAutenticacao() {
		return autenticacao;
	}

	/**
	 * @param autenticacao
	 *            the autenticacao to set
	 */
	public void setAutenticacao(String autenticacao) {
		this.autenticacao = autenticacao;
	}

	/**
	 * @return the dataHoraTransacao
	 */
	public String getDataHoraTransacao() {
		return dataHoraTransacao;
	}

	/**
	 * @param dataHoraTransacao
	 *            the dataHoraTransacao to set
	 */
	public void setDataHoraTransacao(String dataHoraTransacao) {
		this.dataHoraTransacao = dataHoraTransacao;
	}

	/**
	 * @return the nomeTelefone
	 */
	public String getNomeEmpresaTelefone() {
		return nomeEmpresaTelefone;
	}

	/**
	 * @param nomeTelefone
	 *            the nomeTelefone to set
	 */
	public void setNomeEmpresaTelefone(String nomeEmpresaTelefone) {
		this.nomeEmpresaTelefone = nomeEmpresaTelefone;
	}

	/**
	 * @return the periodoApuracao
	 */
	public String getPeriodoApuracao() {
		return periodoApuracao;
	}

	/**
	 * @param periodoApuracao
	 *            the periodoApuracao to set
	 */
	public void setPeriodoApuracao(String periodoApuracao) {
		this.periodoApuracao = periodoApuracao;
	}

	/**
	 * @return the cpfCnpj
	 */
	public String getCpfCnpj() {
		return cpfCnpj;
	}

	/**
	 * @param cpfCnpj
	 *            the cpfCnpj to set
	 */
	public void setCpfCnpj(String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}

	/**
	 * @return the codigoReceita
	 */
	public String getCodigoReceita() {
		return codigoReceita;
	}

	/**
	 * @param codigoReceita
	 *            the codigoReceita to set
	 */
	public void setCodigoReceita(String codigoReceita) {
		this.codigoReceita = codigoReceita;
	}

	/**
	 * @return the receitaBruta
	 */
	public String getReceitaBruta() {
		return receitaBruta;
	}

	/**
	 * @param receitaBruta
	 *            the receitaBruta to set
	 */
	public void setReceitaBruta(String receitaBruta) {
		this.receitaBruta = receitaBruta;
	}

	/**
	 * @return the percentual
	 */
	public String getPercentual() {
		return percentual;
	}

	/**
	 * @param percentual
	 *            the percentual to set
	 */
	public void setPercentual(String percentual) {
		this.percentual = percentual;
	}

	/**
	 * @return the valorPrincipal
	 */
	public String getValorPrincipal() {
		return valorPrincipal;
	}

	/**
	 * @param valorPrincipal
	 *            the valorPrincipal to set
	 */
	public void setValorPrincipal(String valorPrincipal) {
		this.valorPrincipal = valorPrincipal;
	}

	/**
	 * @return the valorMulta
	 */
	public String getValorMulta() {
		return valorMulta;
	}

	/**
	 * @param valorMulta
	 *            the valorMulta to set
	 */
	public void setValorMulta(String valorMulta) {
		this.valorMulta = valorMulta;
	}

	/**
	 * @return the valorJuros
	 */
	public String getValorJurosEncargos() {
		return valorJurosEncargos;
	}

	/**
	 * @param valorJurosEncargos
	 *            the valorJurosEncargos to set
	 */
	public void setValorJurosEncargos(String valorJurosEncargos) {
		this.valorJurosEncargos = valorJurosEncargos;
	}

	/**
	 * @return the valorTotal
	 */
	public String getValorTotal() {
		return valorTotal;
	}

	/**
	 * @param valorTotal
	 *            the valorTotal to set
	 */
	public void setValorTotal(String valorTotal) {
		this.valorTotal = valorTotal;
	}

	/**
	 * @return the darfCadastrado
	 */
	public boolean isDarfCadastrado() {
		return darfCadastrado;
	}

	/**
	 * @param darfCadastrado
	 *            the darfCadastrado to set
	 */
	public void setDarfCadastrado(boolean darfCadastrado) {
		this.darfCadastrado = darfCadastrado;
	}

	/**
	 * @return the contaCorrente
	 */
	public String getContaCorrente() {
		return contaCorrente;
	}

	/**
	 * @param contaCorrente
	 *            the contaCorrente to set
	 */
	public void setContaCorrente(String contaCorrente) {
		this.contaCorrente = contaCorrente;
	}

	/**
	 * @return the apelido
	 */
	public String getApelido() {
		return apelido;
	}

	/**
	 * @param apelido
	 *            the apelido to set
	 */
	public void setApelido(String apelido) {
		this.apelido = apelido;
	}

	/**
	 * @return the gravaApelido
	 */
	public boolean isGravaApelido() {
		return gravaApelido;
	}

	/**
	 * @param gravaApelido
	 *            the gravaApelido to set
	 */
	public void setGravaApelido(boolean gravaApelido) {
		this.gravaApelido = gravaApelido;
	}

	/**
	 * @return the listaApelidos
	 */
	public List<ApelidoDTO> getListaApelidos() {
		return listaApelidos;
	}

	/**
	 * @param listaApelidos
	 *            the listaApelidos to set
	 */
	public void setListaApelidos(List<ApelidoDTO> listaApelidos) {
		this.listaApelidos = listaApelidos;
	}

	/**
	 * @return the dataVencimento
	 */
	public String getDataVencimento() {
		return dataVencimento;
	}

	/**
	 * @param dataVencimento
	 *            the dataVencimento to set
	 */
	public void setDataVencimento(String dataVencimento) {
		this.dataVencimento = dataVencimento;
	}

	public String getNumeroReferencia() {
		return numeroReferencia;
	}

	public void setNumeroReferencia(String numeroReferencia) {
		this.numeroReferencia = numeroReferencia;
	}

	public boolean isPendente() {
		return pendente;
	}

	public void setPendente(boolean pendente) {
		this.pendente = pendente;
	}

	public String getDataQuitacao() {
		return dataQuitacao;
	}

	public void setDataQuitacao(String dataQuitacao) {
		this.dataQuitacao = dataQuitacao;
	}

	/**
	 * @return the codNSU
	 */
	public String getCodNSU() {
		return codNSU;
	}

	/**
	 * @param codNSU the codNSU to set
	 */
	public void setCodNSU(String codNSU) {
		this.codNSU = codNSU;
	}

}
