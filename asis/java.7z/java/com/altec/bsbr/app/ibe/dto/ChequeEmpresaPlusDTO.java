package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;
public class ChequeEmpresaPlusDTO implements Serializable {

	private static final long serialVersionUID = -8631923950222921559L;


	private Date dataInicialDate;
	private Date dataFinalDate;
	private String dataInicial;
	private String dataFinal;
	private Map<String, String> listaPeriodos = new LinkedHashMap<String, String>();
	private String dataProcessamento;
	
	// tabela encargos
	private String encargosPeriodo;
    private String titulo;
    private CampoTabelaDTO campoTabelaDTO;
	
	public String getDataInicial() {
		return dataInicial;
	}
	public void setDataInicial(String dataInicial) {
		this.dataInicial = dataInicial;
	}
	public String getDataFinal() {
		return dataFinal;
	}
	public void setDataFinal(String dataFinal) {
		this.dataFinal = dataFinal;
	}
	public Map<String, String> getListaPeriodos() {
		return listaPeriodos;
	}
	public void setListaPeriodos(Map<String, String> listaPeriodos) {
		this.listaPeriodos = listaPeriodos;
	}
	public String getDataProcessamento() {
		return dataProcessamento;
	}
	public void setDataProcessamento(String dataProcessamento) {
		this.dataProcessamento = dataProcessamento;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public CampoTabelaDTO getCampoTabelaDTO() {
		return campoTabelaDTO;
	}
	public void setCampoTabelaDTO(CampoTabelaDTO campoTabelaDTO) {
		this.campoTabelaDTO = campoTabelaDTO;
	}
	public String getEncargosPeriodo() {
		return encargosPeriodo;
	}
	public void setEncargosPeriodo(String encargosPeriodo) {
		this.encargosPeriodo = encargosPeriodo;
	}
	public Date getDataInicialDate() {
		return dataInicialDate;
	}
	public void setDataInicialDate(Date dataInicialDate) {
		this.dataInicialDate = dataInicialDate;
	}
	public Date getDataFinalDate() {
		return dataFinalDate;
	}
	public void setDataFinalDate(Date dataFinalDate) {
		this.dataFinalDate = dataFinalDate;
	}
}
