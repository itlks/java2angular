package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class ContratoConsultarContasDebitoRequestWebDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private int nu_contrato; 


	public int getNu_contrato(){
		return this.nu_contrato;
	} 

	public void setNu_contrato(int nu_contrato){
		this.nu_contrato = nu_contrato;
	} 
}
