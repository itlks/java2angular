package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class AgendamentoDetalheDTO implements Serializable {

	
	
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2429312539726627364L;
	private String numeroProtocolo;
	private String transacao;
	private String dataSolicitacao;
	private String horaSolicitacao;
	private String dataAgendada;
	private String horaAgendada;
	private String dataHoraCancelamento;
	private String origem;
	private String situacao;
	private BigDecimal valor;
	private String contaDebito;
	private String contaFundoDebito;
	private String vinculo;
	
	
	private Date dataHoraSolicitacao;
	private Date dataAgendadaFormatada;
	
	
	private String codigoErro;
	private String msgErro;
	
	
	/**
	 * @return the transacao
	 */
	public String getTransacao() {
		return transacao;
	}
	/**
	 * @param transacao the transacao to set
	 */
	public void setTransacao(String transacao) {
		this.transacao = transacao;
	}
	/**
	 * @return the dataSolicitacao
	 */
	public String getDataSolicitacao() {
		return dataSolicitacao;
	}
	/**
	 * @param dataSolicitacao the dataSolicitacao to set
	 */
	public void setDataSolicitacao(String dataSolicitacao) {
		this.dataSolicitacao = dataSolicitacao;
	}
	/**
	 * @return the horaSolicitacao
	 */
	public String getHoraSolicitacao() {
		return horaSolicitacao;
	}
	/**
	 * @param horaSolicitacao the horaSolicitacao to set
	 */
	public void setHoraSolicitacao(String horaSolicitacao) {
		this.horaSolicitacao = horaSolicitacao;
	}
	/**
	 * @return the dataAgendada
	 */
	public String getDataAgendada() {
		return dataAgendada;
	}
	/**
	 * @param dataAgendada the dataAgendada to set
	 */
	public void setDataAgendada(String dataAgendada) {
		this.dataAgendada = dataAgendada;
	}
	/**
	 * @return the horaAgendada
	 */
	public String getHoraAgendada() {
		return horaAgendada;
	}
	/**
	 * @param horaAgendada the horaAgendada to set
	 */
	public void setHoraAgendada(String horaAgendada) {
		this.horaAgendada = horaAgendada;
	}
	/**
	 * @return the dataHoraCancelamento
	 */
	public String getDataHoraCancelamento() {
		return dataHoraCancelamento;
	}
	/**
	 * @param dataHoraCancelamento the dataHoraCancelamento to set
	 */
	public void setDataHoraCancelamento(String dataHoraCancelamento) {
		this.dataHoraCancelamento = dataHoraCancelamento;
	}
	/**
	 * @return the numeroProtocolo
	 */
	public String getNumeroProtocolo() {
		return numeroProtocolo;
	}
	/**
	 * @param numeroProtocolo the numeroProtocolo to set
	 */
	public void setNumeroProtocolo(String numeroProtocolo) {
		this.numeroProtocolo = numeroProtocolo;
	}
	/**
	 * @return the origem
	 */
	public String getOrigem() {
		return origem;
	}
	/**
	 * @param origem the origem to set
	 */
	public void setOrigem(String origem) {
		this.origem = origem;
	}
	/**
	 * @return the situacao
	 */
	public String getSituacao() {
		return situacao;
	}
	/**
	 * @param situacao the situacao to set
	 */
	public void setSituacao(String situacao) {
		this.situacao = situacao;
	}
	/**
	 * @return the valor
	 */
	public BigDecimal getValor() {
		return valor;
	}
	/**
	 * @param valor the valor to set
	 */
	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}
	/**
	 * @return the contaDebito
	 */
	public String getContaDebito() {
		return contaDebito;
	}
	/**
	 * @param contaDebito the contaDebito to set
	 */
	public void setContaDebito(String contaDebito) {
		this.contaDebito = contaDebito;
	}
	/**
	 * @return the contaFundoDebito
	 */
	public String getContaFundoDebito() {
		return contaFundoDebito;
	}
	/**
	 * @param contaFundoDebito the contaFundoDebito to set
	 */
	public void setContaFundoDebito(String contaFundoDebito) {
		this.contaFundoDebito = contaFundoDebito;
	}
	/**
	 * @return the vinculo
	 */
	public String getVinculo() {
		return vinculo;
	}
	/**
	 * @param vinculo the vinculo to set
	 */
	public void setVinculo(String vinculo) {
		this.vinculo = vinculo;
	}
	/**
	 * @return the dataHoraSolicitacao
	 */
	public Date getDataHoraSolicitacao() {
		return dataHoraSolicitacao;
	}
	/**
	 * @param dataHoraSolicitacao the dataHoraSolicitacao to set
	 */
	public void setDataHoraSolicitacao(Date dataHoraSolicitacao) {
		this.dataHoraSolicitacao = dataHoraSolicitacao;
	}
	/**
	 * @return the dataAgendadaFormatada
	 */
	public Date getDataAgendadaFormatada() {
		return dataAgendadaFormatada;
	}
	/**
	 * @param dataAgendadaFormatada the dataAgendadaFormatada to set
	 */
	public void setDataAgendadaFormatada(Date dataAgendadaFormatada) {
		this.dataAgendadaFormatada = dataAgendadaFormatada;
	}
	/**
	 * @return the codigoErro
	 */
	public String getCodigoErro() {
		return codigoErro;
	}
	/**
	 * @param codigoErro the codigoErro to set
	 */
	public void setCodigoErro(String codigoErro) {
		this.codigoErro = codigoErro;
	}
	/**
	 * @return the msgErro
	 */
	public String getMsgErro() {
		return msgErro;
	}
	/**
	 * @param msgErro the msgErro to set
	 */
	public void setMsgErro(String msgErro) {
		this.msgErro = msgErro;
	}

	
	

	
	
	
}