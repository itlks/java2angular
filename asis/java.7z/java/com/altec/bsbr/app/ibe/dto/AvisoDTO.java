package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class AvisoDTO implements Serializable {

	private static final long serialVersionUID = -8387873332360213799L;

	private String textoDiv1;
	private String textoDiv2;	
	private String linkURL;
	private String tpLink;
	private String tpCampanha = "";
	private String raAttribSeg = "";
 	private String boId = "";
 	private String blank;  
 	private boolean desabilitarAceite = false;
 	private boolean desabilitarRejeite = false;
	private boolean habilitarAviso = false;
	private String classeSaldoCompleto = "";
	private Integer prioridade;
	private Boolean visualizouMidiaCRM = Boolean.FALSE;
	
	private String linkUrlClassico;
	
	public String getTextoDiv1() {
		return textoDiv1;
	}
	public void setTextoDiv1(String textoDiv1) {
		this.textoDiv1 = textoDiv1;
	}
	public String getTextoDiv2() {
		return textoDiv2;
	}
	public void setTextoDiv2(String textoDiv2) {
		this.textoDiv2 = textoDiv2;
	}
	public String getLinkURL() {
		return linkURL;
	}
	public void setLinkURL(String linkURL) {
		this.linkURL = linkURL;
	}
	public boolean getHabilitarAviso() {
		return habilitarAviso;
	}
	public void setHabilitarAviso(boolean habilitarAviso) {
		this.habilitarAviso = habilitarAviso;
	}
	public String getTpCampanha() {
		return tpCampanha;
	}
	public void setTpCampanha(String tpCampanha) {
		this.tpCampanha = tpCampanha;
	}
	public String getRaAttribSeg() {
		return raAttribSeg;
	}
	public void setRaAttribSeg(String raAttribSeg) {
		this.raAttribSeg = raAttribSeg;
	}
	public String getBoId() {
		return boId;
	}
	public void setBoId(String boId) {
		this.boId = boId;
	}
	public String getTpLink() {
		return tpLink;
	}
	public void setTpLink(String tpLink) {
		this.tpLink = tpLink;
	}
	public String getBlank() {
		return blank;
	}
	public void setBlank(String blank) {
		this.blank = blank;
	}
	public boolean getDesabilitarAceite() {
		return desabilitarAceite;
	}
	public void setDesabilitarAceite(boolean desabilitarAceite) {
		this.desabilitarAceite = desabilitarAceite;
	}
	public boolean getDesabilitarRejeite() {
		return desabilitarRejeite;
	}
	public void setDesabilitarRejeite(boolean desabilitarRejeite) {
		this.desabilitarRejeite = desabilitarRejeite;
	}
	public String getClasseSaldoCompleto() {
		return classeSaldoCompleto;
	}
	public void setClasseSaldoCompleto(String classeSaldoCompleto) {
		this.classeSaldoCompleto = classeSaldoCompleto;
	}
	public Integer getPrioridade() {
		return prioridade;
	}
	public void setPrioridade(Integer prioridade) {
		this.prioridade = prioridade;
	}
	public Boolean getVisualizouMidiaCRM() {
		return visualizouMidiaCRM;
	}
	public void setVisualizouMidiaCRM(Boolean visualizouMidiaCRM) {
		this.visualizouMidiaCRM = visualizouMidiaCRM;
	}
	public String getLinkUrlClassico() {
		return linkUrlClassico;
	}
	public void setLinkUrlClassico(String linkUrlClassico) {
		this.linkUrlClassico = linkUrlClassico;
	}

}
