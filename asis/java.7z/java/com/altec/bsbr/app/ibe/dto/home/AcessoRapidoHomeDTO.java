package com.altec.bsbr.app.ibe.dto.home;

import java.io.Serializable;

public class AcessoRapidoHomeDTO implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 2588585375971712110L;
	private String descricaoMenuAvo;
	private String descricaoMenuNeto;
	private String idMenuNeto;
	private String icone;
	private boolean bloquearAcesso;
	private boolean naoCadastrado;

	public String getDescricaoMenuAvo() {
		return descricaoMenuAvo;
	}
	public void setDescricaoMenuAvo(String descricaoMenuAvo) {
		this.descricaoMenuAvo = descricaoMenuAvo;
	}
	public String getDescricaoMenuNeto() {
		return descricaoMenuNeto;
	}
	public void setDescricaoMenuNeto(String descricaoMenuNeto) {
		this.descricaoMenuNeto = descricaoMenuNeto;
	}
	public String getIdMenuNeto() {
		return idMenuNeto;
	}
	public void setIdMenuNeto(String idMenuNeto) {
		this.idMenuNeto = idMenuNeto;
	}
	public boolean isBloquearAcesso() {
		return bloquearAcesso;
	}
	public void setBloquearAcesso(boolean bloquearAcesso) {
		this.bloquearAcesso = bloquearAcesso;
	}
	public boolean isNaoCadastrado() {
		return naoCadastrado;
	}
	public void setNaoCadastrado(boolean naoCadastrado) {
		this.naoCadastrado = naoCadastrado;
	}
	public String getIcone() {
		return icone;
	}
	public void setIcone(String icone) {
		this.icone = icone;
	}
}
