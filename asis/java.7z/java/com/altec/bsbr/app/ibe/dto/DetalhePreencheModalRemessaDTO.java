package com.altec.bsbr.app.ibe.dto;

public class DetalhePreencheModalRemessaDTO {
	
	private int lngCodUsuario;
	private String nomeFavorecidoPendencia;
	private String codUsuarioUltimaAtu;
	private String descricaoOperacao;	
	private String intProduto;
	private String descricaoProduto;
	private String imgTransacao;
	private String data; 
	private String codigoTransacao;
	private String codigoTransacaoDetalhe;
	private String timeStamp;
	private String contratoUsuarioLogado;
	private String valorUsuarioPendencia;
	private String strConvCuentaDeb;
	private String strMoeda;
	private String strCritPesq;
	private String strConvEntidad;
	private String strConvEntidade;
	private String strConvCentroAlta;
	private String strConvCuenta;
	private String strValorRemessa;
	private String strNumCompromisso;
	private String strEntidadDeb;
	private String strCentroAltaDeb;
	private String strCuentaDeb;
	private String strCODTIPOIDENT;
	private String strCodFornCons;
	private String strFORMPAG;
	private String strNUMLOTE;
	private String strFECPAGTOINI;
	private String strFECPAGTOFIM;
	private String strCritCompr;
	private String strOrdem;
	private String lngIDConexao;
	private String strBanco;
	private String strAgencia;
	private String strConta;
	private String strIPAddrCliente;
	private String strIPAddrServer;
	private String intIdCanal;
	
	
	public String getStrMoeda() {
		return strMoeda;
	}


	public void setStrMoeda(String strMoeda) {
		this.strMoeda = strMoeda;
	}


	public String getStrCritPesq() {
		return strCritPesq;
	}


	public void setStrCritPesq(String strCritPesq) {
		this.strCritPesq = strCritPesq;
	}


	public String getStrConvEntidad() {
		return strConvEntidad;
	}


	public void setStrConvEntidad(String strConvEntidad) {
		this.strConvEntidad = strConvEntidad;
	}


	public String getStrConvEntidade() {
		return strConvEntidade;
	}


	public void setStrConvEntidade(String strConvEntidade) {
		this.strConvEntidade = strConvEntidade;
	}


	public String getStrConvCentroAlta() {
		return strConvCentroAlta;
	}


	public void setStrConvCentroAlta(String strConvCentroAlta) {
		this.strConvCentroAlta = strConvCentroAlta;
	}


	public String getStrConvCuenta() {
		return strConvCuenta;
	}


	public void setStrConvCuenta(String strConvCuenta) {
		this.strConvCuenta = strConvCuenta;
	}


	public String getStrValorRemessa() {
		return strValorRemessa;
	}


	public void setStrValorRemessa(String strValorRemessa) {
		this.strValorRemessa = strValorRemessa;
	}


	public String getStrNumCompromisso() {
		return strNumCompromisso;
	}


	public void setStrNumCompromisso(String strNumCompromisso) {
		this.strNumCompromisso = strNumCompromisso;
	}


	public String getStrEntidadDeb() {
		return strEntidadDeb;
	}


	public void setStrEntidadDeb(String strEntidadDeb) {
		this.strEntidadDeb = strEntidadDeb;
	}


	public String getStrCentroAltaDeb() {
		return strCentroAltaDeb;
	}


	public void setStrCentroAltaDeb(String strCentroAltaDeb) {
		this.strCentroAltaDeb = strCentroAltaDeb;
	}


	public String getStrCuentaDeb() {
		return strCuentaDeb;
	}


	public void setStrCuentaDeb(String strCuentaDeb) {
		this.strCuentaDeb = strCuentaDeb;
	}


	public String getStrCODTIPOIDENT() {
		return strCODTIPOIDENT;
	}


	public void setStrCODTIPOIDENT(String strCODTIPOIDENT) {
		this.strCODTIPOIDENT = strCODTIPOIDENT;
	}


	public String getStrCodFornCons() {
		return strCodFornCons;
	}


	public void setStrCodFornCons(String strCodFornCons) {
		this.strCodFornCons = strCodFornCons;
	}


	public String getStrFORMPAG() {
		return strFORMPAG;
	}


	public void setStrFORMPAG(String strFORMPAG) {
		this.strFORMPAG = strFORMPAG;
	}


	public String getStrNUMLOTE() {
		return strNUMLOTE;
	}


	public void setStrNUMLOTE(String strNUMLOTE) {
		this.strNUMLOTE = strNUMLOTE;
	}


	public String getStrFECPAGTOINI() {
		return strFECPAGTOINI;
	}


	public void setStrFECPAGTOINI(String strFECPAGTOINI) {
		this.strFECPAGTOINI = strFECPAGTOINI;
	}


	public String getStrFECPAGTOFIM() {
		return strFECPAGTOFIM;
	}


	public void setStrFECPAGTOFIM(String strFECPAGTOFIM) {
		this.strFECPAGTOFIM = strFECPAGTOFIM;
	}


	public String getStrCritCompr() {
		return strCritCompr;
	}


	public void setStrCritCompr(String strCritCompr) {
		this.strCritCompr = strCritCompr;
	}


	public String getStrOrdem() {
		return strOrdem;
	}


	public void setStrOrdem(String strOrdem) {
		this.strOrdem = strOrdem;
	}


	public String getLngIDConexao() {
		return lngIDConexao;
	}


	public void setLngIDConexao(String lngIDConexao) {
		this.lngIDConexao = lngIDConexao;
	}


	public String getStrBanco() {
		return strBanco;
	}


	public void setStrBanco(String strBanco) {
		this.strBanco = strBanco;
	}


	public String getStrAgencia() {
		return strAgencia;
	}


	public void setStrAgencia(String strAgencia) {
		this.strAgencia = strAgencia;
	}


	public String getStrConta() {
		return strConta;
	}


	public void setStrConta(String strConta) {
		this.strConta = strConta;
	}


	public String getStrIPAddrCliente() {
		return strIPAddrCliente;
	}


	public void setStrIPAddrCliente(String strIPAddrCliente) {
		this.strIPAddrCliente = strIPAddrCliente;
	}


	public String getStrIPAddrServer() {
		return strIPAddrServer;
	}


	public void setStrIPAddrServer(String strIPAddrServer) {
		this.strIPAddrServer = strIPAddrServer;
	}


	/**
	 * @return the nomeFavorecidoPendencia
	 */
	public String getNomeFavorecidoPendencia() {
		return nomeFavorecidoPendencia;
	}


	/**
	 * @param nomeFavorecidoPendencia the nomeFavorecidoPendencia to set
	 */
	public void setNomeFavorecidoPendencia(String nomeFavorecidoPendencia) {
		this.nomeFavorecidoPendencia = nomeFavorecidoPendencia;
	}


	/**
	 * @return the codUsuarioUltimaAtu
	 */
	public String getCodUsuarioUltimaAtu() {
		return codUsuarioUltimaAtu;
	}


	/**
	 * @param codUsuarioUltimaAtu the codUsuarioUltimaAtu to set
	 */
	public void setCodUsuarioUltimaAtu(String codUsuarioUltimaAtu) {
		this.codUsuarioUltimaAtu = codUsuarioUltimaAtu;
	}


	/**
	 * @return the descricaoOperacao
	 */
	public String getDescricaoOperacao() {
		return descricaoOperacao;
	}


	/**
	 * @param descricaoOperacao the descricaoOperacao to set
	 */
	public void setDescricaoOperacao(String descricaoOperacao) {
		this.descricaoOperacao = descricaoOperacao;
	}


	/**
	 * @return the codigoProduto
	 */
	public String getIntProduto() {
		return intProduto;
	}


	/**
	 * @param codigoProduto the codigoProduto to set
	 */
	public void setIntProduto(String codigoProduto) {
		this.intProduto = codigoProduto;
	}


	/**
	 * @return the descricaoProduto
	 */
	public String getDescricaoProduto() {
		return descricaoProduto;
	}


	/**
	 * @param descricaoProduto the descricaoProduto to set
	 */
	public void setDescricaoProduto(String descricaoProduto) {
		this.descricaoProduto = descricaoProduto;
	}


	/**
	 * @return the imgTransacao
	 */
	public String getImgTransacao() {
		return imgTransacao;
	}


	/**
	 * @param imgTransacao the imgTransacao to set
	 */
	public void setImgTransacao(String imgTransacao) {
		this.imgTransacao = imgTransacao;
	}


	/**
	 * @return the data
	 */
	public String getData() {
		return data;
	}


	/**
	 * @param data the data to set
	 */
	public void setData(String data) {
		this.data = data;
	}


	/**
	 * @return the codigoTransacao
	 */
	public String getCodigoTransacao() {
		return codigoTransacao;
	}


	/**
	 * @param codigoTransacao the codigoTransacao to set
	 */
	public void setCodigoTransacao(String codigoTransacao) {
		this.codigoTransacao = codigoTransacao;
	}


	/**
	 * @return the codigoTransacaoDetalhe
	 */
	public String getCodigoTransacaoDetalhe() {
		return codigoTransacaoDetalhe;
	}


	/**
	 * @param codigoTransacaoDetalhe the codigoTransacaoDetalhe to set
	 */
	public void setCodigoTransacaoDetalhe(String codigoTransacaoDetalhe) {
		this.codigoTransacaoDetalhe = codigoTransacaoDetalhe;
	}


	/**
	 * @return the timeStamp
	 */
	public String getTimeStamp() {
		return timeStamp;
	}


	/**
	 * @param timeStamp the timeStamp to set
	 */
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}


	/**
	 * @return the contratoUsuarioLogado
	 */
	public String getContratoUsuarioLogado() {
		return contratoUsuarioLogado;
	}


	/**
	 * @param contratoUsuarioLogado the contratoUsuarioLogado to set
	 */
	public void setContratoUsuarioLogado(String contratoUsuarioLogado) {
		this.contratoUsuarioLogado = contratoUsuarioLogado;
	}


	/**
	 * @return the valorUsuarioPendencia
	 */
	public String getValorUsuarioPendencia() {
		return valorUsuarioPendencia;
	}


	/**
	 * @param valorUsuarioPendencia the valorUsuarioPendencia to set
	 */
	public void setValorUsuarioPendencia(String valorUsuarioPendencia) {
		this.valorUsuarioPendencia = valorUsuarioPendencia;
	}


	/**
	 * @return the idUsuarioLogin
	 */
	public int getLngCodUsuario() {
		return lngCodUsuario;
	}


	/**
	 * @param idUsuarioLogin the idUsuarioLogin to set
	 */
	public void setLngCodUsuario(int lngCodUsuario) {
		this.lngCodUsuario = lngCodUsuario;
	}


	public String getIntIdCanal() {
		return intIdCanal;
	}


	public void setIntIdCanal(String intIdCanal) {
		this.intIdCanal = intIdCanal;
	}


	public String getStrConvCuentaDeb() {
		return strConvCuentaDeb;
	}


	public void setStrConvCuentaDeb(String strConvCuentaDeb) {
		this.strConvCuentaDeb = strConvCuentaDeb;
	}


}