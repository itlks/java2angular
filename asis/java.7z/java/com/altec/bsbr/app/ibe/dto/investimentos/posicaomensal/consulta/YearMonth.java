package com.altec.bsbr.app.ibe.dto.investimentos.posicaomensal.consulta;

import java.io.Serializable;

public class YearMonth implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String yearMonthReference;

	public YearMonth() {
	}

	public String getYearMonthReference() {
		return yearMonthReference;
	}

	public void setYearMonthReference(String yearMonthReference) {
		this.yearMonthReference = yearMonthReference;
	}

}
