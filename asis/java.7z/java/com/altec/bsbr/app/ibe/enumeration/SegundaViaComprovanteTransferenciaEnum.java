package com.altec.bsbr.app.ibe.enumeration;

public enum SegundaViaComprovanteTransferenciaEnum {
	
	JURIDICA("J"),
	FISICA("F"),
	TIPO_OPERACAO("A"),
	TIPO_SERVICO("A"),
	TIPO_CONTA("1"),
	TIPO_PESQUISA("1"),
	TIPO_DOC("0"),
	CANAL("02"),
	CANAL_DETALHE("06");
	
	private String valor;
	
	private SegundaViaComprovanteTransferenciaEnum(String valor) {
		this.valor = valor;
	}
	
	
	/**
	 * getValor
	 * @return
	 */
	public String getValor() {
		return valor;
	}
	

}