package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;

public class DebitoAutomaticoBloquearDTO implements Serializable {
	
	private static final long serialVersionUID = -4660867865728229759L;
	private String empresa;
	private String identificacao;
	private String formaPagamento;
	private String vencimento;
	private BigDecimal valor;
	private String dataHoraTransacao;
	private String autenticacaoBancaria;
	
	public DebitoAutomaticoBloquearDTO() {
		super();
	}



	public String getEmpresa() {
		return empresa;
	}
	
	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}
	
	public String getIdentificacao() {
		return identificacao;
	}
	
	public void setIdentificacao(String identificacao) {
		this.identificacao = identificacao;
	}
	
	public String getFormaPagamento() {
		return formaPagamento;
	}
	
	public void setFormaPagamento(String formaPagamento) {
		this.formaPagamento = formaPagamento;
	}
	
	public String getVencimento() {
		return vencimento;
	}
	
	public void setVencimento(String vencimento) {
		this.vencimento = vencimento;
	}
	
	public BigDecimal getValor() {
		return valor;
	}
	
	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}

	public String getDataHoraTransacao() {
		return dataHoraTransacao;
	}

	public void setDataHoraTransacao(String dataHoraTransacao) {
		this.dataHoraTransacao = dataHoraTransacao;
	}

	public String getAutenticacaoBancaria() {
		return autenticacaoBancaria;
	}

	public void setAutenticacaoBancaria(String autenticacaoBancaria) {
		this.autenticacaoBancaria = autenticacaoBancaria;
	}
}
