package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.List;


public class AnaliticoPendenciaResptDTO implements Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8642886217418838725L;

	private String url;
	
	public AnaliticoPendenciaResptDTO() {}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
	
	
}

