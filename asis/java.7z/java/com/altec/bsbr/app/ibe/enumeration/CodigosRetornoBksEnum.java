package com.altec.bsbr.app.ibe.enumeration;

public enum CodigosRetornoBksEnum {

	TYE_0057("TYE_0057","NAO HA COMPROVANTES NESTE PERIODO"
			,"TYE_0057 - N�o h� comprovantes neste per�odo."),
	
	JXE_0454("JXE_0454","NAO EXISTE PACOTE DE SERVICOS CADASTRADO PARA ESTA CONTA"
			,"JXE0454 - N�o existe pacote de servi�os cadastrado para esta conta. Para contratar um pacote de servi�os acesse o menu Conta Corrente / Pacote de Servi�os / Contratar."),
	
	JXE_0459("JXE_0459","NAO EXISTE PACOTE DE SERVICOS DISPONIVEL PARA ESTA CONTA"
			,"JXE0459 - N�o existe pacote de servi�os dispon�vel para contrata��o no Internet Banking. Para maiores informa��es entre em contato com a Central de Atendimento Santander Empresarial ou contate sua ag�ncia."),
	
	PGE_0515("PGE_0515","ERRO: HOUVE VIRADA DA DATA CONTABIL"
			,"PGE0515 - Houve virada da data contabil. Para maiores informa��es entre em contato com a Central de Atendimento Santander Empresarial ou contate sua ag�ncia."),
	
	YAE_0391("YAE_0391","FAVOR REINICIAR O PAGAMENTO."
			,"YAE0391 - Favor reiniciar o pagamento do IPVA. Para maiores informa��es entre em contato com a Central de Atendimento Santander Empresarial ou contate sua ag�ncia."),
	
	YAE_0032("YAE_0032","VALOR TOTAL PAGO DEVE SER IGUAL VALOR TOTAL DOCUMENT"
			,"YAE0032 - Valor total pago deve ser igual ao valor total do documento. Para maiores informa��es entre em contato com a Central de Atendimento Santander Empresarial ou contate sua ag�ncia."), 
	
	PGE_0066("PGE_0066","CAMPO IND.TRANSACAO ON-OF OBRIGATORIO NAO PREENCHIDO."
			,"PGE0066 - Campo indicador transa��o ON-OF obrigat�rio n�o preenchido. Para maiores informa��es entre em contato com a Central de Atendimento Santander Empresarial ou contate sua ag�ncia."), 
	
	YAE_4260("YAE_4260","VALOR TOTAL DO SERVICO INCONSISTENTE REFAZER PESQUISA"
			,"YAE4260 - Valor total do servi�o inconsistente, refazer pesquisa. Para maiores informa��es entre em contato com a Central de Atendimento Santander Empresarial ou contate sua ag�ncia."),
	
	YAE_0001("YAE_0001","IPVA EXERC ZERADO"
			,"YAE0001 - IPVA exerc�cio zerado. Para maiores informa��es entre em contato com a Central de Atendimento Santander Empresarial ou contate sua ag�ncia."),
	
	YAE_0002("YAE_0002","NUMERO DO NSU OU LOG NAO EXISTE."
			,"YAE0002 - Numero do NSU ou Log n�o existe. Para maiores informa��es entre em contato com a Central de Atendimento Santander Empresarial ou contate sua ag�ncia."),
	
	YAE_0029("YAE_0029","DEVE INFORMAR VLR TOTAL."
			,"YAE0029 - Deve informar valor total. Para maiores informa��es entre em contato com a Central de Atendimento Santander Empresarial ou contate sua ag�ncia."),
	
	YAE_0021("YAE_0021","RENAVAM INVALIDO"
			,"YAE0021 - Renavam inv�lido. Para maiores informa��es entre em contato com a Central de Atendimento Santander Empresarial ou contate sua ag�ncia."),
		
	YAE_4204("YAE_4204","NAO CONSTA DEBITO PARA IDENTIFICADOR"
			,"YAE4204 - Transa��o n�o realizada. N�o constam d�bitos para o RENAVAM. Para maiores informa��es entre em contato com a Central de Atendimento Santander Empresarial ou contate sua ag�ncia."),
		
	YAE_4203("YAE_4203","CODIGO IDENTIFICADOR INEXISTENTE"
			,"YAE4203 - C�digo identificador inexistente. Para maiores informa��es entre em contato com a Central de Atendimento Santander Empresarial ou contate sua ag�ncia."),
		
	YAE_4220("YAE_4220","CAMPO DO BIT 62 INVALIDO"
			,"YAE4220 - Campo do Bit 62 inv�lido. Para maiores informa��es entre em contato com a Central de Atendimento Santander Empresarial ou contate sua ag�ncia."),
	
	PGE_2176("PGE_2176","O CLIENTE EXCEDEU A QUANTIDADE LIMITE DA OPERACAO"
			,"PGE2176 - O cliente excedeu a quantidade limite da opera��o. Para maiores informa��es entre em contato com a Central de Atendimento Santander Empresarial ou contate sua ag�ncia."),
		
	BGE_0515("BGE_0515","DISPONIVEL INSUF.              0,00  NUM.AUT."
			,"BGE0515 - Dispon�vel insuficiente. Para maiores informa��es entre em contato com a Central de Atendimento Santander Empresarial ou contate sua ag�ncia."),
		
	BGE_6050("BGE_6050","CONTA COM MOVIMENTACAO CONTROLADA E SALDO INSUFICIENTE"
		   ,"BGE6050 - Saldo insuficiente. Para maiores informa��es entre em contato com a Central de Atendimento Santander Empresarial ou contate sua ag�ncia."),
	
	BGE_0459("BGE_0459","A CONTA TEM CODIGOS DE OPERACAO BLOQUEADOS"
			   ,"BGE0459 - Conta tem c�digos de opera��o bloqueados. Para maiores informa��es entre em contato com a Central de Atendimento Santander Empresarial ou contate sua ag�ncia."),
	
	YAE_4205("YAE_4205","ORGAO TEMPORARIAMENTE FORA DE OPERACAO"
			,"YAE4205 - Org�o temporariamente fora de opera��o. Para maiores informa��es entre em contato com a Central de Atendimento Santander Empresarial ou contate sua ag�ncia."),
	
	LSE_0004("LSE_0004","OCORRENCIA DE TIMEOUT"
			,"LSE0004 - Ocorr�ncia de timeout. Por favor entre em contato com a Central de Atendimento Santander Empresarial ou contate sua ag�ncia."),
	
	YAE_0384("YAE_0384","DATA DE AGENDAMENTO NAO POSSIVEL"
			,"YAE0384 - Data de agendamento n�o dispon�vel. Por favor entre em contato com a Central de Atendimento Santander Empresarial ou contate sua ag�ncia."),
	
	NYE_0353("NYE_0353","IPVA  - DUPLICIDADE"
			,"NYE0353 - Pagamento n�o dispon�vel, IPVA em duplicidade. Por favor entre em contato com a Central de Atendimento Santander Empresarial ou contate sua ag�ncia."),
	
	NYE_0038("NYE_0038","DATA SOLICITADA PARA EFETIVACAO NAO UTIL"
			,"NYE0038 - Data solicitada para efetiva��o n�o �til. Por favor entre em contato com a Central de Atendimento Santander Empresarial ou contate sua ag�ncia."),

	YAE_0038("YAE_0038","DOCUMENTO RECOLHIDO ANTERIORMENTE"
			,"YAE0038 - Documento recolhido anteriormente. Por favor entre em contato com a Central de Atendimento Santander Empresarial ou contate sua ag�ncia."),
	
	BGE_3229("BGE_3229","O MONTANTE N�O PODER� SER ZERO"
			,"BGE3229 - O montante a ser pago n�o podera ser zero. Por favor entre em contato com a Central de Atendimento Santander Empresarial ou contate sua ag�ncia."),
	
	YAE_0385("YAE_0385","NUMERO DE RENAVAM INVALIDO"
			,"YAE0385 - Numero renavam invalido. Por favor entre em contato com a Central de Atendimento Santander Empresarial ou contate sua ag�ncia."),
	
	YAE_0370("YAE_0370","@@@@@@@@@@@@@@@@@@@@ NAO PODE SER MAIOR QUE @@@@@@@@@@@@@@@@@@@@"
			,"YAE0370 - Data de agendamento n�o pode ser maior que data de vencimento. Por favor entre em contato com a Central de Atendimento Santander Empresarial ou contate sua ag�ncia."),
	
	YAE_0143("YAE_0143","RENAVAM/PLACA NAO EXISTE NA BASE RECEBIDA DA SEFAZ"
			,"YAE0143 - Renavam/Placa n�o existe na base recebida da Sefaz. Por favor entre em contato com a Central de Atendimento Santander Empresarial ou contate sua ag�ncia."),
		
	PGE_0093("PGE_0093","CODIGO DO RENAVAM JA CADASTRADO"
			,"PGE0093 - C�digo do Renavam j� cadastrado. Por favor entre em contato com a Central de Atendimento Santander Empresarial ou contate sua ag�ncia."),	
	
	TYE_0091("TYE_0091","NAO EXISTE SACADO ATIVO PARA O DOCUMENTO INFORMADO"
			,"TYE0091 - N�o existe sacado ativo para o documento informado. Por favor entre em contato com a Central de Atendimento Santander Empresarial ou contate sua ag�ncia."),
	
	TYE_0021("TYE_0021","CLIENTE NAO CADASTRADO COMO SACADO ELETRONICO"
			,"TYE0021 - Cliente n�o cadastrado como sacado eletr�nico. Por favor entre em contato com a Central de Atendimento Santander Empresarial ou contate sua ag�ncia."),
	
	YAE_0016("YAE_0016","NAO EXISTEM DADOS PARA A CONSULTA"
			,"YAE_0016 - N�o existem dados para a consulta. Por favor entre em contato com a Central de Atendimento Santander Empresarial ou contate sua ag�ncia."),
	
	YAE_0003("YAE_0003","CODIGO DE SERVICO OBRIGATORIO"
			,"YAE_0003 - C�digo de servi�o obrigat�rio. Por favor entre em contato com a Central de Atendimento Santander Empresarial ou contate sua ag�ncia."),
	
	JXE_0072("JXE_0072","NAO SE PODE INCLUIR UM NOVO PACOTE"
			,"JXE0072 - N�o se pode incluir um novo pacote de servi�os para contrata��o no Internet Banking. Para maiores informa��es entre em contato com a Central de Atendimento Santander Empresarial ou contate sua ag�ncia.");
	
	private String codigoErro;
	private String msgBks;
	private String msgTela;

	private CodigosRetornoBksEnum(String codigoErro, String msgBks, String msgTela) {
		this.codigoErro = codigoErro;
		this.msgBks = msgBks;
		this.msgTela = msgTela;
	}
	
	public static CodigosRetornoBksEnum findByCodigoErro(String codigoErro) {
		if (codigoErro == null || codigoErro.isEmpty()) {
			return null;
		}

		for (CodigosRetornoBksEnum erroBks : CodigosRetornoBksEnum.values()) {
			if (erroBks.getCodigoErro().equalsIgnoreCase(codigoErro)) {
				return erroBks;
			}
		}
		return null;
	}

	public String getCodigoErro() {
		return codigoErro;
	}

	public String getMsgBks() {
		return msgBks;
	}

	public String getMsgTela() {
		return msgTela;
	}

}
