package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.List;

import com.altec.bsbr.app.ibe.dto.transferencias.ErrosDTO;

public class SolicitacaoEConfirmacaoDTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5613161037183090962L;
	
	private ErrosDTO erros;
	private List<ContaDocDTO> contaDoc;
	private List<ContaTedDTO> contaTed;
	private java.lang.String strGerouPendencia;
	private java.lang.String linhasRet;
	private java.lang.String strChave23;
	private java.lang.String strChave23SemCript;
	public ErrosDTO getErros() {
		return erros;
	}
	public void setErros(ErrosDTO erros) {
		this.erros = erros;
	}
	public List<ContaDocDTO> getContaDoc() {
		return contaDoc;
	}
	public void setContaDoc(List<ContaDocDTO> contaDoc) {
		this.contaDoc = contaDoc;
	}
	public List<ContaTedDTO> getContaTed() {
		return contaTed;
	}
	public void setContaTed(List<ContaTedDTO> contaTed) {
		this.contaTed = contaTed;
	}
	public java.lang.String getStrGerouPendencia() {
		return strGerouPendencia;
	}
	public void setStrGerouPendencia(java.lang.String strGerouPendencia) {
		this.strGerouPendencia = strGerouPendencia;
	}
	public java.lang.String getLinhasRet() {
		return linhasRet;
	}
	public void setLinhasRet(java.lang.String linhasRet) {
		this.linhasRet = linhasRet;
	}
	public java.lang.String getStrChave23() {
		return strChave23;
	}
	public void setStrChave23(java.lang.String strChave23) {
		this.strChave23 = strChave23;
	}
	public java.lang.String getStrChave23SemCript() {
		return strChave23SemCript;
	}
	public void setStrChave23SemCript(java.lang.String strChave23SemCript) {
		this.strChave23SemCript = strChave23SemCript;
	}
	
}
