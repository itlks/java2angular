package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;

public class AutorizacoesPendenciaDadosSinteticaRespDTO implements Serializable{
	
	private static final long serialVersionUID = 1432945206984919658L;
	private String data;
	private String codigoProduto;
	private String descricaoProduto;
	private String tipoPendencia;
	private String grupo;
	private String convenio; 
	private Integer quantidadePendencias;
	private BigDecimal valorPendencias;
	private Integer quantidadePendenciasAssinadas;
	private String codigoRemessa;
	private boolean itemSelecionado;
	private String analiticaConvenio;
	private boolean flgAutorizarSintetica;
	private Integer qtdPendenciasSelecionadasPorGrupo;
	private BigDecimal vlrTotalPendenciasPorGrupo;
	private BigDecimal vlrTotalPendenciasNaoAprovadas;
	private Integer qtdPendenciasNaoAprovadas;
	
	/**
	 * @return the vlrTotalPendenciasNaoAprovadas
	 */
	public BigDecimal getVlrTotalPendenciasNaoAprovadas() {
		return vlrTotalPendenciasNaoAprovadas;
	}

	/**
	 * @param vlrTotalPendenciasNaoAprovadas the vlrTotalPendenciasNaoAprovadas to set
	 */
	public void setVlrTotalPendenciasNaoAprovadas(BigDecimal vlrTotalPendenciasNaoAprovadas) {
		this.vlrTotalPendenciasNaoAprovadas = vlrTotalPendenciasNaoAprovadas;
	}

	/**
	 * @return the qtdPendenciasNaoAprovadas
	 */
	public Integer getQtdPendenciasNaoAprovadas() {
		return qtdPendenciasNaoAprovadas;
	}

	/**
	 * @param qtdPendenciasNaoAprovadas the qtdPendenciasNaoAprovadas to set
	 */
	public void setQtdPendenciasNaoAprovadas(Integer qtdPendenciasNaoAprovadas) {
		this.qtdPendenciasNaoAprovadas = qtdPendenciasNaoAprovadas;
	}

	
	/**
	 * @return the qtdPendenciasSelecionadasPorGrupo
	 */
	public Integer getQtdPendenciasSelecionadasPorGrupo() {
		return qtdPendenciasSelecionadasPorGrupo;
	}

	/**
	 * @param qtdPendenciasSelecionadasPorGrupo the qtdPendenciasSelecionadasPorGrupo to set
	 */
	public void setQtdPendenciasSelecionadasPorGrupo(Integer qtdPendenciasSelecionadasPorGrupo) {
		this.qtdPendenciasSelecionadasPorGrupo = qtdPendenciasSelecionadasPorGrupo;
	}

	/**
	 * @return the analiticaConvenio
	 */
	public String getAnaliticaConvenio() {
		return analiticaConvenio;
	}

	/**
	 * @param analiticaConvenio the analiticaConvenio to set
	 */
	public void setAnaliticaConvenio(String analiticaConvenio) {
		this.analiticaConvenio = analiticaConvenio;
	}

	/**
	 * @return the data
	 * Data de inclus�o ou efetiva��o, conforme tipos de pesquisa
	 */
	public String getData() {
		return data;
	}
	
	/**
	 * @param data the data to set
	 */
	public void setData(String data) {
		this.data = data;
	}
	
	/**
	 * @return the codigoProduto
	 */
	public String getCodigoProduto() {
		return codigoProduto;
	}
	
	/**
	 * @param codigoProduto the codigoProduto to set
	 */
	public void setCodigoProduto(String codigoProduto) {
		this.codigoProduto = codigoProduto;
	}
	
	/**
	 * @return the descricaoProduto
	 */
	public String getDescricaoProduto() {
		return descricaoProduto;
	}
	
	/**
	 * @param descricaoProduto the descricaoProduto to set
	 */
	public void setDescricaoProduto(String descricaoProduto) {
		this.descricaoProduto = descricaoProduto;
	}
	
	/**
	 * @return the tipoPendencia
	 * C = CASH, O = ON-LINE
	 */
	public String getTipoPendencia() {
		return tipoPendencia;
	}
	
	/**
	 * @param tipoPendencia the tipoPendencia to set
	 */
	public void setTipoPendencia(String tipoPendencia) {
		this.tipoPendencia = tipoPendencia;
	}
	
	/**
	 * @return the convenio
	 * C�digo do conv�nio ou conta corrente.
	 */
	public String getConvenio() {
		return convenio;
	}
	
	/**
	 * @param convenio the convenio to set
	 */
	public void setConvenio(String convenio) {
		this.convenio = convenio;
	}
	
	/**
	 * @return the quantidadePendencias
	 */
	public Integer getQuantidadePendencias() {
		return quantidadePendencias;
	}
	
	/**
	 * @param quantidadePendencias the quantidadePendencias to set
	 */
	public void setQuantidadePendencias(Integer quantidadePendencias) {
		this.quantidadePendencias = quantidadePendencias;
	}
	
	/**
	 * @return the valorPendencias
	 */
	public BigDecimal getValorPendencias() {
		return valorPendencias;
	}
	
	/**
	 * @param valorPendencias the valorPendencias to set
	 */
	public void setValorPendencias(BigDecimal valorPendencias) {
		this.valorPendencias = valorPendencias;
	}
	
	/**
	 * @return the quantidadePendenciasAssinadas
	 */
	public Integer getQuantidadePendenciasAssinadas() {
		return quantidadePendenciasAssinadas;
	}
	
	/**
	 * @param quantidadePendenciasAssinadas the quantidadePendenciasAssinadas to set
	 */
	public void setQuantidadePendenciasAssinadas(Integer quantidadePendenciasAssinadas) {
		this.quantidadePendenciasAssinadas = quantidadePendenciasAssinadas;
	}
	
	/**
	 * @return the codigoRemessa
	 */
	public String getCodigoRemessa() {
		return codigoRemessa;
	}
	
	/**
	 * @param codigoRemessa the codigoRemessa to set
	 */
	public void setCodigoRemessa(String codigoRemessa) {
		this.codigoRemessa = codigoRemessa;
	}
	
	/**
	 * @return the itemSelecionado
	 */
	public boolean isItemSelecionado() {
		return itemSelecionado;
	}
	
	/**
	 * @param itemSelecionado the itemSelecionado to set
	 */
	public void setItemSelecionado(boolean itemSelecionado) {
		this.itemSelecionado = itemSelecionado;
	}
	

	/**
	 * @return the grupo
	 */
	public String getGrupo() {
		return grupo;
	}

	/**
	 * @param grupo the grupo to set
	 */
	public void setGrupo(String grupo) {
		this.grupo = grupo;
	}


	public boolean isFlgAutorizarSintetica() {		
		if (quantidadePendencias.equals(quantidadePendenciasAssinadas)) {
			return false;
		} else{
			return true;
		}		
	}

	public void setFlgAutorizarSintetica(boolean flgAutorizarSintetica) {
		this.flgAutorizarSintetica = flgAutorizarSintetica;
	}

	public BigDecimal getVlrTotalPendenciasPorGrupo() {
		return vlrTotalPendenciasPorGrupo;
	}

	public void setVlrTotalPendenciasPorGrupo(BigDecimal vlrTotalPendenciasPorGrupo) {
		this.vlrTotalPendenciasPorGrupo = vlrTotalPendenciasPorGrupo;
	}
}
