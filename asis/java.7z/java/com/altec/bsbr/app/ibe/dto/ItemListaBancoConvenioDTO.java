package com.altec.bsbr.app.ibe.dto;


public class ItemListaBancoConvenioDTO {
	 private BancoDTO contaConvenio;
	 private BancoDTO contaDebito;
	 
	/**
	 * @return the contaConvenio
	 */
	public BancoDTO getContaConvenio() {
		return contaConvenio;
	}
	/**
	 * @param contaConvenio the contaConvenio to set
	 */
	public void setContaConvenio(BancoDTO contaConvenio) {
		this.contaConvenio = contaConvenio;
	}
	/**
	 * @return the contaDebito
	 */
	public BancoDTO getContaDebito() {
		return contaDebito;
	}
	/**
	 * @param contaDebito the contaDebito to set
	 */
	public void setContaDebito(BancoDTO contaDebito) {
		this.contaDebito = contaDebito;
	}
	 
	 
}
