package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class PagamentoMultasVeiculosDTO implements Serializable {
	private static final long serialVersionUID = 8150343169429694821L;
	
	private String referOper;
	private String autenti;
	private String renavam;
	private String cpfCnpj;
	private List<GuiaDTO> listaGuiaSelecionada =  new ArrayList<GuiaDTO>();
	
	public String getReferOper() {
		return referOper;
	}
	public void setReferOper(String referOper) {
		this.referOper = referOper;
	}
	public String getAutenti() {
		return autenti;
	}
	public void setAutenti(String autenti) {
		this.autenti = autenti;
	}
	public String getRenavam() {
		return renavam;
	}
	public void setRenavam(String renavam) {
		this.renavam = renavam;
	}
	public String getCpfCnpj() {
		return cpfCnpj;
	}
	public void setCpfCnpj(String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}
	public List<GuiaDTO> getListaGuiaSelecionada() {
		return listaGuiaSelecionada;
	}
	public void setListaGuiaSelecionada(List<GuiaDTO> listaGuiaSelecionada) {
		this.listaGuiaSelecionada = listaGuiaSelecionada;
	}
	
}
