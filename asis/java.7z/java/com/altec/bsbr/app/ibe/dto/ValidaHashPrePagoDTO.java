package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import com.altec.bsbr.app.ibe.anotation.Hash;

public class ValidaHashPrePagoDTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7365250137424639488L;

	@Hash(position = 1)
	private String ddd;
	
	@Hash(position = 2)
	private String telefone;
	
	@Hash(position = 3)
	private String dddConfirmacao;

	@Hash(position = 4)
	private String telefoneConfirmacao;
	
	public String getDdd() {
		return ddd;
	}

	public void setDdd(String ddd) {
		this.ddd = ddd;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getDddConfirmacao() {
		return dddConfirmacao;
	}

	public void setDddConfirmacao(String dddConfirmacao) {
		this.dddConfirmacao = dddConfirmacao;
	}

	public String getTelefoneConfirmacao() {
		return telefoneConfirmacao;
	}

	public void setTelefoneConfirmacao(String telefoneConfirmacao) {
		this.telefoneConfirmacao = telefoneConfirmacao;
	}
}
