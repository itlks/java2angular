package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;


public class OperacoesRealizadaResponseDTO implements Serializable {

		
	private static final long serialVersionUID = 4104972346540112453L;

	private String idTransacao;
	
	private String codigoBanco;
	
	private String codigoAgencia;
	
	private String conta;
	
	private String produto;
	
	private String servico;
	
	private String bancoDestino;
	
	private String agenciaDestino;
	
	private String contaDestino;
	
	private Double valor;
	
	private String compHis;
	
	private String clienteDestino;

	/**
	 * @return the idTransacao
	 */
	public String getIdTransacao() {
		return idTransacao;
	}

	/**
	 * @param idTransacao the idTransacao to set
	 */
	public void setIdTransacao(String idTransacao) {
		this.idTransacao = idTransacao;
	}

	/**
	 * @return the codigoBanco
	 */
	public String getCodigoBanco() {
		return codigoBanco;
	}

	/**
	 * @param codigoBanco the codigoBanco to set
	 */
	public void setCodigoBanco(String codigoBanco) {
		this.codigoBanco = codigoBanco;
	}

	/**
	 * @return the codigoAgencia
	 */
	public String getCodigoAgencia() {
		return codigoAgencia;
	}

	/**
	 * @param codigoAgencia the codigoAgencia to set
	 */
	public void setCodigoAgencia(String codigoAgencia) {
		this.codigoAgencia = codigoAgencia;
	}

	/**
	 * @return the conta
	 */
	public String getConta() {
		return conta;
	}

	/**
	 * @param conta the conta to set
	 */
	public void setConta(String conta) {
		this.conta = conta;
	}

	/**
	 * @return the produto
	 */
	public String getProduto() {
		return produto;
	}

	/**
	 * @param produto the produto to set
	 */
	public void setProduto(String produto) {
		this.produto = produto;
	}

	/**
	 * @return the servico
	 */
	public String getServico() {
		return servico;
	}

	/**
	 * @param servico the servico to set
	 */
	public void setServico(String servico) {
		this.servico = servico;
	}

	/**
	 * @return the bancoDestino
	 */
	public String getBancoDestino() {
		return bancoDestino;
	}

	/**
	 * @param bancoDestino the bancoDestino to set
	 */
	public void setBancoDestino(String bancoDestino) {
		this.bancoDestino = bancoDestino;
	}

	/**
	 * @return the agenciaDestino
	 */
	public String getAgenciaDestino() {
		return agenciaDestino;
	}

	/**
	 * @param agenciaDestino the agenciaDestino to set
	 */
	public void setAgenciaDestino(String agenciaDestino) {
		this.agenciaDestino = agenciaDestino;
	}

	/**
	 * @return the contaDestino
	 */
	public String getContaDestino() {
		return contaDestino;
	}

	/**
	 * @param contaDestino the contaDestino to set
	 */
	public void setContaDestino(String contaDestino) {
		this.contaDestino = contaDestino;
	}

	/**
	 * @return the valor
	 */
	public Double getValor() {
		return valor;
	}

	/**
	 * @param valor the valor to set
	 */
	public void setValor(Double valor) {
		this.valor = valor;
	}

	/**
	 * @return the compHis
	 */
	public String getCompHis() {
		return compHis;
	}

	/**
	 * @param compHis the compHis to set
	 */
	public void setCompHis(String compHis) {
		this.compHis = compHis;
	}

	/**
	 * @return the clienteDestino
	 */
	public String getClienteDestino() {
		return clienteDestino;
	}

	/**
	 * @param clienteDestino the clienteDestino to set
	 */
	public void setClienteDestino(String clienteDestino) {
		this.clienteDestino = clienteDestino;
	}	


}
