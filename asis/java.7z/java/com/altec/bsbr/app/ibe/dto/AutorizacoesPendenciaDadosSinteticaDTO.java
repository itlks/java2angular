package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

public class AutorizacoesPendenciaDadosSinteticaDTO implements Serializable{
	
	private static final long serialVersionUID = -576593327453806932L;
	private List<AutorizacoesPendenciaDadosAnaliticaDTO> listaAnaliticaDTO;
	private List<AutorizacoesPendenciaDadosModalidadeDTO> modalidades;
	private List<AutorizacoesPendenciaDadosModalidadeRemessaDTO> modalidadesRemessa;
	
	private String data;
	private String codigoProduto;
	private String descricaoProduto;
	private String tipoPendencia;
	private String grupo;
	private String convenio; 
	private Integer quantidadePendencias;
	private BigDecimal valorPendencias;
	private Integer quantidadePendenciasAssinadas;
	private String codigoRemessa;
	private boolean itemSelecionado;
	private String analiticaConvenio;
	@SuppressWarnings("unused")
	private boolean flgAutorizarSintetica;
	private Integer qtdPendenciasSelecionadasPorGrupo;
	private BigDecimal vlrTotalPendenciasPorGrupo;
	private BigDecimal vlrTotalPendenciasNaoAprovadas;
	private Integer qtdPendenciasNaoAprovadas;
	
	/**
	 * @return the vlrTotalPendenciasNaoAprovadas
	 */
	public BigDecimal getVlrTotalPendenciasNaoAprovadas() {
		return vlrTotalPendenciasNaoAprovadas;
	}

	/**
	 * @param vlrTotalPendenciasNaoAprovadas the vlrTotalPendenciasNaoAprovadas to set
	 */
	public void setVlrTotalPendenciasNaoAprovadas(BigDecimal vlrTotalPendenciasNaoAprovadas) {
		this.vlrTotalPendenciasNaoAprovadas = vlrTotalPendenciasNaoAprovadas;
	}

	/**
	 * @return the qtdPendenciasNaoAprovadas
	 */
	public Integer getQtdPendenciasNaoAprovadas() {
		return qtdPendenciasNaoAprovadas;
	}

	/**
	 * @param qtdPendenciasNaoAprovadas the qtdPendenciasNaoAprovadas to set
	 */
	public void setQtdPendenciasNaoAprovadas(Integer qtdPendenciasNaoAprovadas) {
		this.qtdPendenciasNaoAprovadas = qtdPendenciasNaoAprovadas;
	}

	
	/**
	 * @return the qtdPendenciasSelecionadasPorGrupo
	 */
	public Integer getQtdPendenciasSelecionadasPorGrupo() {
		return qtdPendenciasSelecionadasPorGrupo;
	}

	/**
	 * @param qtdPendenciasSelecionadasPorGrupo the qtdPendenciasSelecionadasPorGrupo to set
	 */
	public void setQtdPendenciasSelecionadasPorGrupo(Integer qtdPendenciasSelecionadasPorGrupo) {
		this.qtdPendenciasSelecionadasPorGrupo = qtdPendenciasSelecionadasPorGrupo;
	}

	/**
	 * @return the analiticaConvenio
	 */
	public String getAnaliticaConvenio() {
		return analiticaConvenio;
	}

	/**
	 * @param analiticaConvenio the analiticaConvenio to set
	 */
	public void setAnaliticaConvenio(String analiticaConvenio) {
		this.analiticaConvenio = analiticaConvenio;
	}

	/**
	 * @return the data
	 * Data de inclus�o ou efetiva��o, conforme tipos de pesquisa
	 */
	public String getData() {
		return data;
	}
	
	/**
	 * @param data the data to set
	 */
	public void setData(String data) {
		this.data = data;
	}
	
	/**
	 * @return the codigoProduto
	 */
	public String getCodigoProduto() {
		return codigoProduto;
	}
	
	/**
	 * @param codigoProduto the codigoProduto to set
	 */
	public void setCodigoProduto(String codigoProduto) {
		this.codigoProduto = codigoProduto;
	}
	
	/**
	 * @return the descricaoProduto
	 */
	public String getDescricaoProduto() {
		return descricaoProduto;
	}
	
	/**
	 * @param descricaoProduto the descricaoProduto to set
	 */
	public void setDescricaoProduto(String descricaoProduto) {
		this.descricaoProduto = descricaoProduto;
	}
	
	/**
	 * @return the tipoPendencia
	 * C = CASH, O = ON-LINE
	 */
	public String getTipoPendencia() {
		return tipoPendencia;
	}
	
	/**
	 * @param tipoPendencia the tipoPendencia to set
	 */
	public void setTipoPendencia(String tipoPendencia) {
		this.tipoPendencia = tipoPendencia;
	}
	
	/**
	 * @return the convenio
	 * C�digo do conv�nio ou conta corrente.
	 */
	public String getConvenio() {
		return convenio;
	}
	
	/**
	 * @param convenio the convenio to set
	 */
	public void setConvenio(String convenio) {
		this.convenio = convenio;
	}
	
	/**
	 * @return the quantidadePendencias
	 */
	public Integer getQuantidadePendencias() {
		return quantidadePendencias;
	}
	
	/**
	 * @param quantidadePendencias the quantidadePendencias to set
	 */
	public void setQuantidadePendencias(Integer quantidadePendencias) {
		this.quantidadePendencias = quantidadePendencias;
	}
	
	/**
	 * @return the valorPendencias
	 */
	public BigDecimal getValorPendencias() {
		return valorPendencias;
	}
	
	/**
	 * @param valorPendencias the valorPendencias to set
	 */
	public void setValorPendencias(BigDecimal valorPendencias) {
		this.valorPendencias = valorPendencias;
	}
	
	/**
	 * @return the quantidadePendenciasAssinadas
	 */
	public Integer getQuantidadePendenciasAssinadas() {
		return quantidadePendenciasAssinadas;
	}
	
	/**
	 * @param quantidadePendenciasAssinadas the quantidadePendenciasAssinadas to set
	 */
	public void setQuantidadePendenciasAssinadas(Integer quantidadePendenciasAssinadas) {
		this.quantidadePendenciasAssinadas = quantidadePendenciasAssinadas;
	}
	
	/**
	 * @return the codigoRemessa
	 */
	public String getCodigoRemessa() {
		return codigoRemessa;
	}
	
	/**
	 * @param codigoRemessa the codigoRemessa to set
	 */
	public void setCodigoRemessa(String codigoRemessa) {
		this.codigoRemessa = codigoRemessa;
	}
	
	/**
	 * @return the itemSelecionado
	 */
	public boolean isItemSelecionado() {
		return itemSelecionado;
	}
	
	/**
	 * @param itemSelecionado the itemSelecionado to set
	 */
	public void setItemSelecionado(boolean itemSelecionado) {
		this.itemSelecionado = itemSelecionado;
	}
	

	/**
	 * @return the grupo
	 */
	public String getGrupo() {
		return grupo;
	}

	/**
	 * @param grupo the grupo to set
	 */
	public void setGrupo(String grupo) {
		this.grupo = grupo;
	}

	/**
	 * @return the listaAnaliticaDTO
	 */
	public List<AutorizacoesPendenciaDadosAnaliticaDTO> getListaAnaliticaDTO() {
		return listaAnaliticaDTO;
	}

	/**
	 * @param listaAnaliticaDTO the listaAnaliticaDTO to set
	 */
	public void setListaAnaliticaDTO(List<AutorizacoesPendenciaDadosAnaliticaDTO> listaAnaliticaDTO) {
		this.listaAnaliticaDTO = listaAnaliticaDTO;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((analiticaConvenio == null) ? 0 : analiticaConvenio.hashCode());
		result = prime * result + ((codigoProduto == null) ? 0 : codigoProduto.hashCode());
		result = prime * result + ((codigoRemessa == null) ? 0 : codigoRemessa.hashCode());
		result = prime * result + ((convenio == null) ? 0 : convenio.hashCode());
		result = prime * result + ((data == null) ? 0 : data.hashCode());
		result = prime * result + ((descricaoProduto == null) ? 0 : descricaoProduto.hashCode());
		result = prime * result + ((grupo == null) ? 0 : grupo.hashCode());
		result = prime * result + (itemSelecionado ? 1231 : 1237);
		result = prime * result + ((listaAnaliticaDTO == null) ? 0 : listaAnaliticaDTO.hashCode());
		result = prime * result + ((quantidadePendencias == null) ? 0 : quantidadePendencias.hashCode());
		result = prime * result
				+ ((quantidadePendenciasAssinadas == null) ? 0 : quantidadePendenciasAssinadas.hashCode());
		result = prime * result + ((tipoPendencia == null) ? 0 : tipoPendencia.hashCode());
		result = prime * result + ((valorPendencias == null) ? 0 : valorPendencias.hashCode());
		return result;
	}

	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AutorizacoesPendenciaDadosSinteticaDTO other = (AutorizacoesPendenciaDadosSinteticaDTO) obj;
		if (analiticaConvenio == null) {
			if (other.analiticaConvenio != null)
				return false;
		} else if (!analiticaConvenio.equals(other.analiticaConvenio))
			return false;
		if (codigoProduto == null) {
			if (other.codigoProduto != null)
				return false;
		} else if (!codigoProduto.equals(other.codigoProduto))
			return false;
		if (codigoRemessa == null) {
			if (other.codigoRemessa != null)
				return false;
		} else if (!codigoRemessa.equals(other.codigoRemessa))
			return false;
		if (convenio == null) {
			if (other.convenio != null)
				return false;
		} else if (!convenio.equals(other.convenio))
			return false;
		if (data == null) {
			if (other.data != null)
				return false;
		} else if (!data.equals(other.data))
			return false;
		if (descricaoProduto == null) {
			if (other.descricaoProduto != null)
				return false;
		} else if (!descricaoProduto.equals(other.descricaoProduto))
			return false;
		if (grupo == null) {
			if (other.grupo != null)
				return false;
		} else if (!grupo.equals(other.grupo))
			return false;
		if (itemSelecionado != other.itemSelecionado)
			return false;
		if (listaAnaliticaDTO == null) {
			if (other.listaAnaliticaDTO != null)
				return false;
		} else if (!listaAnaliticaDTO.equals(other.listaAnaliticaDTO))
			return false;
		if (quantidadePendencias == null) {
			if (other.quantidadePendencias != null)
				return false;
		} else if (!quantidadePendencias.equals(other.quantidadePendencias))
			return false;
		if (quantidadePendenciasAssinadas == null) {
			if (other.quantidadePendenciasAssinadas != null)
				return false;
		} else if (!quantidadePendenciasAssinadas.equals(other.quantidadePendenciasAssinadas))
			return false;
		if (tipoPendencia == null) {
			if (other.tipoPendencia != null)
				return false;
		} else if (!tipoPendencia.equals(other.tipoPendencia))
			return false;
		if (valorPendencias == null) {
			if (other.valorPendencias != null)
				return false;
		} else if (!valorPendencias.equals(other.valorPendencias))
			return false;
		return true;
	}

	public boolean isFlgAutorizarSintetica() {		
		if (quantidadePendencias.equals(quantidadePendenciasAssinadas)) {
			return false;
		} else{
			return true;
		}		
	}

	public void setFlgAutorizarSintetica(boolean flgAutorizarSintetica) {
		this.flgAutorizarSintetica = flgAutorizarSintetica;
	}

	public BigDecimal getVlrTotalPendenciasPorGrupo() {
		return vlrTotalPendenciasPorGrupo;
	}

	public void setVlrTotalPendenciasPorGrupo(BigDecimal vlrTotalPendenciasPorGrupo) {
		this.vlrTotalPendenciasPorGrupo = vlrTotalPendenciasPorGrupo;
	}

	/**
	 * @return the modalidades
	 */
	public List<AutorizacoesPendenciaDadosModalidadeDTO> getModalidades() {
		return modalidades;
	}

	/**
	 * @param modalidades the modalidades to set
	 */
	public void setModalidades(List<AutorizacoesPendenciaDadosModalidadeDTO> modalidades) {
		this.modalidades = modalidades;
	}

	public List<AutorizacoesPendenciaDadosModalidadeRemessaDTO> getModalidadesRemessa() {
		return modalidadesRemessa;
	}

	public void setModalidadesRemessa(List<AutorizacoesPendenciaDadosModalidadeRemessaDTO> modalidadesRemessa) {
		this.modalidadesRemessa = modalidadesRemessa;
	}

}
