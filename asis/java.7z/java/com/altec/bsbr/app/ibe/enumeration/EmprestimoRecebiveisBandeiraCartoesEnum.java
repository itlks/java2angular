package com.altec.bsbr.app.ibe.enumeration;

import org.apache.commons.lang.ArrayUtils;

public enum EmprestimoRecebiveisBandeiraCartoesEnum {
	
	TODOS("999","Todos"),
	VISA("001", "Visa"), 
	MASTER("002", "MasterCard");
	
	
	private String id;
	private String descricao;
	
	private EmprestimoRecebiveisBandeiraCartoesEnum(String id, String descricao){
		this.id = id;
		this.descricao = descricao;
	}

	public String getId() {
		return id;
	}

	public String getDescricao() {
		return descricao;
	}
	
	public static EmprestimoRecebiveisBandeiraCartoesEnum[] removerItemArray(EmprestimoRecebiveisBandeiraCartoesEnum tipoContaEnum){
		
		EmprestimoRecebiveisBandeiraCartoesEnum[] result = EmprestimoRecebiveisBandeiraCartoesEnum.values();
				
		if(tipoContaEnum != null){
			for (int i = 0; i < EmprestimoRecebiveisBandeiraCartoesEnum.values().length; i++) {
				EmprestimoRecebiveisBandeiraCartoesEnum  tipo = EmprestimoRecebiveisBandeiraCartoesEnum.values()[i];
				if(tipo.equals(tipoContaEnum)){
					result = (EmprestimoRecebiveisBandeiraCartoesEnum[]) ArrayUtils.remove(result, i); 
					break;
				}
			}
		}
		return result;
	}
	
	public static EmprestimoRecebiveisBandeiraCartoesEnum findById(String id){
		EmprestimoRecebiveisBandeiraCartoesEnum retorno = null;
				
		if(id != null){
			for(EmprestimoRecebiveisBandeiraCartoesEnum opcao: EmprestimoRecebiveisBandeiraCartoesEnum.values()){
				if(opcao.getId() == id){
					retorno = opcao;
					break;
				}
			}
		}
		return retorno;
	}
	
	public static EmprestimoRecebiveisBandeiraCartoesEnum findByDescricao(String desc){
		EmprestimoRecebiveisBandeiraCartoesEnum retorno = null;
				
		if(desc != null && !desc.isEmpty()){
			for(EmprestimoRecebiveisBandeiraCartoesEnum opcao: EmprestimoRecebiveisBandeiraCartoesEnum.values()){
				if(opcao.getDescricao().equals(desc)){
					retorno = opcao;
					break;
				}
			}
		}
		return retorno;
	}
	
}
