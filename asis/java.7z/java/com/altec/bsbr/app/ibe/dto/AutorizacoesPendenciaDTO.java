package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;


public class AutorizacoesPendenciaDTO implements Serializable {
		
	private static final long serialVersionUID = 7818423973160742182L;

	private List<AutorizacoesPendenciaDadosSinteticaDTO> listaPendencias;
	
	private Calendar periodoHoje;
	private Calendar periodoEfetivacaoTresDias;
	private Calendar periodoEfetivacaoCincoDias;
	private Calendar periodoEfetivacaoSeteDias;
	private Calendar periodoInclusaoTresDias;
	private Calendar periodoInclusaoCincoDias;
	private Calendar periodoInclusaoSeteDias;
	private String dataInicioOutrosPeriodos;	
	private String dataFimOutrosPeriodos;
		
	private String codUsuarioUltimaAtu;
	private String nomeFavorecidoPendencia;
	private String descricaoProduto;
	private String imgTransacao;
	private String data;
	private String codigoTransacao;
	
	private BigDecimal valorTotalPendenciaSelecionadas;
	private Integer quantidadePendenciaSelecionadas;
	private Boolean pendenciasSelecionadas;
	private List<Integer> listaQtdPendenciasSelecionadasPorGrupo;
	private List<String> listaVlrTotalPendenciasPorGrupo;
	private String tipoAba;
	private int tabAtiva;
	private int periodoAtivo;
	
	private List<AutorizacoesPendenciaDadosAnaliticaDTO> listaAnaliticaRetorno;
		
	/**
	 * AutorizacoesPendenciaDTO
	 */
	public AutorizacoesPendenciaDTO() {
		
		setPeriodoHoje(Calendar.getInstance());
		setListaPendencias(new ArrayList<AutorizacoesPendenciaDadosSinteticaDTO>());
		
		initPeriodoEfetivacao();
		initPeriodoInclusao();
		
	}

	
	
	/**
	 * initPeriodoEfetivacao
	 */
	private void initPeriodoEfetivacao() {
		
		periodoEfetivacaoTresDias = Calendar.getInstance();
		periodoEfetivacaoCincoDias = Calendar.getInstance();
		periodoEfetivacaoSeteDias = Calendar.getInstance();
		
		periodoEfetivacaoTresDias.add(Calendar.DAY_OF_YEAR, 2);
		periodoEfetivacaoCincoDias.add(Calendar.DAY_OF_YEAR, 4);
		periodoEfetivacaoSeteDias.add(Calendar.DAY_OF_YEAR, 6);
		
	}
	
	
	/**
	 * initPeriodoInclusao
	 */
	private void initPeriodoInclusao() {
		
		periodoInclusaoTresDias = Calendar.getInstance();
		periodoInclusaoCincoDias = Calendar.getInstance();
		periodoInclusaoSeteDias = Calendar.getInstance();
		
		periodoInclusaoTresDias.add(Calendar.DAY_OF_YEAR, -2);
		periodoInclusaoCincoDias.add(Calendar.DAY_OF_YEAR, -4);
		periodoInclusaoSeteDias.add(Calendar.DAY_OF_YEAR, -6);
		
	}
	
	
	/**
	 * @return the periodoHoje
	 */
	public Calendar getPeriodoHoje() {
		return periodoHoje;
	}


	
	/**
	 * @param periodoHoje the periodoHoje to set
	 */
	public void setPeriodoHoje(Calendar periodoHoje) {
		this.periodoHoje = periodoHoje;
	}


	
	/**
	 * @return the periodoEfetivacaoTresDias
	 */
	public Calendar getPeriodoEfetivacaoTresDias() {
		return periodoEfetivacaoTresDias;
	}


	
	/**
	 * @param periodoEfetivacaoTresDias the periodoEfetivacaoTresDias to set
	 */
	public void setPeriodoEfetivacaoTresDias(Calendar periodoEfetivacaoTresDias) {
		this.periodoEfetivacaoTresDias = periodoEfetivacaoTresDias;
	}


	
	/**
	 * @return the periodoEfetivacaoCincoDias
	 */
	public Calendar getPeriodoEfetivacaoCincoDias() {
		return periodoEfetivacaoCincoDias;
	}


	
	/**
	 * @param periodoEfetivacaoCincoDias the periodoEfetivacaoCincoDias to set
	 */
	public void setPeriodoEfetivacaoCincoDias(Calendar periodoEfetivacaoCincoDias) {
		this.periodoEfetivacaoCincoDias = periodoEfetivacaoCincoDias;
	}


	
	/**
	 * @return the periodoEfetivacaoSeteDias
	 */
	public Calendar getPeriodoEfetivacaoSeteDias() {
		return periodoEfetivacaoSeteDias;
	}


	
	/**
	 * @param periodoEfetivacaoSeteDias the periodoEfetivacaoSeteDias to set
	 */
	public void setPeriodoEfetivacaoSeteDias(Calendar periodoEfetivacaoSeteDias) {
		this.periodoEfetivacaoSeteDias = periodoEfetivacaoSeteDias;
	}


	
	/**
	 * @return the periodoInclusaoTresDias
	 */
	public Calendar getPeriodoInclusaoTresDias() {
		return periodoInclusaoTresDias;
	}


	
	/**
	 * @param periodoInclusaoTresDias the periodoInclusaoTresDias to set
	 */
	public void setPeriodoInclusaoTresDias(Calendar periodoInclusaoTresDias) {
		this.periodoInclusaoTresDias = periodoInclusaoTresDias;
	}


	
	/**
	 * @return the periodoInclusaoCincoDias
	 */
	public Calendar getPeriodoInclusaoCincoDias() {
		return periodoInclusaoCincoDias;
	}


	
	/**
	 * @param periodoInclusaoCincoDias the periodoInclusaoCincoDias to set
	 */
	public void setPeriodoInclusaoCincoDias(Calendar periodoInclusaoCincoDias) {
		this.periodoInclusaoCincoDias = periodoInclusaoCincoDias;
	}


	
	/**
	 * @return the periodoInclusaoSeteDias
	 */
	public Calendar getPeriodoInclusaoSeteDias() {
		return periodoInclusaoSeteDias;
	}


	
	/**
	 * @param periodoInclusaoSeteDias the periodoInclusaoSeteDias to set
	 */
	public void setPeriodoInclusaoSeteDias(Calendar periodoInclusaoSeteDias) {
		this.periodoInclusaoSeteDias = periodoInclusaoSeteDias;
	}

	
	/**
	 * @return the codUsuarioUltimaAtu
	 */
	public String getCodUsuarioUltimaAtu() {
		return codUsuarioUltimaAtu;
	}


	
	/**
	 * @param codUsuarioUltimaAtu the codUsuarioUltimaAtu to set
	 */
	public void setCodUsuarioUltimaAtu(String codUsuarioUltimaAtu) {
		this.codUsuarioUltimaAtu = codUsuarioUltimaAtu;
	}


	
	/**
	 * @return the nomeFavorecidoPendencia
	 */
	public String getNomeFavorecidoPendencia() {
		return nomeFavorecidoPendencia;
	}


	
	/**
	 * @param nomeFavorecidoPendencia the nomeFavorecidoPendencia to set
	 */
	public void setNomeFavorecidoPendencia(String nomeFavorecidoPendencia) {
		this.nomeFavorecidoPendencia = nomeFavorecidoPendencia;
	}


	
	/**
	 * @return the descricaoProduto
	 */
	public String getDescricaoProduto() {
		return descricaoProduto;
	}


	
	/**
	 * @param descricaoProduto the descricaoProduto to set
	 */
	public void setDescricaoProduto(String descricaoProduto) {
		this.descricaoProduto = descricaoProduto;
	}


	
	/**
	 * @return the imgTransacao
	 */
	public String getImgTransacao() {
		return imgTransacao;
	}


	
	/**
	 * @param imgTransacao the imgTransacao to set
	 */
	public void setImgTransacao(String imgTransacao) {
		this.imgTransacao = imgTransacao;
	}


	
	/**
	 * @return the data
	 */
	public String getData() {
		return data;
	}


	
	/**
	 * @param data the data to set
	 */
	public void setData(String data) {
		this.data = data;
	}


	
	/**
	 * @return the codigoTransacao
	 */
	public String getCodigoTransacao() {
		return codigoTransacao;
	}


	
	/**
	 * @param codigoTransacao the codigoTransacao to set
	 */
	public void setCodigoTransacao(String codigoTransacao) {
		this.codigoTransacao = codigoTransacao;
	}



	/**
	 * @return the listaPendencias
	 */
	public List<AutorizacoesPendenciaDadosSinteticaDTO> getListaPendencias() {
		return listaPendencias;
	}



	/**
	 * @param listaPendencias the listaPendencias to set
	 */
	public void setListaPendencias(List<AutorizacoesPendenciaDadosSinteticaDTO> listaPendencias) {
		this.listaPendencias = listaPendencias;
	}



	/**
	 * @return the valorTotalPendenciaSelecionadas
	 */
	public BigDecimal getValorTotalPendenciaSelecionadas() {
		return valorTotalPendenciaSelecionadas;
	}



	/**
	 * @param valorTotalPendenciaSelecionadas the valorTotalPendenciaSelecionadas to set
	 */
	public void setValorTotalPendenciaSelecionadas(BigDecimal valorTotalPendenciaSelecionadas) {
		this.valorTotalPendenciaSelecionadas = valorTotalPendenciaSelecionadas;
	}



	/**
	 * @return the quantidadePendenciaSelecionadas
	 */
	public Integer getQuantidadePendenciaSelecionadas() {
		return quantidadePendenciaSelecionadas;
	}



	/**
	 * @param quantidadePendenciaSelecionadas the quantidadePendenciaSelecionadas to set
	 */
	public void setQuantidadePendenciaSelecionadas(Integer quantidadePendenciaSelecionadas) {
		this.quantidadePendenciaSelecionadas = quantidadePendenciaSelecionadas;
	}

	public String getTipoAba() {
		return tipoAba;
	}

	public void setTipoAba(String tipoAba) {
		this.tipoAba = tipoAba;
	}



	public List<Integer> getListaQtdPendenciasSelecionadasPorGrupo() {
		return listaQtdPendenciasSelecionadasPorGrupo;
	}



	public void setListaQtdPendenciasSelecionadasPorGrupo(List<Integer> listaQtdPendenciasSelecionadasPorGrupo) {
		this.listaQtdPendenciasSelecionadasPorGrupo = listaQtdPendenciasSelecionadasPorGrupo;
	}



	public List<String> getListaVlrTotalPendenciasPorGrupo() {
		return listaVlrTotalPendenciasPorGrupo;
	}



	public void setListaVlrTotalPendenciasPorGrupo(List<String> listaVlrTotalPendenciasPorGrupo) {
		this.listaVlrTotalPendenciasPorGrupo = listaVlrTotalPendenciasPorGrupo;
	}



	public String getDataInicioOutrosPeriodos() {
		return dataInicioOutrosPeriodos;
	}



	public void setDataInicioOutrosPeriodos(String dataInicioOutrosPeriodos) {
		this.dataInicioOutrosPeriodos = dataInicioOutrosPeriodos;
	}



	public String getDataFimOutrosPeriodos() {
		return dataFimOutrosPeriodos;
	}



	public void setDataFimOutrosPeriodos(String dataFimOutrosPeriodos) {
		this.dataFimOutrosPeriodos = dataFimOutrosPeriodos;
	}



	public int getTabAtiva() {
		return tabAtiva;
	}



	public void setTabAtiva(int tabAtiva) {
		this.tabAtiva = tabAtiva;
	}



	public Boolean getPendenciasSelecionadas() {
		return pendenciasSelecionadas;
	}



	public void setPendenciasSelecionadas(Boolean pendenciasSelecionadas) {
		this.pendenciasSelecionadas = pendenciasSelecionadas;
	}



	public int getPeriodoAtivo() {
		return periodoAtivo;
	}



	public void setPeriodoAtivo(int periodoAtivo) {
		this.periodoAtivo = periodoAtivo;
	}



	public List<AutorizacoesPendenciaDadosAnaliticaDTO> getListaAnaliticaRetorno() {
		return listaAnaliticaRetorno;
	}



	public void setListaAnaliticaRetorno(List<AutorizacoesPendenciaDadosAnaliticaDTO> listaAnaliticaRetorno) {
		this.listaAnaliticaRetorno = listaAnaliticaRetorno;
	}



}
