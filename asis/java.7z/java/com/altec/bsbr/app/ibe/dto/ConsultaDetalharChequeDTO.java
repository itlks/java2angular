package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class ConsultaDetalharChequeDTO implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -8470013288850326843L;
	private String banco;
	private String agencia;
	private String conta;
	private String regiao;
	private String numeroPrimeiroChequeTalao;
	private String numeroUltimoChequeTalao;
	private String numeroCheque;
	private String statusCheque;
	
	
	public ConsultaDetalharChequeDTO() {}
	
	
	public String getBanco() {
		return banco;
	}
	public void setBanco(String banco) {
		this.banco = banco;
	}
	public String getAgencia() {
		return agencia;
	}
	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}
	public String getConta() {
		return conta;
	}
	public void setConta(String conta) {
		this.conta = conta;
	}
	public String getRegiao() {
		return regiao;
	}
	public void setRegiao(String regiao) {
		this.regiao = regiao;
	}
	public String getNumeroPrimeiroChequeTalao() {
		return numeroPrimeiroChequeTalao;
	}
	public void setNumeroPrimeiroChequeTalao(String numeroPrimeiroChequeTalao) {
		this.numeroPrimeiroChequeTalao = numeroPrimeiroChequeTalao;
	}
	public String getNumeroUltimoChequeTalao() {
		return numeroUltimoChequeTalao;
	}
	public void setNumeroUltimoChequeTalao(String numeroUltimoChequeTalao) {
		this.numeroUltimoChequeTalao = numeroUltimoChequeTalao;
	}
	public String getNumeroCheque() {
		return numeroCheque;
	}
	public void setNumeroCheque(String numeroCheque) {
		this.numeroCheque = numeroCheque;
	}
	public String getStatusCheque() {
		return statusCheque;
	}
	public void setStatusCheque(String statusCheque) {
		this.statusCheque = statusCheque;
	}
	
	
}
