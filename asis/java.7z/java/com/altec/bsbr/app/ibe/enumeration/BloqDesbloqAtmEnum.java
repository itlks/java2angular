package com.altec.bsbr.app.ibe.enumeration;

public enum BloqDesbloqAtmEnum {
	DiaTodo("S", "Bloquear as informa��es de investimentos e limites em per�odo integral (24 horas).", "", false),
	Madrugada("P", "Bloquear as informa��es de investimentos e limites em per�odo parcial (18 �s 09 horas).", "", false),
	NaoBloquear("N", "N�o Bloquear.", "", false);

	private String id;
	private String descricao;
	private String idBks;
	private boolean bloqueados;
	
	public String getId() {
		return id;
	}

	public String getDescricao() {
		return descricao;
	}

	private BloqDesbloqAtmEnum(String id, String descricao, String idBks, boolean bloqueados) {
		this.id = id;
		this.descricao = descricao;
		this.idBks = idBks;
		this.bloqueados = bloqueados;
	}

	public static BloqDesbloqAtmEnum findById(String id){
		BloqDesbloqAtmEnum retorno = null;
		if(id == null || id == "") retorno = null;
		
		for (BloqDesbloqAtmEnum bloqDesbloqAtm: values()) {
			if (bloqDesbloqAtm.getId().equals(id)) {
				retorno = bloqDesbloqAtm;
				break;
			}
		}
		return retorno;
	}

	public String getIdBks() {
		return idBks;
	}


	public boolean isBloqueados() {
		return bloqueados;
	}

}
