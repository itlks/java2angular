package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class RelacaoBancosEntradaWebDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2356783775019887866L;

	private String lngCodigoParticipante;
	private String sOrdem;
	private String tipoDeServico;
	private String lngIDConexao;
	private String strBanco;
	private String strAgencia;
	private String strConta;
	private String strNomeUsuario;
	private String lngCodigoUsuario;
	private String strFisicaJuridica;
	private String strTipoDeOperacao;
	private String lngRetCode;
	private String strErro;
	private String strErroTecnica;
	private String intIdTipoConta;
	private String intIdCanal;
	private String strIPAddrCliente;
	private String strIPAddrServer;
	private String strOpcao;
	private String strCodISPB;
	private String strCodBanco;

	public String getLngCodigoParticipante() {
		return lngCodigoParticipante;
	}

	public void setLngCodigoParticipante(String lngCodigoParticipante) {
		this.lngCodigoParticipante = lngCodigoParticipante;
	}

	public String getsOrdem() {
		return sOrdem;
	}

	public void setsOrdem(String sOrdem) {
		this.sOrdem = sOrdem;
	}

	public String getTipoDeServico() {
		return tipoDeServico;
	}

	public void setTipoDeServico(String tipoDeServico) {
		this.tipoDeServico = tipoDeServico;
	}

	public String getLngIDConexao() {
		return lngIDConexao;
	}

	public void setLngIDConexao(String lngIDConexao) {
		this.lngIDConexao = lngIDConexao;
	}

	public String getStrBanco() {
		return strBanco;
	}

	public void setStrBanco(String strBanco) {
		this.strBanco = strBanco;
	}

	public String getStrAgencia() {
		return strAgencia;
	}

	public void setStrAgencia(String strAgencia) {
		this.strAgencia = strAgencia;
	}

	public String getStrConta() {
		return strConta;
	}

	public void setStrConta(String strConta) {
		this.strConta = strConta;
	}

	public String getStrNomeUsuario() {
		return strNomeUsuario;
	}

	public void setStrNomeUsuario(String strNomeUsuario) {
		this.strNomeUsuario = strNomeUsuario;
	}

	public String getLngCodigoUsuario() {
		return lngCodigoUsuario;
	}

	public void setLngCodigoUsuario(String lngCodigoUsuario) {
		this.lngCodigoUsuario = lngCodigoUsuario;
	}

	public String getStrFisicaJuridica() {
		return strFisicaJuridica;
	}

	public void setStrFisicaJuridica(String strFisicaJuridica) {
		this.strFisicaJuridica = strFisicaJuridica;
	}

	public String getStrTipoDeOperacao() {
		return strTipoDeOperacao;
	}

	public void setStrTipoDeOperacao(String strTipoDeOperacao) {
		this.strTipoDeOperacao = strTipoDeOperacao;
	}

	public String getLngRetCode() {
		return lngRetCode;
	}

	public void setLngRetCode(String lngRetCode) {
		this.lngRetCode = lngRetCode;
	}

	public String getStrErro() {
		return strErro;
	}

	public void setStrErro(String strErro) {
		this.strErro = strErro;
	}

	public String getStrErroTecnica() {
		return strErroTecnica;
	}

	public void setStrErroTecnica(String strErroTecnica) {
		this.strErroTecnica = strErroTecnica;
	}

	public String getIntIdTipoConta() {
		return intIdTipoConta;
	}

	public void setIntIdTipoConta(String intIdTipoConta) {
		this.intIdTipoConta = intIdTipoConta;
	}

	public String getIntIdCanal() {
		return intIdCanal;
	}

	public void setIntIdCanal(String intIdCanal) {
		this.intIdCanal = intIdCanal;
	}

	public String getStrIPAddrCliente() {
		return strIPAddrCliente;
	}

	public void setStrIPAddrCliente(String strIPAddrCliente) {
		this.strIPAddrCliente = strIPAddrCliente;
	}

	public String getStrIPAddrServer() {
		return strIPAddrServer;
	}

	public void setStrIPAddrServer(String strIPAddrServer) {
		this.strIPAddrServer = strIPAddrServer;
	}

	public String getStrOpcao() {
		return strOpcao;
	}

	public void setStrOpcao(String strOpcao) {
		this.strOpcao = strOpcao;
	}

	public String getStrCodISPB() {
		return strCodISPB;
	}

	public void setStrCodISPB(String strCodISPB) {
		this.strCodISPB = strCodISPB;
	}

	public String getStrCodBanco() {
		return strCodBanco;
	}

	public void setStrCodBanco(String strCodBanco) {
		this.strCodBanco = strCodBanco;
	}

}
