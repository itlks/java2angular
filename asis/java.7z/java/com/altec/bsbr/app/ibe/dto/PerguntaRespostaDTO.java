package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class PerguntaRespostaDTO implements Serializable {

	private static final long serialVersionUID = 4415861601246014287L;

	private String hsRandom;
	private String hsQuestion;
	private String hsRabinN;
	private String resposta;
	private String criptResposta;
	private String pergunta;
	private String perguntaHash;
	private String respostaHash;
	
	public PerguntaRespostaDTO() {}

	public String getHsRandom() {
		return hsRandom;
	}

	public void setHsRandom(String hsRandom) {
		this.hsRandom = hsRandom;
	}

	public String getHsQuestion() {
		return hsQuestion;
	}

	public void setHsQuestion(String hsQuestion) {
		this.hsQuestion = hsQuestion;
	}

	public String getHsRabinN() {
		return hsRabinN;
	}

	public void setHsRabinN(String hsRabinN) {
		this.hsRabinN = hsRabinN;
	}

	public String getResposta() {
		return resposta;
	}

	public void setResposta(String resposta) {
		this.resposta = resposta;
	}

	public String getCriptResposta() {
		return criptResposta;
	}

	public void setCriptResposta(String criptResposta) {
		this.criptResposta = criptResposta;
	}

	public String getPergunta() {
		return pergunta;
	}

	public void setPergunta(String pergunta) {
		this.pergunta = pergunta;
	}

	public String getPerguntaHash() {
		return perguntaHash;
	}

	public void setPerguntaHash(String perguntaHash) {
		this.perguntaHash = perguntaHash;
	}

	public String getRespostaHash() {
		return respostaHash;
	}

	public void setRespostaHash(String respostaHash) {
		this.respostaHash = respostaHash;
	}

	
}
