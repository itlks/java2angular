package com.altec.bsbr.app.ibe.enumeration;

public enum ContaCorrenteConsultaTipoLancamentoEnum {
	
	DEPOSITOS ("Dep�sitos"),
	CREDITOS ("Cr�ditos"),
	DEBITOS ("D�bitos"),
	CHEQUES ("Cheques"),
	CHEQUE_N ("Cheque n�:");
	
	private String descricao;
	
	private ContaCorrenteConsultaTipoLancamentoEnum(String descricao) {
		this.descricao = descricao;
	}

	public String getDescricao() {
		return descricao;
	}
	
}