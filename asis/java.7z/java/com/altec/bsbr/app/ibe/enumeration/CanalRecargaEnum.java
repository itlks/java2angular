package com.altec.bsbr.app.ibe.enumeration;

public enum CanalRecargaEnum {
	TFC(1, "TFC", ""),
	IB(6, "Internet Banking", "06"),
	SL(20, "Superlinha", ""),
	AA(21, "Auto-atendimento", ""),
	DESCONHECIDO(99, "Desconhecido", "");
	
	private int id;
	private String descricao;
	private String idBks;

	public int getId() {
		return id;
	}

	public String getDescricao() {
		return descricao;
	}

	private CanalRecargaEnum(int id, String descricao, String idBks) {
		this.id = id;
		this.descricao = descricao;
		this.idBks = idBks;
	}

	public static CanalRecargaEnum findById(Integer id){
		CanalRecargaEnum retorno = null;
		if(id == null || id == 0) retorno = null;
		
		for (CanalRecargaEnum canal: CanalRecargaEnum.values()) {
			if (canal.getId() == id) {
				retorno = canal;
				break;
			}
		}
		if(retorno == null){
			retorno = CanalRecargaEnum.DESCONHECIDO;
		}
		return retorno;
	}

	public String getIdBks() {
		return idBks;
	}

}
