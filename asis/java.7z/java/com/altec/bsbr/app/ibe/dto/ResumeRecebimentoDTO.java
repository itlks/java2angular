package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import com.altec.bsbr.app.ibe.util.UtilFunction;

public class ResumeRecebimentoDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String dtVencimentoTitulo;
	private List<ListaResumoOperDTO> listaResumo;
	private BigDecimal subTotal;
	private String subTotalFormatado;
	
	public String getDtVencimentoTitulo() {
		return dtVencimentoTitulo;
	}
	public void setDtVencimentoTitulo(String dtVencimentoTitulo) {
		this.dtVencimentoTitulo = dtVencimentoTitulo;
	}
	public List<ListaResumoOperDTO> getListaResumo() {
		return listaResumo;
	}
	public void setListaResumo(List<ListaResumoOperDTO> listaResumo) {
		this.listaResumo = listaResumo;
	}
	public BigDecimal getSubTotal() {
		return subTotal;
	}
	public void setSubTotal(BigDecimal subTotal) {
		this.subTotal = subTotal;
	}
	public String getSubTotalFormatado() {
		subTotalFormatado = UtilFunction.convertBigDecimalToStringFormatoBR(subTotal);
		return subTotalFormatado;
	}
	public void setSubTotalFormatado(String subTotalFormatado) {
		this.subTotalFormatado = subTotalFormatado;
	}

}
