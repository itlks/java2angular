package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.altec.bsbr.app.ibe.dto.obterDadosBasicosConta.ContratoBasicoDTO;

public class ComprovanteDetalheDetranDTO extends GenericDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5272398482798315719L;

	private String razaoSocial;
	private String dscdRet;
	private String dstTrans;
	private String dsTpOpe;
	private Date dsDtCon;
	private String dsCanal;
	private String dscMain;
	private String desCota;
	private String dsCtaDb;
	private BigDecimal dsBloqCi;
	private BigDecimal dsBloq24;
	private BigDecimal dsBloq48;
	private BigDecimal dsBloqIn;
	private BigDecimal dsLimit;
	private BigDecimal dsSld;
	private String dsCpmf;
	private String bcoAgen;
	private String desProd;
	private String desSubP;
	private String desCanal;
	private String dtHr; // <dtHr>2016080316:26:49</dtHr>
	private Date datCont; // <dtInf1>2004-12-02</dtInf1>
	private BigDecimal valTot;
	private String nsuBco;
	private String dadCtrl1;
	private String atInf1;
	private Integer numGu1;
	private Integer cdSeg1;
	private String dtInf1;
	private String dtVen1;
	private BigDecimal vlMul1;
	private Integer cdOAt1;
	private String atInf2;
	private Integer numGu2;
	private Integer cdSeg2;
	private String dtInf2;
	private String dtVen2;
	private BigDecimal vlMul2;
	private Integer cdOAt2;
	private String atInf3;
	private Integer numGu3;
	private Integer cdSeg3;
	private String dtInf3;
	private String dtVen3;
	private BigDecimal vlMul3;
	private Integer cdOAt3;
	private String atInf4;
	private Integer numGu4;
	private Integer cdSeg4;
	private String dtInf4;
	private String dtVen4;
	private BigDecimal vlMul4;
	private Integer cdOAt4;
	private String atInf5;
	private Integer numGu5;
	private Integer cdSeg5;
	private String dtInf5;
	private String dtVen5;
	private BigDecimal vlMul5;
	private Integer cdOAt5;
	private String atInf6;
	private Integer numGu6;
	private Integer cdSeg6;
	private String dtInf6;
	private String dtVen6;
	private BigDecimal vlMul6;
	private Integer cdOAt6;
	private String atInf7;
	private Integer numGu7;
	private Integer cdSeg7;
	private String dtInf7;
	private String dtVen7;
	private BigDecimal vlMul7;
	private Integer cdOAt7;
	private String atInf8;
	private Integer numGu8;
	private Integer cdSeg8;
	private String dtInf8;
	private String dtVen8;
	private BigDecimal vlMul8;
	private Integer cdOAt8;
	private String atInf9;
	private Integer numGu9;
	private Integer cdSeg9;
	private String dtInf9;
	private String dtVen9;
	private BigDecimal vlMul9;
	private Integer cdOAt9;
	private String atInf10;
	private Integer numGu10;
	private Integer cdSeg10;
	private String dtInf10;
	private String dtVen10;
	private BigDecimal vlMul10;
	private Integer cdOAt10;
	private String atInf11;
	private Integer numGu11;
	private Integer cdSeg11;
	private String dtInf11;
	private String dtVen11;
	private BigDecimal vlMul11;
	private Integer cdOAt11;
	private String atInf12;
	private Integer numGu12;
	private Integer cdSeg12;
	private String dtInf12;
	private String dtVen12;
	private BigDecimal vlMul12;
	private Integer cdOAt12;
	private String atInf13;
	private Integer numGu13;
	private Integer cdSeg13;
	private String dtInf13;
	private String dtVen13;
	private BigDecimal vlMul13;
	private Integer cdOAt13;
	private String atInf14;
	private Integer numGu14;
	private Integer cdSeg14;
	private String dtInf14;
	private String dtVen14;
	private BigDecimal vlMul14;
	private Integer cdOAt14;
	private String atInf15;
	private Integer numGu15;
	private Integer cdSeg15;
	private String dtInf15;
	private String dtVen15;
	private BigDecimal vlMul15;
	private Integer cdOAt15;
	private ContratoBasicoDTO entCont = new ContratoBasicoDTO();
	private String autBcDg;
	private String autBcDg2;
	private String autDigt;
	private String renava;
	private String placa;
	private Integer exerLic2;
	private String munEst;
	private String munFed;
	private String desMun;
	private String nomProp;
	private Long cpfcNPJ2;
	private BigDecimal taxaLics;
	private BigDecimal taxaTras;
	private BigDecimal taxaCor2;
	private BigDecimal taxa1Res;
	private String ex1Dpvt1;
	private BigDecimal vl1Dpvt1;
	private String ex2Dpvt2;
	private BigDecimal vl2Dpvt2;
	private BigDecimal vl3Dpvt3;
	private Integer nroIpva2;
	private String ex1Ipva1;
	private BigDecimal vl1Ipva1;
	private String ex2Ipva2;
	private BigDecimal vl2Ipva2;
	private String ex3Ipva3;
	private BigDecimal vl3Ipva3;
	private String ex4Ipva4;
	private BigDecimal vl4Ipva4;
	private String ex5Ipva5;
	private BigDecimal vl5Ipva5;
	private BigDecimal vl6Ipva6;
	private BigDecimal vl7Ipva7;
	private String dtVenc1;

	private boolean dtVenc1Inicial;
	private String autDigtFormatada;
	private String cpfcNPJ2Formatado;
	private String bancoFormatado;
	private String contaFormatado;
	private Date dtHrFormatada;
	private BigDecimal vlTotalMulta;
	private BigDecimal vlTotalMultaRenainf;
	private BigDecimal vlTotalIpva;
	private BigDecimal vlTotalDpvat;
	private int nroOcorrMulta;
	private int nroOcorrMultaRenainf;
	private int nroOcorrIpva;
	private int nroOcorrDpvat;
	private List<MultaComprovanteDTO> listaMulta;
	private List<MultaRenainfComprovanteDTO> listaMultaRenainf;
	private List<IpvaComprovanteDTO> listaIpva;
	private List<DpvatComprovanteDTO> listaDpvat;

	public String getDscdRet() {
		return dscdRet;
	}

	public void setDscdRet(String dscdRet) {
		this.dscdRet = dscdRet;
	}

	public String getDstTrans() {
		return dstTrans;
	}

	public void setDstTrans(String dstTrans) {
		this.dstTrans = dstTrans;
	}

	public String getDsTpOpe() {
		return dsTpOpe;
	}

	public void setDsTpOpe(String dsTpOpe) {
		this.dsTpOpe = dsTpOpe;
	}

	public Date getDsDtCon() {
		return dsDtCon;
	}

	public void setDsDtCon(Date dsDtCon) {
		this.dsDtCon = dsDtCon;
	}

	public String getDsCanal() {
		return dsCanal;
	}

	public void setDsCanal(String dsCanal) {
		this.dsCanal = dsCanal;
	}

	public String getDscMain() {
		return dscMain;
	}

	public void setDscMain(String dscMain) {
		this.dscMain = dscMain;
	}

	public String getDsCtaDb() {
		return dsCtaDb;
	}

	public void setDsCtaDb(String dsCtaDb) {
		this.dsCtaDb = dsCtaDb;
	}

	public BigDecimal getDsBloqCi() {
		return dsBloqCi;
	}

	public void setDsBloqCi(BigDecimal dsBloqCi) {
		this.dsBloqCi = dsBloqCi;
	}

	public BigDecimal getDsBloq24() {
		return dsBloq24;
	}

	public void setDsBloq24(BigDecimal dsBloq24) {
		this.dsBloq24 = dsBloq24;
	}

	public BigDecimal getDsBloq48() {
		return dsBloq48;
	}

	public void setDsBloq48(BigDecimal dsBloq48) {
		this.dsBloq48 = dsBloq48;
	}

	public BigDecimal getDsBloqIn() {
		return dsBloqIn;
	}

	public void setDsBloqIn(BigDecimal dsBloqIn) {
		this.dsBloqIn = dsBloqIn;
	}

	public BigDecimal getDsLimit() {
		return dsLimit;
	}

	public void setDsLimit(BigDecimal dsLimit) {
		this.dsLimit = dsLimit;
	}

	public BigDecimal getDsSld() {
		return dsSld;
	}

	public void setDsSld(BigDecimal dsSld) {
		this.dsSld = dsSld;
	}

	public String getDsCpmf() {
		return dsCpmf;
	}

	public void setDsCpmf(String dsCpmf) {
		this.dsCpmf = dsCpmf;
	}

	public String getBcoAgen() {
		return bcoAgen;
	}

	public void setBcoAgen(String bcoAgen) {
		this.bcoAgen = bcoAgen;
	}

	public String getDesProd() {
		return desProd;
	}

	public void setDesProd(String desProd) {
		this.desProd = desProd;
	}

	public String getDesSubP() {
		return desSubP;
	}

	public void setDesSubP(String desSubP) {
		this.desSubP = desSubP;
	}

	public String getDesCanal() {
		return desCanal;
	}

	public void setDesCanal(String desCanal) {
		this.desCanal = desCanal;
	}

	public String getDtHr() {
		return dtHr;
	}

	public void setDtHr(String dtHr) {
		this.dtHr = dtHr;
	}

	public Date getDatCont() {
		return datCont;
	}

	public void setDatCont(Date datCont) {
		this.datCont = datCont;
	}

	public BigDecimal getValTot() {
		return valTot;
	}

	public void setValTot(BigDecimal valTot) {
		this.valTot = valTot;
	}

	public String getNsuBco() {
		return nsuBco;
	}

	public void setNsuBco(String nsuBco) {
		this.nsuBco = nsuBco;
	}

	public String getDadCtrl1() {
		return dadCtrl1;
	}

	public void setDadCtrl1(String dadCtrl1) {
		this.dadCtrl1 = dadCtrl1;
	}

	public String getAtInf1() {
		return atInf1;
	}

	public void setAtInf1(String atInf1) {
		this.atInf1 = atInf1;
	}

	public Integer getNumGu1() {
		return numGu1;
	}

	public void setNumGu1(Integer numGu1) {
		this.numGu1 = numGu1;
	}

	public Integer getCdSeg1() {
		return cdSeg1;
	}

	public void setCdSeg1(Integer cdSeg1) {
		this.cdSeg1 = cdSeg1;
	}

	public String getDtInf1() {
		return dtInf1;
	}

	public void setDtInf1(String dtInf1) {
		this.dtInf1 = dtInf1;
	}

	public String getDtVen1() {
		return dtVen1;
	}

	public void setDtVen1(String dtVen1) {
		this.dtVen1 = dtVen1;
	}

	public BigDecimal getVlMul1() {
		return vlMul1;
	}

	public void setVlMul1(BigDecimal vlMul1) {
		this.vlMul1 = vlMul1;
	}

	public Integer getCdOAt1() {
		return cdOAt1;
	}

	public void setCdOAt1(Integer cdOAt1) {
		this.cdOAt1 = cdOAt1;
	}

	public String getAtInf2() {
		return atInf2;
	}

	public void setAtInf2(String atInf2) {
		this.atInf2 = atInf2;
	}

	public Integer getNumGu2() {
		return numGu2;
	}

	public void setNumGu2(Integer numGu2) {
		this.numGu2 = numGu2;
	}

	public Integer getCdSeg2() {
		return cdSeg2;
	}

	public void setCdSeg2(Integer cdSeg2) {
		this.cdSeg2 = cdSeg2;
	}

	public String getDtInf2() {
		return dtInf2;
	}

	public void setDtInf2(String dtInf2) {
		this.dtInf2 = dtInf2;
	}

	public String getDtVen2() {
		return dtVen2;
	}

	public void setDtVen2(String dtVen2) {
		this.dtVen2 = dtVen2;
	}

	public BigDecimal getVlMul2() {
		return vlMul2;
	}

	public void setVlMul2(BigDecimal vlMul2) {
		this.vlMul2 = vlMul2;
	}

	public Integer getCdOAt2() {
		return cdOAt2;
	}

	public void setCdOAt2(Integer cdOAt2) {
		this.cdOAt2 = cdOAt2;
	}

	public String getAtInf3() {
		return atInf3;
	}

	public void setAtInf3(String atInf3) {
		this.atInf3 = atInf3;
	}

	public Integer getNumGu3() {
		return numGu3;
	}

	public void setNumGu3(Integer numGu3) {
		this.numGu3 = numGu3;
	}

	public Integer getCdSeg3() {
		return cdSeg3;
	}

	public void setCdSeg3(Integer cdSeg3) {
		this.cdSeg3 = cdSeg3;
	}

	public String getDtInf3() {
		return dtInf3;
	}

	public void setDtInf3(String dtInf3) {
		this.dtInf3 = dtInf3;
	}

	public String getDtVen3() {
		return dtVen3;
	}

	public void setDtVen3(String dtVen3) {
		this.dtVen3 = dtVen3;
	}

	public BigDecimal getVlMul3() {
		return vlMul3;
	}

	public void setVlMul3(BigDecimal vlMul3) {
		this.vlMul3 = vlMul3;
	}

	public Integer getCdOAt3() {
		return cdOAt3;
	}

	public void setCdOAt3(Integer cdOAt3) {
		this.cdOAt3 = cdOAt3;
	}

	public String getAtInf4() {
		return atInf4;
	}

	public void setAtInf4(String atInf4) {
		this.atInf4 = atInf4;
	}

	public Integer getNumGu4() {
		return numGu4;
	}

	public void setNumGu4(Integer numGu4) {
		this.numGu4 = numGu4;
	}

	public Integer getCdSeg4() {
		return cdSeg4;
	}

	public void setCdSeg4(Integer cdSeg4) {
		this.cdSeg4 = cdSeg4;
	}

	public String getDtInf4() {
		return dtInf4;
	}

	public void setDtInf4(String dtInf4) {
		this.dtInf4 = dtInf4;
	}

	public String getDtVen4() {
		return dtVen4;
	}

	public void setDtVen4(String dtVen4) {
		this.dtVen4 = dtVen4;
	}

	public BigDecimal getVlMul4() {
		return vlMul4;
	}

	public void setVlMul4(BigDecimal vlMul4) {
		this.vlMul4 = vlMul4;
	}

	public Integer getCdOAt4() {
		return cdOAt4;
	}

	public void setCdOAt4(Integer cdOAt4) {
		this.cdOAt4 = cdOAt4;
	}

	public String getAtInf5() {
		return atInf5;
	}

	public void setAtInf5(String atInf5) {
		this.atInf5 = atInf5;
	}

	public Integer getNumGu5() {
		return numGu5;
	}

	public void setNumGu5(Integer numGu5) {
		this.numGu5 = numGu5;
	}

	public Integer getCdSeg5() {
		return cdSeg5;
	}

	public void setCdSeg5(Integer cdSeg5) {
		this.cdSeg5 = cdSeg5;
	}

	public String getDtInf5() {
		return dtInf5;
	}

	public void setDtInf5(String dtInf5) {
		this.dtInf5 = dtInf5;
	}

	public String getDtVen5() {
		return dtVen5;
	}

	public void setDtVen5(String dtVen5) {
		this.dtVen5 = dtVen5;
	}

	public BigDecimal getVlMul5() {
		return vlMul5;
	}

	public void setVlMul5(BigDecimal vlMul5) {
		this.vlMul5 = vlMul5;
	}

	public Integer getCdOAt5() {
		return cdOAt5;
	}

	public void setCdOAt5(Integer cdOAt5) {
		this.cdOAt5 = cdOAt5;
	}

	public String getAtInf6() {
		return atInf6;
	}

	public void setAtInf6(String atInf6) {
		this.atInf6 = atInf6;
	}

	public Integer getNumGu6() {
		return numGu6;
	}

	public void setNumGu6(Integer numGu6) {
		this.numGu6 = numGu6;
	}

	public Integer getCdSeg6() {
		return cdSeg6;
	}

	public void setCdSeg6(Integer cdSeg6) {
		this.cdSeg6 = cdSeg6;
	}

	public String getDtInf6() {
		return dtInf6;
	}

	public void setDtInf6(String dtInf6) {
		this.dtInf6 = dtInf6;
	}

	public String getDtVen6() {
		return dtVen6;
	}

	public void setDtVen6(String dtVen6) {
		this.dtVen6 = dtVen6;
	}

	public BigDecimal getVlMul6() {
		return vlMul6;
	}

	public void setVlMul6(BigDecimal vlMul6) {
		this.vlMul6 = vlMul6;
	}

	public Integer getCdOAt6() {
		return cdOAt6;
	}

	public void setCdOAt6(Integer cdOAt6) {
		this.cdOAt6 = cdOAt6;
	}

	public String getAtInf7() {
		return atInf7;
	}

	public void setAtInf7(String atInf7) {
		this.atInf7 = atInf7;
	}

	public Integer getNumGu7() {
		return numGu7;
	}

	public void setNumGu7(Integer numGu7) {
		this.numGu7 = numGu7;
	}

	public Integer getCdSeg7() {
		return cdSeg7;
	}

	public void setCdSeg7(Integer cdSeg7) {
		this.cdSeg7 = cdSeg7;
	}

	public String getDtInf7() {
		return dtInf7;
	}

	public void setDtInf7(String dtInf7) {
		this.dtInf7 = dtInf7;
	}

	public String getDtVen7() {
		return dtVen7;
	}

	public void setDtVen7(String dtVen7) {
		this.dtVen7 = dtVen7;
	}

	public BigDecimal getVlMul7() {
		return vlMul7;
	}

	public void setVlMul7(BigDecimal vlMul7) {
		this.vlMul7 = vlMul7;
	}

	public Integer getCdOAt7() {
		return cdOAt7;
	}

	public void setCdOAt7(Integer cdOAt7) {
		this.cdOAt7 = cdOAt7;
	}

	public String getAtInf8() {
		return atInf8;
	}

	public void setAtInf8(String atInf8) {
		this.atInf8 = atInf8;
	}

	public Integer getNumGu8() {
		return numGu8;
	}

	public void setNumGu8(Integer numGu8) {
		this.numGu8 = numGu8;
	}

	public Integer getCdSeg8() {
		return cdSeg8;
	}

	public void setCdSeg8(Integer cdSeg8) {
		this.cdSeg8 = cdSeg8;
	}

	public String getDtInf8() {
		return dtInf8;
	}

	public void setDtInf8(String dtInf8) {
		this.dtInf8 = dtInf8;
	}

	public String getDtVen8() {
		return dtVen8;
	}

	public void setDtVen8(String dtVen8) {
		this.dtVen8 = dtVen8;
	}

	public BigDecimal getVlMul8() {
		return vlMul8;
	}

	public void setVlMul8(BigDecimal vlMul8) {
		this.vlMul8 = vlMul8;
	}

	public Integer getCdOAt8() {
		return cdOAt8;
	}

	public void setCdOAt8(Integer cdOAt8) {
		this.cdOAt8 = cdOAt8;
	}

	public String getAtInf9() {
		return atInf9;
	}

	public void setAtInf9(String atInf9) {
		this.atInf9 = atInf9;
	}

	public Integer getNumGu9() {
		return numGu9;
	}

	public void setNumGu9(Integer numGu9) {
		this.numGu9 = numGu9;
	}

	public Integer getCdSeg9() {
		return cdSeg9;
	}

	public void setCdSeg9(Integer cdSeg9) {
		this.cdSeg9 = cdSeg9;
	}

	public String getDtInf9() {
		return dtInf9;
	}

	public void setDtInf9(String dtInf9) {
		this.dtInf9 = dtInf9;
	}

	public String getDtVen9() {
		return dtVen9;
	}

	public void setDtVen9(String dtVen9) {
		this.dtVen9 = dtVen9;
	}

	public BigDecimal getVlMul9() {
		return vlMul9;
	}

	public void setVlMul9(BigDecimal vlMul9) {
		this.vlMul9 = vlMul9;
	}

	public Integer getCdOAt9() {
		return cdOAt9;
	}

	public void setCdOAt9(Integer cdOAt9) {
		this.cdOAt9 = cdOAt9;
	}

	public String getAtInf10() {
		return atInf10;
	}

	public void setAtInf10(String atInf10) {
		this.atInf10 = atInf10;
	}

	public Integer getNumGu10() {
		return numGu10;
	}

	public void setNumGu10(Integer numGu10) {
		this.numGu10 = numGu10;
	}

	public Integer getCdSeg10() {
		return cdSeg10;
	}

	public void setCdSeg10(Integer cdSeg10) {
		this.cdSeg10 = cdSeg10;
	}

	public String getDtInf10() {
		return dtInf10;
	}

	public void setDtInf10(String dtInf10) {
		this.dtInf10 = dtInf10;
	}

	public String getDtVen10() {
		return dtVen10;
	}

	public void setDtVen10(String dtVen10) {
		this.dtVen10 = dtVen10;
	}

	public BigDecimal getVlMul10() {
		return vlMul10;
	}

	public void setVlMul10(BigDecimal vlMul10) {
		this.vlMul10 = vlMul10;
	}

	public Integer getCdOAt10() {
		return cdOAt10;
	}

	public void setCdOAt10(Integer cdOAt10) {
		this.cdOAt10 = cdOAt10;
	}

	public String getAtInf11() {
		return atInf11;
	}

	public void setAtInf11(String atInf11) {
		this.atInf11 = atInf11;
	}

	public Integer getNumGu11() {
		return numGu11;
	}

	public void setNumGu11(Integer numGu11) {
		this.numGu11 = numGu11;
	}

	public Integer getCdSeg11() {
		return cdSeg11;
	}

	public void setCdSeg11(Integer cdSeg11) {
		this.cdSeg11 = cdSeg11;
	}

	public String getDtInf11() {
		return dtInf11;
	}

	public void setDtInf11(String dtInf11) {
		this.dtInf11 = dtInf11;
	}

	public String getDtVen11() {
		return dtVen11;
	}

	public void setDtVen11(String dtVen11) {
		this.dtVen11 = dtVen11;
	}

	public BigDecimal getVlMul11() {
		return vlMul11;
	}

	public void setVlMul11(BigDecimal vlMul11) {
		this.vlMul11 = vlMul11;
	}

	public Integer getCdOAt11() {
		return cdOAt11;
	}

	public void setCdOAt11(Integer cdOAt11) {
		this.cdOAt11 = cdOAt11;
	}

	public String getAtInf12() {
		return atInf12;
	}

	public void setAtInf12(String atInf12) {
		this.atInf12 = atInf12;
	}

	public Integer getNumGu12() {
		return numGu12;
	}

	public void setNumGu12(Integer numGu12) {
		this.numGu12 = numGu12;
	}

	public Integer getCdSeg12() {
		return cdSeg12;
	}

	public void setCdSeg12(Integer cdSeg12) {
		this.cdSeg12 = cdSeg12;
	}

	public String getDtInf12() {
		return dtInf12;
	}

	public void setDtInf12(String dtInf12) {
		this.dtInf12 = dtInf12;
	}

	public String getDtVen12() {
		return dtVen12;
	}

	public void setDtVen12(String dtVen12) {
		this.dtVen12 = dtVen12;
	}

	public BigDecimal getVlMul12() {
		return vlMul12;
	}

	public void setVlMul12(BigDecimal vlMul12) {
		this.vlMul12 = vlMul12;
	}

	public Integer getCdOAt12() {
		return cdOAt12;
	}

	public void setCdOAt12(Integer cdOAt12) {
		this.cdOAt12 = cdOAt12;
	}

	public String getAtInf13() {
		return atInf13;
	}

	public void setAtInf13(String atInf13) {
		this.atInf13 = atInf13;
	}

	public Integer getNumGu13() {
		return numGu13;
	}

	public void setNumGu13(Integer numGu13) {
		this.numGu13 = numGu13;
	}

	public Integer getCdSeg13() {
		return cdSeg13;
	}

	public void setCdSeg13(Integer cdSeg13) {
		this.cdSeg13 = cdSeg13;
	}

	public String getDtInf13() {
		return dtInf13;
	}

	public void setDtInf13(String dtInf13) {
		this.dtInf13 = dtInf13;
	}

	public String getDtVen13() {
		return dtVen13;
	}

	public void setDtVen13(String dtVen13) {
		this.dtVen13 = dtVen13;
	}

	public BigDecimal getVlMul13() {
		return vlMul13;
	}

	public void setVlMul13(BigDecimal vlMul13) {
		this.vlMul13 = vlMul13;
	}

	public Integer getCdOAt13() {
		return cdOAt13;
	}

	public void setCdOAt13(Integer cdOAt13) {
		this.cdOAt13 = cdOAt13;
	}

	public String getAtInf14() {
		return atInf14;
	}

	public void setAtInf14(String atInf14) {
		this.atInf14 = atInf14;
	}

	public Integer getNumGu14() {
		return numGu14;
	}

	public void setNumGu14(Integer numGu14) {
		this.numGu14 = numGu14;
	}

	public Integer getCdSeg14() {
		return cdSeg14;
	}

	public void setCdSeg14(Integer cdSeg14) {
		this.cdSeg14 = cdSeg14;
	}

	public String getDtInf14() {
		return dtInf14;
	}

	public void setDtInf14(String dtInf14) {
		this.dtInf14 = dtInf14;
	}

	public String getDtVen14() {
		return dtVen14;
	}

	public void setDtVen14(String dtVen14) {
		this.dtVen14 = dtVen14;
	}

	public BigDecimal getVlMul14() {
		return vlMul14;
	}

	public void setVlMul14(BigDecimal vlMul14) {
		this.vlMul14 = vlMul14;
	}

	public Integer getCdOAt14() {
		return cdOAt14;
	}

	public void setCdOAt14(Integer cdOAt14) {
		this.cdOAt14 = cdOAt14;
	}

	public String getAtInf15() {
		return atInf15;
	}

	public void setAtInf15(String atInf15) {
		this.atInf15 = atInf15;
	}

	public Integer getNumGu15() {
		return numGu15;
	}

	public void setNumGu15(Integer numGu15) {
		this.numGu15 = numGu15;
	}

	public Integer getCdSeg15() {
		return cdSeg15;
	}

	public void setCdSeg15(Integer cdSeg15) {
		this.cdSeg15 = cdSeg15;
	}

	public String getDtInf15() {
		return dtInf15;
	}

	public void setDtInf15(String dtInf15) {
		this.dtInf15 = dtInf15;
	}

	public String getDtVen15() {
		return dtVen15;
	}

	public void setDtVen15(String dtVen15) {
		this.dtVen15 = dtVen15;
	}

	public BigDecimal getVlMul15() {
		return vlMul15;
	}

	public void setVlMul15(BigDecimal vlMul15) {
		this.vlMul15 = vlMul15;
	}

	public Integer getCdOAt15() {
		return cdOAt15;
	}

	public void setCdOAt15(Integer cdOAt15) {
		this.cdOAt15 = cdOAt15;
	}

	public ContratoBasicoDTO getEntCont() {
		return entCont;
	}

	public void setEntCont(ContratoBasicoDTO entCont) {
		this.entCont = entCont;
	}

	public String getAutBcDg2() {
		return autBcDg2;
	}

	public void setAutBcDg2(String autBcDg2) {
		this.autBcDg2 = autBcDg2;
	}

	public String getAutDigt() {
		return autDigt;
	}

	public void setAutDigt(String autDigt) {
		this.autDigt = autDigt;
	}

	public String getRenava() {
		return renava;
	}

	public void setRenava(String renava) {
		this.renava = renava;
	}

	public String getPlaca() {
		return placa;
	}

	public void setPlaca(String placa) {
		this.placa = placa;
	}

	public Integer getExerLic2() {
		return exerLic2;
	}

	public void setExerLic2(Integer exerLic2) {
		this.exerLic2 = exerLic2;
	}

	public String getMunEst() {
		return munEst;
	}

	public void setMunEst(String munEst) {
		this.munEst = munEst;
	}

	public String getMunFed() {
		return munFed;
	}

	public void setMunFed(String munFed) {
		this.munFed = munFed;
	}

	public String getDesMun() {
		return desMun;
	}

	public void setDesMun(String desMun) {
		this.desMun = desMun;
	}

	public String getNomProp() {
		return nomProp;
	}

	public void setNomProp(String nomProp) {
		this.nomProp = nomProp;
	}

	public Long getCpfcNPJ2() {
		return cpfcNPJ2;
	}

	public void setCpfcNPJ2(Long cpfcNPJ2) {
		this.cpfcNPJ2 = cpfcNPJ2;
	}

	public BigDecimal getTaxaLics() {
		return taxaLics;
	}

	public void setTaxaLics(BigDecimal taxaLics) {
		this.taxaLics = taxaLics;
	}

	public BigDecimal getTaxaTras() {
		return taxaTras;
	}

	public void setTaxaTras(BigDecimal taxaTras) {
		this.taxaTras = taxaTras;
	}

	public BigDecimal getTaxaCor2() {
		return taxaCor2;
	}

	public void setTaxaCor2(BigDecimal taxaCor2) {
		this.taxaCor2 = taxaCor2;
	}

	public BigDecimal getTaxa1Res() {
		return taxa1Res;
	}

	public void setTaxa1Res(BigDecimal taxa1Res) {
		this.taxa1Res = taxa1Res;
	}

	public String getEx1Dpvt1() {
		return ex1Dpvt1;
	}

	public void setEx1Dpvt1(String ex1Dpvt1) {
		this.ex1Dpvt1 = ex1Dpvt1;
	}

	public BigDecimal getVl1Dpvt1() {
		return vl1Dpvt1;
	}

	public void setVl1Dpvt1(BigDecimal vl1Dpvt1) {
		this.vl1Dpvt1 = vl1Dpvt1;
	}

	public String getEx2Dpvt2() {
		return ex2Dpvt2;
	}

	public void setEx2Dpvt2(String ex2Dpvt2) {
		this.ex2Dpvt2 = ex2Dpvt2;
	}

	public BigDecimal getVl2Dpvt2() {
		return vl2Dpvt2;
	}

	public void setVl2Dpvt2(BigDecimal vl2Dpvt2) {
		this.vl2Dpvt2 = vl2Dpvt2;
	}

	public BigDecimal getVl3Dpvt3() {
		return vl3Dpvt3;
	}

	public void setVl3Dpvt3(BigDecimal vl3Dpvt3) {
		this.vl3Dpvt3 = vl3Dpvt3;
	}

	public Integer getNroIpva2() {
		return nroIpva2;
	}

	public void setNroIpva2(Integer nroIpva2) {
		this.nroIpva2 = nroIpva2;
	}

	public String getEx1Ipva1() {
		return ex1Ipva1;
	}

	public void setEx1Ipva1(String ex1Ipva1) {
		this.ex1Ipva1 = ex1Ipva1;
	}

	public BigDecimal getVl1Ipva1() {
		return vl1Ipva1;
	}

	public void setVl1Ipva1(BigDecimal vl1Ipva1) {
		this.vl1Ipva1 = vl1Ipva1;
	}

	public String getEx2Ipva2() {
		return ex2Ipva2;
	}

	public void setEx2Ipva2(String ex2Ipva2) {
		this.ex2Ipva2 = ex2Ipva2;
	}

	public BigDecimal getVl2Ipva2() {
		return vl2Ipva2;
	}

	public void setVl2Ipva2(BigDecimal vl2Ipva2) {
		this.vl2Ipva2 = vl2Ipva2;
	}

	public String getEx3Ipva3() {
		return ex3Ipva3;
	}

	public void setEx3Ipva3(String ex3Ipva3) {
		this.ex3Ipva3 = ex3Ipva3;
	}

	public BigDecimal getVl3Ipva3() {
		return vl3Ipva3;
	}

	public void setVl3Ipva3(BigDecimal vl3Ipva3) {
		this.vl3Ipva3 = vl3Ipva3;
	}

	public String getEx4Ipva4() {
		return ex4Ipva4;
	}

	public void setEx4Ipva4(String ex4Ipva4) {
		this.ex4Ipva4 = ex4Ipva4;
	}

	public BigDecimal getVl4Ipva4() {
		return vl4Ipva4;
	}

	public void setVl4Ipva4(BigDecimal vl4Ipva4) {
		this.vl4Ipva4 = vl4Ipva4;
	}

	public String getEx5Ipva5() {
		return ex5Ipva5;
	}

	public void setEx5Ipva5(String ex5Ipva5) {
		this.ex5Ipva5 = ex5Ipva5;
	}

	public BigDecimal getVl5Ipva5() {
		return vl5Ipva5;
	}

	public void setVl5Ipva5(BigDecimal vl5Ipva5) {
		this.vl5Ipva5 = vl5Ipva5;
	}

	public BigDecimal getVl6Ipva6() {
		return vl6Ipva6;
	}

	public void setVl6Ipva6(BigDecimal vl6Ipva6) {
		this.vl6Ipva6 = vl6Ipva6;
	}

	public BigDecimal getVl7Ipva7() {
		return vl7Ipva7;
	}

	public void setVl7Ipva7(BigDecimal vl7Ipva7) {
		this.vl7Ipva7 = vl7Ipva7;
	}

	public String getDtVenc1() {
		return dtVenc1;
	}

	public void setDtVenc1(String dtVenc1) {
		this.dtVenc1 = dtVenc1;
	}

	public String getCpfcNPJ2Formatado() {
		return cpfcNPJ2Formatado;
	}

	public void setCpfcNPJ2Formatado(String cpfcNPJ2Formatado) {
		this.cpfcNPJ2Formatado = cpfcNPJ2Formatado;
	}

	public String getContaFormatado() {
		return contaFormatado;
	}

	public void setContaFormatado(String contaFormatado) {
		this.contaFormatado = contaFormatado;
	}

	public Date getDtHrFormatada() {
		return dtHrFormatada;
	}

	public void setDtHrFormatada(Date dtHrFormatada) {
		this.dtHrFormatada = dtHrFormatada;
	}

	public String getRazaoSocial() {
		return razaoSocial;
	}

	public void setRazaoSocial(String razaoSocial) {
		this.razaoSocial = razaoSocial;
	}

	public String getAutDigtFormatada() {
		return autDigtFormatada;
	}

	public void setAutDigtFormatada(String autDigtFormatada) {
		this.autDigtFormatada = autDigtFormatada;
	}

	public String getBancoFormatado() {
		return bancoFormatado;
	}

	public void setBancoFormatado(String bancoFormatado) {
		this.bancoFormatado = bancoFormatado;
	}

	public BigDecimal getVlTotalMulta() {
		return vlTotalMulta;
	}

	public void setVlTotalMulta(BigDecimal vlTotalMulta) {
		this.vlTotalMulta = vlTotalMulta;
	}

	public BigDecimal getVlTotalIpva() {
		return vlTotalIpva;
	}

	public void setVlTotalIpva(BigDecimal vlTotalIpva) {
		this.vlTotalIpva = vlTotalIpva;
	}

	public BigDecimal getVlTotalDpvat() {
		return vlTotalDpvat;
	}

	public void setVlTotalDpvat(BigDecimal vlTotalDpvat) {
		this.vlTotalDpvat = vlTotalDpvat;
	}

	public int getNroOcorrMulta() {
		return nroOcorrMulta;
	}

	public void setNroOcorrMulta(int nroOcorrMulta) {
		this.nroOcorrMulta = nroOcorrMulta;
	}

	public int getNroOcorrIpva() {
		return nroOcorrIpva;
	}

	public void setNroOcorrIpva(int nroOcorrIpva) {
		this.nroOcorrIpva = nroOcorrIpva;
	}

	public int getNroOcorrDpvat() {
		return nroOcorrDpvat;
	}

	public void setNroOcorrDpvat(int nroOcorrDpvat) {
		this.nroOcorrDpvat = nroOcorrDpvat;
	}

	public List<MultaComprovanteDTO> getListaMulta() {
		return listaMulta;
	}

	public void setListaMulta(List<MultaComprovanteDTO> listaMulta) {
		this.listaMulta = listaMulta;
	}

	public List<IpvaComprovanteDTO> getListaIpva() {
		return listaIpva;
	}

	public void setListaIpva(List<IpvaComprovanteDTO> listaIpva) {
		this.listaIpva = listaIpva;
	}

	public List<DpvatComprovanteDTO> getListaDpvat() {
		return listaDpvat;
	}

	public void setListaDpvat(List<DpvatComprovanteDTO> listaDpvat) {
		this.listaDpvat = listaDpvat;
	}

	public String getDesCota() {
		return desCota;
	}

	public void setDesCota(String desCota) {
		this.desCota = desCota;
	}

	public boolean isDtVenc1Inicial() {
		return dtVenc1Inicial;
	}

	public void setDtVenc1Inicial(boolean dtVenc1Inicial) {
		this.dtVenc1Inicial = dtVenc1Inicial;
	}

	public BigDecimal getVlTotalMultaRenainf() {
		return vlTotalMultaRenainf;
	}

	public void setVlTotalMultaRenainf(BigDecimal vlTotalMultaRenainf) {
		this.vlTotalMultaRenainf = vlTotalMultaRenainf;
	}

	public int getNroOcorrMultaRenainf() {
		return nroOcorrMultaRenainf;
	}

	public void setNroOcorrMultaRenainf(int nroOcorrMultaRenainf) {
		this.nroOcorrMultaRenainf = nroOcorrMultaRenainf;
	}

	public List<MultaRenainfComprovanteDTO> getListaMultaRenainf() {
		return listaMultaRenainf;
	}

	public void setListaMultaRenainf(List<MultaRenainfComprovanteDTO> listaMultaRenainf) {
		this.listaMultaRenainf = listaMultaRenainf;
	}

	public String getAutBcDg() {
		return autBcDg;
	}

	public void setAutBcDg(String autBcDg) {
		this.autBcDg = autBcDg;
	}
}
