package com.altec.bsbr.app.ibe.dto;

import java.util.ArrayList;
import java.util.List;

import javax.xml.datatype.XMLGregorianCalendar;

public class ConsultabgEFCbCBConsTalCheDTO {

    private String codigoMensajeOk;
    private String descErro;
    private String banco;
    private String centroCont;
    private String codigotrxAltair;
    private String tipoDeOperacao;
    private XMLGregorianCalendar fechaco;
    private String codigoDoCanal;
    private String referOper;
    private String meiodePagto;
    private String chvTrx;
    private String referEs;
    private XMLGregorianCalendar dtOrig;
    private XMLGregorianCalendar hrOrig;
    private String codCli;
    private String indAgen;
    private Integer numAute;
    private String tpModul;
    private Integer tpTermi;
    private Integer numPab;
    private Integer versao;
    private Integer numTerm;
    private String siglaUs;
    private Integer numOper;
    private Integer mtrOper;
    private Integer numSupe;
    private Integer mtrSup;
    private String macMsg;
    private String pan;
    private String panCont;
    private String tipoCta;
    private String dadosca;
    private String debitos;
    private Integer itempag;
    
    private String entidadbr;
    private String sucursalbr;
    private String nrocuentabr;
    
    private List<ConsultaChequeDesbloquearTaloesDTO> consultaChequeDesbloquearTaloes = new ArrayList<ConsultaChequeDesbloquearTaloesDTO>();

	public String getCodigoMensajeOk() {
		return codigoMensajeOk;
	}

	public void setCodigoMensajeOk(String codigoMensajeOk) {
		this.codigoMensajeOk = codigoMensajeOk;
	}

	public String getDescErro() {
		return descErro;
	}

	public void setDescErro(String descErro) {
		this.descErro = descErro;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getCentroCont() {
		return centroCont;
	}

	public void setCentroCont(String centroCont) {
		this.centroCont = centroCont;
	}

	public String getCodigotrxAltair() {
		return codigotrxAltair;
	}

	public void setCodigotrxAltair(String codigotrxAltair) {
		this.codigotrxAltair = codigotrxAltair;
	}

	public String getTipoDeOperacao() {
		return tipoDeOperacao;
	}

	public void setTipoDeOperacao(String tipoDeOperacao) {
		this.tipoDeOperacao = tipoDeOperacao;
	}

	public XMLGregorianCalendar getFechaco() {
		return fechaco;
	}

	public void setFechaco(XMLGregorianCalendar fechaco) {
		this.fechaco = fechaco;
	}

	public String getCodigoDoCanal() {
		return codigoDoCanal;
	}

	public void setCodigoDoCanal(String codigoDoCanal) {
		this.codigoDoCanal = codigoDoCanal;
	}

	public String getReferOper() {
		return referOper;
	}

	public void setReferOper(String referOper) {
		this.referOper = referOper;
	}

	public String getMeiodePagto() {
		return meiodePagto;
	}

	public void setMeiodePagto(String meiodePagto) {
		this.meiodePagto = meiodePagto;
	}

	public String getChvTrx() {
		return chvTrx;
	}

	public void setChvTrx(String chvTrx) {
		this.chvTrx = chvTrx;
	}

	public String getReferEs() {
		return referEs;
	}

	public void setReferEs(String referEs) {
		this.referEs = referEs;
	}

	public XMLGregorianCalendar getDtOrig() {
		return dtOrig;
	}

	public void setDtOrig(XMLGregorianCalendar dtOrig) {
		this.dtOrig = dtOrig;
	}

	public XMLGregorianCalendar getHrOrig() {
		return hrOrig;
	}

	public void setHrOrig(XMLGregorianCalendar hrOrig) {
		this.hrOrig = hrOrig;
	}

	public String getCodCli() {
		return codCli;
	}

	public void setCodCli(String codCli) {
		this.codCli = codCli;
	}

	public String getIndAgen() {
		return indAgen;
	}

	public void setIndAgen(String indAgen) {
		this.indAgen = indAgen;
	}

	public Integer getNumAute() {
		return numAute;
	}

	public void setNumAute(Integer numAute) {
		this.numAute = numAute;
	}

	public String getTpModul() {
		return tpModul;
	}

	public void setTpModul(String tpModul) {
		this.tpModul = tpModul;
	}

	public Integer getTpTermi() {
		return tpTermi;
	}

	public void setTpTermi(Integer tpTermi) {
		this.tpTermi = tpTermi;
	}

	public Integer getNumPab() {
		return numPab;
	}

	public void setNumPab(Integer numPab) {
		this.numPab = numPab;
	}

	public Integer getVersao() {
		return versao;
	}

	public void setVersao(Integer versao) {
		this.versao = versao;
	}

	public Integer getNumTerm() {
		return numTerm;
	}

	public void setNumTerm(Integer numTerm) {
		this.numTerm = numTerm;
	}

	public String getSiglaUs() {
		return siglaUs;
	}

	public void setSiglaUs(String siglaUs) {
		this.siglaUs = siglaUs;
	}

	public Integer getNumOper() {
		return numOper;
	}

	public void setNumOper(Integer numOper) {
		this.numOper = numOper;
	}

	public Integer getMtrOper() {
		return mtrOper;
	}

	public void setMtrOper(Integer mtrOper) {
		this.mtrOper = mtrOper;
	}

	public Integer getNumSupe() {
		return numSupe;
	}

	public void setNumSupe(Integer numSupe) {
		this.numSupe = numSupe;
	}

	public Integer getMtrSup() {
		return mtrSup;
	}

	public void setMtrSup(Integer mtrSup) {
		this.mtrSup = mtrSup;
	}

	public String getMacMsg() {
		return macMsg;
	}

	public void setMacMsg(String macMsg) {
		this.macMsg = macMsg;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getPanCont() {
		return panCont;
	}

	public void setPanCont(String panCont) {
		this.panCont = panCont;
	}

	public String getTipoCta() {
		return tipoCta;
	}

	public void setTipoCta(String tipoCta) {
		this.tipoCta = tipoCta;
	}

	public String getDadosca() {
		return dadosca;
	}

	public void setDadosca(String dadosca) {
		this.dadosca = dadosca;
	}

	public String getDebitos() {
		return debitos;
	}

	public void setDebitos(String debitos) {
		this.debitos = debitos;
	}

	public Integer getItempag() {
		return itempag;
	}

	public void setItempag(Integer itempag) {
		this.itempag = itempag;
	}

	public String getEntidadbr() {
		return entidadbr;
	}

	public void setEntidadbr(String entidadbr) {
		this.entidadbr = entidadbr;
	}

	public String getSucursalbr() {
		return sucursalbr;
	}

	public void setSucursalbr(String sucursalbr) {
		this.sucursalbr = sucursalbr;
	}

	public String getNrocuentabr() {
		return nrocuentabr;
	}

	public void setNrocuentabr(String nrocuentabr) {
		this.nrocuentabr = nrocuentabr;
	}

	public List<ConsultaChequeDesbloquearTaloesDTO> getConsultaChequeDesbloquearTaloes() {
		return consultaChequeDesbloquearTaloes;
	}

	public void setConsultaChequeDesbloquearTaloes(
			List<ConsultaChequeDesbloquearTaloesDTO> consultaChequeDesbloquearTaloes) {
		this.consultaChequeDesbloquearTaloes = consultaChequeDesbloquearTaloes;
	}
    
}