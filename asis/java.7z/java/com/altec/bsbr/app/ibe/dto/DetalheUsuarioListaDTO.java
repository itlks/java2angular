package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class DetalheUsuarioListaDTO implements Serializable {
	
private static final long serialVersionUID = 1L;
	
	private String nomeUsuarioInclusao;	

	private Integer codigoUsuarioPRVS;

	private String nomeLogin;

	private String nomeUsuario;

	private String nomeArea;

	private Integer numeroCPF;

	private String flagAcessoMobile;

	private String codigoBanco;

	private String codigoAgencia;

	private Integer numeroConta;

	private Integer nrSeqPefilAcessoSecundario;

	private String nomePefilAcesso;

	private Integer nrSeqPefilAutorizacaoSecundario;

	private String nomePefilAutorizacao;

	private Integer codigoDDDTelefoneFixo;

	private Integer numeroTelefoneFixo;

	private Integer codigoDDDTelefoneCelular;

	private Integer numeroTelefoneCelular;

	private String codigoSituacaoCelular;
	
	public DetalheUsuarioListaDTO() {}
	
	/**
	 * @return the nomeUsuarioInclusao
	 */
	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	/**
	 * @param nomeUsuarioInclusao the nomeUsuarioInclusao to set
	 */
	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	/**
	 * @return the codigoUsuarioPRVS
	 */
	public Integer getCodigoUsuarioPRVS() {
		return codigoUsuarioPRVS;
	}

	/**
	 * @param codigoUsuarioPRVS the codigoUsuarioPRVS to set
	 */
	public void setCodigoUsuarioPRVS(Integer codigoUsuarioPRVS) {
		this.codigoUsuarioPRVS = codigoUsuarioPRVS;
	}

	/**
	 * @return the nomeLogin
	 */
	public String getNomeLogin() {
		return nomeLogin;
	}

	/**
	 * @param nomeLogin the nomeLogin to set
	 */
	public void setNomeLogin(String nomeLogin) {
		this.nomeLogin = nomeLogin;
	}

	/**
	 * @return the nomeUsuario
	 */
	public String getNomeUsuario() {
		return nomeUsuario;
	}

	/**
	 * @param nomeUsuario the nomeUsuario to set
	 */
	public void setNomeUsuario(String nomeUsuario) {
		this.nomeUsuario = nomeUsuario;
	}

	/**
	 * @return the nomeArea
	 */
	public String getNomeArea() {
		return nomeArea;
	}

	/**
	 * @param nomeArea the nomeArea to set
	 */
	public void setNomeArea(String nomeArea) {
		this.nomeArea = nomeArea;
	}

	/**
	 * @return the numeroCPF
	 */
	public Integer getNumeroCPF() {
		return numeroCPF;
	}

	/**
	 * @param numeroCPF the numeroCPF to set
	 */
	public void setNumeroCPF(Integer numeroCPF) {
		this.numeroCPF = numeroCPF;
	}

	/**
	 * @return the flagAcessoMobile
	 */
	public String getFlagAcessoMobile() {
		return flagAcessoMobile;
	}

	/**
	 * @param flagAcessoMobile the flagAcessoMobile to set
	 */
	public void setFlagAcessoMobile(String flagAcessoMobile) {
		this.flagAcessoMobile = flagAcessoMobile;
	}

	/**
	 * @return the codigoBanco
	 */
	public String getCodigoBanco() {
		return codigoBanco;
	}

	/**
	 * @param codigoBanco the codigoBanco to set
	 */
	public void setCodigoBanco(String codigoBanco) {
		this.codigoBanco = codigoBanco;
	}

	/**
	 * @return the codigoAgencia
	 */
	public String getCodigoAgencia() {
		return codigoAgencia;
	}

	/**
	 * @param codigoAgencia the codigoAgencia to set
	 */
	public void setCodigoAgencia(String codigoAgencia) {
		this.codigoAgencia = codigoAgencia;
	}

	/**
	 * @return the numeroConta
	 */
	public Integer getNumeroConta() {
		return numeroConta;
	}

	/**
	 * @param numeroConta the numeroConta to set
	 */
	public void setNumeroConta(Integer numeroConta) {
		this.numeroConta = numeroConta;
	}

	/**
	 * @return the nrSeqPefilAcessoSecundario
	 */
	public Integer getNrSeqPefilAcessoSecundario() {
		return nrSeqPefilAcessoSecundario;
	}

	/**
	 * @param nrSeqPefilAcessoSecundario the nrSeqPefilAcessoSecundario to set
	 */
	public void setNrSeqPefilAcessoSecundario(Integer nrSeqPefilAcessoSecundario) {
		this.nrSeqPefilAcessoSecundario = nrSeqPefilAcessoSecundario;
	}

	/**
	 * @return the nomePefilAcesso
	 */
	public String getNomePefilAcesso() {
		return nomePefilAcesso;
	}

	/**
	 * @param nomePefilAcesso the nomePefilAcesso to set
	 */
	public void setNomePefilAcesso(String nomePefilAcesso) {
		this.nomePefilAcesso = nomePefilAcesso;
	}

	/**
	 * @return the nrSeqPefilAutorizacaoSecundario
	 */
	public Integer getNrSeqPefilAutorizacaoSecundario() {
		return nrSeqPefilAutorizacaoSecundario;
	}

	/**
	 * @param nrSeqPefilAutorizacaoSecundario the nrSeqPefilAutorizacaoSecundario to set
	 */
	public void setNrSeqPefilAutorizacaoSecundario(Integer nrSeqPefilAutorizacaoSecundario) {
		this.nrSeqPefilAutorizacaoSecundario = nrSeqPefilAutorizacaoSecundario;
	}

	/**
	 * @return the nomePefilAutorizacao
	 */
	public String getNomePefilAutorizacao() {
		return nomePefilAutorizacao;
	}

	/**
	 * @param nomePefilAutorizacao the nomePefilAutorizacao to set
	 */
	public void setNomePefilAutorizacao(String nomePefilAutorizacao) {
		this.nomePefilAutorizacao = nomePefilAutorizacao;
	}

	/**
	 * @return the codigoDDDTelefoneFixo
	 */
	public Integer getCodigoDDDTelefoneFixo() {
		return codigoDDDTelefoneFixo;
	}

	/**
	 * @param codigoDDDTelefoneFixo the codigoDDDTelefoneFixo to set
	 */
	public void setCodigoDDDTelefoneFixo(Integer codigoDDDTelefoneFixo) {
		this.codigoDDDTelefoneFixo = codigoDDDTelefoneFixo;
	}

	/**
	 * @return the numeroTelefoneFixo
	 */
	public Integer getNumeroTelefoneFixo() {
		return numeroTelefoneFixo;
	}

	/**
	 * @param numeroTelefoneFixo the numeroTelefoneFixo to set
	 */
	public void setNumeroTelefoneFixo(Integer numeroTelefoneFixo) {
		this.numeroTelefoneFixo = numeroTelefoneFixo;
	}

	/**
	 * @return the codigoDDDTelefoneCelular
	 */
	public Integer getCodigoDDDTelefoneCelular() {
		return codigoDDDTelefoneCelular;
	}

	/**
	 * @param codigoDDDTelefoneCelular the codigoDDDTelefoneCelular to set
	 */
	public void setCodigoDDDTelefoneCelular(Integer codigoDDDTelefoneCelular) {
		this.codigoDDDTelefoneCelular = codigoDDDTelefoneCelular;
	}

	/**
	 * @return the numeroTelefoneCelular
	 */
	public Integer getNumeroTelefoneCelular() {
		return numeroTelefoneCelular;
	}

	/**
	 * @param numeroTelefoneCelular the numeroTelefoneCelular to set
	 */
	public void setNumeroTelefoneCelular(Integer numeroTelefoneCelular) {
		this.numeroTelefoneCelular = numeroTelefoneCelular;
	}

	/**
	 * @return the codigoSituacaoCelular
	 */
	public String getCodigoSituacaoCelular() {
		return codigoSituacaoCelular;
	}

	/**
	 * @param codigoSituacaoCelular the codigoSituacaoCelular to set
	 */
	public void setCodigoSituacaoCelular(String codigoSituacaoCelular) {
		this.codigoSituacaoCelular = codigoSituacaoCelular;
	}
		

}
