package com.altec.bsbr.app.ibe.dto;

public class TrocaContaDTO {

	private Integer id;
	private String banco;
	private String agencia;
	private String contaCorrente;
	private String idUsuario;
	private String nomeTitular;
	private String origem;
	private String tipoAssociado;

	public TrocaContaDTO() {
		/* Construtor */
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getContaCorrente() {
		return contaCorrente;
	}

	public void setContaCorrente(String contaCorrente) {
		this.contaCorrente = contaCorrente;
	}

	public String getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(String idUsuario) {
		this.idUsuario = idUsuario;
	}

	public String getNomeTitular() {
		return nomeTitular;
	}

	public void setNomeTitular(String nomeTitular) {
		this.nomeTitular = nomeTitular;
	}

	public String getOrigem() {
		return origem;
	}

	public void setOrigem(String origem) {
		this.origem = origem;
	}

	public String getTipoAssociado() {
		return tipoAssociado;
	}

	public void setTipoAssociado(String tipoAssociado) {
		this.tipoAssociado = tipoAssociado;
	}

}
