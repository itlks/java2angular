package com.altec.bsbr.app.ibe.dto;

import java.util.ArrayList;
import java.util.List;

public class UsuarioMBS {
	private String sigla;
	private String nome;
	private String matricula;
	private String tipoRecurso;
	private boolean bPerfil;
	private List <String> perfis = new ArrayList<String>();
	
	public String getSigla() {
		return sigla;
	}
	public void setSigla(String sigla) {
		this.sigla = sigla;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getMatricula() {
		return matricula;
	}
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	public String getTipoRecurso() {
		return tipoRecurso;
	}
	public void setTipoRecurso(String tipoRecurso) {
		this.tipoRecurso = tipoRecurso;
	}
	public boolean isbPerfil() {
		return bPerfil;
	}
	public void setbPerfil(boolean bPerfil) {
		this.bPerfil = bPerfil;
	}
	public List<String> getPerfis() {
		return perfis;
	}
	public void setPerfis(List<String> perfis) {
		this.perfis = perfis;
	}

	public boolean isPerfilAdministrador(){
		return perfis.contains("SPS-ADMIN");
	}
	
	public boolean isPerfilUsuario(){
		return perfis.contains("SPS-USUARIO");
	}
}
