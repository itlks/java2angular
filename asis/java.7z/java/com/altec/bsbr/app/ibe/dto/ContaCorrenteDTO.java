package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;



public class ContaCorrenteDTO implements Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
  
	private String coCamiPagina;       

	
	
	public String getCoCamiPagina() {
		return coCamiPagina;
	}
	public void setCoCamiPagina(String coCamiPagina) {
		this.coCamiPagina = coCamiPagina;
	}


	
}
