package com.altec.bsbr.app.ibe.dto;

import java.util.Date;

public class TransferenciaSegundaViaDadosComprovanteRelacaoDTO {

	private int idTabela;
	private String chave;
	private String favorecido;
	private Date dataPagamento;
	private String valor;
	private boolean selecionado;
	
	
	private String agenciaOrigemINF;
	private String contaOrigemINF;
	private String contaOrigemDeb;
	private String agenciaDestinoINF;
	private String contaDestinoCredito;
	private String origemTransacao;
	private String indiceRelacionamento;
	private String cpf;
	
	private String hora;
	private String idLancamento;
	private String autenticacao;
	private String tipoTransferencia;
	private String nomeTitularConta;
	/**
	 * @return the chave
	 */
	public String getChave() {
		return chave;
	}

	/**
	 * @param chave
	 *            the chave to set
	 */
	public void setChave(String chave) {
		this.chave = chave;
	}

	/**
	 * @return the favorecido
	 */
	public String getFavorecido() {
		return favorecido;
	}

	/**
	 * @param favorecido
	 *            the favorecido to set
	 */
	public void setFavorecido(String favorecido) {
		this.favorecido = favorecido;
	}

	/**
	 * @return the dataPagamento
	 */
	public Date getDataPagamento() {
		return dataPagamento;
	}

	/**
	 * @param dataPagamento
	 *            the dataPagamento to set
	 */
	public void setDataPagamento(Date dataPagamento) {
		this.dataPagamento = dataPagamento;
	}

	/**
	 * @return the valor
	 */
	public String getValor() {
		return valor;
	}

	/**
	 * @param valor
	 *            the valor to set
	 */
	public void setValor(String valor) {
		this.valor = valor;
	}

	/**
	 * @return the selecionado
	 */
	public boolean isSelecionado() {
		return selecionado;
	}

	/**
	 * @param selecionado
	 *            the selecionado to set
	 */
	public void setSelecionado(boolean selecionado) {
		this.selecionado = selecionado;
	}

	public String getAgenciaOrigemINF() {
		return agenciaOrigemINF;
	}

	public void setAgenciaOrigemINF(String agenciaOrigemINF) {
		this.agenciaOrigemINF = agenciaOrigemINF;
	}

	public String getContaOrigemINF() {
		return contaOrigemINF;
	}

	public void setContaOrigemINF(String contaOrigemINF) {
		this.contaOrigemINF = contaOrigemINF;
	}

	public String getContaOrigemDeb() {
		return contaOrigemDeb;
	}

	public void setContaOrigemDeb(String contaOrigemDeb) {
		this.contaOrigemDeb = contaOrigemDeb;
	}

	public String getAgenciaDestinoINF() {
		return agenciaDestinoINF;
	}

	public void setAgenciaDestinoINF(String agenciaDestinoINF) {
		this.agenciaDestinoINF = agenciaDestinoINF;
	}

	public String getContaDestinoCredito() {
		return contaDestinoCredito;
	}

	public void setContaDestinoCredito(String contaDestinoCredito) {
		this.contaDestinoCredito = contaDestinoCredito;
	}

	public String getOrigemTransacao() {
		return origemTransacao;
	}

	public void setOrigemTransacao(String origemTransacao) {
		this.origemTransacao = origemTransacao;
	}

	public String getIndiceRelacionamento() {
		return indiceRelacionamento;
	}

	public void setIndiceRelacionamento(String indiceRelacionamento) {
		this.indiceRelacionamento = indiceRelacionamento;
	}

	public String getHora() {
		return hora;
	}

	public void setHora(String hora) {
		this.hora = hora;
	}

	public String getIdLancamento() {
		return idLancamento;
	}

	public void setIdLancamento(String idLancamento) {
		this.idLancamento = idLancamento;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getAutenticacao() {
		return autenticacao;
	}

	public void setAutenticacao(String autenticacao) {
		this.autenticacao = autenticacao;
	}

	public String getTipoTransferencia() {
		return tipoTransferencia;
	}

	public void setTipoTransferencia(String tipoTransferencia) {
		this.tipoTransferencia = tipoTransferencia;
	}

	public String getNomeTitularConta() {
		return nomeTitularConta;
	}

	public void setNomeTitularConta(String nomeTitularConta) {
		this.nomeTitularConta = nomeTitularConta;
	}

	public int getIdTabela() {
		return idTabela;
	}

	public void setIdTabela(int idTabela) {
		this.idTabela = idTabela;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((agenciaDestinoINF == null) ? 0 : agenciaDestinoINF.hashCode());
		result = prime * result + ((agenciaOrigemINF == null) ? 0 : agenciaOrigemINF.hashCode());
		result = prime * result + ((autenticacao == null) ? 0 : autenticacao.hashCode());
		result = prime * result + ((chave == null) ? 0 : chave.hashCode());
		result = prime * result + ((contaDestinoCredito == null) ? 0 : contaDestinoCredito.hashCode());
		result = prime * result + ((contaOrigemDeb == null) ? 0 : contaOrigemDeb.hashCode());
		result = prime * result + ((contaOrigemINF == null) ? 0 : contaOrigemINF.hashCode());
		result = prime * result + ((cpf == null) ? 0 : cpf.hashCode());
		result = prime * result + ((dataPagamento == null) ? 0 : dataPagamento.hashCode());
		result = prime * result + ((favorecido == null) ? 0 : favorecido.hashCode());
		result = prime * result + ((hora == null) ? 0 : hora.hashCode());
		result = prime * result + ((idLancamento == null) ? 0 : idLancamento.hashCode());
		result = prime * result + idTabela;
		result = prime * result + ((indiceRelacionamento == null) ? 0 : indiceRelacionamento.hashCode());
		result = prime * result + ((nomeTitularConta == null) ? 0 : nomeTitularConta.hashCode());
		result = prime * result + ((origemTransacao == null) ? 0 : origemTransacao.hashCode());
		result = prime * result + (selecionado ? 1231 : 1237);
		result = prime * result + ((tipoTransferencia == null) ? 0 : tipoTransferencia.hashCode());
		result = prime * result + ((valor == null) ? 0 : valor.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TransferenciaSegundaViaDadosComprovanteRelacaoDTO other = (TransferenciaSegundaViaDadosComprovanteRelacaoDTO) obj;
		if (agenciaDestinoINF == null) {
			if (other.agenciaDestinoINF != null)
				return false;
		} else if (!agenciaDestinoINF.equals(other.agenciaDestinoINF))
			return false;
		if (agenciaOrigemINF == null) {
			if (other.agenciaOrigemINF != null)
				return false;
		} else if (!agenciaOrigemINF.equals(other.agenciaOrigemINF))
			return false;
		if (autenticacao == null) {
			if (other.autenticacao != null)
				return false;
		} else if (!autenticacao.equals(other.autenticacao))
			return false;
		if (chave == null) {
			if (other.chave != null)
				return false;
		} else if (!chave.equals(other.chave))
			return false;
		if (contaDestinoCredito == null) {
			if (other.contaDestinoCredito != null)
				return false;
		} else if (!contaDestinoCredito.equals(other.contaDestinoCredito))
			return false;
		if (contaOrigemDeb == null) {
			if (other.contaOrigemDeb != null)
				return false;
		} else if (!contaOrigemDeb.equals(other.contaOrigemDeb))
			return false;
		if (contaOrigemINF == null) {
			if (other.contaOrigemINF != null)
				return false;
		} else if (!contaOrigemINF.equals(other.contaOrigemINF))
			return false;
		if (cpf == null) {
			if (other.cpf != null)
				return false;
		} else if (!cpf.equals(other.cpf))
			return false;
		if (dataPagamento == null) {
			if (other.dataPagamento != null)
				return false;
		} else if (!dataPagamento.equals(other.dataPagamento))
			return false;
		if (favorecido == null) {
			if (other.favorecido != null)
				return false;
		} else if (!favorecido.equals(other.favorecido))
			return false;
		if (hora == null) {
			if (other.hora != null)
				return false;
		} else if (!hora.equals(other.hora))
			return false;
		if (idLancamento == null) {
			if (other.idLancamento != null)
				return false;
		} else if (!idLancamento.equals(other.idLancamento))
			return false;
		if (idTabela != other.idTabela)
			return false;
		if (indiceRelacionamento == null) {
			if (other.indiceRelacionamento != null)
				return false;
		} else if (!indiceRelacionamento.equals(other.indiceRelacionamento))
			return false;
		if (nomeTitularConta == null) {
			if (other.nomeTitularConta != null)
				return false;
		} else if (!nomeTitularConta.equals(other.nomeTitularConta))
			return false;
		if (origemTransacao == null) {
			if (other.origemTransacao != null)
				return false;
		} else if (!origemTransacao.equals(other.origemTransacao))
			return false;
		if (selecionado != other.selecionado)
			return false;
		if (tipoTransferencia == null) {
			if (other.tipoTransferencia != null)
				return false;
		} else if (!tipoTransferencia.equals(other.tipoTransferencia))
			return false;
		if (valor == null) {
			if (other.valor != null)
				return false;
		} else if (!valor.equals(other.valor))
			return false;
		return true;
	}
	
	

}