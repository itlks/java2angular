package com.altec.bsbr.app.ibe.dto;

import com.altec.bsbr.app.ibe.util.UtilFunction;

/**
 * @since 2017-01-17
 * @author x187169 - Julio Leme
 *
 */
public class ConsultaListaCNPJWebDTO {

	private String razaoSocial;
	private String cpfCnpj;
	private String cpfCnpjWeb;

	/**
	 * encapsulamento
	 * @return
	 */
	public String getRazaoSocial() {
		return razaoSocial;
	}

	public void setRazaoSocial(String razaoSocial) {
		this.razaoSocial = razaoSocial;
	}

	public String getCpfCnpj() {
		return cpfCnpj;
	}

	public void setCpfCnpj(String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}

	public String getCpfCnpjWeb() {
		cpfCnpjWeb = UtilFunction.formatarCnpj(cpfCnpj);
		return cpfCnpjWeb;
	}

	public void setCpfCnpjWeb(String cpfCnpjWeb) {
		this.cpfCnpjWeb = cpfCnpjWeb;
	}	

}
