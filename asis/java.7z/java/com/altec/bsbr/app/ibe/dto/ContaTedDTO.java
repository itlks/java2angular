package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class ContaTedDTO implements Serializable {

	/**
	* 
	 */
	private static final long serialVersionUID = -419357908756148553L;

	private String OECHAVEAMARRACAO;
	private String OECPFCNPJREMETENTE;
	private String OENOMEREMETENTE;
	private String OEBANCODESTINO;
	private String OEAGENCIADESTINO;
	private String OEDIGITOAGENCIADESTINO;
	private String OECONTADESTINO;
	private String OENOMEDESTINO1;
	private String OETIPOPESSOADESTINO1;
	private String OECPFCNPJDESTINO1;
	private String OENOMEDESTINO2;
	private String OECPFCNPJDESTINO2;
	private String OETIPOCONTA;
	private String OEFINALIDADE;
	private String OETIPOSUPERDOC;
	private String OEVALORTRANSACAO;
	private String OENOMEBANCODESTINO;
	private String OETIPOTRANSACAO;
	private String OEDATAAGENDAMENTO;
	private String OEHORAAGENDAMENTO;
	private String OERECORRENCIA;
	private String OEQTDRECORRENCIA;
	private String OEINDAGENDAMENTO;
	private String OEVALORTARIFA;
	private String OEDISPONIBILIDADE;
	private String OEVALORTARIFASTR;
	private String OEHORALIMITESTR;
	private String OEVALORTARIFACIP;
	private String OEHORALIMITECIP;
	private String OEVALORTARIFACIPAGENDADO;
	private String OELIMITEDOCDIARIO;
	private String OETOTALAGENDADODIA;
	private String OETOTALEFETUADODIA;
	private String OEDATACONTABIL;
	private String OEHORARECIBO;
	private String OEDATARECIBO;
	private String OEARMAZENACONTADOC;
	private String OETEDIFNPC;
	private String OECHAVEAMCNY;
	private String OECHAVECONTROLEAGENDNY;
	private String OEHISTORICO;
	private String OENUDOCTCRED;
	private String OEEPCCNTAREMT;
	private String OETPCNTAREMT;
	private String OEINTIPOPESSREMT;
	private String OENOMEAGDEST;
	private String OESITTOKEN;
	private String OEPENUMPER;
	private String OEINDCLIENTE;
	private String OEINDTOKEN;
	private String OENUMTOKEN;
	private String OEIDSESSAO;
	private String OEDISCRIMANTELYNX;
	private String OECODRETLYNX;
	private String OEINDTOKENSESSAO;
	private String OENUMDDDLIGACAO;
	private String OENUMTELLIGACAO;
	private String OECOISPBDEST;

	private String nomeOrigem;
	private String nomeDestino;
	private String tipoDocumento;
	private String documentoFormatado;
	private String agenciaOrigemFormatada;
	private String contaOrigemFormatada;
	private String bancoDestinoFormatado;
	private String agenciaDestinoFormatada;
	private String contaDestinoFormatada;

	public String getOECHAVEAMARRACAO() {
		return OECHAVEAMARRACAO;
	}

	public void setOECHAVEAMARRACAO(String oECHAVEAMARRACAO) {
		OECHAVEAMARRACAO = oECHAVEAMARRACAO;
	}

	public String getOECPFCNPJREMETENTE() {
		return OECPFCNPJREMETENTE;
	}

	public void setOECPFCNPJREMETENTE(String oECPFCNPJREMETENTE) {
		OECPFCNPJREMETENTE = oECPFCNPJREMETENTE;
	}

	public String getOENOMEREMETENTE() {
		return OENOMEREMETENTE;
	}

	public void setOENOMEREMETENTE(String oENOMEREMETENTE) {
		OENOMEREMETENTE = oENOMEREMETENTE;
	}

	public String getOEBANCODESTINO() {
		return OEBANCODESTINO;
	}

	public void setOEBANCODESTINO(String oEBANCODESTINO) {
		OEBANCODESTINO = oEBANCODESTINO;
	}

	public String getOEAGENCIADESTINO() {
		return OEAGENCIADESTINO;
	}

	public void setOEAGENCIADESTINO(String oEAGENCIADESTINO) {
		OEAGENCIADESTINO = oEAGENCIADESTINO;
	}

	public String getOEDIGITOAGENCIADESTINO() {
		return OEDIGITOAGENCIADESTINO;
	}

	public void setOEDIGITOAGENCIADESTINO(String oEDIGITOAGENCIADESTINO) {
		OEDIGITOAGENCIADESTINO = oEDIGITOAGENCIADESTINO;
	}

	public String getOECONTADESTINO() {
		return OECONTADESTINO;
	}

	public void setOECONTADESTINO(String oECONTADESTINO) {
		OECONTADESTINO = oECONTADESTINO;
	}

	public String getOENOMEDESTINO1() {
		return OENOMEDESTINO1;
	}

	public void setOENOMEDESTINO1(String oENOMEDESTINO1) {
		OENOMEDESTINO1 = oENOMEDESTINO1;
	}

	public String getOETIPOPESSOADESTINO1() {
		return OETIPOPESSOADESTINO1;
	}

	public void setOETIPOPESSOADESTINO1(String oETIPOPESSOADESTINO1) {
		OETIPOPESSOADESTINO1 = oETIPOPESSOADESTINO1;
	}

	public String getOECPFCNPJDESTINO1() {
		return OECPFCNPJDESTINO1;
	}

	public void setOECPFCNPJDESTINO1(String oECPFCNPJDESTINO1) {
		OECPFCNPJDESTINO1 = oECPFCNPJDESTINO1;
	}

	public String getOENOMEDESTINO2() {
		return OENOMEDESTINO2;
	}

	public void setOENOMEDESTINO2(String oENOMEDESTINO2) {
		OENOMEDESTINO2 = oENOMEDESTINO2;
	}

	public String getOECPFCNPJDESTINO2() {
		return OECPFCNPJDESTINO2;
	}

	public void setOECPFCNPJDESTINO2(String oECPFCNPJDESTINO2) {
		OECPFCNPJDESTINO2 = oECPFCNPJDESTINO2;
	}

	public String getOETIPOCONTA() {
		return OETIPOCONTA;
	}

	public void setOETIPOCONTA(String oETIPOCONTA) {
		OETIPOCONTA = oETIPOCONTA;
	}

	public String getOEFINALIDADE() {
		return OEFINALIDADE;
	}

	public void setOEFINALIDADE(String oEFINALIDADE) {
		OEFINALIDADE = oEFINALIDADE;
	}

	public String getOETIPOSUPERDOC() {
		return OETIPOSUPERDOC;
	}

	public void setOETIPOSUPERDOC(String oETIPOSUPERDOC) {
		OETIPOSUPERDOC = oETIPOSUPERDOC;
	}

	public String getOEVALORTRANSACAO() {
		return OEVALORTRANSACAO;
	}

	public void setOEVALORTRANSACAO(String oEVALORTRANSACAO) {
		OEVALORTRANSACAO = oEVALORTRANSACAO;
	}

	public String getOENOMEBANCODESTINO() {
		return OENOMEBANCODESTINO;
	}

	public void setOENOMEBANCODESTINO(String oENOMEBANCODESTINO) {
		OENOMEBANCODESTINO = oENOMEBANCODESTINO;
	}

	public String getOETIPOTRANSACAO() {
		return OETIPOTRANSACAO;
	}

	public void setOETIPOTRANSACAO(String oETIPOTRANSACAO) {
		OETIPOTRANSACAO = oETIPOTRANSACAO;
	}

	public String getOEDATAAGENDAMENTO() {
		return OEDATAAGENDAMENTO;
	}

	public void setOEDATAAGENDAMENTO(String oEDATAAGENDAMENTO) {
		OEDATAAGENDAMENTO = oEDATAAGENDAMENTO;
	}

	public String getOEHORAAGENDAMENTO() {
		return OEHORAAGENDAMENTO;
	}

	public void setOEHORAAGENDAMENTO(String oEHORAAGENDAMENTO) {
		OEHORAAGENDAMENTO = oEHORAAGENDAMENTO;
	}

	public String getOERECORRENCIA() {
		return OERECORRENCIA;
	}

	public void setOERECORRENCIA(String oERECORRENCIA) {
		OERECORRENCIA = oERECORRENCIA;
	}

	public String getOEQTDRECORRENCIA() {
		return OEQTDRECORRENCIA;
	}

	public void setOEQTDRECORRENCIA(String oEQTDRECORRENCIA) {
		OEQTDRECORRENCIA = oEQTDRECORRENCIA;
	}

	public String getOEINDAGENDAMENTO() {
		return OEINDAGENDAMENTO;
	}

	public void setOEINDAGENDAMENTO(String oEINDAGENDAMENTO) {
		OEINDAGENDAMENTO = oEINDAGENDAMENTO;
	}

	public String getOEVALORTARIFA() {
		return OEVALORTARIFA;
	}

	public void setOEVALORTARIFA(String oEVALORTARIFA) {
		OEVALORTARIFA = oEVALORTARIFA;
	}

	public String getOEDISPONIBILIDADE() {
		return OEDISPONIBILIDADE;
	}

	public void setOEDISPONIBILIDADE(String oEDISPONIBILIDADE) {
		OEDISPONIBILIDADE = oEDISPONIBILIDADE;
	}

	public String getOEVALORTARIFASTR() {
		return OEVALORTARIFASTR;
	}

	public void setOEVALORTARIFASTR(String oEVALORTARIFASTR) {
		OEVALORTARIFASTR = oEVALORTARIFASTR;
	}

	public String getOEHORALIMITESTR() {
		return OEHORALIMITESTR;
	}

	public void setOEHORALIMITESTR(String oEHORALIMITESTR) {
		OEHORALIMITESTR = oEHORALIMITESTR;
	}

	public String getOEVALORTARIFACIP() {
		return OEVALORTARIFACIP;
	}

	public void setOEVALORTARIFACIP(String oEVALORTARIFACIP) {
		OEVALORTARIFACIP = oEVALORTARIFACIP;
	}

	public String getOEHORALIMITECIP() {
		return OEHORALIMITECIP;
	}

	public void setOEHORALIMITECIP(String oEHORALIMITECIP) {
		OEHORALIMITECIP = oEHORALIMITECIP;
	}

	public String getOEVALORTARIFACIPAGENDADO() {
		return OEVALORTARIFACIPAGENDADO;
	}

	public void setOEVALORTARIFACIPAGENDADO(String oEVALORTARIFACIPAGENDADO) {
		OEVALORTARIFACIPAGENDADO = oEVALORTARIFACIPAGENDADO;
	}

	public String getOELIMITEDOCDIARIO() {
		return OELIMITEDOCDIARIO;
	}

	public void setOELIMITEDOCDIARIO(String oELIMITEDOCDIARIO) {
		OELIMITEDOCDIARIO = oELIMITEDOCDIARIO;
	}

	public String getOETOTALAGENDADODIA() {
		return OETOTALAGENDADODIA;
	}

	public void setOETOTALAGENDADODIA(String oETOTALAGENDADODIA) {
		OETOTALAGENDADODIA = oETOTALAGENDADODIA;
	}

	public String getOETOTALEFETUADODIA() {
		return OETOTALEFETUADODIA;
	}

	public void setOETOTALEFETUADODIA(String oETOTALEFETUADODIA) {
		OETOTALEFETUADODIA = oETOTALEFETUADODIA;
	}

	public String getOEDATACONTABIL() {
		return OEDATACONTABIL;
	}

	public void setOEDATACONTABIL(String oEDATACONTABIL) {
		OEDATACONTABIL = oEDATACONTABIL;
	}

	public String getOEHORARECIBO() {
		return OEHORARECIBO;
	}

	public void setOEHORARECIBO(String oEHORARECIBO) {
		OEHORARECIBO = oEHORARECIBO;
	}

	public String getOEDATARECIBO() {
		return OEDATARECIBO;
	}

	public void setOEDATARECIBO(String oEDATARECIBO) {
		OEDATARECIBO = oEDATARECIBO;
	}

	public String getOEARMAZENACONTADOC() {
		return OEARMAZENACONTADOC;
	}

	public void setOEARMAZENACONTADOC(String oEARMAZENACONTADOC) {
		OEARMAZENACONTADOC = oEARMAZENACONTADOC;
	}

	public String getOETEDIFNPC() {
		return OETEDIFNPC;
	}

	public void setOETEDIFNPC(String oETEDIFNPC) {
		OETEDIFNPC = oETEDIFNPC;
	}

	public String getOECHAVEAMCNY() {
		return OECHAVEAMCNY;
	}

	public void setOECHAVEAMCNY(String oECHAVEAMCNY) {
		OECHAVEAMCNY = oECHAVEAMCNY;
	}

	public String getOECHAVECONTROLEAGENDNY() {
		return OECHAVECONTROLEAGENDNY;
	}

	public void setOECHAVECONTROLEAGENDNY(String oECHAVECONTROLEAGENDNY) {
		OECHAVECONTROLEAGENDNY = oECHAVECONTROLEAGENDNY;
	}

	public String getOEHISTORICO() {
		return OEHISTORICO;
	}

	public void setOEHISTORICO(String oEHISTORICO) {
		OEHISTORICO = oEHISTORICO;
	}

	public String getOENUDOCTCRED() {
		return OENUDOCTCRED;
	}

	public void setOENUDOCTCRED(String oENUDOCTCRED) {
		OENUDOCTCRED = oENUDOCTCRED;
	}

	public String getOEEPCCNTAREMT() {
		return OEEPCCNTAREMT;
	}

	public void setOEEPCCNTAREMT(String oEEPCCNTAREMT) {
		OEEPCCNTAREMT = oEEPCCNTAREMT;
	}

	public String getOETPCNTAREMT() {
		return OETPCNTAREMT;
	}

	public void setOETPCNTAREMT(String oETPCNTAREMT) {
		OETPCNTAREMT = oETPCNTAREMT;
	}

	public String getOEINTIPOPESSREMT() {
		return OEINTIPOPESSREMT;
	}

	public void setOEINTIPOPESSREMT(String oEINTIPOPESSREMT) {
		OEINTIPOPESSREMT = oEINTIPOPESSREMT;
	}

	public String getOENOMEAGDEST() {
		return OENOMEAGDEST;
	}

	public void setOENOMEAGDEST(String oENOMEAGDEST) {
		OENOMEAGDEST = oENOMEAGDEST;
	}

	public String getOESITTOKEN() {
		return OESITTOKEN;
	}

	public void setOESITTOKEN(String oESITTOKEN) {
		OESITTOKEN = oESITTOKEN;
	}

	public String getOEPENUMPER() {
		return OEPENUMPER;
	}

	public void setOEPENUMPER(String oEPENUMPER) {
		OEPENUMPER = oEPENUMPER;
	}

	public String getOEINDCLIENTE() {
		return OEINDCLIENTE;
	}

	public void setOEINDCLIENTE(String oEINDCLIENTE) {
		OEINDCLIENTE = oEINDCLIENTE;
	}

	public String getOEINDTOKEN() {
		return OEINDTOKEN;
	}

	public void setOEINDTOKEN(String oEINDTOKEN) {
		OEINDTOKEN = oEINDTOKEN;
	}

	public String getOENUMTOKEN() {
		return OENUMTOKEN;
	}

	public void setOENUMTOKEN(String oENUMTOKEN) {
		OENUMTOKEN = oENUMTOKEN;
	}

	public String getOEIDSESSAO() {
		return OEIDSESSAO;
	}

	public void setOEIDSESSAO(String oEIDSESSAO) {
		OEIDSESSAO = oEIDSESSAO;
	}

	public String getOEDISCRIMANTELYNX() {
		return OEDISCRIMANTELYNX;
	}

	public void setOEDISCRIMANTELYNX(String oEDISCRIMANTELYNX) {
		OEDISCRIMANTELYNX = oEDISCRIMANTELYNX;
	}

	public String getOECODRETLYNX() {
		return OECODRETLYNX;
	}

	public void setOECODRETLYNX(String oECODRETLYNX) {
		OECODRETLYNX = oECODRETLYNX;
	}

	public String getOEINDTOKENSESSAO() {
		return OEINDTOKENSESSAO;
	}

	public void setOEINDTOKENSESSAO(String oEINDTOKENSESSAO) {
		OEINDTOKENSESSAO = oEINDTOKENSESSAO;
	}

	public String getOENUMDDDLIGACAO() {
		return OENUMDDDLIGACAO;
	}

	public void setOENUMDDDLIGACAO(String oENUMDDDLIGACAO) {
		OENUMDDDLIGACAO = oENUMDDDLIGACAO;
	}

	public String getOENUMTELLIGACAO() {
		return OENUMTELLIGACAO;
	}

	public void setOENUMTELLIGACAO(String oENUMTELLIGACAO) {
		OENUMTELLIGACAO = oENUMTELLIGACAO;
	}

	public String getOECOISPBDEST() {
		return OECOISPBDEST;
	}

	public void setOECOISPBDEST(String oECOISPBDEST) {
		OECOISPBDEST = oECOISPBDEST;
	}

	public String getNomeOrigem() {
		return nomeOrigem;
	}

	public void setNomeOrigem(String nomeOrigem) {
		this.nomeOrigem = nomeOrigem;
	}

	public String getAgenciaOrigemFormatada() {
		return agenciaOrigemFormatada;
	}

	public void setAgenciaOrigemFormatada(String agenciaOrigemFormatada) {
		this.agenciaOrigemFormatada = agenciaOrigemFormatada;
	}

	public String getContaOrigemFormatada() {
		return contaOrigemFormatada;
	}

	public void setContaOrigemFormatada(String contaOrigemFormatada) {
		this.contaOrigemFormatada = contaOrigemFormatada;
	}

	public String getBancoDestinoFormatado() {
		return bancoDestinoFormatado;
	}

	public void setBancoDestinoFormatado(String bancoDestinoFormatado) {
		this.bancoDestinoFormatado = bancoDestinoFormatado;
	}

	public String getAgenciaDestinoFormatada() {
		return agenciaDestinoFormatada;
	}

	public void setAgenciaDestinoFormatada(String agenciaDestinoFormatada) {
		this.agenciaDestinoFormatada = agenciaDestinoFormatada;
	}

	public String getContaDestinoFormatada() {
		return contaDestinoFormatada;
	}

	public void setContaDestinoFormatada(String contaDestinoFormatada) {
		this.contaDestinoFormatada = contaDestinoFormatada;
	}

	public String getNomeDestino() {
		return nomeDestino;
	}

	public void setNomeDestino(String nomeDestino) {
		this.nomeDestino = nomeDestino;
	}

	public String getDocumentoFormatado() {
		return documentoFormatado;
	}

	public void setDocumentoFormatado(String documentoFormatado) {
		this.documentoFormatado = documentoFormatado;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

}
