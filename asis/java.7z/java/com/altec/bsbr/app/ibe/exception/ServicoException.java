package com.altec.bsbr.app.ibe.exception;

import com.altec.bsbr.app.ibe.message.StatusMensagemEnum;
import com.altec.bsbr.fw.BusinessException;

public class ServicoException extends BusinessException {
	private static final long serialVersionUID = -1350374034132101850L;
	private String codigoRetorno = "0";
	private String mensagemRetornoCliente;
	private String mensagemRetornoProduto;
	private StatusMensagemEnum image;
	private boolean openMessage;
			
	public ServicoException(String message, String codigoRetorno, String mensagemRetornoCliente,
			String mensagemRetornoProduto) {
		super(message);
		this.codigoRetorno = codigoRetorno;
		this.mensagemRetornoCliente = mensagemRetornoCliente;
		this.mensagemRetornoProduto = mensagemRetornoProduto;
		this.image = StatusMensagemEnum.ERRO;
		this.openMessage = true;
	}

	public ServicoException(String message, String codigoRetorno, String mensagemRetornoCliente,
			String mensagemRetornoProduto, boolean openMessage) {
		super(message);
		this.codigoRetorno = codigoRetorno;
		this.mensagemRetornoCliente = mensagemRetornoCliente;
		this.mensagemRetornoProduto = mensagemRetornoProduto;
		this.image = StatusMensagemEnum.ERRO;
		this.openMessage = openMessage;
	}
	
	public ServicoException(String message, String codigoRetorno, String mensagemRetornoCliente,
			String mensagemRetornoProduto, StatusMensagemEnum image, boolean openMessage) {
		super(message);
		this.codigoRetorno = codigoRetorno;
		this.mensagemRetornoCliente = mensagemRetornoCliente;
		this.mensagemRetornoProduto = mensagemRetornoProduto;
		this.image = image;
		this.openMessage = openMessage;
	}
	
	public String getCodigoRetorno() {
		return codigoRetorno;
	}
	public void setCodigoRetorno(String codigoRetorno) {
		this.codigoRetorno = codigoRetorno;
	}
	public String getMensagemRetornoCliente() {
		return mensagemRetornoCliente;
	}
	public void setMensagemRetornoCliente(String mensagemRetornoCliente) {
		this.mensagemRetornoCliente = mensagemRetornoCliente;
	}
	public String getMensagemRetornoProduto() {
		return mensagemRetornoProduto;
	}
	public void setMensagemRetornoProduto(String mensagemRetornoProduto) {
		this.mensagemRetornoProduto = mensagemRetornoProduto;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public StatusMensagemEnum getImage() {
		return image;
	}
	public void setImage(StatusMensagemEnum image) {
		this.image = image;
	}
	public boolean getOpenMessage() {
		return openMessage;
	}
	public void setOpenMessage(boolean openMessage) {
		this.openMessage = openMessage;
	}
	
}
