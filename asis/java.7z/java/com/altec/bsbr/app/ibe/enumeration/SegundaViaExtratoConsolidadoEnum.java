package com.altec.bsbr.app.ibe.enumeration;

public enum SegundaViaExtratoConsolidadoEnum {

	INTERNET_BANCK("Pelo Intenet Banking", "T","","A 2� via do seu Extrato estar� dispon�vel para consulta no Internet Banking em at� 2 dias �teis."),
	RESIDENCIA("No seu endere�o de correspond�ncia", "C","P","A 2� via do seu Extrato ser� enviada para seu endere�o de correspond�ncia em at� 4 dias �teis."),
	AGENCIA("Em sua ag�ncia", "A","N","A 2� via do seu Extrato estar� dispon�vel para retirada em sua ag�ncia em at� 4 dias �teis.");
	
	private String descricao;
	private String tipoEnvioExtrato;
	private String tipoEmissaoExtrato;
	private String mensagemEnvioPrazo;
	
	
	private SegundaViaExtratoConsolidadoEnum(String descricao, String tipoEnvioExtrato, String tipoEmissaoExtrato, String mensagemEnvioPrazo) {
		this.descricao = descricao;
		this.tipoEnvioExtrato = tipoEnvioExtrato;
		this.tipoEmissaoExtrato = tipoEmissaoExtrato;
		this.mensagemEnvioPrazo = mensagemEnvioPrazo;
	}

	public String getDescricao() {
		return descricao;
	}

	public String getTipoEnvioExtrato() {
		return tipoEnvioExtrato;
	}

	public String getTipoEmissaoExtrato() {
		return tipoEmissaoExtrato;
	}
	
	public static SegundaViaExtratoConsolidadoEnum findEnum(String find){
		SegundaViaExtratoConsolidadoEnum enumRetorno = null;
		for(SegundaViaExtratoConsolidadoEnum enumValor : SegundaViaExtratoConsolidadoEnum.values()){
			if (find.equals(enumValor.getDescricao()) || enumValor.getDescricao().contains("ag�ncia")) {
				enumRetorno = enumValor;
				break;
			}
		}
		return enumRetorno;
	}

	public String getMensagemEnvioPrazo() {
		return mensagemEnvioPrazo;
	}	
}
