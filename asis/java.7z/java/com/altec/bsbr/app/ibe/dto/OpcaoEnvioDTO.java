package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class OpcaoEnvioDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2121469827277792284L;

	private int id;
	private String descricao;
	

	public OpcaoEnvioDTO() {
		super();
	}

	public OpcaoEnvioDTO(Integer id, String descricao) {
		super();
		this.id = id;
		this.descricao = descricao;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	
	
	
	
}
