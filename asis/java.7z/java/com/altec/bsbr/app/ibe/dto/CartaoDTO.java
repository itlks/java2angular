package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

import com.altec.bsbr.app.ibe.anotation.Hash;
import com.altec.bsbr.app.ibe.util.UtilFunction;

public class CartaoDTO implements Serializable {
	
	private static final long serialVersionUID = -8007356805854621374L;
	
	private String tipo;
	private String bandeira;
	private String numero;	
	private String numeroFormatado;		
	private String nomeTitular;
	private String img;
	private String codigoCliente;
	private Integer contrato;
	private String banco;
	private String agencia;
	private String conta;
	private String codigoBloqueio;
	private String desbloqueio;
	private String codTipo;
	private String codBandeira;	
	private String nomeCartao;
	
	public CartaoDTO() {
		//
	}
	
	public CartaoDTO(String tipo, String numero, String numeroFormatado, String nomeTitular, 
			String img, String codigoCliente, String bandeira, Integer contrato, 
			String banco, String agencia, String conta) {
		super();
		this.tipo = tipo;
		this.numero = numero;
		this.numeroFormatado = numeroFormatado;
		this.nomeTitular = nomeTitular;
		this.img = img;
		this.codigoCliente = codigoCliente;
		this.bandeira = bandeira;
		this.contrato = contrato;
		this.banco = banco;
		this.agencia= agencia;
		this.conta= conta;
	}
	
	
	
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public String getNumero() {
		return numero;
	}
	public void setNumero(String numero) {
		this.numero = numero;
	}
	public String getNomeTitular() {
		return nomeTitular;
	}
	public void setNomeTitular(String nomeTitular) {
		this.nomeTitular = nomeTitular;
	}

	public String getNumeroFormatado() {
		return numeroFormatado;
	}

	public void setNumeroFormatado(String numeroFormatado) {
		this.numeroFormatado = numeroFormatado;
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	public String getCodigoCliente() {
		return codigoCliente;
	}

	public void setCodigoCliente(String codigoCliente) {
		this.codigoCliente = codigoCliente;
	}

	public String getBandeira() {
		return bandeira;
	}
	
	public String getBandeiraCaseSensitive() {
		return UtilFunction.convertStringToCaseSensitive(bandeira);
	}

	public void setBandeira(String bandeira) {
		this.bandeira = bandeira;
	}

	public Integer getContrato() {
		return contrato;
	}

	public void setContrato(Integer contrato) {
		this.contrato = contrato;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getConta() {
		return conta;
	}

	public void setConta(String conta) {
		this.conta = conta;
	}

	public String getCodigoBloqueio() {
		return codigoBloqueio;
	}

	public void setCodigoBloqueio(String codigoBloqueio) {
		this.codigoBloqueio = codigoBloqueio;
	}

	public String getDesbloqueio() {
		return desbloqueio;
	}

	public void setDesbloqueio(String desbloqueio) {
		this.desbloqueio = desbloqueio;
	}

	public String getCodTipo() {
		return codTipo;
	}

	public void setCodTipo(String codTipo) {
		this.codTipo = codTipo;
	}

	public String getCodBandeira() {
		return codBandeira;
	}

	public void setCodBandeira(String codBandeira) {
		this.codBandeira = codBandeira;
	}

	public String getNomeCartao() {
		return nomeCartao;
	}

	public void setNomeCartao(String nomeCartao) {
		this.nomeCartao = nomeCartao;
	}
	
	
}
