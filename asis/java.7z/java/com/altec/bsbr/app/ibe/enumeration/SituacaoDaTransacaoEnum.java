package com.altec.bsbr.app.ibe.enumeration;

public enum SituacaoDaTransacaoEnum {
	FLAGPOSICAO("A"),
	FLAGSERVICO("S"),
	FLAGCONSULTIVA("B"),
	FLAGSEGUNDAVIA("V"),
	FLAGIMPERATIVACONFIRMACAO("C"), 
	FLAGIMPERATIVACANCELAMENTO("D");
	
	private String situacao;
	
	private SituacaoDaTransacaoEnum(String situacao) {
		this.situacao = situacao;
	}

	public String getSituacao() {
		return situacao;
	}
	
	
	
}
