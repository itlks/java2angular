package com.altec.bsbr.app.ibe.dto;

public class LinhaExcelAdquirencia {

	private String descricao;
	private String dado;

	public LinhaExcelAdquirencia(String descricao, String dado) {
		super();
		this.descricao = descricao;
		this.dado = dado;
	}

	public String getDado() {
		return dado;
	}

	public void setDado(String dado) {
		this.dado = dado;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
}
