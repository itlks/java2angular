package com.altec.bsbr.app.ibe.enumeration;

import org.apache.commons.lang.ArrayUtils;

public enum GoFacesNavigationEnum {
	
	DATAEFETIVACAO(1, "goAutorizacoesPendenciasAutorizacoesDataEfetivacao"),
	DATAINCLUSAO(2, "goAutorizacoesPendenciasAutorizacoesDataInclusao"),
	PRODUTO(3, "goAutorizacoesPendenciasAutorizacoesProduto"),
	CONTACONVENIO(4, "goAutorizacoesPendenciasAutorizacoesContaConvenio"),
	AUTORIZACOESREMESSA(5, "goAutorizacoesPendenciasAutorizacoesRemessa");
	
	private Integer id;
	private String descricao;
	
	private GoFacesNavigationEnum(Integer id, String descricao){
		this.id = id;
		this.descricao = descricao;
	}

	public static GoFacesNavigationEnum[] removerItemArray(GoFacesNavigationEnum tipoContaEnum){
		
		GoFacesNavigationEnum[] result = GoFacesNavigationEnum.values();
				
		if(tipoContaEnum != null){
			for (int i = 0; i < GoFacesNavigationEnum.values().length; i++) {
				GoFacesNavigationEnum  tipo = GoFacesNavigationEnum.values()[i];
				if(tipo.equals(tipoContaEnum)){
					result = (GoFacesNavigationEnum[]) ArrayUtils.remove(result, i); 
					break;
				}
			}
		}
		return result;
	}
	
	public static GoFacesNavigationEnum findById(Integer id){
		GoFacesNavigationEnum retorno = null;
				
		if(id != null){
			for(GoFacesNavigationEnum opcao: GoFacesNavigationEnum.values()){
				if(opcao.getId() == id){
					retorno = opcao;
					break;
				}
			}
		}
		return retorno;
	}
	
	public static GoFacesNavigationEnum findByDescricao(String desc){
		GoFacesNavigationEnum retorno = null;
				
		if(desc != null && !desc.isEmpty()){
			for(GoFacesNavigationEnum opcao: GoFacesNavigationEnum.values()){
				if(opcao.getDescricao().equals(desc)){
					retorno = opcao;
					break;
				}
			}
		}
		return retorno;
	}

	public Integer getId() {
		return id;
	}

	public String getDescricao() {
		return descricao;
	}
	
}
