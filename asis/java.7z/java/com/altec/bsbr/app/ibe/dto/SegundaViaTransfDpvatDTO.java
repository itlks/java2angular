package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;

public class SegundaViaTransfDpvatDTO implements Serializable{

	private static final long serialVersionUID = 3590565680893842779L;
	
	private Integer anoExercicio;
	private BigDecimal valor;
	
	public SegundaViaTransfDpvatDTO(){
		//
	}
	
	
	public SegundaViaTransfDpvatDTO(Integer anoExercicio, BigDecimal valor) {
		super();
		this.anoExercicio = anoExercicio;
		this.valor = valor;
	}

	public Integer getAnoExercicio() {
		return anoExercicio;
	}
	public void setAnoExercicio(Integer anoExercicio) {
		this.anoExercicio = anoExercicio;
	}
	public BigDecimal getValor() {
		return valor;
	}
	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}
	
	
	

}
