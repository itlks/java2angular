package com.altec.bsbr.app.ibe.dto;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.Serializable;
import java.util.List;

/**
 *
 * @author daniel.r.krokovsky
 */
public class CategoriaDTO implements Serializable, Comparable<CategoriaDTO> {

	private static final long serialVersionUID = 458377107493930068L;
	
	private String categoriaName;
    private Integer idItemMenu;
    private Integer idItemMenuPai;
    private boolean selecionado;
    private Integer coluna;
    private List<CategoriaDTO> listaFilhos;

    public CategoriaDTO() {
    }

    public CategoriaDTO(String categoriaName) {
        this.categoriaName = categoriaName;
    }
   
    public String getCategoriaName() {
        return categoriaName;
    }

    public void setCategoriaName(String categoriaName) {
        this.categoriaName = categoriaName;
    }

	public Integer getIdItemMenu() {
		return idItemMenu;
	}

	public void setIdItemMenu(Integer idItemMenu) {
		this.idItemMenu = idItemMenu;
	}

	public Integer getIdItemMenuPai() {
		return idItemMenuPai;
	}

	public void setIdItemMenuPai(Integer idItemMenuPai) {
		this.idItemMenuPai = idItemMenuPai;
	}
	
	public List<CategoriaDTO> getListaFilhos() {
		return listaFilhos;
	}

	public void setListaFilhos(List<CategoriaDTO> listaFilhos) {
		this.listaFilhos = listaFilhos;
	}

	public boolean isSelecionado() {
		return selecionado;
	}

	public void setSelecionado(boolean selecionado) {
		this.selecionado = selecionado;
	}

	public Integer getColuna() {
		return coluna;
	}

	public void setColuna(Integer coluna) {
		this.coluna = coluna;
	}

	@Override
	public int compareTo(CategoriaDTO o) {
		return idItemMenu.compareTo(o.getIdItemMenu());
	}

}
