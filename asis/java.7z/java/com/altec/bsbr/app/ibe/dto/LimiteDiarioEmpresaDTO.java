package com.altec.bsbr.app.ibe.dto;

import com.altec.bsbr.app.ibe.util.WSFormat;

public class LimiteDiarioEmpresaDTO {
	private boolean checked;
	private String nome;
	private String agencia;
	private String contaCorrente;
	private int index;
	

	public boolean isChecked() {
		return checked;
	}

	public void setChecked(boolean checked) {
		this.checked = checked;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = WSFormat.getFormatString(agencia, 4, "0", WSFormat.Position.RIGHT);
	}

	public String getContaCorrente() {
		return contaCorrente;
	}

	public void setContaCorrente(String contaCorrente) {

		this.contaCorrente = WSFormat.getFormatString(contaCorrente, 9, "0", WSFormat.Position.RIGHT);
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}
	
}
