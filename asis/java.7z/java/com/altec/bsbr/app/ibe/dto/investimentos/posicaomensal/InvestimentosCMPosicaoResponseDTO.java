
package com.altec.bsbr.app.ibe.dto.investimentos.posicaomensal;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class InvestimentosCMPosicaoResponseDTO implements Serializable
{

    private List<AltairMessage> altairMessage = new ArrayList<AltairMessage>();
    private List<MensalPosition> mensalPosition = new ArrayList<MensalPosition>();
    private final static long serialVersionUID = 4479822146238067465L;

    /**
     * No args constructor for use in serialization
     * 
     */
    public InvestimentosCMPosicaoResponseDTO() {
    }

    /**
     * 
     * @param mensalPosition
     * @param altairMessage
     */
    public InvestimentosCMPosicaoResponseDTO(List<AltairMessage> altairMessage, List<MensalPosition> mensalPosition) {
        super();
        this.altairMessage = altairMessage;
        this.mensalPosition = mensalPosition;
    }

    public List<AltairMessage> getAltairMessage() {
        return altairMessage;
    }

    public void setAltairMessage(List<AltairMessage> altairMessage) {
        this.altairMessage = altairMessage;
    }

    public InvestimentosCMPosicaoResponseDTO withAltairMessage(List<AltairMessage> altairMessage) {
        this.altairMessage = altairMessage;
        return this;
    }

    public List<MensalPosition> getMensalPosition() {
        return mensalPosition;
    }

    public void setMensalPosition(List<MensalPosition> mensalPosition) {
        this.mensalPosition = mensalPosition;
    }

    public InvestimentosCMPosicaoResponseDTO withMensalPosition(List<MensalPosition> mensalPosition) {
        this.mensalPosition = mensalPosition;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(altairMessage).append(mensalPosition).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof InvestimentosCMPosicaoResponseDTO) == false) {
            return false;
        }
        InvestimentosCMPosicaoResponseDTO rhs = ((InvestimentosCMPosicaoResponseDTO) other);
        return new EqualsBuilder().append(altairMessage, rhs.altairMessage).append(mensalPosition, rhs.mensalPosition).isEquals();
    }

}
