package com.altec.bsbr.app.ibe.dto.agendamentos;

import java.io.Serializable;

public class CelularDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4816407484962486897L;
	
	private String tipoRecorrente;
	private String nomeOperadora;
	private String telefoneComDdd;

	public String getTipoRecorrente() {
		return tipoRecorrente;
	}

	public void setTipoRecorrente(String tipoRecorrente) {
		this.tipoRecorrente = tipoRecorrente;
	}

	public String getNomeOperadora() {
		return nomeOperadora;
	}

	public void setNomeOperadora(String nomeOperadora) {
		this.nomeOperadora = nomeOperadora;
	}

	public String getTelefoneComDdd() {
		return telefoneComDdd;
	}

	public void setTelefoneComDdd(String telefoneComDdd) {
		this.telefoneComDdd = telefoneComDdd;
	}

}
