package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;

import com.altec.bsbr.app.ibe.enumeration.TipoContaEnum;
import com.altec.bsbr.app.ibe.enumeration.TipoDocumentoEnum;
import com.altec.bsbr.app.ibe.enumeration.TipoFinalidadeEnum;
import com.altec.bsbr.app.ibe.enumeration.TipoTitularidadeEnum;
import com.altec.bsbr.app.ibe.enumeration.TipoTransferenciaEnum;

public class DadosTransferenciaDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8117424054039761446L;
	private BigDecimal valor;
	private String valorTarifa;
	private String dtAgendamento;
	private String dtContabil;
	private TipoContaEnum tipoContaDestino;
	private TipoContaEnum tipoContaOrigem;
	private String agenciaDestino;
	private String bancoDestino;
	private String contaDestino;
	private String dvContaDestino;
	private String titularDestino;
	private String titularDestino2;
	private String docDestino;
	private String docDestino2;
	private String tipoOperacao;
	private TipoFinalidadeEnum finalidade;
	private String chaveAutenticacao;
	private String chave23SemCript;
	private String gerouPendencia;
	private TipoDocumentoEnum tipoDocumento;
	private TipoTransferenciaEnum tipoTransferencia;
	private TipoTitularidadeEnum tipoTitularidade;
	private String salvarConta;
	private String nomeBancoDestino;
	private String numeroDoc;
	private String tipoContaDestinoDOCTED;
	private String tipoTransacao;
	private ListaRelacaoBancosDTO bancoAtivo;
	private String historico;
	
	public String getValorTarifa() {
		return valorTarifa;
	}
	public void setValorTarifa(String valorTarifa) {
		this.valorTarifa = valorTarifa;
	}
	public String getDtContabil() {
		return dtContabil;
	}
	public void setDtContabil(String dtContabil) {
		this.dtContabil = dtContabil;
	}
	public String getNumeroDoc() {
		return numeroDoc;
	}
	public void setNumeroDoc(String numeroDoc) {
		this.numeroDoc = numeroDoc;
	}
	public String getSalvarConta() {
		return salvarConta;
	}
	public void setSalvarConta(String salvarConta) {
		this.salvarConta = salvarConta;
	}
	public String getNomeBancoDestino() {
		return nomeBancoDestino;
	}
	public void setNomeBancoDestino(String nomeBancoDestino) {
		this.nomeBancoDestino = nomeBancoDestino;
	}
	public BigDecimal getValor() {
		return valor;
	}
	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}
	public String getDtAgendamento() {
		return dtAgendamento;
	}
	public void setDtAgendamento(String dtAgendamento) {
		this.dtAgendamento = dtAgendamento;
	}
	public TipoContaEnum getTipoContaDestino() {
		return tipoContaDestino;
	}
	public void setTipoContaDestino(TipoContaEnum tipoContaDestino) {
		this.tipoContaDestino = tipoContaDestino;
	}
	public String getAgenciaDestino() {
		return agenciaDestino;
	}
	public void setAgenciaDestino(String agenciaDestino) {
		this.agenciaDestino = agenciaDestino;
	}
	public String getContaDestino() {
		return contaDestino;
	}
	public void setContaDestino(String contaDestino) {
		this.contaDestino = contaDestino;
	}
	public String getTipoOperacao() {
		return tipoOperacao;
	}
	public void setTipoOperacao(String tipoOperacao) {
		this.tipoOperacao = tipoOperacao;
	}
	public TipoFinalidadeEnum getFinalidade() {
		return finalidade;
	}
	public void setFinalidade(TipoFinalidadeEnum finalidade) {
		this.finalidade = finalidade;
	}
	public String getChaveAutenticacao() {
		return chaveAutenticacao;
	}
	public void setChaveAutenticacao(String chaveAutenticacao) {
		this.chaveAutenticacao = chaveAutenticacao;
	}
	public String getChave23SemCript() {
		return chave23SemCript;
	}
	public void setChave23SemCript(String chave23SemCript) {
		this.chave23SemCript = chave23SemCript;
	}
	public String getBancoDestino() {
		return bancoDestino;
	}
	public void setBancoDestino(String bancoDestino) {
		this.bancoDestino = bancoDestino;
	}
	public String getGerouPendencia() {
		return gerouPendencia;
	}
	public void setGerouPendencia(String gerouPendencia) {
		this.gerouPendencia = gerouPendencia;
	}
	public TipoDocumentoEnum getTipoDocumento() {
		return tipoDocumento;
	}
	public void setTipoDocumento(TipoDocumentoEnum tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}
	public String getTitularDestino() {
		return titularDestino;
	}
	public void setTitularDestino(String titularDestino) {
		this.titularDestino = titularDestino;
	}
	public String getDocDestino() {
		return docDestino;
	}
	public void setDocDestino(String docDestino) {
		this.docDestino = docDestino;
	}
	public TipoTransferenciaEnum getTipoTransferencia() {
		return tipoTransferencia;
	}
	public void setTipoTransferencia(TipoTransferenciaEnum tipoTransferencia) {
		this.tipoTransferencia = tipoTransferencia;
	}
	public TipoContaEnum getTipoContaOrigem() {
		return tipoContaOrigem;
	}
	public void setTipoContaOrigem(TipoContaEnum tipoContaOrigem) {
		this.tipoContaOrigem = tipoContaOrigem;
	}
	public String getTitularDestino2() {
		return titularDestino2;
	}
	public void setTitularDestino2(String titularDestino2) {
		this.titularDestino2 = titularDestino2;
	}
	public String getDocDestino2() {
		return docDestino2;
	}
	public void setDocDestino2(String docDestino2) {
		this.docDestino2 = docDestino2;
	}
	public TipoTitularidadeEnum getTipoTitularidade() {
		return tipoTitularidade;
	}
	public void setTipoTitularidade(TipoTitularidadeEnum tipoTitularidade) {
		this.tipoTitularidade = tipoTitularidade;
	}
	public String getTipoContaDestinoDOCTED() {
		return tipoContaDestinoDOCTED;
	}
	public void setTipoContaDestinoDOCTED(String tipoContaDestinoDOCTED) {
		this.tipoContaDestinoDOCTED = tipoContaDestinoDOCTED;
	}
	public String getTipoTransacao() {
		return tipoTransacao;
	}
	public void setTipoTransacao(String tipoTransacao) {
		this.tipoTransacao = tipoTransacao;
	}
	public ListaRelacaoBancosDTO getBancoAtivo() {
		return bancoAtivo;
	}
	public void setBancoAtivo(ListaRelacaoBancosDTO bancoAtivo) {
		this.bancoAtivo = bancoAtivo;
	}
	public String getHistorico() {
		return historico;
	}
	public void setHistorico(String historico) {
		this.historico = historico;
	}
	public String getDvContaDestino() {
		return dvContaDestino;
	}
	public void setDvContaDestino(String dvContaDestino) {
		this.dvContaDestino = dvContaDestino;
	}
}
