package com.altec.bsbr.app.ibe.dto;

import java.util.Date;
import java.util.List;

import com.altec.bsbr.app.ibe.enumeration.PosicaoConsTransacaoEnum;

public class ConsultaPosicaoConsolidadaDTO {

	private Date dataInicial;
	private Date dataFinal;
	private Integer codProdutoSelecionado;
	private String nomeProdutoSelecionado;
	private PosicaoConsTransacaoEnum tipoTransacaoSelecionada;
	private String transacaoSelecionada;
	private String convenioSelecionado;
	private String contaDebSelecionada;
	private List<ItemPosicaoConsolidadaConsultarDTO> posicaoConsolidadaResult;
	
	
	public Date getDataInicial() {
		return dataInicial;
	}
	public void setDataInicial(Date dataInicial) {
		this.dataInicial = dataInicial;
	}
	public Date getDataFinal() {
		return dataFinal;
	}
	public void setDataFinal(Date dataFinal) {
		this.dataFinal = dataFinal;
	}
	public Integer getCodProdutoSelecionado() {
		return codProdutoSelecionado;
	}
	public void setCodProdutoSelecionado(Integer codProdutoSelecionado) {
		this.codProdutoSelecionado = codProdutoSelecionado;
	}
	public String getNomeProdutoSelecionado() {
		return nomeProdutoSelecionado;
	}
	public void setNomeProdutoSelecionado(String nomeProdutoSelecionado) {
		this.nomeProdutoSelecionado = nomeProdutoSelecionado;
	}
	public PosicaoConsTransacaoEnum getTipoTransacaoSelecionada() {
		return tipoTransacaoSelecionada;
	}
	public void setTipoTransacaoSelecionada(PosicaoConsTransacaoEnum tipoTransacaoSelecionada) {
		this.tipoTransacaoSelecionada = tipoTransacaoSelecionada;
	}
	public String getConvenioSelecionado() {
		return convenioSelecionado;
	}
	public void setConvenioSelecionado(String convenioSelecionado) {
		this.convenioSelecionado = convenioSelecionado;
	}
	public String getContaDebSelecionada() {
		return contaDebSelecionada;
	}
	public void setContaDebSelecionada(String contaDebSelecionada) {
		this.contaDebSelecionada = contaDebSelecionada;
	}
	public List<ItemPosicaoConsolidadaConsultarDTO> getPosicaoConsolidadaResult() {
		return posicaoConsolidadaResult;
	}
	public void setPosicaoConsolidadaResult(List<ItemPosicaoConsolidadaConsultarDTO> posicaoConsolidadaResult) {
		this.posicaoConsolidadaResult = posicaoConsolidadaResult;
	}
	
	
	/**
	 * Formatar conta debito e convenio para apresentar na tela de resultado
	 */
	public String getContaDebFormatada(){
		String conta = this.contaDebSelecionada;
		
		return conta.substring(4, 8) + " - " + conta.substring(11, 20);
	}
	
	public String getConvenioFormatado(){
		String convenio = this.convenioSelecionado;
		
		return convenio.substring(0, 4) + " - " + convenio.substring(4, 8) + " - " + convenio.substring(8, 20);
	}
	public String getTransacaoSelecionada() {
		return transacaoSelecionada;
	}
	public void setTransacaoSelecionada(String transacaoSelecionada) {
		PosicaoConsTransacaoEnum tSelecionada = PosicaoConsTransacaoEnum.findByDescricao(transacaoSelecionada);
		this.tipoTransacaoSelecionada = tSelecionada;
		this.transacaoSelecionada = transacaoSelecionada;
	}
}
