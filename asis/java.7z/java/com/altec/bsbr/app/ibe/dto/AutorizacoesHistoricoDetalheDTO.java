package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.jsoup.select.Evaluator.IsEmpty;

public class AutorizacoesHistoricoDetalheDTO implements Serializable{

	private static final long serialVersionUID = 7862291142463960632L;
	
	private String produto;
	private String dataEfetivacao;
	private String valor;
	private String tipoPagamento;
	private String agenciaConta;
	private String situacaoTrasacao;
	private String codigoRetorno;
	private String mensagemRetornoCliente;
	private String mensagemRetornoProduto;
	private List<HistoricoTrasacaoDetalheItemDTO> detalhes;
	private List<DetalheHistoricoAssinatura> historicoAssinatura;
	
	/**
	 * AutorizacoesHistoricoDetalheDTO
	 */
	public AutorizacoesHistoricoDetalheDTO() {
		setDetalhes(new ArrayList<HistoricoTrasacaoDetalheItemDTO>());
		setHistoricoAssinatura(new ArrayList<DetalheHistoricoAssinatura>());
	}
	
	
	/**
	 * @return the produto
	 */
	public String getProduto() {
		return produto;
	}

	/**
	 * @param produto
	 *            the produto to set
	 */
	public void setProduto(String produto) {
		this.produto = produto;
	}

	/**
	 * @return the dataEfetivacao
	 */
	public String getDataEfetivacao() {
		return dataEfetivacao;
	}

	/**
	 * @param dataEfetivacao
	 *            the dataEfetivacao to set
	 */
	public void setDataEfetivacao(String dataEfetivacao) {
		this.dataEfetivacao = dataEfetivacao;
	}

	/**
	 * @return the detalhes
	 */
	public List<HistoricoTrasacaoDetalheItemDTO> getDetalhes() {
		return detalhes;
	}

	/**
	 * @param detalhes
	 *            the detalhes to set
	 */
	public void setDetalhes(List<HistoricoTrasacaoDetalheItemDTO> detalhes) {
		this.detalhes = detalhes;
	}


	/**
	 * @return the valor
	 */
	public String getValor() {
		return valor;
	}


	/**
	 * @param valor the valor to set
	 */
	public void setValor(String valor) {
		this.valor = valor;
	}


	/**
	 * @return the tipoPagamento
	 */
	public String getTipoPagamento() {
		return tipoPagamento;
	}


	/**
	 * @param tipoPagamento the tipoPagamento to set
	 */
	public void setTipoPagamento(String tipoPagamento) {
		this.tipoPagamento = tipoPagamento;
	}


	/**
	 * @return the agenciaConta
	 */
	public String getAgenciaConta() {
		return agenciaConta;
	}


	/**
	 * @param agenciaConta the agenciaConta to set
	 */
	public void setAgenciaConta(String agenciaConta) {
		this.agenciaConta = agenciaConta;
	}


	/**
	 * @return the situacaoTrasacao
	 */
	public String getSituacaoTrasacao() {
		return situacaoTrasacao;
	}


	/**
	 * @param situacaoTrasacao the situacaoTrasacao to set
	 */
	public void setSituacaoTrasacao(String situacaoTrasacao) {
		this.situacaoTrasacao = situacaoTrasacao;
	}


	/**
	 * @return the historicoAssinatura
	 */
	public List<DetalheHistoricoAssinatura> getHistoricoAssinatura() {
		return historicoAssinatura;
	}


	/**
	 * @param historicoAssinatura the historicoAssinatura to set
	 */
	public void setHistoricoAssinatura(List<DetalheHistoricoAssinatura> historicoAssinatura) {
		this.historicoAssinatura = historicoAssinatura;
	}


	/**
	 * @return the codigoRetorno
	 */
	public String getCodigoRetorno() {
		return codigoRetorno;
	}


	/**
	 * @param codigoRetorno the codigoRetorno to set
	 */
	public void setCodigoRetorno(String codigoRetorno) {
		this.codigoRetorno = codigoRetorno;
	}


	/**
	 * @return the mensagemRetornoCliente
	 */
	public String getMensagemRetornoCliente() {
		return mensagemRetornoCliente;
	}


	/**
	 * @param mensagemRetornoCliente the mensagemRetornoCliente to set
	 */
	public void setMensagemRetornoCliente(String mensagemRetornoCliente) {
		this.mensagemRetornoCliente = mensagemRetornoCliente;
	}


	/**
	 * @return the mensagemRetornoProduto
	 */
	public String getMensagemRetornoProduto() {
		return mensagemRetornoProduto;
	}


	/**
	 * @param mensagemRetornoProduto the mensagemRetornoProduto to set
	 */
	public void setMensagemRetornoProduto(String mensagemRetornoProduto) {
		this.mensagemRetornoProduto = mensagemRetornoProduto;
	}
	
	
}