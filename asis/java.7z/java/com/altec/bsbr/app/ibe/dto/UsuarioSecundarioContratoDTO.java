package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class UsuarioSecundarioContratoDTO implements Serializable {

	private static final long serialVersionUID = 1;

	private String idUsuario;
	private String nomeUsuario;
	private String nomeAcesso;

	public UsuarioSecundarioContratoDTO() {

	}

	public String getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(String idUsuario) {
		this.idUsuario = idUsuario;
	}

	public String getNomeUsuario() {
		return nomeUsuario;
	}

	public void setNomeUsuario(String nomeUsuario) {
		this.nomeUsuario = nomeUsuario;
	}

	public String getNomeAcesso() {
		return nomeAcesso;
	}

	public void setNomeAcesso(String nomeAcesso) {
		this.nomeAcesso = nomeAcesso;
	}

	public String getNomeConcatenado() {
		if (getIdUsuario() != null && getNomeAcesso() != null && getNomeUsuario() != null) {
			StringBuilder nomeContatenado = new StringBuilder();
			nomeContatenado.append(getIdUsuario());
			nomeContatenado.append(" ");
			nomeContatenado.append(getNomeUsuario());
			nomeContatenado.append(" [");
			nomeContatenado.append(getNomeAcesso());
			nomeContatenado.append("]");
			return nomeContatenado.toString();
		} else {
			return "";
		}
	}

}
