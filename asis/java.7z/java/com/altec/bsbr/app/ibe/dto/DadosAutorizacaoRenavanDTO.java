package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class DadosAutorizacaoRenavanDTO implements Serializable {

	private static final long serialVersionUID = -7115052930472414705L;
	
	private String tpprod;
	private String sbtppag;
	private String indaut;
	private String identif;
	private String nome;
	private String placa;
	private String indexc;
	private Boolean selecionado;

	public String getTpprod() {
		return tpprod;
	}

	public void setTpprod(String tpprod) {
		this.tpprod = tpprod;
	}

	public String getSbtppag() {
		return sbtppag;
	}

	public void setSbtppag(String sbtppag) {
		this.sbtppag = sbtppag;
	}

	public String getIndaut() {
		return indaut;
	}

	public void setIndaut(String indaut) {
		this.indaut = indaut;
	}

	public String getIdentif() {
		return identif;
	}

	public void setIdentif(String identif) {
		this.identif = identif;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getPlaca() {
		return placa;
	}

	public void setPlaca(String placa) {
		this.placa = placa;
	}

	public String getIndexc() {
		return indexc;
	}

	public void setIndexc(String indexc) {
		this.indexc = indexc;
	}

	public Boolean getSelecionado() {
		return selecionado;
	}

	public void setSelecionado(Boolean selecionado) {
		this.selecionado = selecionado;
	}

}
