package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;


public class PerfilAcessoInclusaoDTO implements Serializable {

	private static final long serialVersionUID = 8150343169429694821L;


	private String nomePerfil;
	private String descricao;
	private Integer id;
	private boolean pendencias;
	//private String OrigemSec;	
	
	public Boolean getPendencias() {
		return pendencias;
	}
	public void setPendencias(Boolean pendencias) {
		this.pendencias = pendencias;
	}
	public String getNomePerfil() {
		return nomePerfil;
	}
	public void setNomePerfil(String nomePerfil) {
		this.nomePerfil = nomePerfil;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	public PerfilAcessoInclusaoDTO() {
		
	}
	
	public PerfilAcessoInclusaoDTO(String nomePerfil, String descricaoPerfil) {
		super();
		this.nomePerfil = nomePerfil;
		this.descricao =  descricaoPerfil;
	}
	
}
