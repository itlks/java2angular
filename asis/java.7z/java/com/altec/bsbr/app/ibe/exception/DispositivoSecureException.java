package com.altec.bsbr.app.ibe.exception;

import com.altec.bsbr.fw.BusinessException;

public class DispositivoSecureException extends BusinessException {
	private static final long serialVersionUID = -1350374034132101850L;
	private String aliasPaginaErro;
	
	public DispositivoSecureException(String message) {
		super(message);
	}

	public DispositivoSecureException(String message, String aliasPaginaErro, Exception e) {
		super(message, e);
		this.aliasPaginaErro = aliasPaginaErro;
	}

	public String getAlias() {
		return aliasPaginaErro;
	}
}
