package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

import com.altec.bsbr.app.ibe.webclient.bks.convenio.CONTRATOBRType;

public class ConsultarListaConvenioProdutoRequestWebDTO  implements Serializable {

	
	private static final long serialVersionUID = 1L;
	
	protected String sistema;
    protected String produto;
    protected String penum01;
    protected String penum02;
    protected String penum03;
    protected String penum04;
    protected String penum05;
    protected String penum06;
    protected String penum07;
    protected String penum08;
    protected String penum09;
    protected String penum10;
    protected String penum11;
    protected String penum12;
    protected String penum13;
    protected String penum14;
    protected String penum15;
    protected String penum16;
    protected String penum17;
    protected String penum18;
    protected String penum19;
    protected String penum20;
    protected String penum21;
    protected String penum22;
    protected String penum23;
    protected String penum24;
    protected String penum25;
    protected String penum26;
    protected String penum27;
    protected String penum28;
    protected String penum29;
    protected String penum30;
    protected String penum31;
    protected String penum32;
    protected String penum33;
    protected String penum34;
    protected String penum35;
    protected String penum36;
    protected String penum37;
    protected String penum38;
    protected String penum39;
    protected String penum40;
    protected String penum41;
    protected String penum42;
    protected String penum43;
    protected String penum44;
    protected String penum45;
    protected String penum46;
    protected String penum47;
    protected String penum48;
    protected String penum49;
    protected String penum50;
    protected String indrea;
    protected Integer numreg;
    protected String penumre;
    protected Long penomre;
    protected CONTRATOBRType entppal;
    protected CONTRATOBRType entideb;

    /**
     * Gets the value of the sistema property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSistema() {
        return sistema;
    }

    /**
     * Sets the value of the sistema property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSistema(String value) {
        this.sistema = value;
    }

    /**
     * Gets the value of the produto property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProduto() {
        return produto;
    }

    /**
     * Sets the value of the produto property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProduto(String value) {
        this.produto = value;
    }

    /**
     * Gets the value of the penum01 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum01() {
        return penum01;
    }

    /**
     * Sets the value of the penum01 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum01(String value) {
        this.penum01 = value;
    }

    /**
     * Gets the value of the penum02 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum02() {
        return penum02;
    }

    /**
     * Sets the value of the penum02 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum02(String value) {
        this.penum02 = value;
    }

    /**
     * Gets the value of the penum03 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum03() {
        return penum03;
    }

    /**
     * Sets the value of the penum03 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum03(String value) {
        this.penum03 = value;
    }

    /**
     * Gets the value of the penum04 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum04() {
        return penum04;
    }

    /**
     * Sets the value of the penum04 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum04(String value) {
        this.penum04 = value;
    }

    /**
     * Gets the value of the penum05 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum05() {
        return penum05;
    }

    /**
     * Sets the value of the penum05 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum05(String value) {
        this.penum05 = value;
    }

    /**
     * Gets the value of the penum06 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum06() {
        return penum06;
    }

    /**
     * Sets the value of the penum06 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum06(String value) {
        this.penum06 = value;
    }

    /**
     * Gets the value of the penum07 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum07() {
        return penum07;
    }

    /**
     * Sets the value of the penum07 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum07(String value) {
        this.penum07 = value;
    }

    /**
     * Gets the value of the penum08 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum08() {
        return penum08;
    }

    /**
     * Sets the value of the penum08 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum08(String value) {
        this.penum08 = value;
    }

    /**
     * Gets the value of the penum09 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum09() {
        return penum09;
    }

    /**
     * Sets the value of the penum09 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum09(String value) {
        this.penum09 = value;
    }

    /**
     * Gets the value of the penum10 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum10() {
        return penum10;
    }

    /**
     * Sets the value of the penum10 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum10(String value) {
        this.penum10 = value;
    }

    /**
     * Gets the value of the penum11 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum11() {
        return penum11;
    }

    /**
     * Sets the value of the penum11 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum11(String value) {
        this.penum11 = value;
    }

    /**
     * Gets the value of the penum12 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum12() {
        return penum12;
    }

    /**
     * Sets the value of the penum12 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum12(String value) {
        this.penum12 = value;
    }

    /**
     * Gets the value of the penum13 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum13() {
        return penum13;
    }

    /**
     * Sets the value of the penum13 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum13(String value) {
        this.penum13 = value;
    }

    /**
     * Gets the value of the penum14 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum14() {
        return penum14;
    }

    /**
     * Sets the value of the penum14 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum14(String value) {
        this.penum14 = value;
    }

    /**
     * Gets the value of the penum15 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum15() {
        return penum15;
    }

    /**
     * Sets the value of the penum15 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum15(String value) {
        this.penum15 = value;
    }

    /**
     * Gets the value of the penum16 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum16() {
        return penum16;
    }

    /**
     * Sets the value of the penum16 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum16(String value) {
        this.penum16 = value;
    }

    /**
     * Gets the value of the penum17 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum17() {
        return penum17;
    }

    /**
     * Sets the value of the penum17 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum17(String value) {
        this.penum17 = value;
    }

    /**
     * Gets the value of the penum18 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum18() {
        return penum18;
    }

    /**
     * Sets the value of the penum18 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum18(String value) {
        this.penum18 = value;
    }

    /**
     * Gets the value of the penum19 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum19() {
        return penum19;
    }

    /**
     * Sets the value of the penum19 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum19(String value) {
        this.penum19 = value;
    }

    /**
     * Gets the value of the penum20 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum20() {
        return penum20;
    }

    /**
     * Sets the value of the penum20 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum20(String value) {
        this.penum20 = value;
    }

    /**
     * Gets the value of the penum21 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum21() {
        return penum21;
    }

    /**
     * Sets the value of the penum21 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum21(String value) {
        this.penum21 = value;
    }

    /**
     * Gets the value of the penum22 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum22() {
        return penum22;
    }

    /**
     * Sets the value of the penum22 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum22(String value) {
        this.penum22 = value;
    }

    /**
     * Gets the value of the penum23 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum23() {
        return penum23;
    }

    /**
     * Sets the value of the penum23 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum23(String value) {
        this.penum23 = value;
    }

    /**
     * Gets the value of the penum24 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum24() {
        return penum24;
    }

    /**
     * Sets the value of the penum24 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum24(String value) {
        this.penum24 = value;
    }

    /**
     * Gets the value of the penum25 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum25() {
        return penum25;
    }

    /**
     * Sets the value of the penum25 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum25(String value) {
        this.penum25 = value;
    }

    /**
     * Gets the value of the penum26 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum26() {
        return penum26;
    }

    /**
     * Sets the value of the penum26 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum26(String value) {
        this.penum26 = value;
    }

    /**
     * Gets the value of the penum27 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum27() {
        return penum27;
    }

    /**
     * Sets the value of the penum27 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum27(String value) {
        this.penum27 = value;
    }

    /**
     * Gets the value of the penum28 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum28() {
        return penum28;
    }

    /**
     * Sets the value of the penum28 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum28(String value) {
        this.penum28 = value;
    }

    /**
     * Gets the value of the penum29 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum29() {
        return penum29;
    }

    /**
     * Sets the value of the penum29 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum29(String value) {
        this.penum29 = value;
    }

    /**
     * Gets the value of the penum30 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum30() {
        return penum30;
    }

    /**
     * Sets the value of the penum30 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum30(String value) {
        this.penum30 = value;
    }

    /**
     * Gets the value of the penum31 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum31() {
        return penum31;
    }

    /**
     * Sets the value of the penum31 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum31(String value) {
        this.penum31 = value;
    }

    /**
     * Gets the value of the penum32 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum32() {
        return penum32;
    }

    /**
     * Sets the value of the penum32 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum32(String value) {
        this.penum32 = value;
    }

    /**
     * Gets the value of the penum33 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum33() {
        return penum33;
    }

    /**
     * Sets the value of the penum33 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum33(String value) {
        this.penum33 = value;
    }

    /**
     * Gets the value of the penum34 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum34() {
        return penum34;
    }

    /**
     * Sets the value of the penum34 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum34(String value) {
        this.penum34 = value;
    }

    /**
     * Gets the value of the penum35 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum35() {
        return penum35;
    }

    /**
     * Sets the value of the penum35 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum35(String value) {
        this.penum35 = value;
    }

    /**
     * Gets the value of the penum36 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum36() {
        return penum36;
    }

    /**
     * Sets the value of the penum36 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum36(String value) {
        this.penum36 = value;
    }

    /**
     * Gets the value of the penum37 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum37() {
        return penum37;
    }

    /**
     * Sets the value of the penum37 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum37(String value) {
        this.penum37 = value;
    }

    /**
     * Gets the value of the penum38 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum38() {
        return penum38;
    }

    /**
     * Sets the value of the penum38 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum38(String value) {
        this.penum38 = value;
    }

    /**
     * Gets the value of the penum39 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum39() {
        return penum39;
    }

    /**
     * Sets the value of the penum39 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum39(String value) {
        this.penum39 = value;
    }

    /**
     * Gets the value of the penum40 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum40() {
        return penum40;
    }

    /**
     * Sets the value of the penum40 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum40(String value) {
        this.penum40 = value;
    }

    /**
     * Gets the value of the penum41 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum41() {
        return penum41;
    }

    /**
     * Sets the value of the penum41 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum41(String value) {
        this.penum41 = value;
    }

    /**
     * Gets the value of the penum42 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum42() {
        return penum42;
    }

    /**
     * Sets the value of the penum42 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum42(String value) {
        this.penum42 = value;
    }

    /**
     * Gets the value of the penum43 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum43() {
        return penum43;
    }

    /**
     * Sets the value of the penum43 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum43(String value) {
        this.penum43 = value;
    }

    /**
     * Gets the value of the penum44 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum44() {
        return penum44;
    }

    /**
     * Sets the value of the penum44 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum44(String value) {
        this.penum44 = value;
    }

    /**
     * Gets the value of the penum45 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum45() {
        return penum45;
    }

    /**
     * Sets the value of the penum45 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum45(String value) {
        this.penum45 = value;
    }

    /**
     * Gets the value of the penum46 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum46() {
        return penum46;
    }

    /**
     * Sets the value of the penum46 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum46(String value) {
        this.penum46 = value;
    }

    /**
     * Gets the value of the penum47 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum47() {
        return penum47;
    }

    /**
     * Sets the value of the penum47 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum47(String value) {
        this.penum47 = value;
    }

    /**
     * Gets the value of the penum48 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum48() {
        return penum48;
    }

    /**
     * Sets the value of the penum48 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum48(String value) {
        this.penum48 = value;
    }

    /**
     * Gets the value of the penum49 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum49() {
        return penum49;
    }

    /**
     * Sets the value of the penum49 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum49(String value) {
        this.penum49 = value;
    }

    /**
     * Gets the value of the penum50 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenum50() {
        return penum50;
    }

    /**
     * Sets the value of the penum50 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenum50(String value) {
        this.penum50 = value;
    }

    /**
     * Gets the value of the indrea property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIndrea() {
        return indrea;
    }

    /**
     * Sets the value of the indrea property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIndrea(String value) {
        this.indrea = value;
    }

    /**
     * Gets the value of the numreg property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNumreg() {
        return numreg;
    }

    /**
     * Sets the value of the numreg property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumreg(Integer value) {
        this.numreg = value;
    }

    /**
     * Gets the value of the penumre property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPenumre() {
        return penumre;
    }

    /**
     * Sets the value of the penumre property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPenumre(String value) {
        this.penumre = value;
    }

    /**
     * Gets the value of the penomre property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getPenomre() {
        return penomre;
    }

    /**
     * Sets the value of the penomre property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setPenomre(Long value) {
        this.penomre = value;
    }

    /**
     * Gets the value of the entppal property.
     * 
     * @return
     *     possible object is
     *     {@link CONTRATOBRType }
     *     
     */
    public CONTRATOBRType getEntppal() {
        return entppal;
    }

    /**
     * Sets the value of the entppal property.
     * 
     * @param value
     *     allowed object is
     *     {@link CONTRATOBRType }
     *     
     */
    public void setEntppal(CONTRATOBRType value) {
        this.entppal = value;
    }

    /**
     * Gets the value of the entideb property.
     * 
     * @return
     *     possible object is
     *     {@link CONTRATOBRType }
     *     
     */
    public CONTRATOBRType getEntideb() {
        return entideb;
    }

    /**
     * Sets the value of the entideb property.
     * 
     * @param value
     *     allowed object is
     *     {@link CONTRATOBRType }
     *     
     */
    public void setEntideb(CONTRATOBRType value) {
        this.entideb = value;
    }
}
