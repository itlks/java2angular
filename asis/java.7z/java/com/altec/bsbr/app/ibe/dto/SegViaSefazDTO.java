package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class SegViaSefazDTO extends GenericDTO implements Serializable {

	private static final long serialVersionUID = -7156575846863409394L;

	private String entArrecadacao;
	private String cenArrecadacao;
	private Date dtMovimentacao;
	private Integer seqArrecadacao;
	private Date dtArrecadacao;
	private String convenio;
	private String descConvenio;
	private String descProduto;
	private String descCanal;
	private String status;
	private String numNio;
	private Integer seqNio;
	private String tpIdentificador;
	private String identificador;
	private String ctaDebito;
	private BigDecimal valTotal;
	private String tpRecolhimento;
	private Date dtContabil;
	private Integer codServico;
	private String renavam;
	private String placa;
	private String param;
	private String tab;
	private Integer part;
	private String dataPagamento;
	private boolean selecionado;

	public String getEntArrecadacao() {
		return entArrecadacao;
	}

	public void setEntArrecadacao(String entArrecadacao) {
		this.entArrecadacao = entArrecadacao;
	}

	public String getCenArrecadacao() {
		return cenArrecadacao;
	}

	public void setCenArrecadacao(String cenArrecadacao) {
		this.cenArrecadacao = cenArrecadacao;
	}

	public Date getDtMovimentacao() {
		return dtMovimentacao;
	}

	public void setDtMovimentacao(Date dtMovimentacao) {
		this.dtMovimentacao = dtMovimentacao;
	}

	public Integer getSeqArrecadacao() {
		return seqArrecadacao;
	}

	public void setSeqArrecadacao(Integer seqArrecadacao) {
		this.seqArrecadacao = seqArrecadacao;
	}

	public Date getDtArrecadacao() {
		return dtArrecadacao;
	}

	public void setDtArrecadacao(Date dtArrecadacao) {
		this.dtArrecadacao = dtArrecadacao;
	}

	public String getConvenio() {
		return convenio;
	}

	public void setConvenio(String convenio) {
		this.convenio = convenio;
	}

	public String getDescConvenio() {
		return descConvenio;
	}

	public void setDescConvenio(String descConvenio) {
		this.descConvenio = descConvenio;
	}

	public String getDescProduto() {
		return descProduto;
	}

	public void setDescProduto(String descProduto) {
		this.descProduto = descProduto;
	}

	public String getDescCanal() {
		return descCanal;
	}

	public void setDescCanal(String descCanal) {
		this.descCanal = descCanal;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getNumNio() {
		return numNio;
	}

	public void setNumNio(String numNio) {
		this.numNio = numNio;
	}

	public Integer getSeqNio() {
		return seqNio;
	}

	public void setSeqNio(Integer seqNio) {
		this.seqNio = seqNio;
	}

	public String getTpIdentificador() {
		return tpIdentificador;
	}

	public void setTpIdentificador(String tpIdentificador) {
		this.tpIdentificador = tpIdentificador;
	}

	public String getIdentificador() {
		return identificador;
	}

	public void setIdentificador(String identificador) {
		this.identificador = identificador;
	}

	public String getCtaDebito() {
		return ctaDebito;
	}

	public void setCtaDebito(String ctaDebito) {
		this.ctaDebito = ctaDebito;
	}

	public BigDecimal getValTotal() {
		return valTotal;
	}

	public void setValTotal(BigDecimal valTotal) {
		this.valTotal = valTotal;
	}

	public String getTpRecolhimento() {
		return tpRecolhimento;
	}

	public void setTpRecolhimento(String tpRecolhimento) {
		this.tpRecolhimento = tpRecolhimento;
	}

	public Date getDtContabil() {
		return dtContabil;
	}

	public void setDtContabil(Date dtContabil) {
		this.dtContabil = dtContabil;
	}

	public Integer getCodServico() {
		return codServico;
	}

	public void setCodServico(Integer codServico) {
		this.codServico = codServico;
	}

	public String getRenavam() {
		return renavam;
	}

	public void setRenavam(String renavam) {
		this.renavam = renavam;
	}

	public String getPlaca() {
		return placa;
	}

	public void setPlaca(String placa) {
		this.placa = placa;
	}

	public String getParam() {
		return param;
	}

	public void setParam(String param) {
		this.param = param;
	}

	public String getTab() {
		return tab;
	}

	public void setTab(String tab) {
		this.tab = tab;
	}

	public Integer getPart() {
		return part;
	}

	public void setPart(Integer part) {
		this.part = part;
	}

	public String getDataPagamento() {
		return dataPagamento;
	}

	public void setDataPagamento(String dataPagamento) {
		this.dataPagamento = dataPagamento;
	}

	public boolean isSelecionado() {
		return selecionado;
	}

	public void setSelecionado(boolean selecionado) {
		this.selecionado = selecionado;
	}
}