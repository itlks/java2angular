/*
 * Cheque Ades�o Empresa Protegido (Hub DTO para controle de fluxo)
 *
 */

package com.altec.bsbr.app.ibe.rest.hub.dto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class HubRestResourceDTO {

	@Autowired
	@Qualifier("hub-host")
	private String host;
	@Autowired
	@Qualifier("gw-app-key")
	private String appKey;
	private String resource;

	public void setHost(String host) {
		this.host = host;
	}

	public void setAppKey(String appKey) {
		this.appKey = appKey;
	}

	public void setResource(String resource) {
		this.resource = resource;
	}

	public String getUrl() {
		return new StringBuilder(host).append(resource).append(appKey).toString();
	}

}
