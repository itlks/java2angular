package com.altec.bsbr.app.ibe.enumeration;

public enum DicionarioEnum {
    
    TPTRANS     ("Tipo Transacao",                      1),
    CDRET       ("Codigo Retorno",                      2),
    AREAREP     ("Area de Repeticao",                   3),
    IDTRANS     ("ID Transacao",                        4),
    CDCANAL     ("Codigo Canal",                        5),   
    PERNPER     ("PERNUMPER",                           6),
    IDUSER      ("ID Usuario",                          7),
    AGENCIA   	("Numero Agencia",                      8),
    CONTA     	("Numero Conta",                        9),
    CPFCNPJ     ("CPF CNPJ",                            10),
    CDUF        ("Unidade Federativa (UF)",             11),
    BANCO 	    ("Banco Origem",                     	12),
    CDTRANS     ("Codigo Transacao",                    13),
    SEGCLIE     ("Segmento Cliente",                    14),
    VATRANS     ("Valor Transacao",                     15),
    INAGEND     ("Indicator Agendamento",               16),
    INDAPROV    ("Indicador Aprovacao Master",          17),
    BANCOFAV    ("Banco Favorecido",                    18),
    AGENCIAFAV  ("Agencia Favorecido",                  19),
    CONTAFAV    ("Conta Favorecido",                    20),
    CPFCNPJFAV  ("CPF CNPJ Favorecido",                 21),
    CDCEDENT    ("Codigo Cedente",                      22),
    NMCEDENT    ("Nome Cedente",                        23),
    NMSACADO    ("Nome Sacado",                         24),
    LINHADIG    ("Linha Digitavel",                     25),
    CDCONCE     ("Codigo Concessionaria",               26),
    CDTRIBU     ("Codigo Tributo",                      27),
    CDCONTRIB   ("Codigo Contribuinte",                 28),
    CDRENAV     ("Codigo RENAVAN",                      29),
    NUCARTAO    ("Numero Cartao",                       30),
    NUCELULAR   ("Numero Celular",                      31),
    TPPAGTO     ("Tipo Pagamento",                      32),
    CDORGREB    ("Codigo Orgao Recebedor",              33),
    NUCONTR     ("Numero Contrato",                     34),
    TPPESSOA    ("Tipo Pessoa",                         35),
    CONVENIO    ("Convenio",	                        36),
    PRFILETRANS ("Produto File Transfer",		        37),
    STAUTFAV    ("Status Autenticacao Favorecido",      38),
    CNAUTFAV    ("Canal Autorizacao Favorecido",	    39),
    INDCADRNV   ("Indicador Cadastramento RENAVAN",     40),
    CNAUTRNV    ("Canal Autorizacao RENAVAN",     		41),
    WLISTRNV    ("White List RENAVAN",     				42),
    USERLOGIN	("Login Usuario",						43),
    INDMSMTIT	("Indicador Mesma Titularidade",		44),
    INDLOGIN	("Indicador Sucesso Login",				45),
    TPCONTA		("Tipo de Conta",						46),
    INDCRE 		("Indicador Credito em Conta",			47),
        
    //CAMPOS ADAPTIVE AUTHENTICATION
    HTTPACPT    ("httpAccept",                          5001),
    HTTPACPTC   ("httpAcceptChars",                     5002),
    HTTPACPTE	("httpAcceptEncoding",                  5003),
    HTTPACPTL	("httpAcceptLanguage",                  5004),
    HTTPREFER	("httpReferrer",                        5005),
    IPADDRESS	("ipAddress",                           5006),
    USERAGENT 	("userAgent",                           5007),
    DEVCPRINT	("DevicePrint",                         5008),
    DOMELEM     ("DomElements",		                    5009),
    JSEVENTS	("jsEvents",		                    5010),
    GEOLOCAL	("GeoLocation",                   		5011),
    DEVCTKCKIE	("deviceTokenCookie",                   5012),
    DEVCTKFSO	("deviceTokenFSO",                      5013),
    PAGEID		("PageID",			                    5014),
    DATAHR		("Data e Hora",                         5015),
    DEVCIDENT	("Device Identifier",                   5016),
    
    //CAMPOS WC
    TPDISP      ("Tipo Dispositivo",                    6001),
    IDDISP      ("ID Dispositivo",                      6002),
    SENHA       ("Senha",                               6003),
    CDFORN      ("Codigo Fornecedor",                   6004),
    APELIDO     ("Apelido Dispositivo",                 6005),
    STDISP      ("Status Dispositivo",                  6006),
    DDTRANS     ("Dados Transacao",                     6007),
    TITRANS     ("Titulo Transacao",                    6008),
    MSGQR       ("Mensagem QR",                         6009),
    QRCODE      ("Imagem do QR Code",                   6010);
    
    private String nome;
    private int chave;
    
    DicionarioEnum(String nome, int chave)
    {
        this.nome = nome;
        this.chave = chave;
    }
    
    public int getChave()
    {
        return chave;
    }
    
    public String getNome()
    {
        return nome;
    }
    
    public static String getNomePorChave(int chave) 
    {
        for(DicionarioEnum e : values()) 
        {
            if(e.chave == chave)
            {
            	return e.nome;
            }
        }
        return "Campo desconhecido";
     }

}

