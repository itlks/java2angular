package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.Date;

public class SaldoPeriodoDTO implements Serializable {

  private static final long serialVersionUID = -4982485678096839764L;
  private String dataInicial;
  private String dataFinal;
  private String dataInicialPesquisada;
  private String dataFinalPesquisada;
  private String dataHoraPesquisa;
  private Date dataInicialDate;
  private Date dataFinalDate;

  public String getDataInicial() {
    return dataInicial;
  }

  public void setDataInicial(String dataInicial) {
    this.dataInicial = dataInicial;
  }

  public String getDataFinal() {
    return dataFinal;
  }

  public void setDataFinal(String dataFinal) {
    this.dataFinal = dataFinal;
  }

  public String getDataInicialPesquisada() {
    return dataInicialPesquisada;
  }

  public void setDataInicialPesquisada(String dataInicialPesquisada) {
    this.dataInicialPesquisada = dataInicialPesquisada;
  }

  public String getDataFinalPesquisada() {
    return dataFinalPesquisada;
  }

  public void setDataFinalPesquisada(String dataFinalPesquisada) {
    this.dataFinalPesquisada = dataFinalPesquisada;
  }

  public String getDataHoraPesquisa() {
    return dataHoraPesquisa;
  }

  public void setDataHoraPesquisa(String dataHoraPesquisa) {
    this.dataHoraPesquisa = dataHoraPesquisa;
  }

  public Date getDataInicialDate() {
    return dataInicialDate;
  }

  public void setDataInicialDate(Date dataInicialDate) {
    this.dataInicialDate = dataInicialDate;
  }

  public Date getDataFinalDate() {
    return dataFinalDate;
  }

  public void setDataFinalDate(Date dataFinalDate) {
    this.dataFinalDate = dataFinalDate;
  }
}
