package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

import com.altec.bsbr.app.ibe.enumeration.CampanhasEnum;

public class BannerDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8387873332360213799L;

	/**
	 * variaveis de controle
	 */
	private String strImagemUrl;
	private String strTipoCampanha;
	private String strTextoLinkUrl;
	private String strLeftDiv1;
	private String strLeftDiv2;
	private String strLeftDiv3;
	private String strTopDiv1;
	private String strTopDiv2;
	private String strTopDiv3;
	private String strTextoDiv1;
	private String strTextoDiv2;
	private String strTextoDiv3;
	private String strLeftLinkUrl;
	private String linkUrlClassico;
	private String strLinkURL;
	private String strTopLinkUrl;
	private String pagina;
	private String blank;
	private String tpLink;
	private String boId;
	private String raAttribSeg;
	private Boolean habilitarBanner = Boolean.FALSE;
	private Boolean visualizouMidiaCRM = Boolean.FALSE;
	private String width;
	private String height;
	
	private Boolean isMidia3;

	public String getPagina() {
		return pagina;
	}

	public void setPagina(String pagina) {
		this.pagina = pagina;
	}	
	
	public String getStrTextoLinkUrl() {
		return strTextoLinkUrl;
	}

	public void setStrTextoLinkUrl(String strTextoLinkUrl) {
		this.strTextoLinkUrl = strTextoLinkUrl;
	}

	public String getStrImagemUrl() {
		return strImagemUrl;
	}

	public void setStrImagemUrl(String strImagemUrl) {
		this.strImagemUrl = strImagemUrl;
	}

	public String getStrTipoCampanha() {
		return strTipoCampanha;
	}

	public void setStrTipoCampanha(String strTipoCampanha) {
		this.strTipoCampanha = strTipoCampanha;
	}

	public String getStrLeftLinkUrl() {
		return strLeftLinkUrl;
	}

	public void setStrLeftLinkUrl(String strLeftLinkUrl) {
		this.strLeftLinkUrl = strLeftLinkUrl;
	}

	public String getStrLinkURL() {
		return strLinkURL;
	}

	public void setStrLinkURL(String strLinkURL) {
		this.strLinkURL = strLinkURL;
	}

	public String getStrTopLinkUrl() {
		return strTopLinkUrl;
	}

	public void setStrTopLinkUrl(String strTopLinkUrl) {
		this.strTopLinkUrl = strTopLinkUrl;
	}

	public String getStrLeftDiv1() {
		return strLeftDiv1;
	}

	public void setStrLeftDiv1(String strLeftDiv1) {
		this.strLeftDiv1 = strLeftDiv1;
	}

	public String getStrLeftDiv2() {
		return strLeftDiv2;
	}

	public void setStrLeftDiv2(String strLeftDiv2) {
		this.strLeftDiv2 = strLeftDiv2;
	}

	public String getStrLeftDiv3() {
		return strLeftDiv3;
	}

	public void setStrLeftDiv3(String strLeftDiv3) {
		this.strLeftDiv3 = strLeftDiv3;
	}

	public String getStrTopDiv1() {
		return strTopDiv1;
	}

	public void setStrTopDiv1(String strTopDiv1) {
		this.strTopDiv1 = strTopDiv1;
	}

	public String getStrTopDiv2() {
		return strTopDiv2;
	}

	public void setStrTopDiv2(String strTopDiv2) {
		this.strTopDiv2 = strTopDiv2;
	}

	public String getStrTopDiv3() {
		return strTopDiv3;
	}

	public void setStrTopDiv3(String strTopDiv3) {
		this.strTopDiv3 = strTopDiv3;
	}

	public String getStrTextoDiv1() {
		return strTextoDiv1;
	}

	public void setStrTextoDiv1(String strTextoDiv1) {
		this.strTextoDiv1 = strTextoDiv1;
	}

	public String getStrTextoDiv2() {
		return strTextoDiv2;
	}

	public void setStrTextoDiv2(String strTextoDiv2) {
		this.strTextoDiv2 = strTextoDiv2;
	}

	public String getStrTextoDiv3() {
		return strTextoDiv3;
	}

	public void setStrTextoDiv3(String strTextoDiv3) {
		this.strTextoDiv3 = strTextoDiv3;
	}

	public Boolean getIsMidia3() {
		return isMidia3;
	}

	public void setIsMidia3(Boolean isMidia3) {
		this.isMidia3 = isMidia3;
	}

	public String getBlank() {
		return blank;
	}

	public void setBlank(String blank) {
		this.blank = blank;
	}

	public String getTpLink() {
		return tpLink;
	}

	public void setTpLink(String tpLink) {
		this.tpLink = tpLink;
	}

	public String getBoId() {
		return boId;
	}

	public void setBoId(String boId) {
		this.boId = boId;
	}

	public String getRaAttribSeg() {
		return raAttribSeg;
	}

	public void setRaAttribSeg(String raAttribSeg) {
		this.raAttribSeg = raAttribSeg;
	}

	public Boolean getHabilitarBanner() {
		return habilitarBanner;
	}

	public void setHabilitarBanner(Boolean habilitarBanner) {
		this.habilitarBanner = habilitarBanner;
	}

	public Boolean getVisualizouMidiaCRM() {
		return visualizouMidiaCRM;
	}

	public void setVisualizouMidiaCRM(Boolean visualizouMidiaCRM) {
		this.visualizouMidiaCRM = visualizouMidiaCRM;
	}

	public Boolean getIsCRM() {
		boolean isCRM = false;
		if (CampanhasEnum.CAMPANHA_CRM.getValor().equals(strTipoCampanha)) {
			isCRM = true;
		}
		return isCRM;
	}

	public String getLinkUrlClassico() {
		return linkUrlClassico;
	}

	public void setLinkUrlClassico(String linkUrlClassico) {
		this.linkUrlClassico = linkUrlClassico;
	}

	public String getWidth() {
		return width;
	}

	public void setWidth(String width) {
		this.width = width;
	}

	public String getHeight() {
		return height;
	}

	public void setHeight(String height) {
		this.height = height;
	}

}
