package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.altec.bsbr.app.ibe.dto.clsfinancashvisa.ErrosDTO;

public class ConsultaRecebimentosDiaSaidaDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1070615061037118136L;
	
	private ErrosDTO erros;
	private String saida;
	private String lngRetCode;
	private String strErro;
	private String strErroTecnica;
	private String strErroMQS;
	private String strValorTotalRece;
	private List<ListaRecebimentoRSDTO> rsRecebimentos = new ArrayList<ListaRecebimentoRSDTO>();
	private List<ListaConsultaDiaRSDTO> rsConsulta = new ArrayList<ListaConsultaDiaRSDTO>();
	private ListaRecebimentoRSDTO recebimento = new ListaRecebimentoRSDTO();
	
	public ErrosDTO getErros() {
		return erros;
	}
	public void setErros(ErrosDTO erros) {
		this.erros = erros;
	}
	public String getSaida() {
		return saida;
	}
	public void setSaida(String saida) {
		this.saida = saida;
	}
	public String getLngRetCode() {
		return lngRetCode;
	}
	public void setLngRetCode(String lngRetCode) {
		this.lngRetCode = lngRetCode;
	}
	public String getStrErro() {
		return strErro;
	}
	public void setStrErro(String strErro) {
		this.strErro = strErro;
	}
	public String getStrErroTecnica() {
		return strErroTecnica;
	}
	public void setStrErroTecnica(String strErroTecnica) {
		this.strErroTecnica = strErroTecnica;
	}
	public String getStrErroMQS() {
		return strErroMQS;
	}
	public void setStrErroMQS(String strErroMQS) {
		this.strErroMQS = strErroMQS;
	}
	public String getStrValorTotalRece() {
		return strValorTotalRece;
	}
	public void setStrValorTotalRece(String strValorTotalRece) {
		this.strValorTotalRece = strValorTotalRece;
	}
	public List<ListaRecebimentoRSDTO> getRsRecebimentos() {
		return rsRecebimentos;
	}
	public void setRsRecebimentos(List<ListaRecebimentoRSDTO> rsRecebimentos) {
		this.rsRecebimentos = rsRecebimentos;
	}
	public List<ListaConsultaDiaRSDTO> getRsConsulta() {
		return rsConsulta;
	}
	public void setRsConsulta(List<ListaConsultaDiaRSDTO> rsConsulta) {
		this.rsConsulta = rsConsulta;
	}
	public ListaRecebimentoRSDTO getRecebimento() {
		return recebimento;
	}
	public void setRecebimento(ListaRecebimentoRSDTO recebimento) {
		this.recebimento = recebimento;
	}
}
