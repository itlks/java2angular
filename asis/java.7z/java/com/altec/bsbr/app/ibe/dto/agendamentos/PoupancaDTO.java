package com.altec.bsbr.app.ibe.dto.agendamentos;

public class PoupancaDTO {
	
	
	private String contaDebito;
	private String contaCredito; 
	private String tipo;

	
	
	public String getContaDebito() {
		return contaDebito;
	}
	
	public void setContaDebito(String contaDebito) {
		this.contaDebito = contaDebito;
	}
	
	public String getContaCredito() {
		return contaCredito;
	}
		public void setContaCredito(String contaCredito) {
		this.contaCredito = contaCredito;
	}
	
	public String getTipo() {
		return tipo;
	}
	
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

}
