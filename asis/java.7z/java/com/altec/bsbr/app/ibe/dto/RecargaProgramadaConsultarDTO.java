package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.altec.bsbr.app.ibe.enumeration.PeriodicidadeEnum;

public class RecargaProgramadaConsultarDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8383297258165127190L;
	private List<RecargaProgramadaListaConsultarDTO> listaRecargas = new ArrayList<RecargaProgramadaListaConsultarDTO>();

	private String nomeOperadora;
	private String prefixoDddTelefone;
	private String periodicidade;
	private Integer situacao;
	private BigDecimal valor;
	private Date dataInicial;
	private Date dataInclusaoProgramacao;
	private String prazo;
	private String canal;
	private Date dataCancelamento;
	private String motivoCancelamento;
	private BigDecimal numeroTelefoneFormatado;

	private String valorAlterado;
	public PeriodicidadeEnum periodicidadeAlterado;
	private Date dataInicialAlterado;
	private Date prazoAlterado;
	public boolean dataIndeterminada;
	private RecargaCelularDTO celularDTO;

	public String getNomeOperadora() {
		return nomeOperadora;
	}

	public void setNomeOperadora(String nomeOperadora) {
		this.nomeOperadora = nomeOperadora;
	}

	public String getPrefixoDddTelefone() {
		return prefixoDddTelefone;
	}

	public void setPrefixoDddTelefone(String prefixoDddTelefone) {
		this.prefixoDddTelefone = prefixoDddTelefone;
	}

	public String getPeriodicidade() {
		return periodicidade;
	}

	public void setPeriodicidade(String periodicidade) {
		this.periodicidade = periodicidade;
	}

	public List<RecargaProgramadaListaConsultarDTO> getListaRecargas() {
		return listaRecargas;
	}

	public void setListaRecargas(List<RecargaProgramadaListaConsultarDTO> listaRecargas) {
		this.listaRecargas = listaRecargas;
	}

	public Integer getSituacao() {
		return situacao;
	}

	public void setSituacao(Integer situacao) {
		this.situacao = situacao;
	}

	public BigDecimal getValor() {
		return valor;
	}

	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}

	public Date getDataInicial() {
		return dataInicial;
	}

	public void setDataInicial(Date dataInicial) {
		this.dataInicial = dataInicial;
	}

	public Date getDataInclusaoProgramacao() {
		return dataInclusaoProgramacao;
	}

	public void setDataInclusaoProgramacao(Date dataInclusaoProgramacao) {
		this.dataInclusaoProgramacao = dataInclusaoProgramacao;
	}

	public String getPrazo() {
		return prazo;
	}

	public void setPrazo(String prazo) {
		this.prazo = prazo;
	}

	public String getCanal() {
		return canal;
	}

	public void setCanal(String canal) {
		this.canal = canal;
	}

	public Date getDataCancelamento() {
		return dataCancelamento;
	}

	public void setDataCancelamento(Date dataCancelamento) {
		this.dataCancelamento = dataCancelamento;
	}

	public String getMotivoCancelamento() {
		return motivoCancelamento;
	}

	public void setMotivoCancelamento(String motivoCancelamento) {
		this.motivoCancelamento = motivoCancelamento;
	}

	public BigDecimal getNumeroTelefoneFormatado() {
		return numeroTelefoneFormatado;
	}

	public void setNumeroTelefoneFormatado(BigDecimal numeroTelefoneFormatado) {
		this.numeroTelefoneFormatado = numeroTelefoneFormatado;
	}

	public RecargaCelularDTO getCelularDTO() {
		return celularDTO;
	}

	public void setCelularDTO(RecargaCelularDTO celularDTO) {
		this.celularDTO = celularDTO;
	}

	public String getValorAlterado() {
		return valorAlterado;
	}

	public void setValorAlterado(String valorAlterado) {
		this.valorAlterado = valorAlterado;
	}

	public Date getDataInicialAlterado() {
		return dataInicialAlterado;
	}

	public void setDataInicialAlterado(Date dataInicialAlterado) {
		this.dataInicialAlterado = dataInicialAlterado;
	}

	public void setPeriodicidadeAlterado(PeriodicidadeEnum periodicidadeAlterado) {
		this.periodicidadeAlterado = periodicidadeAlterado;
	}

	public PeriodicidadeEnum getPeriodicidadeAlterado() {
		return periodicidadeAlterado;
	}

	public boolean isDataIndeterminada() {
		return dataIndeterminada;
	}

	public void setDataIndeterminada(boolean dataIndeterminada) {
		this.dataIndeterminada = dataIndeterminada;
	}

	public Date getPrazoAlterado() {
		return prazoAlterado;
	}

	public void setPrazoAlterado(Date prazoAlterado) {
		this.prazoAlterado = prazoAlterado;
	}

}
