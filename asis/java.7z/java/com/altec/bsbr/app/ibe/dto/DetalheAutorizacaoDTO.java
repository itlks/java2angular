package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;



public class DetalheAutorizacaoDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private int retCode;

	private List<DetalheAutorizacaoListaDTO> detalhesAutorizacao = new ArrayList<DetalheAutorizacaoListaDTO>();
	
	public DetalheAutorizacaoDTO() {}
	
	/**
	 * @return the retCode
	 */
	public int getRetCode() {
		return retCode;
	}

	/**
	 * @param retCode the retCode to set
	 */
	public void setRetCode(int retCode) {
		this.retCode = retCode;
	}

	/**
	 * @return the detalhesAutorizacao
	 */
	public List<DetalheAutorizacaoListaDTO> getDetalhesAutorizacao() {
		return detalhesAutorizacao;
	}

	/**
	 * @param detalhesAutorizacao the detalhesAutorizacao to set
	 */
	public void setDetalhesAutorizacao(List<DetalheAutorizacaoListaDTO> detalhesAutorizacao) {
		this.detalhesAutorizacao = detalhesAutorizacao;
	}
	
			

}
