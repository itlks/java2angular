package com.altec.bsbr.app.ibe.dto;

public class ImprimirAditivoCovenio {
	
	private String codCovenio;
	private String penumper;
	
	
	public String getCodCovenio() {
		return codCovenio;
	}
	public void setCodCovenio(String codCovenio) {
		this.codCovenio = codCovenio;
	}
	public String getPenumper() {
		return penumper;
	}
	public void setPenumper(String penumper) {
		this.penumper = penumper;
	}
	
}
