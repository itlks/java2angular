

/*
 * Cheque Ades�o Empresa Protegido (Rest Implementation para controle de fluxo)
 *
 */
package com.altec.bsbr.app.ibe.rest.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.altec.bsbr.app.ibe.dto.InformacoesDeOperacoesDTO;
import com.altec.bsbr.app.ibe.dto.pendencia.BGMSPE1;
import com.altec.bsbr.app.ibe.dto.pendencia.DadosConsultaPendencia;
import com.altec.bsbr.app.ibe.dto.pendencia.DadosPendencia;
import com.altec.bsbr.app.ibe.dto.pendencia.HeaderPgPadrao;
import com.altec.bsbr.app.ibe.dto.pendencia.PGECCD3;
import com.altec.bsbr.app.ibe.dto.pendencia.PGECHDR;
import com.altec.bsbr.app.ibe.dto.pendencia.RetornoConsultaPendencia;
import com.altec.bsbr.app.ibe.dto.pendencia.RetornoPendencia;
import com.altec.bsbr.app.ibe.enumeration.EstatisticaEnum;
import com.altec.bsbr.app.ibe.enumeration.ProdutoEnum;
import com.altec.bsbr.app.ibe.enumeration.ServicoEnum;
import com.altec.bsbr.app.ibe.enumeration.SituacaoDaTransacaoEnum;
import com.altec.bsbr.app.ibe.enumeration.TransacoesEnum;
import com.altec.bsbr.app.ibe.service.PendenciaDelegateService;
import com.altec.bsbr.app.ibe.service.impl.IBEBasicDelegate;
import com.altec.bsbr.app.ibe.util.WSFormat;
import com.altec.bsbr.app.ibe.util.WSFormat.Position;
import com.altec.bsbr.app.ibe.web.jsf.attributes.AtributosDaAplicacao;
import com.altec.bsbr.app.ibe.web.jsf.attributes.AtributosDaSessao;
import com.altec.bsbr.fw.BusinessException;

public class SeguroPrestamistaRequest extends IBEBasicDelegate implements SeguroPrestamistaRequestServices {
	private static final int NUMERO_DOZE = 12;
	private static final int NUMERO_QUATRO = 4;
	@Autowired
	private PendenciaDelegateService pendenciaDelegateService;
	private static final String DATA_FORMATADA = "dd/MM/yyyy";

	@Override
	public RetornoConsultaPendencia consultarSeGeraPendencia(AtributosDaAplicacao aplicacao, AtributosDaSessao session)
			throws BusinessException {

		DadosConsultaPendencia dadosConsulta = new DadosConsultaPendencia();
		String banco = WSFormat.getFormatString(session.getBanco(), NUMERO_QUATRO, "0", Position.RIGHT);
		dadosConsulta.setBanco(banco);
		dadosConsulta.setAgencia(session.getAgencia());
		dadosConsulta.setCodigoTransacao(
				Integer.valueOf(TransacoesEnum.CONTA_CORRENTE_SEGURO_ADESAO_CHEQUE_EMPRESA_PROTEGIDO.getIdTransacao()));
		dadosConsulta.setConta(session.getConta());
		dadosConsulta.setContrato(session.getContrato());
		dadosConsulta
				.setIdTransacao(TransacoesEnum.CONTA_CORRENTE_SEGURO_ADESAO_CHEQUE_EMPRESA_PROTEGIDO.getIdTransacao());
		dadosConsulta.setIdUsuario(session.getCodigoUsuario());
		dadosConsulta.setNivelUsuario(session.getNivelUsuario());
		dadosConsulta.setTipoAdministracao(session.getTipoAdministracao());
		return pendenciaDelegateService.consultarSeGeraPendencia(dadosConsulta, getDadosLog(session));
	}

	@Override
	public RetornoPendencia gerarPendencia(RetornoConsultaPendencia retornoConsultaPendencia, AtributosDaSessao session)
			throws BusinessException {

		DadosPendencia dadosPendencia = new DadosPendencia();
		dadosPendencia.setASSINA(retornoConsultaPendencia.getAssina());
		dadosPendencia.setTPUSUA(retornoConsultaPendencia.getTipoUsuario());

		dadosPendencia.setCDCONTR(Long.parseLong(session.getContrato()));
		dadosPendencia.setCDTRANS(
				Integer.valueOf(TransacoesEnum.CONTA_CORRENTE_SEGURO_ADESAO_CHEQUE_EMPRESA_PROTEGIDO.getIdTransacao()));
		dadosPendencia.setCDAGEN(session.getAgencia());
		dadosPendencia.setCDCTA(session.getConta());
		String banco = WSFormat.getFormatString(session.getBanco(), NUMERO_QUATRO, "0", Position.RIGHT);
		dadosPendencia.setCDBCO(banco);
		dadosPendencia.setNMUSER(session.getCodigoUsuario());
		dadosPendencia.setNVLUSER(session.getNivelUsuario());
		dadosPendencia.setIDTRANS(session.getReferOper());
		dadosPendencia.setQTASSMA(String.valueOf(retornoConsultaPendencia.getQuantidadeAssinaturaMaster()));
		dadosPendencia.setCDTRANL("BGSP");
		dadosPendencia.setIDUSUAR(session.getCodigoUsuario());
		dadosPendencia.setCDGRP("100");
		dadosPendencia.setVLTRANS("0");

		Date agora = new Date();
		dadosPendencia.getAvisos()
				.add("Data de Solicita��o: ".concat(new SimpleDateFormat(DATA_FORMATADA).format(agora)));
		dadosPendencia.getAvisos()
				.add("Hora de Solicita��o: ".concat(new SimpleDateFormat("HH:mm").format(agora).concat("h")));
		dadosPendencia.getAvisos().add("Nome do segurado: ".concat(session.getNomeTitularConta()));
		dadosPendencia.getAvisos().add("CNPJ do segurado: ".concat(session.getCnpj()));

		HeaderPgPadrao headerPgPadrao = new HeaderPgPadrao();

		PGECCD3 pge = new PGECCD3();
		PGECHDR pgeheader = new PGECHDR();

		pgeheader.setCANAL(session.getCanal().toString());
		pgeheader.setMEIPAG("CB");
		pgeheader.setIDTRANS(TransacoesEnum.SEGURO_ADESAO_CHEQUE_EMPRESA_PROTEGIDO.getIdTransacao());

		pgeheader.setENTIDAD(banco);
		pgeheader.setCENTRO(session.getAgencia());
		pgeheader.setCENTCTA(session.getAgencia());
		pgeheader.setNUMCTA(StringUtils.leftPad(session.getConta(), NUMERO_DOZE, "0"));
		pgeheader.setREFEROP(session.getReferOper());
		pgeheader.setINDAGEN("N");
		pgeheader.setENTCONT(banco);
		pgeheader.setTRANSMA("BGSP");
		pgeheader.setINDDEBT("N");

		headerPgPadrao.setpGECHDR(pgeheader);
		headerPgPadrao.setpGECCD3(pge);

		BGMSPE1 imagemTransacao = new BGMSPE1();

		imagemTransacao.setBANCO(banco);
		imagemTransacao.setCENTALT("BGSP");
		imagemTransacao.setCODRET("");
		imagemTransacao.setCUENTA(StringUtils.leftPad(session.getConta(), NUMERO_DOZE, "0"));
		imagemTransacao.setFILLER("06");

		return pendenciaDelegateService.gerarPendenciaBGSP(dadosPendencia, headerPgPadrao, imagemTransacao,
				getDadosLog(session));
	}
	
	private InformacoesDeOperacoesDTO getDadosLog(AtributosDaSessao session) {
		return getDadosBasicosLog(ProdutoEnum.PRODUTOCONTACORRENTE, ServicoEnum.SERVCONTRATACAOCHQEMPPROT, session,
				EstatisticaEnum.FLAGTRANSACAOVALIDAPARAESTATISTICA.getEstatistica(),
				SituacaoDaTransacaoEnum.FLAGIMPERATIVACONFIRMACAO.getSituacao(),
				session.getNomeTitularConta() + "|" + session.getCnpj(), "");
	}

}
