package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class ManutencaoApelidosTitulosDTO extends GenericDTO implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8122053163608364834L;
	
	private String banco;
	private String agencia;
	private String conta;
	private String apelido;
	private String nomeFavorecido;
	private String nomeCedente;
	
	public String getApelido() {
		return apelido;
	}
	public void setApelido(String apelido) {
		this.apelido = apelido;
	}
	public String getNomeFavorecido() {
		return nomeFavorecido;
	}
	public void setNomeFavorecido(String nomeFavorecido) {
		this.nomeFavorecido = nomeFavorecido;
	}
	public String getNomeCedente() {
		return nomeCedente;
	}
	public void setNomeCedente(String nomeCedente) {
		this.nomeCedente = nomeCedente;
	}
	public String getBanco() {
		return banco;
	}
	public void setBanco(String banco) {
		this.banco = banco;
	}
	public String getAgencia() {
		return agencia;
	}
	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}
	public String getConta() {
		return conta;
	}
	public void setConta(String conta) {
		this.conta = conta;
	}
	
	

}
