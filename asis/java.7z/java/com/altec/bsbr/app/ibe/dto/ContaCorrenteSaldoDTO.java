package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import javax.xml.datatype.XMLGregorianCalendar;

public class ContaCorrenteSaldoDTO implements Serializable {
	private static final long serialVersionUID = -6461736410799675734L;
	// Os campos com valores zerados n�o constam no documento de AS-IS
	private BigDecimal oeSaldoBlqDia;
	private BigDecimal lancProvCredito;
	private BigDecimal lancProvDebito;
	private BigDecimal sldCtbpoup;
	private BigDecimal vlSaldocc;
	private BigDecimal oeSaldoDisp;
	private BigDecimal vlSaldoci;
	private BigDecimal vlTotalCcCi;
	private BigDecimal vlChequesBloq;
	private BigDecimal vlBloq24;
	private BigDecimal vlBloq48;
	private BigDecimal vlBloqind;
	private BigDecimal oeSaldoBlqJud;
	private BigDecimal oeSaldoProvEnc;
	private BigDecimal oeJurosAcumProv;
	private BigDecimal oeIofAcumProv;
	private BigDecimal vlCpmf;
	private BigDecimal oeCpmfAcum;
	private BigDecimal oeVlSegPrestFech;
	private BigDecimal oeCcSaldoDisponiv;
	private BigDecimal vlResgAut;
	private BigDecimal vlTotalSaldo;
	private String oeDescPrimLimite;
	private String oeSegPrimLimite;
	private BigDecimal oeChqInvLimite;
	private BigDecimal vlDisponivel;
	private BigDecimal vlJuros;
	private BigDecimal vlIof;
	private XMLGregorianCalendar oeChqInvVenc;
	private XMLGregorianCalendar dtUltMov;
	private XMLGregorianCalendar dtDebJuros;
	private XMLGregorianCalendar dtDebIof;
	private String indCpmf;
	private String flagMostraCi;
	private String indPoupmax;
	private XMLGregorianCalendar dtVctoCeb;
	private BigDecimal vlTxJurosMensal;
	private BigDecimal vlLimite;
	private XMLGregorianCalendar oeChqEspUltima; 
	private Integer qtDiaNdia;
	private BigDecimal oeChqEspUtilizado;
	private BigDecimal oeChqEspDisp;
	private BigDecimal vlJurNaoDeb;
	private List<SaldoDeContaCorrenteItemDTO> saldoDeContaCorrenteItemList;
	private List<SaldoDeContaCorrenteItemDTO> componentesJuros;
	private List<SaldoDeContaCorrenteItemDTO> componentesDatas;
	private List<SaldoDeContaCorrenteItemDTO> componentesChequeEspecial;

	/**
	 * @return the oeSaldoBlqDia
	 */
	public BigDecimal getOeSaldoBlqDia() {
		return oeSaldoBlqDia;
	}
	/**
	 * @param oeSaldoBlqDia the oeSaldoBlqDia to set
	 */
	public void setOeSaldoBlqDia(BigDecimal oeSaldoBlqDia) {
		this.oeSaldoBlqDia = oeSaldoBlqDia;
	}
	/**
	 * @return the lancProvCredito
	 */
	public BigDecimal getLancProvCredito() {
		return lancProvCredito;
	}
	/**
	 * @param lancProvCredito the lancProvCredito to set
	 */
	public void setLancProvCredito(BigDecimal lancProvCredito) {
		this.lancProvCredito = lancProvCredito;
	}
	/**
	 * @return the lancProvDebito
	 */
	public BigDecimal getLancProvDebito() {
		return lancProvDebito;
	}
	/**
	 * @param lancProvDebito the lancProvDebito to set
	 */
	public void setLancProvDebito(BigDecimal lancProvDebito) {
		this.lancProvDebito = lancProvDebito;
	}
	/**
	 * @return the sldCtbpoup
	 */
	public BigDecimal getSldCtbpoup() {
		return sldCtbpoup;
	}
	/**
	 * @param sldCtbpoup the sldCtbpoup to set
	 */
	public void setSldCtbpoup(BigDecimal sldCtbpoup) {
		this.sldCtbpoup = sldCtbpoup;
	}
	/**
	 * @return the vlSaldocc
	 */
	public BigDecimal getVlSaldocc() {
		return vlSaldocc;
	}
	/**
	 * @param vlSaldocc the vlSaldocc to set
	 */
	public void setVlSaldocc(BigDecimal vlSaldocc) {
		this.vlSaldocc = vlSaldocc;
	}
	/**
	 * @return the oeSaldoDisp
	 */
	public BigDecimal getOeSaldoDisp() {
		return oeSaldoDisp;
	}
	/**
	 * @param oeSaldoDisp the oeSaldoDisp to set
	 */
	public void setOeSaldoDisp(BigDecimal oeSaldoDisp) {
		this.oeSaldoDisp = oeSaldoDisp;
	}
	/**
	 * @return the vlSaldoci
	 */
	public BigDecimal getVlSaldoci() {
		return vlSaldoci;
	}
	/**
	 * @param vlSaldoci the vlSaldoci to set
	 */
	public void setVlSaldoci(BigDecimal vlSaldoci) {
		this.vlSaldoci = vlSaldoci;
	}
	/**
	 * @return the vlTotalCcCi
	 */
	public BigDecimal getVlTotalCcCi() {
		return vlTotalCcCi;
	}
	/**
	 * @param vlTotalCcCi the vlTotalCcCi to set
	 */
	public void setVlTotalCcCi(BigDecimal vlTotalCcCi) {
		this.vlTotalCcCi = vlTotalCcCi;
	}
	/**
	 * @return the vlChequesBloq
	 */
	public BigDecimal getVlChequesBloq() {
		return vlChequesBloq;
	}
	/**
	 * @param vlChequesBloq the vlChequesBloq to set
	 */
	public void setVlChequesBloq(BigDecimal vlChequesBloq) {
		this.vlChequesBloq = vlChequesBloq;
	}
	/**
	 * @return the vlBloq24
	 */
	public BigDecimal getVlBloq24() {
		return vlBloq24;
	}
	/**
	 * @param vlBloq24 the vlBloq24 to set
	 */
	public void setVlBloq24(BigDecimal vlBloq24) {
		this.vlBloq24 = vlBloq24;
	}
	/**
	 * @return the vlBloq48
	 */
	public BigDecimal getVlBloq48() {
		return vlBloq48;
	}
	/**
	 * @param vlBloq48 the vlBloq48 to set
	 */
	public void setVlBloq48(BigDecimal vlBloq48) {
		this.vlBloq48 = vlBloq48;
	}
	/**
	 * @return the vlBloqind
	 */
	public BigDecimal getVlBloqind() {
		return vlBloqind;
	}
	/**
	 * @param vlBloqind the vlBloqind to set
	 */
	public void setVlBloqind(BigDecimal vlBloqind) {
		this.vlBloqind = vlBloqind;
	}
	/**
	 * @return the oeSaldoBlqJud
	 */
	public BigDecimal getOeSaldoBlqJud() {
		return oeSaldoBlqJud;
	}
	/**
	 * @param oeSaldoBlqJud the oeSaldoBlqJud to set
	 */
	public void setOeSaldoBlqJud(BigDecimal oeSaldoBlqJud) {
		this.oeSaldoBlqJud = oeSaldoBlqJud;
	}
	/**
	 * @return the oeSaldoProvEnc
	 */
	public BigDecimal getOeSaldoProvEnc() {
		return oeSaldoProvEnc;
	}
	/**
	 * @param oeSaldoProvEnc the oeSaldoProvEnc to set
	 */
	public void setOeSaldoProvEnc(BigDecimal oeSaldoProvEnc) {
		this.oeSaldoProvEnc = oeSaldoProvEnc;
	}
	/**
	 * @return the oeJurosAcumProv
	 */
	public BigDecimal getOeJurosAcumProv() {
		return oeJurosAcumProv;
	}
	/**
	 * @param oeJurosAcumProv the oeJurosAcumProv to set
	 */
	public void setOeJurosAcumProv(BigDecimal oeJurosAcumProv) {
		this.oeJurosAcumProv = oeJurosAcumProv;
	}
	/**
	 * @return the oeIofAcumProv
	 */
	public BigDecimal getOeIofAcumProv() {
		return oeIofAcumProv;
	}
	/**
	 * @param oeIofAcumProv the oeIofAcumProv to set
	 */
	public void setOeIofAcumProv(BigDecimal oeIofAcumProv) {
		this.oeIofAcumProv = oeIofAcumProv;
	}
	/**
	 * @return the vlCpmf
	 */
	public BigDecimal getVlCpmf() {
		return vlCpmf;
	}
	/**
	 * @param vlCpmf the vlCpmf to set
	 */
	public void setVlCpmf(BigDecimal vlCpmf) {
		this.vlCpmf = vlCpmf;
	}
	/**
	 * @return the oeCpmfAcum
	 */
	public BigDecimal getOeCpmfAcum() {
		return oeCpmfAcum;
	}
	/**
	 * @param oeCpmfAcum the oeCpmfAcum to set
	 */
	public void setOeCpmfAcum(BigDecimal oeCpmfAcum) {
		this.oeCpmfAcum = oeCpmfAcum;
	}
	/**
	 * @return the oeVlSegPrestFech
	 */
	public BigDecimal getOeVlSegPrestFech() {
		return oeVlSegPrestFech;
	}
	/**
	 * @param oeVlSegPrestFech the oeVlSegPrestFech to set
	 */
	public void setOeVlSegPrestFech(BigDecimal oeVlSegPrestFech) {
		this.oeVlSegPrestFech = oeVlSegPrestFech;
	}
	/**
	 * @return the oeCcSaldoDisponiv
	 */
	public BigDecimal getOeCcSaldoDisponiv() {
		return oeCcSaldoDisponiv;
	}
	/**
	 * @param oeCcSaldoDisponiv the oeCcSaldoDisponiv to set
	 */
	public void setOeCcSaldoDisponiv(BigDecimal oeCcSaldoDisponiv) {
		this.oeCcSaldoDisponiv = oeCcSaldoDisponiv;
	}
	/**
	 * @return the vlResgAut
	 */
	public BigDecimal getVlResgAut() {
		return vlResgAut;
	}
	/**
	 * @param vlResgAut the vlResgAut to set
	 */
	public void setVlResgAut(BigDecimal vlResgAut) {
		this.vlResgAut = vlResgAut;
	}
	/**
	 * @return the vlTotalSaldo
	 */
	public BigDecimal getVlTotalSaldo() {
		return vlTotalSaldo;
	}
	/**
	 * @param vlTotalSaldo the vlTotalSaldo to set
	 */
	public void setVlTotalSaldo(BigDecimal vlTotalSaldo) {
		this.vlTotalSaldo = vlTotalSaldo;
	}
	/**
	 * @return the oeDescPrimLimite
	 */
	public String getOeDescPrimLimite() {
		return oeDescPrimLimite;
	}
	/**
	 * @param oeDescPrimLimite the oeDescPrimLimite to set
	 */
	public void setOeDescPrimLimite(String oeDescPrimLimite) {
		this.oeDescPrimLimite = oeDescPrimLimite;
	}
	/**
	 * @return the oeSegPrimLimite
	 */
	public String getOeSegPrimLimite() {
		return oeSegPrimLimite;
	}
	/**
	 * @param oeSegPrimLimite the oeSegPrimLimite to set
	 */
	public void setOeSegPrimLimite(String oeSegPrimLimite) {
		this.oeSegPrimLimite = oeSegPrimLimite;
	}
	/**
	 * @return the oeChqInvLimite
	 */
	public BigDecimal getOeChqInvLimite() {
		return oeChqInvLimite;
	}
	/**
	 * @param oeChqInvLimite the oeChqInvLimite to set
	 */
	public void setOeChqInvLimite(BigDecimal oeChqInvLimite) {
		this.oeChqInvLimite = oeChqInvLimite;
	}
	/**
	 * @return the vlDisponivel
	 */
	public BigDecimal getVlDisponivel() {
		return vlDisponivel;
	}
	/**
	 * @param vlDisponivel the vlDisponivel to set
	 */
	public void setVlDisponivel(BigDecimal vlDisponivel) {
		this.vlDisponivel = vlDisponivel;
	}
	/**
	 * @return the vlJuros
	 */
	public BigDecimal getVlJuros() {
		return vlJuros;
	}
	/**
	 * @param vlJuros the vlJuros to set
	 */
	public void setVlJuros(BigDecimal vlJuros) {
		this.vlJuros = vlJuros;
	}
	/**
	 * @return the vlIof
	 */
	public BigDecimal getVlIof() {
		return vlIof;
	}
	/**
	 * @param vlIof the vlIof to set
	 */
	public void setVlIof(BigDecimal vlIof) {
		this.vlIof = vlIof;
	}
	/**
	 * @return the oeChqInvVenc
	 */
	public XMLGregorianCalendar getOeChqInvVenc() {
		return oeChqInvVenc;
	}
	/**
	 * @param oeChqInvVenc the oeChqInvVenc to set
	 */
	public void setOeChqInvVenc(XMLGregorianCalendar oeChqInvVenc) {
		this.oeChqInvVenc = oeChqInvVenc;
	}
	/**
	 * @return the dtUltMov
	 */
	public XMLGregorianCalendar getDtUltMov() {
		return dtUltMov;
	}
	/**
	 * @param dtUltMov the dtUltMov to set
	 */
	public void setDtUltMov(XMLGregorianCalendar dtUltMov) {
		this.dtUltMov = dtUltMov;
	}
	/**
	 * @return the dtDebJuros
	 */
	public XMLGregorianCalendar getDtDebJuros() {
		return dtDebJuros;
	}
	/**
	 * @param dtDebJuros the dtDebJuros to set
	 */
	public void setDtDebJuros(XMLGregorianCalendar dtDebJuros) {
		this.dtDebJuros = dtDebJuros;
	}
	/**
	 * @return the dtDebIof
	 */
	public XMLGregorianCalendar getDtDebIof() {
		return dtDebIof;
	}
	/**
	 * @param dtDebIof the dtDebIof to set
	 */
	public void setDtDebIof(XMLGregorianCalendar dtDebIof) {
		this.dtDebIof = dtDebIof;
	}
	/**
	 * @return the indCpmf
	 */
	public String getIndCpmf() {
		return indCpmf;
	}
	/**
	 * @param indCpmf the indCpmf to set
	 */
	public void setIndCpmf(String indCpmf) {
		this.indCpmf = indCpmf;
	}
	/**
	 * @return the flagMostraCi
	 */
	public String getFlagMostraCi() {
		return flagMostraCi;
	}
	/**
	 * @param flagMostraCi the flagMostraCi to set
	 */
	public void setFlagMostraCi(String flagMostraCi) {
		this.flagMostraCi = flagMostraCi;
	}
	/**
	 * @return the indPoupmax
	 */
	public String getIndPoupmax() {
		return indPoupmax;
	}
	/**
	 * @param indPoupmax the indPoupmax to set
	 */
	public void setIndPoupmax(String indPoupmax) {
		this.indPoupmax = indPoupmax;
	}
	/**
	 * @return the dtVctoCeb
	 */
	public XMLGregorianCalendar getDtVctoCeb() {
		return dtVctoCeb;
	}
	/**
	 * @param dtVctoCeb the dtVctoCeb to set
	 */
	public void setDtVctoCeb(XMLGregorianCalendar dtVctoCeb) {
		this.dtVctoCeb = dtVctoCeb;
	}
	/**
	 * @return the vlTxJurosMensal
	 */
	public BigDecimal getVlTxJurosMensal() {
		return vlTxJurosMensal;
	}
	/**
	 * @param vlTxJurosMensal the vlTxJurosMensal to set
	 */
	public void setVlTxJurosMensal(BigDecimal vlTxJurosMensal) {
		this.vlTxJurosMensal = vlTxJurosMensal;
	}
	/**
	 * @return the vlLimite
	 */
	public BigDecimal getVlLimite() {
		return vlLimite;
	}
	/**
	 * @param vlLimite the vlLimite to set
	 */
	public void setVlLimite(BigDecimal vlLimite) {
		this.vlLimite = vlLimite;
	}
	/**
	 * @return the oeChqEspUltima
	 */
	public XMLGregorianCalendar getOeChqEspUltima() {
		return oeChqEspUltima;
	}
	/**
	 * @param oeChqEspUltima the oeChqEspUltima to set
	 */
	public void setOeChqEspUltima(XMLGregorianCalendar oeChqEspUltima) {
		this.oeChqEspUltima = oeChqEspUltima;
	}
	/**
	 * @return the qtDiaNdia
	 */
	public Integer getQtDiaNdia() {
		return qtDiaNdia;
	}
	/**
	 * @param qtDiaNdia the qtDiaNdia to set
	 */
	public void setQtDiaNdia(Integer qtDiaNdia) {
		this.qtDiaNdia = qtDiaNdia;
	}
	/**
	 * @return the oeChqEspUtilizado
	 */
	public BigDecimal getOeChqEspUtilizado() {
		return oeChqEspUtilizado;
	}
	/**
	 * @param oeChqEspUtilizado the oeChqEspUtilizado to set
	 */
	public void setOeChqEspUtilizado(BigDecimal oeChqEspUtilizado) {
		this.oeChqEspUtilizado = oeChqEspUtilizado;
	}
	/**
	 * @return the oeChqEspDisp
	 */
	public BigDecimal getOeChqEspDisp() {
		return oeChqEspDisp;
	}
	/**
	 * @param oeChqEspDisp the oeChqEspDisp to set
	 */
	public void setOeChqEspDisp(BigDecimal oeChqEspDisp) {
		this.oeChqEspDisp = oeChqEspDisp;
	}
	/**
	 * @return the vlJurNaoDeb
	 */
	public BigDecimal getVlJurNaoDeb() {
		return vlJurNaoDeb;
	}
	/**
	 * @param vlJurNaoDeb the vlJurNaoDeb to set
	 */
	public void setVlJurNaoDeb(BigDecimal vlJurNaoDeb) {
		this.vlJurNaoDeb = vlJurNaoDeb;
	}
	/**
	 * @return the saldoDeContaCorrenteItemList
	 */
	public List<SaldoDeContaCorrenteItemDTO> getSaldoDeContaCorrenteItemList() {
		return saldoDeContaCorrenteItemList;
	}
	/**
	 * @param saldoDeContaCorrenteItemList the saldoDeContaCorrenteItemList to set
	 */
	public void setSaldoDeContaCorrenteItemList(List<SaldoDeContaCorrenteItemDTO> saldoDeContaCorrenteItemList) {
		this.saldoDeContaCorrenteItemList = saldoDeContaCorrenteItemList;
	}
	/**
	 * @return the componentesJuros
	 */
	public List<SaldoDeContaCorrenteItemDTO> getComponentesJuros() {
		return componentesJuros;
	}
	/**
	 * @param componentesJuros the componentesJuros to set
	 */
	public void setComponentesJuros(List<SaldoDeContaCorrenteItemDTO> componentesJuros) {
		this.componentesJuros = componentesJuros;
	}
	/**
	 * @return the componentesDatas
	 */
	public List<SaldoDeContaCorrenteItemDTO> getComponentesDatas() {
		return componentesDatas;
	}
	/**
	 * @param componentesDatas the componentesDatas to set
	 */
	public void setComponentesDatas(List<SaldoDeContaCorrenteItemDTO> componentesDatas) {
		this.componentesDatas = componentesDatas;
	}
	/**
	 * @return the componentesChequeEspecial
	 */
	public List<SaldoDeContaCorrenteItemDTO> getComponentesChequeEspecial() {
		return componentesChequeEspecial;
	}
	/**
	 * @param componentesChequeEspecial the componentesChequeEspecial to set
	 */
	public void setComponentesChequeEspecial(List<SaldoDeContaCorrenteItemDTO> componentesChequeEspecial) {
		this.componentesChequeEspecial = componentesChequeEspecial;
	}
	
	
}
