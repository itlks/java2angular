package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;

public class ListaOperacoesSubTotalDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7382900276727570665L;

	private String TSOEMBNROPER;
	private String TSOEMBDTOPER;
	private String TSOEMBVLOPER;

	private BigDecimal subTotal;

	/**
	 * @return the tSOEMBNROPER
	 */
	public String getTSOEMBNROPER() {
		return TSOEMBNROPER;
	}

	/**
	 * @param tSOEMBNROPER
	 *            the tSOEMBNROPER to set
	 */
	public void setTSOEMBNROPER(String tSOEMBNROPER) {
		TSOEMBNROPER = tSOEMBNROPER;
	}

	/**
	 * @return the tSOEMBDTOPER
	 */
	public String getTSOEMBDTOPER() {
		return TSOEMBDTOPER;
	}

	/**
	 * @param tSOEMBDTOPER
	 *            the tSOEMBDTOPER to set
	 */
	public void setTSOEMBDTOPER(String tSOEMBDTOPER) {
		TSOEMBDTOPER = tSOEMBDTOPER;
	}

	/**
	 * @return the tSOEMBVLOPER
	 */
	public String getTSOEMBVLOPER() {
		return TSOEMBVLOPER;
	}

	/**
	 * @param tSOEMBVLOPER
	 *            the tSOEMBVLOPER to set
	 */
	public void setTSOEMBVLOPER(String tSOEMBVLOPER) {
		TSOEMBVLOPER = tSOEMBVLOPER;
	}

	/**
	 * @return the subTotal
	 */
	public BigDecimal getSubTotal() {
		return subTotal;
	}

	/**
	 * @param subTotal
	 *            the subTotal to set
	 */
	public void setSubTotal(BigDecimal subTotal) {
		this.subTotal = subTotal;
	}

}
