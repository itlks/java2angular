package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class IpvaDTO  extends GenericDTO implements Serializable {
	private static final long serialVersionUID = 2765492161750098054L;

	private String codServ;
	private String numDocum;
	private String codMun;
	private int codFede;
	private String nomePro;
	private String siglaFede;
	private String dataVencCotaUni;
	private String valorCotaUni;
	private String banco;
	private String agencia;
	private String conta;
	private String anoExercicio;
	private float valor;
	private int pendentes;
	private String renavam;
	private String proprietario;
	private String codMunicipio;
	private String cpfCnpj;
	private String placaVeiculo;
	private String autBancaria;
	private String dataContabil;
	private String codigoDoCanal;
	private String referOper;
	private String dataAgendamento;
	private String indicadorCota;
	private int cotaParcela;	
	private String dataHoraPagamento;	
	private List<ExercicioDTO> listaExercicio;
	private Double valorTotal;
	private String produtoCodAlfa2;
	private String produtoCodAlfa4;
	private boolean habilitaAgendamento = false;
	private boolean geraPendencia = false;	
	private List<DadosIpvaDTO> dados;

	public IpvaDTO() {
		super();
		this.listaExercicio = new ArrayList<ExercicioDTO>();
		this.dados = new ArrayList<DadosIpvaDTO>();
	}
	
	public IpvaDTO(String anoExercicio, float valor, int pendentes, String renavam, String proprietario,
			String codMunicipio, String cpfCnpj, String placaVeiculo, String autBancaria, String dataContabil,
			String valorTotal) {
		this.anoExercicio = anoExercicio;
		this.valor = valor;
		this.pendentes = pendentes;
		this.renavam = renavam;
		this.proprietario = proprietario;
		this.codMunicipio = codMunicipio;
		this.cpfCnpj = cpfCnpj;
		this.placaVeiculo = placaVeiculo;
		this.autBancaria = autBancaria;
		this.dataContabil = dataContabil;
		this.listaExercicio = new ArrayList<ExercicioDTO>();
	}
	
	public boolean isHabilitaAgendamento() {
		return habilitaAgendamento;
	}

	public void setHabilitaAgendamento(boolean habilitaAgendamento) {
		this.habilitaAgendamento = habilitaAgendamento;
	}

	public String getCodigoDoCanal() {
		return codigoDoCanal;
	}

	public void setCodigoDoCanal(String codigoDoCanal) {
		this.codigoDoCanal = codigoDoCanal;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getConta() {
		return conta;
	}

	public void setConta(String conta) {
		this.conta = conta;
	}

	public String getAnoExercicio() {
		return anoExercicio;
	}

	public void setAnoExercicio(String anoExercicio) {
		this.anoExercicio = anoExercicio;
	}

	public float getValor() {
		return valor;
	}

	public void setValor(float valor) {
		this.valor = valor;
	}

	public int getPendentes() {
		return pendentes;
	}

	public void setPendentes(int pendentes) {
		this.pendentes = pendentes;
	}

	public IpvaDTO(String anoExercicio, float valor) {
		super();
		this.anoExercicio = anoExercicio;
		this.valor = valor;
	}

	public String getRenavam() {
		return renavam;
	}

	public void setRenavam(String renavam) {
		this.renavam = renavam;
	}

	public String getProprietario() {
		return proprietario;
	}

	public void setProprietario(String proprietario) {
		this.proprietario = proprietario;
	}

	public String getCodMunicipio() {
		return codMunicipio;
	}

	public void setCodMunicipio(String codMunicipio) {
		this.codMunicipio = codMunicipio;
	}

	public String getCpfCnpj() {
		return cpfCnpj;
	}

	public void setCpfCnpj(String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}

	public String getPlacaVeiculo() {
		return placaVeiculo;
	}

	public void setPlacaVeiculo(String placaVeiculo) {
		this.placaVeiculo = placaVeiculo;
	}

	public String getAutBancaria() {
		return autBancaria;
	}

	public void setAutBancaria(String autBancaria) {
		this.autBancaria = autBancaria;
	}

	public String getDataContabil() {
		return dataContabil;
	}

	public void setDataContabil(String dataContabil) {
		this.dataContabil = dataContabil;
	}

	public List<ExercicioDTO> getListaExercicio() {
		return listaExercicio;
	}

	public int getTamanhoListaExercicio() {
		return listaExercicio.size();
	}

	
	public void setListaExercicio(List<ExercicioDTO> listaExercicio) {
		this.listaExercicio = listaExercicio;
	}

	public int getAnoExercicioByPosicao(int index) {
		if (index < this.listaExercicio.size()) {
			return this.listaExercicio.get(index) != null ? Integer.valueOf(this.listaExercicio.get(index).getExercicio())  : 0;	
		}
		return 0;
	}

	public ExercicioDTO getExercicioByPosicao(int index) {
		if (index < this.listaExercicio.size()) {
			return this.listaExercicio.get(index) != null ? this.listaExercicio.get(index) : null;	
		}
		return null;
	}
	
	public Double getValorTotal() {
		return valorTotal;
	}

	public void setValorTotal(Double valorTotal) {
		this.valorTotal = valorTotal;
	}

	public int getCotaParcela() {
		return cotaParcela;
	}

	public void setCotaParcela(int cotaParcela) {
		this.cotaParcela = cotaParcela;
	}

	public String getIndicadorCota() {
		return indicadorCota;
	}

	public void setIndicadorCota(String indicadorCota) {
		this.indicadorCota = indicadorCota;
	}

	public String getReferOper() {
		return referOper;
	}

	public void setReferOper(String referOper) {
		this.referOper = referOper;
	}

	public String getDataAgendamento() {
		return dataAgendamento;
	}

	public void setDataAgendamento(String dataAgendamento) {
		this.dataAgendamento = dataAgendamento;
	}

	public String getCodServ() {
		return codServ;
	}

	public void setCodServ(String codServ) {
		this.codServ = codServ;
	}

	public String getNumDocum() {
		return numDocum;
	}

	public void setNumDocum(String numDocum) {
		this.numDocum = numDocum;
	}

	public String getCodMun() {
		return codMun;
	}

	public void setCodMun(String codMun) {
		this.codMun = codMun;
	}

	public int getCodFede() {
		return codFede;
	}

	public void setCodFede(int codFede) {
		this.codFede = codFede;
	}

	public String getNomePro() {
		return nomePro;
	}

	public void setNomePro(String nomePro) {
		this.nomePro = nomePro;
	}

	public String getSiglaFede() {
		return siglaFede;
	}

	public void setSiglaFede(String siglaFede) {
		this.siglaFede = siglaFede;
	}

	public String getDataVencCotaUni() {
		return dataVencCotaUni;
	}

	public void setDataVencCotaUni(String dataVencCotaUni) {
		this.dataVencCotaUni = dataVencCotaUni;
	}

	public String getValorCotaUni() {
		return valorCotaUni;
	}

	public void setValorCotaUni(String valorCotaUni) {
		this.valorCotaUni = valorCotaUni;
	}

	public String getDataHoraPagamento() {
		return dataHoraPagamento;
	}

	public void setDataHoraPagamento(String dataHoraPagamento) {
		this.dataHoraPagamento = dataHoraPagamento;
	}

	public String getProdutoCodAlfa2() {
		return produtoCodAlfa2;
	}

	public void setProdutoCodAlfa2(String produtoCodAlfa2) {
		this.produtoCodAlfa2 = produtoCodAlfa2;
	}

	public String getProdutoCodAlfa4() {
		return produtoCodAlfa4;
	}

	public void setProdutoCodAlfa4(String produtoCodAlfa4) {
		this.produtoCodAlfa4 = produtoCodAlfa4;
	}

	public boolean getGeraPendencia() {
		return geraPendencia;
	}

	public void setGeraPendencia(boolean geraPendencia) {
		this.geraPendencia = geraPendencia;
	}
	
	public List<DadosIpvaDTO> getDados() {
		return dados;
	}

	public void setDados(List<DadosIpvaDTO> dados) {
		this.dados = dados;
	}
	
	public String getDadosInformacao1() {
		for (DadosIpvaDTO dado: dados) {
			if (dado.getTpLinha().equals("I")) {
				return dado.getValor();
			}
		}
		return null;
	}
	
	public String getDadosInformacao2() {
		int controle=0;
		for (DadosIpvaDTO dado: dados) {
			if (dado.getTpLinha().equals("I") && controle==0) {
				controle++;
			}
			else if (dado.getTpLinha().equals("I") && controle==1) {
				return dado.getValor();
			}
		}
		return null;
	}
	
	
}