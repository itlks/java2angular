package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class ItemRecargaProgramadaHistoricoDetalheDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String numProtocolo;
    private Date dataSolicitacao;
    private Date dataAgendada;
    private Date dataExecucao;
    private Date dataCancelamento;
    private BigDecimal valor;
    private String codCanalProgramacao;
    private String indProgrAgendamento;
    private String motivoCancelamento;
    private String descrRecarga;
    private String ddd;
    private String numCelular;
    private String operadora;
    private String flgMais;
    private String situacao;
    private String transacao;
    private String origem;
    private String tipo;
	/**
	 * @return the numProtocolo
	 */
	public String getNumProtocolo() {
		return numProtocolo;
	}
	/**
	 * @param numProtocolo the numProtocolo to set
	 */
	public void setNumProtocolo(String numProtocolo) {
		this.numProtocolo = numProtocolo;
	}
	/**
	 * @return the dataSolicitacao
	 */
	public Date getDataSolicitacao() {
		return dataSolicitacao;
	}
	/**
	 * @param dataSolicitacao the dataSolicitacao to set
	 */
	public void setDataSolicitacao(Date dataSolicitacao) {
		this.dataSolicitacao = dataSolicitacao;
	}
	/**
	 * @return the dataAgendada
	 */
	public Date getDataAgendada() {
		return dataAgendada;
	}
	/**
	 * @param dataAgendada the dataAgendada to set
	 */
	public void setDataAgendada(Date dataAgendada) {
		this.dataAgendada = dataAgendada;
	}
	/**
	 * @return the dataExecucao
	 */
	public Date getDataExecucao() {
		return dataExecucao;
	}
	/**
	 * @param dataExecucao the dataExecucao to set
	 */
	public void setDataExecucao(Date dataExecucao) {
		this.dataExecucao = dataExecucao;
	}
	/**
	 * @return the dataCancelamento
	 */
	public Date getDataCancelamento() {
		return dataCancelamento;
	}
	/**
	 * @param dataCancelamento the dataCancelamento to set
	 */
	public void setDataCancelamento(Date dataCancelamento) {
		this.dataCancelamento = dataCancelamento;
	}
	/**
	 * @return the valor
	 */
	public BigDecimal getValor() {
		return valor;
	}
	/**
	 * @param valor the valor to set
	 */
	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}
	/**
	 * @return the codCanalProgramacao
	 */
	public String getCodCanalProgramacao() {
		return codCanalProgramacao;
	}
	/**
	 * @param codCanalProgramacao the codCanalProgramacao to set
	 */
	public void setCodCanalProgramacao(String codCanalProgramacao) {
		this.codCanalProgramacao = codCanalProgramacao;
	}
	/**
	 * @return the indProgrAgendamento
	 */
	public String getIndProgrAgendamento() {
		return indProgrAgendamento;
	}
	/**
	 * @param indProgrAgendamento the indProgrAgendamento to set
	 */
	public void setIndProgrAgendamento(String indProgrAgendamento) {
		this.indProgrAgendamento = indProgrAgendamento;
	}
	/**
	 * @return the motivoCancelamento
	 */
	public String getMotivoCancelamento() {
		return motivoCancelamento;
	}
	/**
	 * @param motivoCancelamento the motivoCancelamento to set
	 */
	public void setMotivoCancelamento(String motivoCancelamento) {
		this.motivoCancelamento = motivoCancelamento;
	}
	/**
	 * @return the descrRecarga
	 */
	public String getDescrRecarga() {
		return descrRecarga;
	}
	/**
	 * @param descrRecarga the descrRecarga to set
	 */
	public void setDescrRecarga(String descrRecarga) {
		this.descrRecarga = descrRecarga;
	}
	/**
	 * @return the ddd
	 */
	public String getDdd() {
		return ddd;
	}
	/**
	 * @param ddd the ddd to set
	 */
	public void setDdd(String ddd) {
		this.ddd = ddd;
	}
	/**
	 * @return the numCelular
	 */
	public String getNumCelular() {
		return numCelular;
	}
	/**
	 * @param numCelular the numCelular to set
	 */
	public void setNumCelular(String numCelular) {
		this.numCelular = numCelular;
	}
	/**
	 * @return the operadora
	 */
	public String getOperadora() {
		return operadora;
	}
	/**
	 * @param operadora the operadora to set
	 */
	public void setOperadora(String operadora) {
		this.operadora = operadora;
	}
	/**
	 * @return the flgMais
	 */
	public String getFlgMais() {
		return flgMais;
	}
	/**
	 * @param flgMais the flgMais to set
	 */
	public void setFlgMais(String flgMais) {
		this.flgMais = flgMais;
	}
	/**
	 * @return the situacao
	 */
	public String getSituacao() {
		return situacao;
	}
	/**
	 * @param situacao the situacao to set
	 */
	public void setSituacao(String situacao) {
		this.situacao = situacao;
	}
	/**
	 * @return the transacao
	 */
	public String getTransacao() {
		return transacao;
	}
	/**
	 * @param transacao the transacao to set
	 */
	public void setTransacao(String transacao) {
		this.transacao = transacao;
	}
	/**
	 * @return the origem
	 */
	public String getOrigem() {
		return origem;
	}
	/**
	 * @param origem the origem to set
	 */
	public void setOrigem(String origem) {
		this.origem = origem;
	}
	/**
	 * @return the tipo
	 */
	public String getTipo() {
		return tipo;
	}
	/**
	 * @param tipo the tipo to set
	 */
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	    
}
