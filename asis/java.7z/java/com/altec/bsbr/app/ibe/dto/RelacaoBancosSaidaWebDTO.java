package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.altec.bsbr.app.ibe.dto.bancos.ErrosDTO;

public class RelacaoBancosSaidaWebDTO implements Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = -1310434037592405955L;
	
	private List<ListaRelacaoBancosDTO> resultados = new ArrayList<ListaRelacaoBancosDTO>();
	private String lngRetCode;
	private String strErro;
	private String strErroTecnica;
	private String saida;
	private ErrosDTO erros = new ErrosDTO();
	

	public String getLngRetCode() {
		return lngRetCode;
	}
	public void setLngRetCode(String lngRetCode) {
		this.lngRetCode = lngRetCode;
	}
	public String getStrErro() {
		return strErro;
	}
	public void setStrErro(String strErro) {
		this.strErro = strErro;
	}
	public String getStrErroTecnica() {
		return strErroTecnica;
	}
	public void setStrErroTecnica(String strErroTecnica) {
		this.strErroTecnica = strErroTecnica;
	}
	public String getSaida() {
		return saida;
	}
	public void setSaida(String saida) {
		this.saida = saida;
	}
	public ErrosDTO getErros() {
		return erros;
	}
	public void setErros(ErrosDTO erros) {
		this.erros = erros;
	}
	public List<ListaRelacaoBancosDTO> getResultados() {
		return resultados;
	}
	public void setResultados(List<ListaRelacaoBancosDTO> resultados) {
		this.resultados = resultados;
	}
	
	
	
	
	

}
