package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.Date;

import com.altec.bsbr.app.ibe.dto.consultarconveniosdebitoautomatico.ItemConsultarConveniosDebitoAutomaticoResponseDTO;

public class DebitoAutomaticoDesbloqueioDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String dataDebito;
	private String identificacaoConsumidor;
	private String bloqueadoPor;
	private String formaPagamento;
	private ItemConsultarConveniosDebitoAutomaticoResponseDTO empresaConveniadaDTO;
	private String nomeEmpresaConveniada;
	private String valor;
	private BancoDTO entDeb;
	private BancoDTO banco;
	private Date dataInicial;
	private Date dataFinal;
	private String vencimento;
	private String autenticacaoBancaria;
	private Date dataHoraTransacao;
	private String remessaWeb;
	private String comproWeb;
	private String codigoNSU;
	private String numCartaoCredito;
	
	public String getDataDebito() {
		return dataDebito;
	}

	public void setDataDebito(String dataDebito) {
		this.dataDebito = dataDebito;
	}

	public String getIdentificacaoConsumidor() {
		return identificacaoConsumidor;
	}

	public void setIdentificacaoConsumidor(String identificacaoConsumidor) {
		this.identificacaoConsumidor = identificacaoConsumidor;
	}

	public String getBloqueadoPor() {
		return bloqueadoPor;
	}

	public void setBloqueadoPor(String bloqueadoPor) {
		this.bloqueadoPor = bloqueadoPor;
	}

	public String getFormaPagamento() {
		return formaPagamento;
	}

	public void setFormaPagamento(String formaPagamento) {
		this.formaPagamento = formaPagamento;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	public BancoDTO getEntDeb() {
		return entDeb;
	}

	public void setEntDeb(BancoDTO entDeb) {
		this.entDeb = entDeb;
	}

	public BancoDTO getBanco() {
		return banco;
	}

	public void setBanco(BancoDTO banco) {
		this.banco = banco;
	}

	public Date getDataInicial() {
		return dataInicial;
	}

	public void setDataInicial(Date dataInicial) {
		this.dataInicial = dataInicial;
	}

	public Date getDataFinal() {
		return dataFinal;
	}

	public void setDataFinal(Date dataFinal) {
		this.dataFinal = dataFinal;
	}

	public String getVencimento() {
		return vencimento;
	}

	public void setVencimento(String vencimento) {
		this.vencimento = vencimento;
	}

	public String getAutenticacaoBancaria() {
		return autenticacaoBancaria;
	}

	public void setAutenticacaoBancaria(String autenticacaoBancaria) {
		this.autenticacaoBancaria = autenticacaoBancaria;
	}

	public Date getDataHoraTransacao() {
		return dataHoraTransacao;
	}

	public void setDataHoraTransacao(Date dataHoraTransacao) {
		this.dataHoraTransacao = dataHoraTransacao;
	}

	public String getRemessaWeb() {
		return remessaWeb;
	}

	public void setRemessaWeb(String remessaWeb) {
		this.remessaWeb = remessaWeb;
	}

	public String getComproWeb() {
		return comproWeb;
	}

	public void setComproWeb(String comproWeb) {
		this.comproWeb = comproWeb;
	}

	public String getNomeEmpresaConveniada() {
		return nomeEmpresaConveniada;
	}

	public void setNomeEmpresaConveniada(String nomeEmpresaConveniada) {
		this.nomeEmpresaConveniada = nomeEmpresaConveniada;
	}

	public ItemConsultarConveniosDebitoAutomaticoResponseDTO getEmpresaConveniadaDTO() {
		return empresaConveniadaDTO;
	}

	public void setEmpresaConveniadaDTO(ItemConsultarConveniosDebitoAutomaticoResponseDTO empresaConveniadaDTO) {
		this.empresaConveniadaDTO = empresaConveniadaDTO;
	}

	public String getCodigoNSU() {
		return codigoNSU;
	}

	public void setCodigoNSU(String codigoNSU) {
		this.codigoNSU = codigoNSU;
	}

	public String getNumCartaoCredito() {
		return numCartaoCredito;
	}

	public void setNumCartaoCredito(String numCartaoCredito) {
		this.numCartaoCredito = numCartaoCredito;
	}

}
