package com.altec.bsbr.app.ibe.enumeration;

public enum TipoDarfEnum {
	PRETA("P"),
	SIMPLES("S");

	private String codigo;

	private TipoDarfEnum(String codigo) {		
		this.codigo = codigo;
	}
	
	public String getCodigo() {
		return codigo;
	}



	
}
