package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

import com.altec.bsbr.app.ibe.webclient.bks.agendamento.CONTRATOBRType;

public class ConsultarAgendamentosDetalheRequestDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	private CONTRATOBRType banco;
	private Integer tipoGrupoProgramacion;
	private Integer tipoProgramacion;
	private String canalAgendado;
	private Integer situacionAgendamento;
	private String fechaInicio;
	private String fechaFin;
	private String numProtocoloRechamada;
	private String dataRechamada;
	private String valoRechamada;
	private String ordenacion;
	
	public CONTRATOBRType getBanco() {
		return banco;
	}

	public void setBanco(CONTRATOBRType banco) {
		this.banco = banco;
	}

	public Integer getTipoGrupoProgramacion() {
		return tipoGrupoProgramacion;
	}

	public void setTipoGrupoProgramacion(Integer tipoGrupoProgramacion) {
		this.tipoGrupoProgramacion = tipoGrupoProgramacion;
	}

	public String getCanalAgendado() {
		return canalAgendado;
	}

	public void setCanalAgendado(String canalAgendado) {
		this.canalAgendado = canalAgendado;
	}

	public Integer getSituacionAgendamento() {
		return situacionAgendamento;
	}

	public void setSituacionAgendamento(Integer situacionAgendamento) {
		this.situacionAgendamento = situacionAgendamento;
	}

	public String getFechaInicio() {
		return fechaInicio;
	}

	public void setFechaInicio(String fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	public String getFechaFin() {
		return fechaFin;
	}

	public void setFechaFin(String fechaFin) {
		this.fechaFin = fechaFin;
	}

	public String getNumProtocoloRechamada() {
		return numProtocoloRechamada;
	}

	public void setNumProtocoloRechamada(String numProtocoloRechamada) {
		this.numProtocoloRechamada = numProtocoloRechamada;
	}

	public String getDataRechamada() {
		return dataRechamada;
	}

	public void setDataRechamada(String dataRechamada) {
		this.dataRechamada = dataRechamada;
	}

	public String getValoRechamada() {
		return valoRechamada;
	}

	public void setValoRechamada(String valoRechamada) {
		this.valoRechamada = valoRechamada;
	}

	public String getOrdenacion() {
		return ordenacion;
	}

	public void setOrdenacion(String ordenacion) {
		this.ordenacion = ordenacion;
	}

	public Integer getTipoProgramacion() {
		return tipoProgramacion;
	}

	public void setTipoProgramacion(Integer tipoProgramacion) {
		this.tipoProgramacion = tipoProgramacion;
	}

}
