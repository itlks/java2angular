package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;

public class GuiaDTO  implements Serializable, Comparable<GuiaDTO> {
	
	private static final long serialVersionUID = 8150343169429694821L;
	
	private String guia;
	private String dataVencimento;
	private BigDecimal valor;	
	private String dataInfracao;
	private String autoInfracao;
	private String orgaoAutuador;
	private String ufInfracao;
	
	public GuiaDTO(){
		
	}	

	public GuiaDTO(String guia, String dataVencimento, BigDecimal valor, String dataInfracao,
			String autoInfracao, String orgaoAutuador) {
		super();
		this.guia = guia;
		this.dataVencimento = dataVencimento;
		this.valor = valor;
		this.dataInfracao = dataInfracao;
		this.autoInfracao = autoInfracao;
		this.orgaoAutuador = orgaoAutuador;
	}


	public String getGuia() {
		return guia;
	}

	public void setGuia(String guia) {
		this.guia = guia;
	}

	public String getDataVencimento() {
		return dataVencimento;
	}

	public void setDataVencimento(String dataVencimento) {
		this.dataVencimento = dataVencimento;
	}

	public BigDecimal getValor() {
		return valor;
	}

	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}

	public String getDataInfracao() {
		return dataInfracao;
	}

	public void setDataInfracao(String dataInfracao) {
		this.dataInfracao = dataInfracao;
	}

	public String getAutoInfracao() {
		return autoInfracao;
	}

	public void setAutoInfracao(String autoInfracao) {
		this.autoInfracao = autoInfracao;
	}

	public String getOrgaoAutuador() {
		return orgaoAutuador;
	}

	public void setOrgaoAutuador(String orgaoAutuador) {
		this.orgaoAutuador = orgaoAutuador;
	}

	public void setUfInfracao(String ufMult1) {
		this.ufInfracao = ufMult1;
	}
	
	public String getUfInfracao() {
		return this.ufInfracao;
	}

	@Override
	public int compareTo(GuiaDTO guia) {
		return this.guia.compareTo(guia.getGuia());
	}	
}
