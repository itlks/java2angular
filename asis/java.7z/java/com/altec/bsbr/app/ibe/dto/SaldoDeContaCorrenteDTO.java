package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.text.WordUtils;

import com.altec.bsbr.app.ibe.message.Mensagem;
import com.altec.bsbr.app.ibe.util.StringUtil;
import com.altec.bsbr.app.ibe.util.UtilFunction;
import com.santander.component.domain.SaldoContaCorrenteOE;

public class SaldoDeContaCorrenteDTO implements Serializable {

	private static final long serialVersionUID = 726630466141688175L;

	private String letraAtual = "";

	// Variaveis que representam as letras das partes que compoem o saldo
	private String lSaldoCC_CC = "";
	private String lSaldoBloqDia_CC = "";
	private String lLancamentosProvisionadosCredito_CC = "";
	private String lLancamentosProvisionadosDebito_CC = "";
	private String lSaldoContaInvestimento_CC_CI = "";
	private String lTotalDaContaCorrente_CC = "";
	private String lSaldoBloqueado_CC = "";
	private String lSaldoBloqueioJudicial_CC = "";
	private String lSaldoDisponivelContaCorrenteMaisContaInvestimento_CC = "";
	private String lSaldoFundosResgateAutomatico_CC = "";
	private String lProvisaoEncargos_CC = "";
	private String lSaldoDisponivel_CC = "";
	private String lLimiteChequeEspecial_CC = "";
	private String lLimiteChequeInvestidor_CC = "";

	private Boolean contaInvestimento = null;
	private Boolean contaMax = null;
	private Boolean pessoaFisica = null;
	private Boolean cpmf = null;

	private SaldoContaCorrenteOE saldo;
	private List<SaldoDeContaCorrenteItemDTO> componentesSaldo = new ArrayList<SaldoDeContaCorrenteItemDTO>();
	private List<SaldoDeContaCorrenteItemDTO> componentesJuros = new ArrayList<SaldoDeContaCorrenteItemDTO>();
	private List<SaldoDeContaCorrenteItemDTO> componentesDatas = new ArrayList<SaldoDeContaCorrenteItemDTO>();
	private List<SaldoDeContaCorrenteItemDTO> componentesChequeEspecial = new ArrayList<SaldoDeContaCorrenteItemDTO>();
	private Date dataPosicao;

	public SaldoDeContaCorrenteDTO(SaldoContaCorrenteOE saldo, Date dataConsulta, String tipoPessoa) {
		this.saldo = saldo;
		this.dataPosicao = dataConsulta;
		letraAtual = "";
		contaInvestimento = ("N".equalsIgnoreCase(saldo.getFLAG_MOSTRA_CI()) ? false : true);
		contaMax = ("N".equalsIgnoreCase(saldo.getIND_POUPMAX()) ? false : true);
		pessoaFisica = "F".equalsIgnoreCase(tipoPessoa);
		cpmf = !"P".equalsIgnoreCase(saldo.getIND_CPMF());

	}
	
	public void geraComponentesSaldoContaCorrente() {
		getSaldoDeConta();
		getSaldoBloqueadoDia();
		getLancamentosProvisionadosACredito();
		getLancamentosProvisionadosADebito();

		getSaldoTotalDeContaCorrente();

		if (contaInvestimento) {
			getSaldoContaInvestimento();
			getSaldoContaCorrenteMaisContaInvestimento();
		}

		getSaldoBloqueado();
		getSaldoBloqueadoJudicial();
		insereProvisaoEncargos();
		getSeguroChequeProtegidoAteAData();
		getSaldoDisponivelContaCorrenteMaisContaInvestimento();
		getValorResgateAutomatico();
		getSaldoDisponivel();
		getLimiteChequeEspecial();
		getLimiteChequeInvestidor();
		getSaldoDisponivelTotal();
		getJuros();
		getMovimento();
	}
	
	public void geraComponentesSaldoContaCorrenteExtrato() {
		getSaldoDeConta();
		getSaldoBloqueadoDia();
		getLancamentosProvisionadosACredito();
		getLancamentosProvisionadosADebito();

		getSaldoTotalDeContaCorrente();

		if (contaInvestimento) {
			getSaldoContaInvestimento();
			getSaldoContaCorrenteMaisContaInvestimento();
		}

		getSaldoBloqueado();
		getSaldoBloqueadoJudicial();
		insereProvisaoEncargos();
		getSeguroChequeProtegidoAteAData();
		getSaldoDisponivelContaCorrenteMaisContaInvestimento();
		getValorResgateAutomatico();
		getSaldoDisponivel();
		getLimiteChequeEspecial();
		getLimiteChequeInvestidor();
		getSaldoDisponivelTotal();
		getJuros();
		getMovimento();
		getChequeEspecial();
	}

	private void getSaldoDeConta() {
		if ((saldo.getOE_SALDO_BLQ_DIA() != null && saldo.getOE_SALDO_BLQ_DIA().doubleValue() != 0)
				|| (saldo.getLANC_PROV_CREDITO() != null && saldo.getLANC_PROV_CREDITO().doubleValue() != 0)
				|| (saldo.getLANC_PROV_DEBITO() != null && saldo.getLANC_PROV_DEBITO().doubleValue() != 0)) {
			lSaldoCC_CC = getProxLetra();
//			getProxLetra();
			String descricao = Mensagem.getMensagem("page.conta.corrente.consulta.saldo.label.saldo.de.conta");
			BigDecimal valor = (contaMax ? (saldo.getSLD_CTBPOUP() == null ? BigDecimal.ZERO : saldo.getSLD_CTBPOUP()) : (saldo.getVL_SALDOCC() == null ? BigDecimal.ZERO : saldo.getVL_SALDOCC()));

			if (contaMax && pessoaFisica) {
				descricao = Mensagem.getMensagem("page.conta.corrente.consulta.saldo.label.saldo.de.contamax");
			} else if (contaInvestimento) {
				descricao = Mensagem.getMensagem("page.conta.corrente.consulta.saldo.label.saldo.de.conta.corrente");
			}
			componentesSaldo.add(new SaldoDeContaCorrenteItemDTO(letraAtual + " - " + descricao,
					UtilFunction.convertBigDecimalToStringFormatoBR(valor)));
		}
	}

	private void getSaldoBloqueadoDia() {
		if (saldo.getOE_SALDO_BLQ_DIA() != null && saldo.getOE_SALDO_BLQ_DIA().doubleValue() != 0) {
			lSaldoBloqDia_CC = " + " + getProxLetra();
			componentesSaldo
					.add(new SaldoDeContaCorrenteItemDTO(
							letraAtual + " - "
									+ Mensagem
											.getMensagem("page.conta.corrente.consulta.saldo.label.saldo.bloqueio.dia"),
							UtilFunction.convertBigDecimalToStringFormatoBR(saldo.getOE_SALDO_BLQ_DIA() == null ? BigDecimal.ZERO : saldo.getOE_SALDO_BLQ_DIA())));
		}
	}

	private void getLancamentosProvisionadosACredito() {
		if (saldo.getLANC_PROV_CREDITO() != null && saldo.getLANC_PROV_CREDITO().doubleValue() != 0) {
			lLancamentosProvisionadosCredito_CC = " + " + getProxLetra();
			componentesSaldo.add(new SaldoDeContaCorrenteItemDTO(
					letraAtual + " - "
							+ Mensagem.getMensagem(
									"page.conta.corrente.consulta.saldo.label.lancamentos.provisionados.a.credito"),
					UtilFunction.convertBigDecimalToStringFormatoBR(saldo.getLANC_PROV_CREDITO() == null ? BigDecimal.ZERO : saldo.getLANC_PROV_CREDITO())));
		}
	}

	private void getLancamentosProvisionadosADebito() {
		if (saldo.getLANC_PROV_DEBITO() != null && saldo.getLANC_PROV_DEBITO().doubleValue() != 0) {
			lLancamentosProvisionadosDebito_CC = " - " + getProxLetra();
			componentesSaldo.add(new SaldoDeContaCorrenteItemDTO(
					letraAtual + " - "
							+ Mensagem.getMensagem(
									"page.conta.corrente.consulta.saldo.label.lancamentos.provisionados.a.debito"),
					UtilFunction.convertBigDecimalToStringFormatoBR(saldo.getLANC_PROV_DEBITO() == null ? BigDecimal.ZERO : saldo.getLANC_PROV_DEBITO())));
		}
	}

	private void getSaldoTotalDeContaCorrente() {
		String descricao = Mensagem.getMensagem("page.conta.corrente.consulta.saldo.label.saldo.de.conta.corrente");
		lTotalDaContaCorrente_CC = getProxLetra();
		if ((saldo.getOE_SALDO_BLQ_DIA() != null && saldo.getOE_SALDO_BLQ_DIA().doubleValue() != 0)
				|| (saldo.getLANC_PROV_CREDITO() != null && saldo.getLANC_PROV_CREDITO().doubleValue() != 0)
				|| (saldo.getLANC_PROV_DEBITO() != null && saldo.getLANC_PROV_DEBITO().doubleValue() != 0)) {
			if (contaMax && pessoaFisica) {
				descricao = Mensagem.getMensagem("page.conta.corrente.consulta.saldo.label.saldo.total.de.contamax");
			} else {
				descricao = Mensagem
						.getMensagem("page.conta.corrente.consulta.saldo.label.saldo.total.de.conta.corrente");
			}
		} else {
			if (contaMax && pessoaFisica) {
				descricao = Mensagem.getMensagem("page.conta.corrente.consulta.saldo.label.saldo.de.contamax");
			}
		}
		
		String detalhe = lSaldoCC_CC + lSaldoBloqDia_CC + lLancamentosProvisionadosCredito_CC + lLancamentosProvisionadosDebito_CC;
		if (! "".equals(detalhe)) {
			descricao += " (" + detalhe + ")";
		}

		componentesSaldo.add(new SaldoDeContaCorrenteItemDTO(letraAtual + " - " + descricao,
				UtilFunction.convertBigDecimalToStringFormatoBR(saldo.getOE_SALDO_DISP() == null ? BigDecimal.ZERO : saldo.getOE_SALDO_DISP())));
	}

	private void getSaldoContaInvestimento() {
		lSaldoContaInvestimento_CC_CI = getProxLetra();
		componentesSaldo
				.add(new SaldoDeContaCorrenteItemDTO(
						letraAtual + " - "
								+ Mensagem.getMensagem(
										"page.conta.corrente.consulta.saldo.label.saldo.de.conta.investimento"),
						UtilFunction.convertBigDecimalToStringFormatoBR(saldo.getVL_SALDOCI() == null ? BigDecimal.ZERO : saldo.getVL_SALDOCI())));
	}

	private void getSaldoContaCorrenteMaisContaInvestimento() {
		// lSaldoContaCorrenteMaisSaldoContaInvestimento_CC_CI = getProxLetra();
		getProxLetra();
		String descricao = Mensagem.getMensagem(
				"page.conta.corrente.consulta.saldo.label.saldo.de.conta.corrente.mais.saldo.de.conta.investimento");
		if (contaMax && pessoaFisica) {
			descricao = Mensagem.getMensagem(
					"page.conta.corrente.consulta.saldo.label.saldo.de.contamax.mais.saldo.de.conta.investimento") + "("
					+ lTotalDaContaCorrente_CC + " + " + lSaldoContaInvestimento_CC_CI + ")";
		}
		descricao += " (" + lTotalDaContaCorrente_CC + " + " + lSaldoContaInvestimento_CC_CI + ")";
		componentesSaldo.add(new SaldoDeContaCorrenteItemDTO(letraAtual + " - " + descricao,
				UtilFunction.convertBigDecimalToStringFormatoBR(saldo.getVL_TOTAL_CC_CI() == null ? BigDecimal.ZERO : saldo.getVL_TOTAL_CC_CI())));
	}

	private void getSaldoBloqueado() {
		lSaldoBloqueado_CC = getProxLetra();
		List<SaldoDeContaCorrenteItemDTO> detalheSaldoBloqueado = new ArrayList<SaldoDeContaCorrenteItemDTO>();
		detalheSaldoBloqueado.add(new SaldoDeContaCorrenteItemDTO(
				Mensagem.getMensagem("page.conta.corrente.consulta.saldo.label.desbloqueio.em.um.dia"),
				UtilFunction.convertBigDecimalToStringFormatoBR(saldo.getVL_BLOQ24() == null ? BigDecimal.ZERO : saldo.getVL_BLOQ24())));
		detalheSaldoBloqueado.add(new SaldoDeContaCorrenteItemDTO(
				Mensagem.getMensagem("page.conta.corrente.consulta.saldo.label.desbloqueio.em.dois.dias"),
				UtilFunction.convertBigDecimalToStringFormatoBR(saldo.getVL_BLOQ48() == null ? BigDecimal.ZERO : saldo.getVL_BLOQ48())));
		detalheSaldoBloqueado.add(new SaldoDeContaCorrenteItemDTO(
				Mensagem.getMensagem("page.conta.corrente.consulta.saldo.label.desbloqueio.em.mais.de.dois.dias"),
				UtilFunction.convertBigDecimalToStringFormatoBR(saldo.getVL_BLOQIND() == null ? BigDecimal.ZERO : saldo.getVL_BLOQIND())));
		componentesSaldo.add(new SaldoDeContaCorrenteItemDTO(
				letraAtual + " - " + Mensagem.getMensagem("page.conta.corrente.consulta.saldo.label.saldo.bloqueado"),
				UtilFunction.convertBigDecimalToStringFormatoBR(saldo.getVL_CHEQUES_BLOQ() == null ? BigDecimal.ZERO : saldo.getVL_CHEQUES_BLOQ()), detalheSaldoBloqueado));
	}

	private void getSaldoBloqueadoJudicial() {
		if (saldo.getOE_SALDO_BLQ_JUD() != null && saldo.getOE_SALDO_BLQ_JUD().doubleValue() != 0) {
			lSaldoBloqueioJudicial_CC = getProxLetra();
			componentesSaldo
					.add(new SaldoDeContaCorrenteItemDTO(
							letraAtual + " - "
									+ Mensagem.getMensagem(
											"page.conta.corrente.consulta.saldo.label.saldo.bloqueio.judicial"),
							UtilFunction.convertBigDecimalToStringFormatoBR(saldo.getOE_SALDO_BLQ_JUD() == null ? BigDecimal.ZERO : saldo.getOE_SALDO_BLQ_JUD())));
		}
	}

	private void insereProvisaoEncargos() {
		if (saldo.getOE_SALDO_PROV_ENC() != null && saldo.getOE_SALDO_PROV_ENC().doubleValue() != 0) {
			getProxLetra();
			if (StringUtils.isEmpty(saldo.getOE_DESC_PRIM_LIMITE()) && StringUtils.isEmpty(saldo.getOE_SEG_PRIM_LIMITE())) {
				lProvisaoEncargos_CC = letraAtual;
			}
			List<SaldoDeContaCorrenteItemDTO> detalheProvisaoEncargos = new ArrayList<SaldoDeContaCorrenteItemDTO>();
			detalheProvisaoEncargos.add(new SaldoDeContaCorrenteItemDTO(
					Mensagem.getMensagem("page.conta.corrente.consulta.saldo.label.juros.acumulados.ate.a.data"),
					UtilFunction.convertBigDecimalToStringFormatoBR(saldo.getOE_JUROS_ACUM_PROV() == null ? BigDecimal.ZERO : saldo.getOE_JUROS_ACUM_PROV())));
			detalheProvisaoEncargos.add(new SaldoDeContaCorrenteItemDTO(
					Mensagem.getMensagem("page.conta.corrente.consulta.saldo.label.iof.acumulado.ate.a.data"),
					UtilFunction.convertBigDecimalToStringFormatoBR(saldo.getOE_IOF_ACUM_PROV() == null ? BigDecimal.ZERO : saldo.getOE_IOF_ACUM_PROV())));
			detalheProvisaoEncargos.add(new SaldoDeContaCorrenteItemDTO(
					Mensagem.getMensagem("page.conta.corrente.consulta.saldo.label.cpmf.acumulada"),
					UtilFunction.convertBigDecimalToStringFormatoBR(saldo.getVL_CPMF() == null ? BigDecimal.ZERO : saldo.getVL_CPMF())));
			detalheProvisaoEncargos.add(new SaldoDeContaCorrenteItemDTO(
					Mensagem.getMensagem("page.conta.corrente.consulta.saldo.label.cpmf.provisionada.sobre.saldo"),
					UtilFunction.convertBigDecimalToStringFormatoBR(saldo.getOE_CPMF_ACUM() == null ? BigDecimal.ZERO : saldo.getOE_CPMF_ACUM())));
			String mensagem = letraAtual + " - " + Mensagem.getMensagem("page.conta.corrente.consulta.saldo.label.provisao.de.encargos");
			componentesSaldo.add(new SaldoDeContaCorrenteItemDTO(
							mensagem,
							UtilFunction.convertBigDecimalToStringFormatoBR(saldo.getOE_SALDO_PROV_ENC() == null ? BigDecimal.ZERO : saldo.getOE_SALDO_PROV_ENC()),
							Mensagem.getMensagem("page.conta.corrente.consulta.saldo.msg.valoresdeduzidosdosaldodisponivelparacontassemlimite"),
							detalheProvisaoEncargos));
		}
	}

	private void getSeguroChequeProtegidoAteAData() {
		if (saldo.getOE_VL_SEG_PREST_FECH() != null & saldo.getOE_VL_SEG_PREST_FECH().doubleValue() != Double.parseDouble("9999999999999.99")) {
			getProxLetra();
			String descricao = Mensagem
					.getMensagem("page.conta.corrente.consulta.saldo.label.seguro.cheque.empresa.protegido.ate.a.data");
			String info = Mensagem.getMensagem("page.conta.corrente.consulta.saldo.msg.valorseradebitadonomesmodiadosencargosdochequeempresa");
			
			if (pessoaFisica) {
				descricao = Mensagem.getMensagem(
						"page.conta.corrente.consulta.saldo.label.seguro.cheque.especial.protegido.ate.a.data");
				info = Mensagem.getMensagem("page.conta.corrente.consulta.saldo.msg.valorseracobradonomesmodiadosencargosdochequeespecial");
			}
			componentesSaldo.add(new SaldoDeContaCorrenteItemDTO(letraAtual + " - " + descricao,
					UtilFunction.convertBigDecimalToStringFormatoBR(saldo.getOE_VL_SEG_PREST_FECH() == null ? BigDecimal.ZERO : saldo.getOE_VL_SEG_PREST_FECH()), info));
		}
	}

	private void getSaldoDisponivelContaCorrenteMaisContaInvestimento() {
		lSaldoDisponivelContaCorrenteMaisContaInvestimento_CC = getProxLetra();
		String descricao = Mensagem
				.getMensagem("page.conta.corrente.consulta.saldo.label.saldo.disponivel.de.conta.corrente");
		if (contaInvestimento && contaMax && pessoaFisica) {
			descricao = Mensagem.getMensagem(
					"page.conta.corrente.consulta.saldo.label.saldo.disponivel.de.contamax.mais.conta.investimento");
		} else if (contaInvestimento) {
			descricao = Mensagem.getMensagem(
					"page.conta.corrente.consulta.saldo.label.saldo.disponivel.de.conta.corrente.mais.conta.investimento");
		} else if (contaMax  && pessoaFisica) {
			descricao = Mensagem.getMensagem("page.conta.corrente.consulta.saldo.label.saldo.disponivel.contamax");
		}
		descricao += " (" + lTotalDaContaCorrente_CC;
		if (!"".equals(lSaldoBloqueado_CC)) {
			descricao += " - "  + lSaldoBloqueado_CC;
		}
		if (!"".equals(lSaldoBloqueioJudicial_CC)) {
			descricao += " - "  + lSaldoBloqueioJudicial_CC;
		}
		if (!"".equals(lProvisaoEncargos_CC)) {
			descricao += " - "  + lProvisaoEncargos_CC;
		}
		descricao += ")";
		componentesSaldo.add(new SaldoDeContaCorrenteItemDTO(letraAtual + " - " + descricao,
				UtilFunction.convertBigDecimalToStringFormatoBR(saldo.getOE_CC_SALDO_DISPONIV() == null ? BigDecimal.ZERO : saldo.getOE_CC_SALDO_DISPONIV())));
	}

	private void getValorResgateAutomatico() {
		if (saldo.getVL_RESG_AUT() != null && saldo.getVL_RESG_AUT().doubleValue() != 0) {
			lSaldoFundosResgateAutomatico_CC = getProxLetra();
			String descricao = Mensagem.getMensagem(
					"page.conta.corrente.consulta.saldo.label.saldo.em.investimentos.com.resgate.automatico");
			if (pessoaFisica) {
				descricao = Mensagem
						.getMensagem("page.conta.corrente.consulta.saldo.label.saldo.fundos.com.resgate.automatico");
			}
			componentesSaldo.add(new SaldoDeContaCorrenteItemDTO(letraAtual + " - " + descricao,
					UtilFunction.convertBigDecimalToStringFormatoBR(saldo.getVL_RESG_AUT() == null ? BigDecimal.ZERO : saldo.getVL_RESG_AUT())));
		} else {
			lSaldoDisponivel_CC = lSaldoDisponivelContaCorrenteMaisContaInvestimento_CC;
		}
	}

	private void getSaldoDisponivel() {
		if (saldo.getVL_RESG_AUT() != null && saldo.getVL_RESG_AUT().doubleValue() != 0) {
			lSaldoDisponivel_CC = getProxLetra();
			String descricao = letraAtual + " - "
					+ Mensagem.getMensagem("page.conta.corrente.consulta.saldo.label.saldo.disponivel") + " ("
					+ lSaldoDisponivelContaCorrenteMaisContaInvestimento_CC + " + "
					+ lSaldoFundosResgateAutomatico_CC + ")";
			componentesSaldo.add(new SaldoDeContaCorrenteItemDTO(descricao, UtilFunction.convertBigDecimalToStringFormatoBR(saldo.getVL_TOTAL_SALDO() == null ? BigDecimal.ZERO : saldo.getVL_TOTAL_SALDO())));
			lSaldoDisponivel_CC = lSaldoDisponivelContaCorrenteMaisContaInvestimento_CC;
		}
	}

	private void getLimiteChequeEspecial() {
		if (StringUtils.isNotEmpty(saldo.getOE_DESC_PRIM_LIMITE())) {
			if (saldo.getVL_LIMITE() != null && saldo.getVL_LIMITE().doubleValue() != 0) {
				lLimiteChequeEspecial_CC = " + " + getProxLetra();
				componentesSaldo.add(new SaldoDeContaCorrenteItemDTO(
						letraAtual + " - " + Mensagem.getMensagem("page.conta.corrente.consulta.saldo.label.limite")
								+ " " + WordUtils.capitalizeFully(saldo.getOE_DESC_PRIM_LIMITE().trim()),
						UtilFunction.convertBigDecimalToStringFormatoBR(saldo.getVL_LIMITE() == null ? BigDecimal.ZERO : saldo.getVL_LIMITE())));
				
			}
		}
	}

	private void getLimiteChequeInvestidor() {
		if (StringUtils.isNotEmpty(saldo.getOE_SEG_PRIM_LIMITE())) {
			if (saldo.getOE_CHQ_INV_LIMITE() != null && saldo.getOE_CHQ_INV_LIMITE().doubleValue() != 0) {
				lLimiteChequeInvestidor_CC = " + " + getProxLetra();
				componentesSaldo.add(new SaldoDeContaCorrenteItemDTO(
						letraAtual + " - " + Mensagem.getMensagem("page.conta.corrente.consulta.saldo.label.limite")
								+ " " + WordUtils.capitalizeFully(saldo.getOE_SEG_PRIM_LIMITE().trim()),
						UtilFunction.convertBigDecimalToStringFormatoBR(saldo.getOE_CHQ_INV_LIMITE() == null ? BigDecimal.ZERO : saldo.getOE_CHQ_INV_LIMITE())));
			}
		}
	}

	private void getSaldoDisponivelTotal() {
		if ((saldo.getVL_LIMITE() != null && saldo.getVL_LIMITE().doubleValue() != 0)
				|| (saldo.getOE_CHQ_INV_LIMITE() != null && saldo.getOE_CHQ_INV_LIMITE().doubleValue() != 0)) {
//			lSaldoDisponivelTotal_CC_CI = getProxLetra();
			getProxLetra();
			componentesSaldo.add(
					new SaldoDeContaCorrenteItemDTO(
							letraAtual + " - "
									+ Mensagem.getMensagem(
											"page.conta.corrente.consulta.saldo.label.saldo.disponivel.total")
									+ " (" + lSaldoDisponivel_CC + lLimiteChequeEspecial_CC + lLimiteChequeInvestidor_CC
									+ ")",
							UtilFunction.convertBigDecimalToStringFormatoBR(saldo.getVL_DISPONIVEL() == null ? BigDecimal.ZERO : saldo.getVL_DISPONIVEL())));
		}
	}

	private void getJuros() {
//		if ((saldo.getVLJUR_NAO_DEB() != null && saldo.getVLJUR_NAO_DEB().doubleValue() != 0)
//		|| (saldo.getQT_DIA_NDIA() != null && saldo.getQT_DIA_NDIA() != 0)) {
			componentesJuros.add(new SaldoDeContaCorrenteItemDTO(
					Mensagem.getMensagem("page.conta.corrente.consulta.saldo.label.juros.calculados"),
					UtilFunction.convertBigDecimalToStringFormatoBR(saldo.getVLJUR_NAO_DEB() == null ? BigDecimal.ZERO : saldo.getVLJUR_NAO_DEB().abs())));
			
			NumberFormat nf = NumberFormat.getInstance(new Locale("es", "ES"));
			nf.setMinimumIntegerDigits(2);
			
			componentesJuros.add(new SaldoDeContaCorrenteItemDTO(
					Mensagem.getMensagem("page.conta.corrente.consulta.saldo.label.dias.utilizados.ate.a.data"),
					saldo.getQT_DIA_NDIA() == null ? "" : nf.format(saldo.getQT_DIA_NDIA())));
//		}
		componentesJuros.add(new SaldoDeContaCorrenteItemDTO(
				Mensagem.getMensagem("page.conta.corrente.consulta.saldo.label.juros.acumulados.ate.a.data"),
				UtilFunction.convertBigDecimalToStringFormatoBR(saldo.getVL_JUROS() == null ? BigDecimal.ZERO : saldo.getVL_JUROS().abs())));
		componentesJuros.add(new SaldoDeContaCorrenteItemDTO(
				Mensagem.getMensagem("page.conta.corrente.consulta.saldo.label.iof.acumulado.ate.a.data"),
				UtilFunction.convertBigDecimalToStringFormatoBR(saldo.getVL_IOF() == null ? BigDecimal.ZERO : saldo.getVL_IOF().abs())));

		if (cpmf) {
			String[] cpmfInd = { "A", "N" };
			if ("".equals(saldo.getIND_CPMF()) || ArrayUtils.contains(cpmfInd, saldo.getIND_CPMF())) {
				componentesJuros.add(new SaldoDeContaCorrenteItemDTO(
						Mensagem.getMensagem("page.conta.corrente.consulta.saldo.label.cpmf.acumulada"),
						UtilFunction.convertBigDecimalToStringFormatoBR(saldo.getVL_CPMF() == null ? BigDecimal.ZERO : saldo.getVL_CPMF())));
			}
		}
	}

	private void getMovimento() {
		componentesDatas.add(new SaldoDeContaCorrenteItemDTO(
				Mensagem.getMensagem("page.conta.corrente.consulta.saldo.label.ultimo.movimento"),
				saldo.getDT_ULT_MOV() == null ? "" : UtilFunction.dateToString(saldo.getDT_ULT_MOV().toGregorianCalendar().getTime())));
		componentesDatas.add(new SaldoDeContaCorrenteItemDTO(
				Mensagem.getMensagem("page.conta.corrente.consulta.saldo.label.data.para.debito.de.juros"),
				saldo.getDT_DEB_JUROS() == null ? "" : UtilFunction.dateToString(saldo.getDT_DEB_JUROS().toGregorianCalendar().getTime())));
		componentesDatas.add(new SaldoDeContaCorrenteItemDTO(
				Mensagem.getMensagem("page.conta.corrente.consulta.saldo.label.data.para.debito.de.iof"),
				saldo.getDT_DEB_IOF() == null ? "" : UtilFunction.dateToString(saldo.getDT_DEB_IOF().toGregorianCalendar().getTime())));
		if (cpmf) {
			if (saldo.getVL_LIMITE() != null && saldo.getVL_LIMITE().doubleValue() != 0) {
				componentesDatas.add(new SaldoDeContaCorrenteItemDTO(
						Mensagem.getMensagem("page.conta.corrente.consulta.saldo.label.venc") + " "
								+ WordUtils.capitalizeFully(saldo.getOE_SEG_PRIM_LIMITE().trim()),
								saldo.getOE_CHQ_INV_VENC() == null ? "" : UtilFunction.dateToString(saldo.getOE_CHQ_INV_VENC().toGregorianCalendar().getTime())));
			}
		}
	}
	
	private void getChequeEspecial(){
		componentesChequeEspecial.add(new SaldoDeContaCorrenteItemDTO("Vencimento", 
				saldo.getDtVctoCeb() == null ? "" : UtilFunction.dateToString(saldo.getDtVctoCeb().toGregorianCalendar().getTime())));
		componentesChequeEspecial.add(new SaldoDeContaCorrenteItemDTO("Taxa de Juros", 
				saldo.getVlTxJurosMensal() == null ? "" : UtilFunction.convertBigDecimalToStringFormatoBR(saldo.getVlTxJurosMensal()) + "%"));
		componentesChequeEspecial.add(new SaldoDeContaCorrenteItemDTO("Limite", 
				saldo.getVlLimite() == null ? "" : UtilFunction.convertBigDecimalToStringFormatoBR(saldo.getVlLimite())));
		componentesChequeEspecial.add(new SaldoDeContaCorrenteItemDTO("�ltima Utiliza��o", 
				saldo.getOeChqEspUltima() == null ? "" : UtilFunction.dateToString(saldo.getOeChqEspUltima().toGregorianCalendar().getTime())));
		componentesChequeEspecial.add(new SaldoDeContaCorrenteItemDTO("Juros Calculado", "R$" + 
				saldo.getVlJurNaoDeb() == null ? "" : UtilFunction.convertBigDecimalToStringFormatoBR(saldo.getVlJurNaoDeb())));
		componentesChequeEspecial.add(new SaldoDeContaCorrenteItemDTO("Dias utilizados at� a data",
				saldo.getQtDiaNdia() == null ? "" : StringUtil.completarPadding(Boolean.FALSE, saldo.getQtDiaNdia().toString(), "0", 2)));
		componentesChequeEspecial.add(new SaldoDeContaCorrenteItemDTO("Valor Utilizado",
				saldo.getOeChqEspUtilizado() == null ? "" : UtilFunction.convertBigDecimalToStringFormatoBR(saldo.getOeChqEspUtilizado())));
		componentesChequeEspecial.add(new SaldoDeContaCorrenteItemDTO("Dispon�vel",
				saldo.getOeChqEspDisp() == null ? "" : UtilFunction.convertBigDecimalToStringFormatoBR(saldo.getOeChqEspDisp())));
	}

	private String getProxLetra() {
		String letra;
		if ("".equals(letraAtual)) {
			letra = "A";
		} else {
			letra = String.valueOf((char) ((int) letraAtual.charAt(0) + 1));
		}
		letraAtual = letra;
		return letra;
	}

	/**
	 * @return the componentesSaldo
	 */
	public List<SaldoDeContaCorrenteItemDTO> getComponentesSaldo() {
		return componentesSaldo;
	}

	/**
	 * @return the componentesJuros
	 */
	public List<SaldoDeContaCorrenteItemDTO> getComponentesJuros() {
		return componentesJuros;
	}

	/**
	 * @return the componentesDatas
	 */
	public List<SaldoDeContaCorrenteItemDTO> getComponentesDatas() {
		return componentesDatas;
	}
	
	/**
	 * @return the componentesChequeEspecial
	 */
	public List<SaldoDeContaCorrenteItemDTO> getComponentesChequeEspecial() {
		return componentesChequeEspecial;
	}
	

	/**
	 * @return the dataPosicao
	 */
	public Date getDataPosicao() {
		return dataPosicao;
	}
	
	public String getDataPosicaoFormated() {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy '�s' HH'h'mm");
		return sdf.format(dataPosicao);
	}

}
