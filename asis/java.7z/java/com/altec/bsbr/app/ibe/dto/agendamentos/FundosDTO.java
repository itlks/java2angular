package com.altec.bsbr.app.ibe.dto.agendamentos;

public class FundosDTO {

	private String contaCorrenteCredito;
	private String contaCorrenteDebito;
	private String contaDebito;
	private String contaFundoCredito;
	private String contaFundoDebito;
	private String vinculo;
	private String situacaoDoContrato;
	private String codigoDeBarras;
	
	
	
	public String getContaCorrenteCredito() {
		return contaCorrenteCredito;
	}
	public void setContaCorrenteCredito(String contaCorrenteCredito) {
		this.contaCorrenteCredito = contaCorrenteCredito;
	}
	public String getContaCorrenteDebito() {
		return contaCorrenteDebito;
	}
	public void setContaCorrenteDebito(String contaCorrenteDebito) {
		this.contaCorrenteDebito = contaCorrenteDebito;
	}
	public String getContaDebito() {
		return contaDebito;
	}
	public void setContaDebito(String contaDebito) {
		this.contaDebito = contaDebito;
	}
	public String getContaFundoCredito() {
		return contaFundoCredito;
	}
	public void setContaFundoCredito(String contaFundoCredito) {
		this.contaFundoCredito = contaFundoCredito;
	}
	public String getContaFundoDebito() {
		return contaFundoDebito;
	}
	public void setContaFundoDebito(String contaFundoDebito) {
		this.contaFundoDebito = contaFundoDebito;
	}
	public String getVinculo() {
		return vinculo;
	}
	public void setVinculo(String vinculo) {
		this.vinculo = vinculo;
	}
	public String getSituacaoDoContrato() {
		return situacaoDoContrato;
	}
	public void setSituacaoDoContrato(String situacaoDoContrato) {
		this.situacaoDoContrato = situacaoDoContrato;
	}
	public String getCodigoDeBarras() {
		return codigoDeBarras;
	}
	public void setCodigoDeBarras(String codigoDeBarras) {
		this.codigoDeBarras = codigoDeBarras;
	}
	
	
	
	
	
	
	
	
	
	
}
