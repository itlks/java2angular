package com.altec.bsbr.app.ibe.dto;


public class AutorizacoesPendenciaDetalheOnLineDTO {
	
	
	private String nmCedente;
	private String nmSacado;
	private String dtVencimento;
	private String dtSolicitacao;
	private String horaSolicitacao;
	private String valor;
	
	
	

	
	public AutorizacoesPendenciaDetalheOnLineDTO() {
		
//		pendenciasPorData = new ListaPendenciaAutorizacaoDTO();
//		
//		setPeriodoHoje(Calendar.getInstance());
//		setCheckBoxPendencia(Boolean.FALSE);
//		setQuantidadePendenciaSelecionadas(0);
//		setValorTotalPendenciaSelecionadas(BigDecimal.ZERO);
		
		/*setCodUsuarioUltimaAtu("x178130");
		setNomeFavorecidoPendencia("TEST");
		setDescricaoProduto("PRODUCT DESC");
		setImgTransacao("PAGAMENTO ETC...");
		setData("28/07/2016");*/
		
	}
	
	private String codDeBarra;
	/**
	 * @return the codDeBarra
	 */
	public String getCodDeBarra() {
		return codDeBarra;
	}





	/**
	 * @param codDeBarra the codDeBarra to set
	 */
	public void setCodDeBarra(String codDeBarra) {
		this.codDeBarra = codDeBarra;
	}





	/**
	 * @return the nmCedente
	 */
	public String getNmCedente() {
		return nmCedente;
	}





	/**
	 * @param nmCedente the nmCedente to set
	 */
	public void setNmCedente(String nmCedente) {
		this.nmCedente = nmCedente;
	}





	/**
	 * @return the nmSacado
	 */
	public String getNmSacado() {
		return nmSacado;
	}





	/**
	 * @param nmSacado the nmSacado to set
	 */
	public void setNmSacado(String nmSacado) {
		this.nmSacado = nmSacado;
	}





	/**
	 * @return the dtVencimento
	 */
	public String getDtVencimento() {
		return dtVencimento;
	}





	/**
	 * @param dtVencimento the dtVencimento to set
	 */
	public void setDtVencimento(String dtVencimento) {
		this.dtVencimento = dtVencimento;
	}





	/**
	 * @return the dtSolicitacao
	 */
	public String getDtSolicitacao() {
		return dtSolicitacao;
	}





	/**
	 * @param dtSolicitacao the dtSolicitacao to set
	 */
	public void setDtSolicitacao(String dtSolicitacao) {
		this.dtSolicitacao = dtSolicitacao;
	}





	/**
	 * @return the horaSolicitacao
	 */
	public String getHoraSolicitacao() {
		return horaSolicitacao;
	}





	/**
	 * @param horaSolicitacao the horaSolicitacao to set
	 */
	public void setHoraSolicitacao(String horaSolicitacao) {
		this.horaSolicitacao = horaSolicitacao;
	}





	/**
	 * @return the valor
	 */
	public String getValor() {
		return valor;
	}





	/**
	 * @param valor the valor to set
	 */
	public void setValor(String valor) {
		this.valor = valor;
	}





	
	
	

}
