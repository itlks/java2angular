package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.altec.bsbr.app.ibe.dto.agendamentos.AplicacaoCdbDTO;
import com.altec.bsbr.app.ibe.dto.agendamentos.AplicacaoDTO;
import com.altec.bsbr.app.ibe.dto.agendamentos.CartaoCreditoDTO;
import com.altec.bsbr.app.ibe.dto.agendamentos.CelularDTO;
import com.altec.bsbr.app.ibe.dto.agendamentos.ConcessionariaDTO;
import com.altec.bsbr.app.ibe.dto.agendamentos.DocDTO;
import com.altec.bsbr.app.ibe.dto.agendamentos.IpvaDTO;
import com.altec.bsbr.app.ibe.dto.agendamentos.PagueDiretoDTO;
import com.altec.bsbr.app.ibe.dto.agendamentos.TedDTO;
import com.altec.bsbr.app.ibe.dto.agendamentos.TituloDTO;
import com.altec.bsbr.app.ibe.dto.agendamentos.TransferenciaDTO;
import com.altec.bsbr.app.ibe.dto.agendamentos.TributoDTO;
import com.altec.bsbr.app.ibe.enumeration.CanalEnum;
import com.altec.bsbr.app.ibe.enumeration.SituacaoAgendamentoEnum;

public class ConsultarDetalheAgendamentosDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8652807403317214904L;
	private Integer tipoAgendamento;
	private String tituloStr;
	private String transacao;
	private String tipo;
	private String contaDebito;
	private String situacaoContrato;
	private String vinculo;
	private String numeroFrequenciaProgramacao;
	private CanalEnum canal;
	private SituacaoAgendamentoEnum situacaoAgendamento;
	private BigDecimal vlOperacao;
	private Date dataHoraSolicitacao;
	private Date dataAgendada;
	private Date dataHoraExecucao;
	private String descricaoPoupanca;
	private String nomePagina;

	private TransferenciaDTO transferencia = new TransferenciaDTO();
	private AplicacaoDTO aplicacao = new AplicacaoDTO();
	private CartaoCreditoDTO cartaoCredito = new CartaoCreditoDTO();
	private ConcessionariaDTO concessionaria = new ConcessionariaDTO();
	private TributoDTO tributo = new TributoDTO();
	private DocDTO doc = new DocDTO();
	private TedDTO ted = new TedDTO();
	private AplicacaoCdbDTO aplicacaoCDB = new AplicacaoCdbDTO();
	private IpvaDTO ipva = new IpvaDTO();
	private TituloDTO titulo = new TituloDTO();
	private CelularDTO celular = new CelularDTO();
	private PagueDiretoDTO pagueDireto = new PagueDiretoDTO();

	public TransferenciaDTO getTransferencia() {
		return transferencia;
	}

	public void setTransferencia(TransferenciaDTO transferencia) {
		this.transferencia = transferencia;
	}

	public AplicacaoDTO getAplicacao() {
		return aplicacao;
	}

	public void setAplicacao(AplicacaoDTO aplicacao) {
		this.aplicacao = aplicacao;
	}

	public CartaoCreditoDTO getCartaoCredito() {
		return cartaoCredito;
	}

	public void setCartaoCredito(CartaoCreditoDTO cartaoCredito) {
		this.cartaoCredito = cartaoCredito;
	}

	public ConcessionariaDTO getConcessionaria() {
		return concessionaria;
	}

	public void setConcessionaria(ConcessionariaDTO concessionaria) {
		this.concessionaria = concessionaria;
	}

	public TributoDTO getTributo() {
		return tributo;
	}

	public void setTributo(TributoDTO tributo) {
		this.tributo = tributo;
	}

	public DocDTO getDoc() {
		return doc;
	}

	public void setDoc(DocDTO doc) {
		this.doc = doc;
	}

	public TedDTO getTed() {
		return ted;
	}

	public void setTed(TedDTO ted) {
		this.ted = ted;
	}

	public AplicacaoCdbDTO getAplicacaoCDB() {
		return aplicacaoCDB;
	}

	public void setAplicacaoCDB(AplicacaoCdbDTO aplicacaoCDB) {
		this.aplicacaoCDB = aplicacaoCDB;
	}

	public IpvaDTO getIpva() {
		return ipva;
	}

	public void setIpva(IpvaDTO ipva) {
		this.ipva = ipva;
	}

	public TituloDTO getTitulo() {
		return titulo;
	}

	public void setTitulo(TituloDTO titulo) {
		this.titulo = titulo;
	}

	public CelularDTO getCelular() {
		return celular;
	}

	public void setCelular(CelularDTO celular) {
		this.celular = celular;
	}

	public String getContaDebito() {
		return contaDebito;
	}

	public void setContaDebito(String contaDebito) {
		this.contaDebito = contaDebito;
	}

	public String getSituacaoContrato() {
		return situacaoContrato;
	}

	public void setSituacaoContrato(String situacaoContrato) {
		this.situacaoContrato = situacaoContrato;
	}

	public Integer getTipoAgendamento() {
		return tipoAgendamento;
	}

	public void setTipoAgendamento(Integer tipoAgendamento) {
		this.tipoAgendamento = tipoAgendamento;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getTituloStr() {
		return tituloStr;
	}

	public void setTituloStr(String tituloStr) {
		this.tituloStr = tituloStr;
	}

	public String getVinculo() {
		return vinculo;
	}

	public void setVinculo(String vinculo) {
		this.vinculo = vinculo;
	}

	public Date getDataHoraSolicitacao() {
		return dataHoraSolicitacao;
	}

	public void setDataHoraSolicitacao(Date dataHoraSolicitacao) {
		this.dataHoraSolicitacao = dataHoraSolicitacao;
	}

	public Date getDataAgendada() {
		return dataAgendada;
	}

	public void setDataAgendada(Date dataAgendada) {
		this.dataAgendada = dataAgendada;
	}

	public Date getDataHoraExecucao() {
		return dataHoraExecucao;
	}

	public void setDataHoraExecucao(Date dataHoraExecucao) {
		this.dataHoraExecucao = dataHoraExecucao;
	}

	public String getNumeroFrequenciaProgramacao() {
		return numeroFrequenciaProgramacao;
	}

	public void setNumeroFrequenciaProgramacao(String numeroFrequenciaProgramacao) {
		this.numeroFrequenciaProgramacao = numeroFrequenciaProgramacao;
	}

	public CanalEnum getCanal() {
		return canal;
	}

	public void setCanal(CanalEnum canal) {
		this.canal = canal;
	}

	public BigDecimal getVlOperacao() {
		return vlOperacao;
	}

	public void setVlOperacao(BigDecimal vlOperacao) {
		this.vlOperacao = vlOperacao;
	}

	public SituacaoAgendamentoEnum getSituacaoAgendamento() {
		return situacaoAgendamento;
	}

	public void setSituacaoAgendamento(SituacaoAgendamentoEnum situacaoAgendamento) {
		this.situacaoAgendamento = situacaoAgendamento;
	}

	public String getTransacao() {
		return transacao;
	}

	public void setTransacao(String transacao) {
		this.transacao = transacao;
	}

	public String getDescricaoPoupanca() {
		return descricaoPoupanca;
	}

	public void setDescricaoPoupanca(String descricaoPoupanca) {
		this.descricaoPoupanca = descricaoPoupanca;
	}

	public PagueDiretoDTO getPagueDireto() {
		return pagueDireto;
	}

	public void setPagueDireto(PagueDiretoDTO pagueDireto) {
		this.pagueDireto = pagueDireto;
	}

	public String getNomePagina() {
		return nomePagina;
	}

	public void setNomePagina(String nomePagina) {
		this.nomePagina = nomePagina;
	}

}
