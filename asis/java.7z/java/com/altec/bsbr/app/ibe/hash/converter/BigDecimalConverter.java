package com.altec.bsbr.app.ibe.hash.converter;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.Locale;

import com.altec.bsbr.fw.converter.BaseConverter;
import com.altec.bsbr.fw.record.exception.ConverterException;

public class BigDecimalConverter extends  BaseConverter<BigDecimal>{

	public String formatValue(Object arg0) throws ConverterException {
		String s1 = NumberFormat.getCurrencyInstance(new Locale("pt", "BR")).format(arg0);
		//retira o simbolo da moeda
		return s1 = s1.substring(s1.indexOf(" ") + 1);
	}

	public BigDecimal parseValue(String arg0) throws ConverterException {
		return null;
	}

}
