package com.altec.bsbr.app.ibe.dto.agendamentos;

import java.io.Serializable;

public class TedDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2302392683447411260L;
	
	private String tipoRecorrente;
	private String tipoTed;

	// ISPB
	private String numeroBanco;
	private String agencia;
	private String favorecido;
	private String finalidade;
	private String historico;
	private String tipoConta;
	private String conta;

	public String getTipoTed() {
		return tipoTed;
	}

	public void setTipoTed(String tipoTed) {
		this.tipoTed = tipoTed;
	}

	public String getNumeroBanco() {
		return numeroBanco;
	}

	public void setNumeroBanco(String numeroBanco) {
		this.numeroBanco = numeroBanco;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getFavorecido() {
		return favorecido;
	}

	public void setFavorecido(String favorecido) {
		this.favorecido = favorecido;
	}

	public String getFinalidade() {
		return finalidade;
	}

	public void setFinalidade(String finalidade) {
		this.finalidade = finalidade;
	}

	public String getHistorico() {
		return historico;
	}

	public void setHistorico(String historico) {
		this.historico = historico;
	}
	
	public String getTipoConta() {
		return tipoConta;
	}

	public void setTipoConta(String tipoConta) {
		this.tipoConta = tipoConta;
	}

	public String getTipoRecorrente() {
		return tipoRecorrente;
	}

	public void setTipoRecorrente(String tipoRecorrente) {
		this.tipoRecorrente = tipoRecorrente;
	}

	public String getConta() {
		return conta;
	}

	public void setConta(String conta) {
		this.conta = conta;
	}

}
