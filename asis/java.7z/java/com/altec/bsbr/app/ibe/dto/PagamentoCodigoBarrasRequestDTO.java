package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.Date;

public class PagamentoCodigoBarrasRequestDTO  implements Serializable {

	private static final long serialVersionUID = -2325607825793469332L;
	
	private String codBarras;
	private static final String INDICATIVOlECTURAdITALIZACION = "1";
	private Date dataPagamento;
	private String banco;
	private String agencia;
	private String conta;
	
	private String formaPagamento;
	private String dataAgendamento;
	private String horaAgendamento;
	private String valorPrincipal;
	private String valorAPagar;
	private String nomeConvenio;
	private String clienteConsumidor;
	
	private String codigoProduto;
	private String codigoSubProduto;
	private String strtextoDestaque;
	private String textoSecNivel;
	private String strTextoComum;
	private String strPasso;
	private String referOper;
	
	public String getCodBarras() {
		return codBarras;
	}
	public void setCodBarras(String codBarras) {
		this.codBarras = codBarras;
	}
	public static String getIndicativolecturadigitalizacion() {
		return INDICATIVOlECTURAdITALIZACION;
	}
	public Date getDataPagamento() {
		return dataPagamento;
	}
	public void setDataPagamento(Date dataPagamento) {
		this.dataPagamento = dataPagamento;
	}
	public String getBanco() {
		return banco;
	}
	public void setBanco(String banco) {
		this.banco = banco;
	}
	public String getAgencia() {
		return agencia;
	}
	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}
	public String getConta() {
		return conta;
	}
	public void setConta(String conta) {
		this.conta = conta;
	}
	public String getFormaPagamento() {
		return formaPagamento;
	}
	public void setFormaPagamento(String formaPagamento) {
		this.formaPagamento = formaPagamento;
	}
	public String getDataAgendamento() {
		return dataAgendamento;
	}
	public void setDataAgendamento(String dataAgendamento) {
		this.dataAgendamento = dataAgendamento;
	}
	public String getHoraAgendamento() {
		return horaAgendamento;
	}
	public void setHoraAgendamento(String horaAgendamento) {
		this.horaAgendamento = horaAgendamento;
	}
	public String getValorPrincipal() {
		return valorPrincipal;
	}
	public void setValorPrincipal(String valorPrincipal) {
		this.valorPrincipal = valorPrincipal;
	}
	public String getValorAPagar() {
		return valorAPagar;
	}
	public void setValorAPagar(String valorAPagar) {
		this.valorAPagar = valorAPagar;
	}
	public String getNomeConvenio() {
		return nomeConvenio;
	}
	public void setNomeConvenio(String nomeConvenio) {
		this.nomeConvenio = nomeConvenio;
	}
	public String getCodigoProduto() {
		return codigoProduto;
	}
	public void setCodigoProduto(String codigoProduto) {
		this.codigoProduto = codigoProduto;
	}
	public String getCodigoSubProduto() {
		return codigoSubProduto;
	}
	public void setCodigoSubProduto(String codigoSubProduto) {
		this.codigoSubProduto = codigoSubProduto;
	}
	public String getStrtextoDestaque() {
		return strtextoDestaque;
	}
	public void setStrtextoDestaque(String strtextoDestaque) {
		this.strtextoDestaque = strtextoDestaque;
	}
	public String getTextoSecNivel() {
		return textoSecNivel;
	}
	public void setTextoSecNivel(String textoSecNivel) {
		this.textoSecNivel = textoSecNivel;
	}
	public String getStrTextoComum() {
		return strTextoComum;
	}
	public void setStrTextoComum(String strTextoComum) {
		this.strTextoComum = strTextoComum;
	}
	public String getStrPasso() {
		return strPasso;
	}
	public void setStrPasso(String strPasso) {
		this.strPasso = strPasso;
	}
	public String getClienteConsumidor() {
		return clienteConsumidor;
	}
	public void setClienteConsumidor(String clienteConsumidor) {
		this.clienteConsumidor = clienteConsumidor;
	}
	public String getReferOper() {
		return referOper;
	}
	public void setReferOper(String referOper) {
		this.referOper = referOper;
	}
	
}
