package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;

import com.altec.bsbr.app.ibe.dto.clsrecebiveisantec.ListaPLConsultaFluxoCartoesRSDTO;

public class ListaPLConsultaFluxoCartoesDTO implements Serializable {

	private static final long serialVersionUID = 6670232995844814195L;
	/**
	 * Atributos
	 */
	private ListaPLConsultaFluxoCartoesRSDTO listaPLConsultaFluxoCartoesRSDTO;
	private String dtTitulo;
	private BigDecimal vlTitulo;
	private BigDecimal vlTituloOrig;
	private String indBandeira;
	
	/**
	 * Getters e Setters respectivos
	 */
	
	public ListaPLConsultaFluxoCartoesRSDTO getListaPLConsultaFluxoCartoesRSDTO() {
		return listaPLConsultaFluxoCartoesRSDTO;
	}
	public void setListaPLConsultaFluxoCartoesRSDTO(ListaPLConsultaFluxoCartoesRSDTO listaPLConsultaFluxoCartoesRSDTO) {
		this.listaPLConsultaFluxoCartoesRSDTO = listaPLConsultaFluxoCartoesRSDTO;
	}
	public String getDtTitulo() {
		return dtTitulo;
	}
	public void setDtTitulo(String dtTitulo) {
		this.dtTitulo = dtTitulo;
	}
	public BigDecimal getVlTitulo() {
		return vlTitulo;
	}
	public void setVlTitulo(BigDecimal vlTitulo) {
		this.vlTitulo = vlTitulo;
	}
	public BigDecimal getVlTituloOrig() {
		return vlTituloOrig;
	}
	public void setVlTituloOrig(BigDecimal vlTituloOrig) {
		this.vlTituloOrig = vlTituloOrig;
	}
	public String getIndBandeira() {
		return indBandeira;
	}
	public void setIndBandeira(String indBandeira) {
		this.indBandeira = indBandeira;
	}

}
