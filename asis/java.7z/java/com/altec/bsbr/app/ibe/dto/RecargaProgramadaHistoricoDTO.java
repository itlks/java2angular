package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class RecargaProgramadaHistoricoDTO implements Serializable {
		
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private List<ItemRecargaProgramadaHistoricoDTO> listaRecargaProgramada;
	private List<ItemRecargaProgramadaHistoricoDTO> listaRecargaProgramadaSelecionada;
		
	public RecargaProgramadaHistoricoDTO() {
	
		listaRecargaProgramada =  new ArrayList<ItemRecargaProgramadaHistoricoDTO>();
		listaRecargaProgramadaSelecionada = new ArrayList<ItemRecargaProgramadaHistoricoDTO>();
	}

	/**
	 * @return the listaRecargaProgramadaSelecionada
	 */
	public List<ItemRecargaProgramadaHistoricoDTO> getListaRecargaProgramadaSelecionada() {
		return listaRecargaProgramadaSelecionada;
	}

	/**
	 * @param listaRecargaProgramadaSelecionada the listaRecargaProgramadaSelecionada to set
	 */
	public void setListaRecargaProgramadaSelecionada(
			List<ItemRecargaProgramadaHistoricoDTO> listaRecargaProgramadaSelecionada) {
		this.listaRecargaProgramadaSelecionada = listaRecargaProgramadaSelecionada;
	}

	public List<ItemRecargaProgramadaHistoricoDTO> getListaRecargaProgramada() {
		return listaRecargaProgramada;
	}

	public void setListaRecargaProgramada(List<ItemRecargaProgramadaHistoricoDTO> listaRecargaProgramada) {
		this.listaRecargaProgramada = listaRecargaProgramada;
	}
	

}
