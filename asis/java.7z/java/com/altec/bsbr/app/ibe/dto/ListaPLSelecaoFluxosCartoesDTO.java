package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;

import com.altec.bsbr.app.ibe.dto.clsrecebiveisantec.ListaPLSelecaoFluxosCartoesRSDTO;

public class ListaPLSelecaoFluxosCartoesDTO implements Serializable {
	
	private static final long serialVersionUID = 5648655453025570968L;
	/**
	 * Atributos
	 */
	private ListaPLSelecaoFluxosCartoesRSDTO listaPLSelecaoFluxosCartoesRSDTO;
	private String dtTitulo;
	private BigDecimal vlTitulo;
	private BigDecimal vlTituloOrig;
	private String indBandeira;
	private String ecVenda;

	/**
	 * Getters e Setters respectivos
	 */
	public ListaPLSelecaoFluxosCartoesRSDTO getListaPLSelecaoFluxosCartoesRSDTO() {
		return listaPLSelecaoFluxosCartoesRSDTO;
	}
	public void setListaPLSelecaoFluxosCartoesRSDTO(ListaPLSelecaoFluxosCartoesRSDTO listaPLSelecaoFluxosCartoesRSDTO) {
		this.listaPLSelecaoFluxosCartoesRSDTO = listaPLSelecaoFluxosCartoesRSDTO;
	}
	public String getDtTitulo() {
		return dtTitulo;
	}
	public void setDtTitulo(String dtTitulo) {
		this.dtTitulo = dtTitulo;
	}
	public BigDecimal getVlTitulo() {
		return vlTitulo;
	}
	public void setVlTitulo(BigDecimal vlTitulo) {
		this.vlTitulo = vlTitulo;
	}
	public BigDecimal getVlTituloOrig() {
		return vlTituloOrig;
	}
	public void setVlTituloOrig(BigDecimal vlTituloOrig) {
		this.vlTituloOrig = vlTituloOrig;
	}
	public String getIndBandeira() {
		return indBandeira;
	}
	public void setIndBandeira(String indBandeira) {
		this.indBandeira = indBandeira;
	}
	public String getEcVenda() {
		return ecVenda;
	}
	public void setEcVenda(String ecVenda) {
		this.ecVenda = ecVenda;
	}

}
