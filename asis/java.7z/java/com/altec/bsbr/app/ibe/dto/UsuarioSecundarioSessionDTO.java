package com.altec.bsbr.app.ibe.dto;

public class UsuarioSecundarioSessionDTO {

	private String codigoUsuario;
	private Integer numeroTransacao;

	public Integer getNumeroTransacao() {
		return numeroTransacao;
	}

	public void setNumeroTransacao(Integer numeroTransacao) {
		this.numeroTransacao = numeroTransacao;
	}

	public String getCodigoUsuario() {
		return codigoUsuario;
	}

	public void setCodigoUsuario(String codigoUsuario) {
		this.codigoUsuario = codigoUsuario;
	}
	
	
	
}
