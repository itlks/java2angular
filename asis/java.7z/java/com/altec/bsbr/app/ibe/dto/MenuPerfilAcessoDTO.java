package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;



public class MenuPerfilAcessoDTO implements Serializable {

	private static final long serialVersionUID = -2408064392055505967L;
	private String nomeItemMenuPai;
	private Integer idItemMenuPrin;
	private List<MenuDTO> listaMenuItemCol1 = new ArrayList<MenuDTO>();
	private List<MenuDTO> listaMenuItemCol2 = new ArrayList<MenuDTO>();
	private List<MenuDTO> listaMenuItemCol3 = new ArrayList<MenuDTO>();

	public MenuPerfilAcessoDTO() {
		super();
	}

	public List<MenuDTO> getListaMenuItemCol1() {
		return listaMenuItemCol1;
	}

	public void setListaMenuItemCol1(List<MenuDTO> listaMenuItemCol1) {
		this.listaMenuItemCol1 = listaMenuItemCol1;
	}

	public List<MenuDTO> getListaMenuItemCol2() {
		return listaMenuItemCol2;
	}

	public void setListaMenuItemCol2(List<MenuDTO> listaMenuItemCol2) {
		this.listaMenuItemCol2 = listaMenuItemCol2;
	}

	public List<MenuDTO> getListaMenuItemCol3() {
		return listaMenuItemCol3;
	}

	public void setListaMenuItemCol3(List<MenuDTO> listaMenuItemCol3) {
		this.listaMenuItemCol3 = listaMenuItemCol3;
	}

	public String getNomeItemMenuPai() {
		return nomeItemMenuPai;
	}

	public void setNomeItemMenuPai(String nomeItemMenuPai) {
		this.nomeItemMenuPai = nomeItemMenuPai;
	}

	public Integer getIdItemMenuPrin() {
		return idItemMenuPrin;
	}

	public void setIdItemMenuPrin(Integer idItemMenuPrin) {
		this.idItemMenuPrin = idItemMenuPrin;
	}
	

}
