package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class ContaDocDTO implements Serializable {

	

	/**
	 * 
	 */
	private static final long serialVersionUID = -6021361799033516238L;
	
	private java.lang.String OECHAVEAMARRACAO;
	private java.lang.String OEDTACONTAB;
	private java.lang.String OECPFCNPJTITULAR1;
	private java.lang.String OENOMETITULAR1;
	private java.lang.String OENOMETITULAR2;
	private java.lang.String OETIPOCCORIGEM;
	private java.lang.String OEBANCODESTINO;
	private java.lang.String OEAGENCIADESTINO;
	private java.lang.String OEDIGITOAGENCIADESTINO;
	private java.lang.String OECONTACORRENTEDESTINO;
	private java.lang.String OEDIGITOCTACORDESTINO;
	private java.lang.String OEVALORREMESSA;
	private java.lang.String OEVALORTARIFA;
	private java.lang.String OENOMEFAVORECIDO;
	private java.lang.String OECPFCNPJFAVORECIDO;
	private java.lang.String OETIPOCCDESTINO;
	private java.lang.String OEFINALIDADE;
	private java.lang.String OECOMPLFINALIDADE;
	private java.lang.String OETIPODOC;
	private java.lang.String OETPOCPFCNPJTIT1;
	private java.lang.String OENOMEFAVORECIDO2;
	private java.lang.String OECPFCNPJTITULAR2;
	private java.lang.String OETPOCPFCNPJFAV;
	private java.lang.String OEDATAAGENDAMENTO;
	private java.lang.String OEHORAAGENDAMENTO;
	private java.lang.String OERECORRENCIA;
	private java.lang.String OEQTDRECORRENCIA;
	private java.lang.String OEINDAGENDAMENTO;
	private java.lang.String OEDATARECIBO;
	private java.lang.String OEHORARECIBO;
	private java.lang.String OECTRLCHVAMARRACAO;
	private java.lang.String OECADASTROCONTA;
	private java.lang.String OENOMEBANCODESTINO;
	private java.lang.String OENUMERODOC;
	private java.lang.String OESITTOKEN;
	private java.lang.String OEPENUMPER;
	private java.lang.String OEINDCLIENTE;
	private java.lang.String OEINDTOKEN;
	private java.lang.String OENUMTOKEN;
	private java.lang.String OEIDSESSAO;
	private java.lang.String OEDISCRIMANTELYNX;
	private java.lang.String OECODRETLYNX;
	private java.lang.String OEINDTOKENSESSAO;
	private java.lang.String OENUMDDDLIGACAO;
	private java.lang.String OENUMTELLIGACAO;
	private String nomeOrigem;
	private String nomeDestino;
	private String tipoDocumento;
	private String documentoFormatado;
	private String agenciaOrigemFormatada;
	private String contaOrigemFormatada;
	private String bancoDestinoFormatado;
	private String agenciaDestinoFormatada;
	private String contaDestinoFormatada;
	
	public java.lang.String getOECHAVEAMARRACAO() {
		return OECHAVEAMARRACAO;
	}
	public void setOECHAVEAMARRACAO(java.lang.String oECHAVEAMARRACAO) {
		OECHAVEAMARRACAO = oECHAVEAMARRACAO;
	}
	public java.lang.String getOEDTACONTAB() {
		return OEDTACONTAB;
	}
	public void setOEDTACONTAB(java.lang.String oEDTACONTAB) {
		OEDTACONTAB = oEDTACONTAB;
	}
	public java.lang.String getOECPFCNPJTITULAR1() {
		return OECPFCNPJTITULAR1;
	}
	public void setOECPFCNPJTITULAR1(java.lang.String oECPFCNPJTITULAR1) {
		OECPFCNPJTITULAR1 = oECPFCNPJTITULAR1;
	}
	public java.lang.String getOENOMETITULAR1() {
		return OENOMETITULAR1;
	}
	public void setOENOMETITULAR1(java.lang.String oENOMETITULAR1) {
		OENOMETITULAR1 = oENOMETITULAR1;
	}
	public java.lang.String getOENOMETITULAR2() {
		return OENOMETITULAR2;
	}
	public void setOENOMETITULAR2(java.lang.String oENOMETITULAR2) {
		OENOMETITULAR2 = oENOMETITULAR2;
	}
	public java.lang.String getOETIPOCCORIGEM() {
		return OETIPOCCORIGEM;
	}
	public void setOETIPOCCORIGEM(java.lang.String oETIPOCCORIGEM) {
		OETIPOCCORIGEM = oETIPOCCORIGEM;
	}
	public java.lang.String getOEBANCODESTINO() {
		return OEBANCODESTINO;
	}
	public void setOEBANCODESTINO(java.lang.String oEBANCODESTINO) {
		OEBANCODESTINO = oEBANCODESTINO;
	}
	public java.lang.String getOEAGENCIADESTINO() {
		return OEAGENCIADESTINO;
	}
	public void setOEAGENCIADESTINO(java.lang.String oEAGENCIADESTINO) {
		OEAGENCIADESTINO = oEAGENCIADESTINO;
	}
	public java.lang.String getOEDIGITOAGENCIADESTINO() {
		return OEDIGITOAGENCIADESTINO;
	}
	public void setOEDIGITOAGENCIADESTINO(java.lang.String oEDIGITOAGENCIADESTINO) {
		OEDIGITOAGENCIADESTINO = oEDIGITOAGENCIADESTINO;
	}
	public java.lang.String getOECONTACORRENTEDESTINO() {
		return OECONTACORRENTEDESTINO;
	}
	public void setOECONTACORRENTEDESTINO(java.lang.String oECONTACORRENTEDESTINO) {
		OECONTACORRENTEDESTINO = oECONTACORRENTEDESTINO;
	}
	public java.lang.String getOEDIGITOCTACORDESTINO() {
		return OEDIGITOCTACORDESTINO;
	}
	public void setOEDIGITOCTACORDESTINO(java.lang.String oEDIGITOCTACORDESTINO) {
		OEDIGITOCTACORDESTINO = oEDIGITOCTACORDESTINO;
	}
	public java.lang.String getOEVALORREMESSA() {
		return OEVALORREMESSA;
	}
	public void setOEVALORREMESSA(java.lang.String oEVALORREMESSA) {
		OEVALORREMESSA = oEVALORREMESSA;
	}
	public java.lang.String getOEVALORTARIFA() {
		return OEVALORTARIFA;
	}
	public void setOEVALORTARIFA(java.lang.String oEVALORTARIFA) {
		OEVALORTARIFA = oEVALORTARIFA;
	}
	public java.lang.String getOENOMEFAVORECIDO() {
		return OENOMEFAVORECIDO;
	}
	public void setOENOMEFAVORECIDO(java.lang.String oENOMEFAVORECIDO) {
		OENOMEFAVORECIDO = oENOMEFAVORECIDO;
	}
	public java.lang.String getOECPFCNPJFAVORECIDO() {
		return OECPFCNPJFAVORECIDO;
	}
	public void setOECPFCNPJFAVORECIDO(java.lang.String oECPFCNPJFAVORECIDO) {
		OECPFCNPJFAVORECIDO = oECPFCNPJFAVORECIDO;
	}
	public java.lang.String getOETIPOCCDESTINO() {
		return OETIPOCCDESTINO;
	}
	public void setOETIPOCCDESTINO(java.lang.String oETIPOCCDESTINO) {
		OETIPOCCDESTINO = oETIPOCCDESTINO;
	}
	public java.lang.String getOEFINALIDADE() {
		return OEFINALIDADE;
	}
	public void setOEFINALIDADE(java.lang.String oEFINALIDADE) {
		OEFINALIDADE = oEFINALIDADE;
	}
	public java.lang.String getOECOMPLFINALIDADE() {
		return OECOMPLFINALIDADE;
	}
	public void setOECOMPLFINALIDADE(java.lang.String oECOMPLFINALIDADE) {
		OECOMPLFINALIDADE = oECOMPLFINALIDADE;
	}
	public java.lang.String getOETIPODOC() {
		return OETIPODOC;
	}
	public void setOETIPODOC(java.lang.String oETIPODOC) {
		OETIPODOC = oETIPODOC;
	}
	public java.lang.String getOETPOCPFCNPJTIT1() {
		return OETPOCPFCNPJTIT1;
	}
	public void setOETPOCPFCNPJTIT1(java.lang.String oETPOCPFCNPJTIT1) {
		OETPOCPFCNPJTIT1 = oETPOCPFCNPJTIT1;
	}
	public java.lang.String getOENOMEFAVORECIDO2() {
		return OENOMEFAVORECIDO2;
	}
	public void setOENOMEFAVORECIDO2(java.lang.String oENOMEFAVORECIDO2) {
		OENOMEFAVORECIDO2 = oENOMEFAVORECIDO2;
	}
	public java.lang.String getOECPFCNPJTITULAR2() {
		return OECPFCNPJTITULAR2;
	}
	public void setOECPFCNPJTITULAR2(java.lang.String oECPFCNPJTITULAR2) {
		OECPFCNPJTITULAR2 = oECPFCNPJTITULAR2;
	}
	public java.lang.String getOETPOCPFCNPJFAV() {
		return OETPOCPFCNPJFAV;
	}
	public void setOETPOCPFCNPJFAV(java.lang.String oETPOCPFCNPJFAV) {
		OETPOCPFCNPJFAV = oETPOCPFCNPJFAV;
	}
	public java.lang.String getOEDATAAGENDAMENTO() {
		return OEDATAAGENDAMENTO;
	}
	public void setOEDATAAGENDAMENTO(java.lang.String oEDATAAGENDAMENTO) {
		OEDATAAGENDAMENTO = oEDATAAGENDAMENTO;
	}
	public java.lang.String getOEHORAAGENDAMENTO() {
		return OEHORAAGENDAMENTO;
	}
	public void setOEHORAAGENDAMENTO(java.lang.String oEHORAAGENDAMENTO) {
		OEHORAAGENDAMENTO = oEHORAAGENDAMENTO;
	}
	public java.lang.String getOERECORRENCIA() {
		return OERECORRENCIA;
	}
	public void setOERECORRENCIA(java.lang.String oERECORRENCIA) {
		OERECORRENCIA = oERECORRENCIA;
	}
	public java.lang.String getOEQTDRECORRENCIA() {
		return OEQTDRECORRENCIA;
	}
	public void setOEQTDRECORRENCIA(java.lang.String oEQTDRECORRENCIA) {
		OEQTDRECORRENCIA = oEQTDRECORRENCIA;
	}
	public java.lang.String getOEINDAGENDAMENTO() {
		return OEINDAGENDAMENTO;
	}
	public void setOEINDAGENDAMENTO(java.lang.String oEINDAGENDAMENTO) {
		OEINDAGENDAMENTO = oEINDAGENDAMENTO;
	}
	public java.lang.String getOEDATARECIBO() {
		return OEDATARECIBO;
	}
	public void setOEDATARECIBO(java.lang.String oEDATARECIBO) {
		OEDATARECIBO = oEDATARECIBO;
	}
	public java.lang.String getOEHORARECIBO() {
		return OEHORARECIBO;
	}
	public void setOEHORARECIBO(java.lang.String oEHORARECIBO) {
		OEHORARECIBO = oEHORARECIBO;
	}
	public java.lang.String getOECTRLCHVAMARRACAO() {
		return OECTRLCHVAMARRACAO;
	}
	public void setOECTRLCHVAMARRACAO(java.lang.String oECTRLCHVAMARRACAO) {
		OECTRLCHVAMARRACAO = oECTRLCHVAMARRACAO;
	}
	public java.lang.String getOECADASTROCONTA() {
		return OECADASTROCONTA;
	}
	public void setOECADASTROCONTA(java.lang.String oECADASTROCONTA) {
		OECADASTROCONTA = oECADASTROCONTA;
	}
	public java.lang.String getOENOMEBANCODESTINO() {
		return OENOMEBANCODESTINO;
	}
	public void setOENOMEBANCODESTINO(java.lang.String oENOMEBANCODESTINO) {
		OENOMEBANCODESTINO = oENOMEBANCODESTINO;
	}
	public java.lang.String getOENUMERODOC() {
		return OENUMERODOC;
	}
	public void setOENUMERODOC(java.lang.String oENUMERODOC) {
		OENUMERODOC = oENUMERODOC;
	}
	public java.lang.String getOESITTOKEN() {
		return OESITTOKEN;
	}
	public void setOESITTOKEN(java.lang.String oESITTOKEN) {
		OESITTOKEN = oESITTOKEN;
	}
	public java.lang.String getOEPENUMPER() {
		return OEPENUMPER;
	}
	public void setOEPENUMPER(java.lang.String oEPENUMPER) {
		OEPENUMPER = oEPENUMPER;
	}
	public java.lang.String getOEINDCLIENTE() {
		return OEINDCLIENTE;
	}
	public void setOEINDCLIENTE(java.lang.String oEINDCLIENTE) {
		OEINDCLIENTE = oEINDCLIENTE;
	}
	public java.lang.String getOEINDTOKEN() {
		return OEINDTOKEN;
	}
	public void setOEINDTOKEN(java.lang.String oEINDTOKEN) {
		OEINDTOKEN = oEINDTOKEN;
	}
	public java.lang.String getOENUMTOKEN() {
		return OENUMTOKEN;
	}
	public void setOENUMTOKEN(java.lang.String oENUMTOKEN) {
		OENUMTOKEN = oENUMTOKEN;
	}
	public java.lang.String getOEIDSESSAO() {
		return OEIDSESSAO;
	}
	public void setOEIDSESSAO(java.lang.String oEIDSESSAO) {
		OEIDSESSAO = oEIDSESSAO;
	}
	public java.lang.String getOEDISCRIMANTELYNX() {
		return OEDISCRIMANTELYNX;
	}
	public void setOEDISCRIMANTELYNX(java.lang.String oEDISCRIMANTELYNX) {
		OEDISCRIMANTELYNX = oEDISCRIMANTELYNX;
	}
	public java.lang.String getOECODRETLYNX() {
		return OECODRETLYNX;
	}
	public void setOECODRETLYNX(java.lang.String oECODRETLYNX) {
		OECODRETLYNX = oECODRETLYNX;
	}
	public java.lang.String getOEINDTOKENSESSAO() {
		return OEINDTOKENSESSAO;
	}
	public void setOEINDTOKENSESSAO(java.lang.String oEINDTOKENSESSAO) {
		OEINDTOKENSESSAO = oEINDTOKENSESSAO;
	}
	public java.lang.String getOENUMDDDLIGACAO() {
		return OENUMDDDLIGACAO;
	}
	public void setOENUMDDDLIGACAO(java.lang.String oENUMDDDLIGACAO) {
		OENUMDDDLIGACAO = oENUMDDDLIGACAO;
	}
	public java.lang.String getOENUMTELLIGACAO() {
		return OENUMTELLIGACAO;
	}
	public void setOENUMTELLIGACAO(java.lang.String oENUMTELLIGACAO) {
		OENUMTELLIGACAO = oENUMTELLIGACAO;
	}
	public String getNomeOrigem() {
		return nomeOrigem;
	}
	public void setNomeOrigem(String nomeOrigem) {
		this.nomeOrigem = nomeOrigem;
	}
	public String getAgenciaOrigemFormatada() {
		return agenciaOrigemFormatada;
	}
	public void setAgenciaOrigemFormatada(String agenciaOrigemFormatada) {
		this.agenciaOrigemFormatada = agenciaOrigemFormatada;
	}
	public String getContaOrigemFormatada() {
		return contaOrigemFormatada;
	}
	public void setContaOrigemFormatada(String contaOrigemFormatada) {
		this.contaOrigemFormatada = contaOrigemFormatada;
	}
	public String getBancoDestinoFormatado() {
		return bancoDestinoFormatado;
	}
	public void setBancoDestinoFormatado(String bancoDestinoFormatado) {
		this.bancoDestinoFormatado = bancoDestinoFormatado;
	}
	public String getAgenciaDestinoFormatada() {
		return agenciaDestinoFormatada;
	}
	public void setAgenciaDestinoFormatada(String agenciaDestinoFormatada) {
		this.agenciaDestinoFormatada = agenciaDestinoFormatada;
	}
	public String getContaDestinoFormatada() {
		return contaDestinoFormatada;
	}
	public void setContaDestinoFormatada(String contaDestinoFormatada) {
		this.contaDestinoFormatada = contaDestinoFormatada;
	}
	public String getNomeDestino() {
		return nomeDestino;
	}
	public void setNomeDestino(String nomeDestino) {
		this.nomeDestino = nomeDestino;
	}
	public String getTipoDocumento() {
		return tipoDocumento;
	}
	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}
	public String getDocumentoFormatado() {
		return documentoFormatado;
	}
	public void setDocumentoFormatado(String documentoFormatado) {
		this.documentoFormatado = documentoFormatado;
	}
}
