package com.altec.bsbr.app.ibe.dto;

import java.util.Date;

import com.altec.bsbr.app.ibe.dto.debitoautomatico.consultListaCadastro.ConsultaListaCadastroSuspensaoTemporariaItemDTO;
import com.altec.bsbr.app.ibe.dto.debitoautomatico.empresaConveniadaSuspensaoTemporaria.EmpresaConveniadaSuspensaoTemporariaDTO;
import com.altec.bsbr.app.ibe.enumeration.DebitoAutomaticoTipoContaEnum;
import com.altec.bsbr.app.ibe.web.util.ConverterUtil;

public class DebitoAutomaticoSuspensaoIncluirDTO {

	private DebitoAutomaticoTipoContaEnum tipoConta;
	private EmpresaConveniadaSuspensaoTemporariaDTO empresaConveniada;
	private ConsultaListaCadastroSuspensaoTemporariaItemDTO debito;
	private Date inicioSuspensao;
	private Date terminoSuspensao;
	private Date dataHoraTransacao;
	private String autenticacaoBancaria;
	private String codigoNSU;

	public DebitoAutomaticoTipoContaEnum getTipoConta() {
		return tipoConta;
	}

	public void setTipoConta(DebitoAutomaticoTipoContaEnum tipoConta) {
		this.tipoConta = tipoConta;
	}

	public EmpresaConveniadaSuspensaoTemporariaDTO getEmpresaConveniada() {
		return empresaConveniada;
	}

	public void setEmpresaConveniada(EmpresaConveniadaSuspensaoTemporariaDTO empresaConveniada) {
		this.empresaConveniada = empresaConveniada;
	}

	public Date getInicioSuspensao() {
		return inicioSuspensao;
	}

	public void setInicioSuspensao(Date inicioSuspensao) {
		this.inicioSuspensao = inicioSuspensao;
	}

	public Date getTerminoSuspensao() {
		return terminoSuspensao;
	}

	public void setTerminoSuspensao(Date terminoSuspensao) {
		this.terminoSuspensao = terminoSuspensao;
	}

	public ConsultaListaCadastroSuspensaoTemporariaItemDTO getDebito() {
		return debito;
	}

	public void setDebito(ConsultaListaCadastroSuspensaoTemporariaItemDTO debito) {
		this.debito = debito;
	}

	public Date getDataHoraTransacao() {
		return dataHoraTransacao;
	}

	public void setDataHoraTransacao(Date dataHoraTransacao) {
		this.dataHoraTransacao = dataHoraTransacao;
	}

	public String getAutenticacaoBancaria() {
		return autenticacaoBancaria;
	}

	public void setAutenticacaoBancaria(String autenticacaoBancaria) {
		this.autenticacaoBancaria = autenticacaoBancaria;
	}

	public String getDataHoraTransacaoFormatada() {
		return ConverterUtil.dateToString(getDataHoraTransacao(), "dd/MM/yyyy - HH:mm:ss");
	}

	public String getCodigoNSU() {
		return codigoNSU;
	}

	public void setCodigoNSU(String codigoNSU) {
		this.codigoNSU = codigoNSU;
	}

}
