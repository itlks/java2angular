package com.altec.bsbr.app.ibe.dto.home;

import com.altec.bsbr.app.ibe.dto.conveniospj.ListaObterConveniosPersonasRSDTO;
import com.altec.bsbr.app.ibe.enumeration.PainelHomeEnum;

public class PainelAcessoPEContingenciaDTO {
	ListaObterConveniosPersonasRSDTO retornoInvestimento;
	PainelHomeEnum painelEscolhido;
	boolean duplicado;
	String codigoCedente;
	
	public PainelAcessoPEContingenciaDTO(ListaObterConveniosPersonasRSDTO retornoInvestimento,PainelHomeEnum painelEscolhido) {
		super();
	
		this.retornoInvestimento = retornoInvestimento;
		this.painelEscolhido = painelEscolhido;
		this.duplicado=false;
	}

	public ListaObterConveniosPersonasRSDTO getRetornoInvestimento() {
		return retornoInvestimento;
	}

	public void setRetornoInvestimento(ListaObterConveniosPersonasRSDTO retornoInvestimento) {
		this.retornoInvestimento = retornoInvestimento;
	}
	public PainelHomeEnum getPainelEscolhido() {
		return painelEscolhido;
	}
	public void setPainelEscolhido(PainelHomeEnum painelEscolhido) {
		this.painelEscolhido = painelEscolhido;
	}
	public boolean isDuplicado() {
		return duplicado;
	}

	public void setDuplicado(boolean duplicado) {
		this.duplicado = duplicado;
	}

	public String getCodigoCedente() {
		return retornoInvestimento.getTSOECONTRATO().substring(4, 11);
	}

	public void setCodigoCedente(String codigoCedente) {
		this.codigoCedente = codigoCedente;
	}
	
	
}
