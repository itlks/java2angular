package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.text.ParseException;

import javax.swing.text.MaskFormatter;

import com.altec.bsbr.app.ibe.anotation.Hash;
import com.altec.bsbr.app.ibe.message.Mensagem;


@SuppressWarnings("unused")
public class GareSPDTO implements Serializable {

	private static final long serialVersionUID = 8150343169429694821L;

	private String ufFavorecida = Mensagem.getMensagem("page.gare.conteudo.ufFavorecida");

	private String dataVencimento;
	@Hash(position = 1)
	private String codigoReceita;
	@Hash(position = 2)
	private String inscricaoEstadual;

	private boolean pendencias;

	public boolean isPendencias() {
		return pendencias;
	}

	public void setPendencias(boolean pendencias) {
		this.pendencias = pendencias;
	}

	private String chaveNSU;
	@Hash(position = 3)
	private String cpfCnpj;

	@Hash(position = 4)
	private String inscricaoDivida;

	private String referencia;
	@Hash(position = 5)
	private String numeroAIIM;

	private String valorReceita;

	private String jurosMora;

	private String multaMora;

	private String honorariosAdvocaticios;

	@Hash(position = 6)
	private String valorTotal;

	@Hash(position = 7)
	private String nomeOuRazaoSocial;

	private String endereco;

	private String municipio;

	private String uf = "SP";

	private String telefone;

	private String tributoReceita;

	private String cnae;

	private String observacoes;

	private String apelido;

	private String placaVeiculo;

	private String assinaturaEletronica;

	private String numeroControle;

	private String dataHoraTransacao; // formato 14/08/2012 - 15:06:45

	private String autenticacaoBancaria;

	private String autenticacaoDigital;

	private boolean gravaApelido;

	// Token OTP
	private String tokenFisico;

	private String mobileToken;

	private String qrToken;
	
	private String codigoReceitaFormatdo;
	
	private String numeroAIIMFormatado;

	public String getNumeroAIIMFormatado() {
		String saida;
		if (getNumeroAIIM()!=null)
			saida= getNumeroAIIM().replaceFirst("^0+(?!$)", "");
		else
			saida ="";

		return  saida;
	}

	public void setNumeroAIIMFormatado(String numeroAIIMFormatado) {
		this.numeroAIIMFormatado = numeroAIIMFormatado;
	}

	public String getChaveNSU() {
		return chaveNSU;
	}

	public void setChaveNSU(String chaveNSU) {
		this.chaveNSU = chaveNSU;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getUfFavorecida() {
		return ufFavorecida;
	}

	public void setUfFavorecida(String ufFavorecida) {
		this.ufFavorecida = ufFavorecida;
	}

	public String getDataVencimento() {
		return dataVencimento;
	}

	public void setDataVencimento(String dataVencimento) {
		this.dataVencimento = dataVencimento;
	}

	public String getCodigoReceita() {
		return codigoReceita;
	}

	public void setCodigoReceita(String codigoReceita) {
		this.codigoReceita = codigoReceita;
	}

	public String getInscricaoEstadual() {
		return inscricaoEstadual;
	}

	public void setInscricaoEstadual(String inscricaoEstadual) {
		this.inscricaoEstadual = inscricaoEstadual;
	}

	public String getCpfCnpj() {
		return cpfCnpj;
	}

	public void setCpfCnpj(String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}

	public String getInscricaoDivida() {
		return inscricaoDivida;
	}

	public void setInscricaoDivida(String inscricaoDivida) {
		this.inscricaoDivida = inscricaoDivida;
	}

	public String getReferencia() {
		return referencia;
	}

	public void setReferencia(String referencia) {
		this.referencia = referencia;
	}

	public String getNumeroAIIM() {
		return numeroAIIM;
	}

	public void setNumeroAIIM(String numeroAIIM) {
		this.numeroAIIM = numeroAIIM;
	}

	public String getValorReceita() {
		return valorReceita;
	}

	public void setValorReceita(String valorReceita) {
		this.valorReceita = valorReceita;
	}

	public String getJurosMora() {
		return jurosMora;
	}

	public void setJurosMora(String jurosMora) {
		this.jurosMora = jurosMora;
	}

	public String getMultaMora() {
		return multaMora;
	}

	public void setMultaMora(String multaMora) {
		this.multaMora = multaMora;
	}

	public String getHonorariosAdvocaticios() {
		return honorariosAdvocaticios;
	}

	public void setHonorariosAdvocaticios(String honorariosAdvocaticios) {
		this.honorariosAdvocaticios = honorariosAdvocaticios;
	}

	public String getValorTotal() {
		return valorTotal;
	}

	public void setValorTotal(String valorTotal) {
		this.valorTotal = valorTotal;
	}

	public String getNomeOuRazaoSocial() {
		return nomeOuRazaoSocial;
	}

	public void setNomeOuRazaoSocial(String nomeOuRazaoSocial) {
		this.nomeOuRazaoSocial = nomeOuRazaoSocial;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getMunicipio() {
		return municipio;
	}

	public void setMunicipio(String municipio) {
		this.municipio = municipio;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getTributoReceita() {
		return tributoReceita;
	}

	public void setTributoReceita(String tributoReceita) {
		this.tributoReceita = tributoReceita;
	}

	public String getCnae() {
		return cnae;
	}

	public void setCnae(String cnae) {
		this.cnae = cnae;
	}

	public String getObservacoes() {
		return observacoes;
	}

	public void setObservacoes(String observacoes) {
		this.observacoes = observacoes;
	}

	public String getApelido() {
		return apelido;
	}

	public void setApelido(String apelido) {
		this.apelido = apelido;
	}

	public String getPlacaVeiculo() {
		return placaVeiculo;
	}

	public void setPlacaVeiculo(String placaVeiculo) {
		this.placaVeiculo = placaVeiculo;
	}

	public String getAssinaturaEletronica() {
		return assinaturaEletronica;
	}

	public void setAssinaturaEletronica(String assinaturaEletronica) {
		this.assinaturaEletronica = assinaturaEletronica;
	}

	public String getNumeroControle() {
		return numeroControle;
	}

	public void setNumeroControle(String numeroControle) {
		this.numeroControle = numeroControle;
	}

	public String getDataHoraTransacao() {
		return dataHoraTransacao;
	}

	public void setDataHoraTransacao(String dataHoraTransacao) {
		this.dataHoraTransacao = dataHoraTransacao;
	}

	public String getAutenticacaoBancaria() {
		return autenticacaoBancaria;
	}

	public void setAutenticacaoBancaria(String autenticacaoBancaria) {
		this.autenticacaoBancaria = autenticacaoBancaria;
	}

	public String getAutenticacaoDigital() {
		return autenticacaoDigital;
	}

	public void setAutenticacaoDigital(String autenticacaoDigital) {
		this.autenticacaoDigital = autenticacaoDigital;
	}

	public String getTokenFisico() {
		return tokenFisico;
	}

	public void setTokenFisico(String tokenFisico) {
		this.tokenFisico = tokenFisico;
	}

	public String getMobileToken() {
		return mobileToken;
	}

	public void setMobileToken(String mobileToken) {
		this.mobileToken = mobileToken;
	}

	public String getQRToken() {
		return qrToken;
	}

	public void setQRToken(String qrToken) {
		this.qrToken = qrToken;
	}

	public boolean isGravaApelido() {
		return gravaApelido;
	}

	public void setGravaApelido(boolean gravaApelido) {
		this.gravaApelido = gravaApelido;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((qrToken == null) ? 0 : qrToken.hashCode());
		result = prime * result + ((apelido == null) ? 0 : apelido.hashCode());
		result = prime * result + ((assinaturaEletronica == null) ? 0 : assinaturaEletronica.hashCode());
		result = prime * result + ((autenticacaoBancaria == null) ? 0 : autenticacaoBancaria.hashCode());
		result = prime * result + ((autenticacaoDigital == null) ? 0 : autenticacaoDigital.hashCode());
		result = prime * result + ((cnae == null) ? 0 : cnae.hashCode());
		result = prime * result + ((codigoReceita == null) ? 0 : codigoReceita.hashCode());
		result = prime * result + ((cpfCnpj == null) ? 0 : cpfCnpj.hashCode());
		result = prime * result + ((dataHoraTransacao == null) ? 0 : dataHoraTransacao.hashCode());
		result = prime * result + ((dataVencimento == null) ? 0 : dataVencimento.hashCode());
		result = prime * result + ((endereco == null) ? 0 : endereco.hashCode());
		result = prime * result + (gravaApelido ? 1231 : 1237);
		result = prime * result + ((honorariosAdvocaticios == null) ? 0 : honorariosAdvocaticios.hashCode());
		result = prime * result + ((inscricaoDivida == null) ? 0 : inscricaoDivida.hashCode());
		result = prime * result + ((inscricaoEstadual == null) ? 0 : inscricaoEstadual.hashCode());
		result = prime * result + ((jurosMora == null) ? 0 : jurosMora.hashCode());
		result = prime * result + ((mobileToken == null) ? 0 : mobileToken.hashCode());
		result = prime * result + ((multaMora == null) ? 0 : multaMora.hashCode());
		result = prime * result + ((municipio == null) ? 0 : municipio.hashCode());
		result = prime * result + ((nomeOuRazaoSocial == null) ? 0 : nomeOuRazaoSocial.hashCode());
		result = prime * result + ((numeroAIIM == null) ? 0 : numeroAIIM.hashCode());
		result = prime * result + ((numeroControle == null) ? 0 : numeroControle.hashCode());
		result = prime * result + ((observacoes == null) ? 0 : observacoes.hashCode());
		result = prime * result + ((placaVeiculo == null) ? 0 : placaVeiculo.hashCode());
		result = prime * result + ((referencia == null) ? 0 : referencia.hashCode());
		result = prime * result + ((telefone == null) ? 0 : telefone.hashCode());
		result = prime * result + ((tokenFisico == null) ? 0 : tokenFisico.hashCode());
		result = prime * result + ((tributoReceita == null) ? 0 : tributoReceita.hashCode());
		result = prime * result + ((uf == null) ? 0 : uf.hashCode());
		result = prime * result + ((ufFavorecida == null) ? 0 : ufFavorecida.hashCode());
		result = prime * result + ((valorReceita == null) ? 0 : valorReceita.hashCode());
		result = prime * result + ((valorTotal == null) ? 0 : valorTotal.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		boolean retorno = true;
		if (this == obj)
			retorno = true;
		if (obj == null){
			retorno = false;
		}else{
			if (getClass() != obj.getClass())
				retorno = false;
		}
		GareSPDTO other = (GareSPDTO) obj;
		if(other!=null){
			if (qrToken == null) {
				if (other.qrToken != null)
					retorno = false;
			} else if (!qrToken.equals(other.qrToken))
				retorno = false;
			if (apelido == null) {
				if (other.apelido != null)
					retorno = false;
			} else if (!apelido.equals(other.apelido))
				retorno = false;
			if (assinaturaEletronica == null) {
				if (other.assinaturaEletronica != null)
					retorno = false;
			} else if (!assinaturaEletronica.equals(other.assinaturaEletronica))
				retorno = false;
			if (autenticacaoBancaria == null) {
				if (other.autenticacaoBancaria != null)
					retorno = false;
			} else if (!autenticacaoBancaria.equals(other.autenticacaoBancaria))
				retorno = false;
			if (autenticacaoDigital == null) {
				if (other.autenticacaoDigital != null)
					retorno = false;
			} else if (!autenticacaoDigital.equals(other.autenticacaoDigital))
				retorno = false;
			if (cnae == null) {
				if (other.cnae != null)
					retorno = false;
			} else if (!cnae.equals(other.cnae))
				retorno = false;
			if (codigoReceita == null) {
				if (other.codigoReceita != null)
					retorno = false;
			} else if (!codigoReceita.equals(other.codigoReceita))
				retorno = false;
			if (cpfCnpj == null) {
				if (other.cpfCnpj != null)
					retorno = false;
			} else if (!cpfCnpj.equals(other.cpfCnpj))
				retorno = false;
			if (dataHoraTransacao == null) {
				if (other.dataHoraTransacao != null)
					retorno = false;
			} else if (!dataHoraTransacao.equals(other.dataHoraTransacao))
				retorno = false;
			if (dataVencimento == null) {
				if (other.dataVencimento != null)
					retorno = false;
			} else if (!dataVencimento.equals(other.dataVencimento))
				retorno = false;
			if (endereco == null) {
				if (other.endereco != null)
					retorno = false;
			} else if (!endereco.equals(other.endereco))
				retorno = false;
			if (gravaApelido != other.gravaApelido)
				retorno = false;
			if (honorariosAdvocaticios == null) {
				if (other.honorariosAdvocaticios != null)
					retorno = false;
			} else if (!honorariosAdvocaticios.equals(other.honorariosAdvocaticios))
				retorno = false;
			if (inscricaoDivida == null) {
				if (other.inscricaoDivida != null)
					retorno = false;
			} else if (!inscricaoDivida.equals(other.inscricaoDivida))
				retorno = false;
			if (inscricaoEstadual == null) {
				if (other.inscricaoEstadual != null)
					retorno = false;
			} else if (!inscricaoEstadual.equals(other.inscricaoEstadual))
				retorno = false;
			if (jurosMora == null) {
				if (other.jurosMora != null)
					retorno = false;
			} else if (!jurosMora.equals(other.jurosMora))
				retorno = false;
			if (mobileToken == null) {
				if (other.mobileToken != null)
					retorno = false;
			} else if (!mobileToken.equals(other.mobileToken))
				retorno = false;
			if (multaMora == null) {
				if (other.multaMora != null)
					retorno = false;
			} else if (!multaMora.equals(other.multaMora))
				retorno = false;
			if (municipio == null) {
				if (other.municipio != null)
					retorno = false;
			} else if (!municipio.equals(other.municipio))
				retorno = false;
			if (nomeOuRazaoSocial == null) {
				if (other.nomeOuRazaoSocial != null)
					retorno = false;
			} else if (!nomeOuRazaoSocial.equals(other.nomeOuRazaoSocial))
				retorno = false;
			if (numeroAIIM == null) {
				if (other.numeroAIIM != null)
					retorno = false;
			} else if (!numeroAIIM.equals(other.numeroAIIM))
				retorno = false;
			if (numeroControle == null) {
				if (other.numeroControle != null)
					retorno = false;
			} else if (!numeroControle.equals(other.numeroControle))
				retorno = false;
			if (observacoes == null) {
				if (other.observacoes != null)
					retorno = false;
			} else if (!observacoes.equals(other.observacoes))
				retorno = false;
			if (placaVeiculo == null) {
				if (other.placaVeiculo != null)
					retorno = false;
			} else if (!placaVeiculo.equals(other.placaVeiculo))
				retorno = false;
			if (referencia == null) {
				if (other.referencia != null)
					retorno = false;
			} else if (!referencia.equals(other.referencia))
				retorno = false;
			if (telefone == null) {
				if (other.telefone != null)
					retorno = false;
			} else if (!telefone.equals(other.telefone))
				retorno = false;
			if (tokenFisico == null) {
				if (other.tokenFisico != null)
					retorno = false;
			} else if (!tokenFisico.equals(other.tokenFisico))
				retorno = false;
			if (tributoReceita == null) {
				if (other.tributoReceita != null)
					retorno = false;
			} else if (!tributoReceita.equals(other.tributoReceita))
				retorno = false;
			if (uf == null) {
				if (other.uf != null)
					retorno = false;
			} else if (!uf.equals(other.uf))
				retorno = false;
			if (ufFavorecida == null) {
				if (other.ufFavorecida != null)
					retorno = false;
			} else if (!ufFavorecida.equals(other.ufFavorecida))
				retorno = false;
			if (valorReceita == null) {
				if (other.valorReceita != null)
					retorno = false;
			} else if (!valorReceita.equals(other.valorReceita))
				retorno = false;
			if (valorTotal == null) {
				if (other.valorTotal != null)
					retorno = false;
			} else if (!valorTotal.equals(other.valorTotal))
				retorno = false;
		}
		return retorno;
	}

	@Override
	public String toString() {
		StringBuilder retorno = new StringBuilder();

		retorno.append("GareSPDTO [ufFavorecida=").append(ufFavorecida).append(", dataVencimento=")
		.append(dataVencimento).append(", codigoReceita=").append(codigoReceita)
		.append(", inscricaoEstadual=").append(inscricaoEstadual).append(", cpfCnpj=")
		.append(cpfCnpj).append(", inscricaoDivida=").append(inscricaoDivida)
		.append(", referencia=").append(referencia).append(", numeroAIIM=").append(numeroAIIM)
		.append(", valorReceita=").append(valorReceita).append(", jurosMora=").append(jurosMora)
		.append(", multaMora=").append(multaMora).append(", honorariosAdvocaticios=").append(honorariosAdvocaticios)
		.append(", valorTotal=").append(valorTotal).append(", nomeOuRazaoSocial=").append(nomeOuRazaoSocial)
		.append(", endereco=").append(endereco).append(", municipio=").append(municipio).append(", uf=")
		.append(uf).append(", telefone=").append(telefone).append(", tributoReceita=").append(tributoReceita)
		.append(", cnae=").append(cnae).append(", observacoes=").append(observacoes).append(", apelido=")
		.append(apelido).append(", placaVeiculo=").append(placaVeiculo).append(", assinaturaEletronica=")
		.append(assinaturaEletronica).append(", numeroControle=").append(numeroControle).append(", dataHoraTransacao=")
		.append(dataHoraTransacao).append(", autenticacaoBancaria=").append(autenticacaoBancaria)
		.append(", autenticacaoDigital=").append(autenticacaoDigital).append(", gravaApelido=").append(gravaApelido)
		.append(", tokenFisico=").append(tokenFisico).append(", mobileToken=").append(mobileToken)
		.append(", QRToken=").append(qrToken).append("]");

		return retorno.toString();
	}

	public String getCodigoReceitaFormatdo() {
		String auxliar = getCodigoReceita();
		while (auxliar.length()<4){
			auxliar="0".concat(auxliar);
		}
		try {
			MaskFormatter mask = new MaskFormatter("###-#");
			mask.setValueContainsLiteralCharacters(false);
			codigoReceitaFormatdo = mask.valueToString(auxliar);
		} catch (ParseException e) {
			codigoReceitaFormatdo=getCodigoReceita();
		}
		
		
		
		return codigoReceitaFormatdo;
	}

	public void setCodigoReceitaFormatdo(String codigoReceitaFormatdo) {
		this.codigoReceitaFormatdo = codigoReceitaFormatdo;
	}

}
