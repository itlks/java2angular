package com.altec.bsbr.app.ibe.dto;

public class DadosIpvaDTO {
	private String tpLinha;
	private String numVias;
	private String plLinha;
	private String valor;
	private String label;

	public String getTpLinha() {
		return tpLinha;
	}

	public void setTpLinha(String tpLinha) {
		this.tpLinha = tpLinha;
	}

	public String getNumVias() {
		return numVias;
	}

	public void setNumVias(String numVias) {
		this.numVias = numVias;
	}

	public String getPlLinha() {
		return plLinha;
	}

	public void setPlLinha(String plLinha) {
		this.plLinha = plLinha;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}
	
}
