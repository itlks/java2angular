package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class CartaoDebitoLancamentosCartaoDTO implements Serializable {

	private static final long serialVersionUID = -7954520640261627112L;
	
	private String numeroCartao;
	private String titular;
	private String situacao;
	private String modalidade;
	private String bandeira;
	private String numeroCartaoComMascara;
	/**
	 * @return the numeroCartao
	 */
	public String getNumeroCartao() {
		return numeroCartao;
	}
	/**
	 * @param numeroCartao the numeroCartao to set
	 */
	public void setNumeroCartao(String numeroCartao) {
		this.numeroCartao = numeroCartao;
	}
	/**
	 * @return the titular
	 */
	public String getTitular() {
		return titular;
	}
	/**
	 * @param titular the titular to set
	 */
	public void setTitular(String titular) {
		this.titular = titular;
	}
	/**
	 * @return the situacao
	 */
	public String getSituacao() {
		return situacao;
	}
	/**
	 * @param situacao the situacao to set
	 */
	public void setSituacao(String situacao) {
		this.situacao = situacao;
	}
	/**
	 * @return the modalidade
	 */
	public String getModalidade() {
		return modalidade;
	}
	/**
	 * @param modalidade the modalidade to set
	 */
	public void setModalidade(String modalidade) {
		this.modalidade = modalidade;
	}
	public String getBandeira() {
		return bandeira;
	}
	public void setBandeira(String bandeira) {
		this.bandeira = bandeira;
	}
	public String getNumeroCartaoComMascara() {
		return numeroCartaoComMascara;
	}
	public void setNumeroCartaoComMascara(String numeroCartaoComMascara) {
		this.numeroCartaoComMascara = numeroCartaoComMascara;
	}
}
