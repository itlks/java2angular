package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

import com.altec.bsbr.app.ibe.enumeration.AutorizacaoEnum;
import com.altec.bsbr.app.ibe.enumeration.TipoDocumentoEnum;
import com.altec.bsbr.app.ibe.enumeration.TipoTitularidadeEnum;

public class FavoritoTransferenciaDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2130055838975533437L;
	private String TSOECDPROD;
	private String TSOECDBANCCRED;
	private String TSOECDAGENCRED;
	private String TSOENRCNTACRED;
	private AutorizacaoEnum TSOEINREGTAUTORIZ;
	private String TSOENMETIT1;
	private String TSOECPFCNPJTIT1;
	private String TSOENMETIT2;
	private String TSOECPFCNPJTIT2;
	private String TSOETPCADR;
	private String TSOEINDCJ;
	private TipoDocumentoEnum TSOETIPDOCTIT1;
	private TipoTitularidadeEnum TSOEINDMMTIT;
	private String TSOECDISPB;
	private String agenciaContaFormatada;
	private String bancoFormatado;
	private String documentoFormatado;

	public String getTSOECDPROD() {
		return TSOECDPROD;
	}

	public void setTSOECDPROD(String tSOECDPROD) {
		TSOECDPROD = tSOECDPROD;
	}

	public String getTSOECDBANCCRED() {
		return TSOECDBANCCRED;
	}

	public void setTSOECDBANCCRED(String tSOECDBANCCRED) {
		TSOECDBANCCRED = tSOECDBANCCRED;
	}

	public String getTSOECDAGENCRED() {
		return TSOECDAGENCRED;
	}

	public void setTSOECDAGENCRED(String tSOECDAGENCRED) {
		TSOECDAGENCRED = tSOECDAGENCRED;
	}

	public String getTSOENRCNTACRED() {
		return TSOENRCNTACRED;
	}

	public void setTSOENRCNTACRED(String tSOENRCNTACRED) {
		TSOENRCNTACRED = tSOENRCNTACRED;
	}

	public AutorizacaoEnum getTSOEINREGTAUTORIZ() {
		return TSOEINREGTAUTORIZ;
	}

	public void setTSOEINREGTAUTORIZ(AutorizacaoEnum tSOEINREGTAUTORIZ) {
		TSOEINREGTAUTORIZ = tSOEINREGTAUTORIZ;
	}

	public String getTSOENMETIT1() {
		return TSOENMETIT1;
	}

	public void setTSOENMETIT1(String tSOENMETIT1) {
		TSOENMETIT1 = tSOENMETIT1;
	}

	public String getTSOECPFCNPJTIT1() {
		return TSOECPFCNPJTIT1;
	}

	public void setTSOECPFCNPJTIT1(String tSOECPFCNPJTIT1) {
		TSOECPFCNPJTIT1 = tSOECPFCNPJTIT1;
	}

	public String getTSOENMETIT2() {
		return TSOENMETIT2;
	}

	public void setTSOENMETIT2(String tSOENMETIT2) {
		TSOENMETIT2 = tSOENMETIT2;
	}

	public String getTSOECPFCNPJTIT2() {
		return TSOECPFCNPJTIT2;
	}

	public void setTSOECPFCNPJTIT2(String tSOECPFCNPJTIT2) {
		TSOECPFCNPJTIT2 = tSOECPFCNPJTIT2;
	}

	public String getTSOETPCADR() {
		return TSOETPCADR;
	}

	public void setTSOETPCADR(String tSOETPCADR) {
		TSOETPCADR = tSOETPCADR;
	}

	public String getTSOEINDCJ() {
		return TSOEINDCJ;
	}

	public void setTSOEINDCJ(String tSOEINDCJ) {
		TSOEINDCJ = tSOEINDCJ;
	}

	public TipoDocumentoEnum getTSOETIPDOCTIT1() {
		return TSOETIPDOCTIT1;
	}

	public void setTSOETIPDOCTIT1(TipoDocumentoEnum tSOETIPDOCTIT1) {
		TSOETIPDOCTIT1 = tSOETIPDOCTIT1;
	}

	public TipoTitularidadeEnum getTSOEINDMMTIT() {
		return TSOEINDMMTIT;
	}

	public void setTSOEINDMMTIT(TipoTitularidadeEnum tSOEINDMMTIT) {
		TSOEINDMMTIT = tSOEINDMMTIT;
	}

	public String getTSOECDISPB() {
		return TSOECDISPB;
	}

	public void setTSOECDISPB(String tSOECDISPB) {
		TSOECDISPB = tSOECDISPB;
	}

	public String getBancoFormatado() {
		return bancoFormatado;
	}

	public void setBancoFormatado(String bancoFormatado) {
		this.bancoFormatado = bancoFormatado;
	}

	public String getAgenciaContaFormatada() {
		return agenciaContaFormatada;
	}

	public void setAgenciaContaFormatada(String agenciaContaFormatada) {
		this.agenciaContaFormatada = agenciaContaFormatada;
	}

	public String getDocumentoFormatado() {
		return documentoFormatado;
	}

	public void setDocumentoFormatado(String documentoFormatado) {
		this.documentoFormatado = documentoFormatado;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((TSOECDAGENCRED == null) ? 0 : TSOECDAGENCRED.hashCode());
		result = prime * result + ((TSOECDBANCCRED == null) ? 0 : TSOECDBANCCRED.hashCode());
		result = prime * result + ((TSOECDISPB == null) ? 0 : TSOECDISPB.hashCode());
		result = prime * result + ((TSOECDPROD == null) ? 0 : TSOECDPROD.hashCode());
		result = prime * result + ((TSOECPFCNPJTIT1 == null) ? 0 : TSOECPFCNPJTIT1.hashCode());
		result = prime * result + ((TSOECPFCNPJTIT2 == null) ? 0 : TSOECPFCNPJTIT2.hashCode());
		result = prime * result + ((TSOEINDCJ == null) ? 0 : TSOEINDCJ.hashCode());
		result = prime * result + ((TSOEINDMMTIT == null) ? 0 : TSOEINDMMTIT.hashCode());
		result = prime * result + ((TSOEINREGTAUTORIZ == null) ? 0 : TSOEINREGTAUTORIZ.hashCode());
		result = prime * result + ((TSOENMETIT1 == null) ? 0 : TSOENMETIT1.hashCode());
		result = prime * result + ((TSOENMETIT2 == null) ? 0 : TSOENMETIT2.hashCode());
		result = prime * result + ((TSOENRCNTACRED == null) ? 0 : TSOENRCNTACRED.hashCode());
		result = prime * result + ((TSOETIPDOCTIT1 == null) ? 0 : TSOETIPDOCTIT1.hashCode());
		result = prime * result + ((TSOETPCADR == null) ? 0 : TSOETPCADR.hashCode());
		result = prime * result + ((agenciaContaFormatada == null) ? 0 : agenciaContaFormatada.hashCode());
		result = prime * result + ((bancoFormatado == null) ? 0 : bancoFormatado.hashCode());
		result = prime * result + ((documentoFormatado == null) ? 0 : documentoFormatado.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FavoritoTransferenciaDTO other = (FavoritoTransferenciaDTO) obj;
		if (TSOECDAGENCRED == null) {
			if (other.TSOECDAGENCRED != null)
				return false;
		} else if (!TSOECDAGENCRED.equals(other.TSOECDAGENCRED))
			return false;
		if (TSOECDBANCCRED == null) {
			if (other.TSOECDBANCCRED != null)
				return false;
		} else if (!TSOECDBANCCRED.equals(other.TSOECDBANCCRED))
			return false;
		if (TSOECDISPB == null) {
			if (other.TSOECDISPB != null)
				return false;
		} else if (!TSOECDISPB.equals(other.TSOECDISPB))
			return false;
		if (TSOECDPROD == null) {
			if (other.TSOECDPROD != null)
				return false;
		} else if (!TSOECDPROD.equals(other.TSOECDPROD))
			return false;
		if (TSOECPFCNPJTIT1 == null) {
			if (other.TSOECPFCNPJTIT1 != null)
				return false;
		} else if (!TSOECPFCNPJTIT1.equals(other.TSOECPFCNPJTIT1))
			return false;
		if (TSOECPFCNPJTIT2 == null) {
			if (other.TSOECPFCNPJTIT2 != null)
				return false;
		} else if (!TSOECPFCNPJTIT2.equals(other.TSOECPFCNPJTIT2))
			return false;
		if (TSOEINDCJ == null) {
			if (other.TSOEINDCJ != null)
				return false;
		} else if (!TSOEINDCJ.equals(other.TSOEINDCJ))
			return false;
		if (TSOEINDMMTIT != other.TSOEINDMMTIT)
			return false;
		if (TSOEINREGTAUTORIZ != other.TSOEINREGTAUTORIZ)
			return false;
		if (TSOENMETIT1 == null) {
			if (other.TSOENMETIT1 != null)
				return false;
		} else if (!TSOENMETIT1.equals(other.TSOENMETIT1))
			return false;
		if (TSOENMETIT2 == null) {
			if (other.TSOENMETIT2 != null)
				return false;
		} else if (!TSOENMETIT2.equals(other.TSOENMETIT2))
			return false;
		if (TSOENRCNTACRED == null) {
			if (other.TSOENRCNTACRED != null)
				return false;
		} else if (!TSOENRCNTACRED.equals(other.TSOENRCNTACRED))
			return false;
		if (TSOETIPDOCTIT1 != other.TSOETIPDOCTIT1)
			return false;
		if (TSOETPCADR == null) {
			if (other.TSOETPCADR != null)
				return false;
		} else if (!TSOETPCADR.equals(other.TSOETPCADR))
			return false;
		if (agenciaContaFormatada == null) {
			if (other.agenciaContaFormatada != null)
				return false;
		} else if (!agenciaContaFormatada.equals(other.agenciaContaFormatada))
			return false;
		if (bancoFormatado == null) {
			if (other.bancoFormatado != null)
				return false;
		} else if (!bancoFormatado.equals(other.bancoFormatado))
			return false;
		if (documentoFormatado == null) {
			if (other.documentoFormatado != null)
				return false;
		} else if (!documentoFormatado.equals(other.documentoFormatado))
			return false;
		return true;
	}

}
