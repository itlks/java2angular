package com.altec.bsbr.app.ibe.dto;

public class PosicaoConsolidadaConvenioDTO {

	private String bancoEntidadBr;
	private String bancoSucursalBr;
	private String bancoNroCuentaBr;
	private String valueCombo;
	
	public String getBancoEntidadBr() {
		return bancoEntidadBr;
	}
	public void setBancoEntidadBr(String bancoEntidadBr) {
		this.bancoEntidadBr = bancoEntidadBr;
	}
	public String getBancoSucursalBr() {
		return bancoSucursalBr;
	}
	public void setBancoSucursalBr(String bancoSucursalBr) {
		this.bancoSucursalBr = bancoSucursalBr;
	}
	public String getBancoNroCuentaBr() {
		return bancoNroCuentaBr;
	}
	public void setBancoNroCuentaBr(String bancoNroCuentaBr) {
		this.bancoNroCuentaBr = bancoNroCuentaBr;
	}
	public String getValueCombo() {
		return valueCombo;
	}
	public void setValueCombo(String valueCombo) {
		this.valueCombo = valueCombo;
	}

	
}
