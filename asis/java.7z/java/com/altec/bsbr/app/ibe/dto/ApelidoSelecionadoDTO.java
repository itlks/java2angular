package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang3.math.NumberUtils;

import com.altec.bsbr.app.ibe.util.UtilFunction;

@SuppressWarnings("unused")
public class ApelidoSelecionadoDTO implements Serializable {

	private static final long serialVersionUID = -1L;

	
	private String tipoApelido;
	private String apelido;
	
	private String numeroCPF;
	private String nomeContribuinte;
	private String endereco;
	private String municipio;
	private String estado;
	private String telefone;
	private String tributo;
	private String cnae;
	private String placa;
	private String codReceita;
	private String inscEstadual;
	private Date dataRef;
	private String aiim;
	private String inscDivida;
	private String observaciones;
	private String codigoalfanum5;
	private String codigoalfanum3;
	private String goPreenchimento;
	private String goExcluir;
	private String goAlterar;
	
	private String codPagamento;
	private String identPagamento;
	private String nomeFavorecido;
	private String infoComplementaria;
	
	private String chvTrx;
	
	private String codReceitaFormatado;
	private String telefoneFormatado;
	
	private String aimFormatado;
	
	private String placaFormatado;
	
	private String municipioFormatado;
	
	private String inscDividaFormatado;
	
	private String nomeRazaoSocial;
	
	
	 public String getTipoApelido() {
			return tipoApelido;
		}
		public void setTipoApelido(String tipoApelido) {
			this.tipoApelido = tipoApelido;
		}
		public String getApelido() {
			return apelido;
		}
		public void setApelido(String apelido) {
			this.apelido = apelido;
		}
		public String getNumeroCPF() {
			return UtilFunction.formatarCpfCnpj(numeroCPF);
		}
		public void setNumeroCPF(String numeroCPF) {
			this.numeroCPF = UtilFunction.formatarCpfCnpj(numeroCPF);
		}
		public String getNomeContribuinte() {
			return nomeContribuinte;
		}
		public void setNomeContribuinte(String nomeContribuinte) {
			this.nomeContribuinte = nomeContribuinte;
		}
		public String getEndereco() {
			return validaString(endereco);
		}
		public void setEndereco(String endereco) {
			this.endereco = validaString(endereco);
		}
		public String getMunicipio() {
			return validaString(municipio);
		}
		public void setMunicipio(String municipio) {
			this.municipio = validaString(municipio);
		}
		public String getEstado() {
			return validaString(estado);
		}
		public void setEstado(String estado) {
			this.estado = validaString(estado);
		}
		public String getTelefone() {
			String saida;
			if (telefone!=null)
				saida= telefone.replaceFirst("^0+(?!$)", "");
			else
				saida ="";

			return  saida;
			
		}
		public void setTelefone(String telefone) {
			this.telefone = validaString(telefone);
		}
		public String getTributo() {
			return validaString(tributo);
		}
		public void setTributo(String tributo) {
			this.tributo = validaString(tributo);
		}
		public String getCnae() {
			return validaString(cnae);
		}
		public void setCnae(String cnae) {
			this.cnae = validaString(cnae);
		}
		public String getPlaca() {
			
			String saida;
			if (placa!=null)
				saida= placa.replaceFirst("^0+(?!$)", "");
			else
				saida ="";

			return  saida;
	
		}
		public void setPlaca(String placa) {
			this.placa = validaString(placa);
		}
		public String getCodReceita() {
			
//			String auxliar = codReceita.replaceFirst("^0+(?!$)", "");;
//			
//			return auxliar;
			
			return codReceita;
		}
		public void setCodReceita(String codReceita) {
//			this.codReceita = validaString(codReceita);
			if (codReceita != null && codReceita.length() >= 5){
				this.codReceita = codReceita.substring(1);
			}
			else{
				this.codReceita = codReceita;
			}	
		}
		public String getInscEstadual() {
			return validaString(inscEstadual);
		}
		public void setInscEstadual(String inscEstadual) {
			this.inscEstadual = validaString(inscEstadual);
		}
		public Date getDataRef() {
			return dataRef;
		}
		public void setDataRef(Date dataRef) {
			this.dataRef = dataRef;
		}
		public String getAiim() {
			String saida;
			if (aiim!=null)
				saida= aiim.replaceFirst("^0+(?!$)", "");
			else
				saida ="";

			return  saida;
		}
		public void setAiim(String aiim) {
			this.aiim = validaString(aiim);
		}
		public String getInscDivida() {
			return validaString(inscDivida);
		}
		public void setInscDivida(String inscDivida) {
			this.inscDivida = validaString(inscDivida);
		}
		public String getObservaciones() {
			return validaString(observaciones);
		}
		public void setObservaciones(String observaciones) {
			this.observaciones = validaString(observaciones);
		}
		public String getCodigoalfanum5() {
			return codigoalfanum5;
		}
		public void setCodigoalfanum5(String codigoalfanum5) {
			this.codigoalfanum5 = codigoalfanum5;
		}
		public String getCodigoalfanum3() {
			return codigoalfanum3;
		}
		public void setCodigoalfanum3(String codigoalfanum3) {
			this.codigoalfanum3 = codigoalfanum3;
		}
		public String getGoPreenchimento() {
			return goPreenchimento;
		}
		public void setGoPreenchimento(String goPreenchimento) {
			this.goPreenchimento = goPreenchimento;
		}
		public String getGoExcluir() {
			return goExcluir;
		}
		public void setGoExcluir(String goExcluir) {
			this.goExcluir = goExcluir;
		}
		public String getGoAlterar() {
			return goAlterar;
		}
		public void setGoAlterar(String goAlterar) {
			this.goAlterar = goAlterar;
		}
		
		/**
		 * @return the codPagamento
		 */
		public String getCodPagamento() {
			return codPagamento;
		}
		/**
		 * @param codPagamento the codPagamento to set
		 */
		public void setCodPagamento(String codPagamento) {
			this.codPagamento = codPagamento;
		}
		/**
		 * @return the identPagamento
		 */
		public String getIdentPagamento() {
			return identPagamento;
		}
		/**
		 * @param identPagamento the identPagamento to set
		 */
		public void setIdentPagamento(String identPagamento) {
			this.identPagamento = identPagamento;
		}
		/**
		 * @return the nomeFavorecido
		 */
		public String getNomeFavorecido() {
			return nomeFavorecido;
		}
		/**
		 * @param nomeFavorecido the nomeFavorecido to set
		 */
		public void setNomeFavorecido(String nomeFavorecido) {
			this.nomeFavorecido = nomeFavorecido;
		}
		/**
		 * @return the infoComplementaria
		 */
		public String getInfoComplementaria() {
			return infoComplementaria;
		}
		/**
		 * @param infoComplementaria the infoComplementaria to set
		 */
		public void setInfoComplementaria(String infoComplementaria) {
			this.infoComplementaria = infoComplementaria;
		}
		
		
		
		/**
		 * @return the chvTrx
		 */
		public String getChvTrx() {
			return chvTrx;
		}
		/**
		 * @param chvTrx the chvTrx to set
		 */
		public void setChvTrx(String chvTrx) {
			this.chvTrx = chvTrx;
		}
		private String validaString(String s){
			
			if (s!=null && !s.equals("")){
				s=s.trim().replace(".", "").replace("-", "").replace("-", "").replace("/", "");
				
				if (NumberUtils.isNumber(s)){
						Long d = Long.parseLong(s);
						if (d>0){
							s= d.toString();
						}else{
							s="";
						}
				}
				
			}
			
			return s;
		}
		public String getCodReceitaFormatado() {
			String auxliar = getCodReceita();
			while (auxliar.length()>4)
				auxliar = auxliar.substring(1, auxliar.length());
			
			while (auxliar.length()<4){
				auxliar="0".concat(auxliar);
			}
				
			return auxliar;
		}
		public void setCodReceitaFormatado(String codReceitaFormatado) {
			this.codReceitaFormatado = codReceitaFormatado;
		}
		public String getTelefoneFormatado() {
			String saida;
			if (getTelefone()!=null)
				saida= getTelefone().replaceFirst("^0+(?!$)", "");
			else
				saida ="";

			return  saida;
		}

		public String getAimFormatado() {
			String saida;
			if (getAiim()!=null)
				saida= getAiim().replaceFirst("^0+(?!$)", "");
			else
				saida ="";

			return  saida;
			
		}
		public String getPlacaFormatado() {
			String saida;
			if (getPlaca()!=null)
				saida= getPlaca().replaceFirst("^0+(?!$)", "");
			else
				saida ="";

			return  saida;
			
			
		}
		public String getMunicipioFormatado() {
			String saida;
			if (getInscEstadual()!=null)
				saida= getInscEstadual().replaceFirst("^0+(?!$)", "");
			else
				saida ="";

			return  saida;
		
		}
		public String getInscDividaFormatado() {
			
			String saida;
			if (getInscDivida()!=null)
				saida= getInscDivida().replaceFirst("^0+(?!$)", "");
			else
				saida ="";

			return  saida;
			
		}
		/**
		 * @return the nomeRazaoSocial
		 */
		public String getNomeRazaoSocial() {
			return nomeRazaoSocial;
		}
		/**
		 * @param nomeRazaoSocial the nomeRazaoSocial to set
		 */
		public void setNomeRazaoSocial(String nomeRazaoSocial) {
			this.nomeRazaoSocial = nomeRazaoSocial;
		}
		
		

		

}
