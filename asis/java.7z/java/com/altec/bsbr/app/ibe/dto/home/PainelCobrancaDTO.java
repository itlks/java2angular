package com.altec.bsbr.app.ibe.dto.home;

import java.io.Serializable;

public class PainelCobrancaDTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1857074482928357954L;

	private Integer qteTitulosVencidos;
	private Integer qteTitulosAVencer;
	private Integer qteTitulosTotal;
	
	private Double valorTtulosVencidos;
	private Double valorTitulosAVencer;
	private Double valorTitulosTotal;
	
	
	public Integer getQteTitulosVencidos() {
		return qteTitulosVencidos;
	}
	public void setQteTitulosVencidos(Integer qteTitulosVencidos) {
		this.qteTitulosVencidos = qteTitulosVencidos;
	}
	public Integer getQteTitulosAVencer() {
		return qteTitulosAVencer;
	}
	public void setQteTitulosAVencer(Integer qteTitulosAVencer) {
		this.qteTitulosAVencer = qteTitulosAVencer;
	}
	public Integer getQteTitulosTotal() {
		return qteTitulosTotal;
	}
	public void setQteTitulosTotal(Integer qteTitulosTotal) {
		this.qteTitulosTotal = qteTitulosTotal;
	}
	public Double getValorTtulosVencidos() {
		return valorTtulosVencidos;
	}
	public void setValorTtulosVencidos(Double valorTtulosVencidos) {
		this.valorTtulosVencidos = valorTtulosVencidos;
	}
	public Double getValorTitulosAVencer() {
		return valorTitulosAVencer;
	}
	public void setValorTitulosAVencer(Double valorTitulosAVencer) {
		this.valorTitulosAVencer = valorTitulosAVencer;
	}
	public Double getValorTitulosTotal() {
		return valorTitulosTotal;
	}
	public void setValorTitulosTotal(Double valorTitulosTotal) {
		this.valorTitulosTotal = valorTitulosTotal;
	}
		
}
