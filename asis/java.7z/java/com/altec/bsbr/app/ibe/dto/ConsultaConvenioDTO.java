package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class ConsultaConvenioDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String penum01;
	private String penum02;
	private String penum03;
	private String penum04;
	private String penum05;
	private String penum06;
	private String penum07;
	private String penum08;
	private String penum09;
	private String penum10;
	private String penum11;
	private String penum12;
	private String penum13;
	private String penum14;
	private String penum15;
	private String penum16;
	private String penum17;
	private String penum18;
	private String penum19;
	private String penum20;
	private String penum21;
	private String penum22;
	private String penum23;
	private String penum24;
	private String penum25;
	private String penum26;
	private String penum27;
	private String penum28;
	private String penum29;
	private String penum30;
	private String penum31;
	private String penum32;
	private String penum33;
	private String penum34;
	private String penum35;
	private String penum36;
	private String penum37;
	private String penum38;
	private String penum39;
	private String penum40;
	private String penum41;
	private String penum42;
	private String penum43;
	private String penum44;
	private String penum45;
	private String penum46;
	private String penum47;
	private String penum48;
	private String penum49;
	private String penum50;
	private String bancoPPALRepaginacao;
	private String agenciaPPALRepaginacao;
	private String numeroContaPPALRepaginacao;
	private String bancoDEBRepaginacao;
	private String agenciaDEBRepaginacao;
	private String numeroContaDEBRepaginacao;
	private String contrato;

	public String getContrato() {
		return contrato;
	}

	public void setContrato(String contrato) {
		this.contrato = contrato;
	}

	public String getPenum01() {
		return penum01;
	}
	
	public void setPenum01(String penum01) {
		this.penum01 = penum01;
	}

	public String getPenum02() {
		return penum02;
	}

	public void setPenum02(String penum02) {
		this.penum02 = penum02;
	}

	public String getPenum03() {
		return penum03;
	}

	public void setPenum03(String penum03) {
		this.penum03 = penum03;
	}

	public String getPenum04() {
		return penum04;
	}

	public void setPenum04(String penum04) {
		this.penum04 = penum04;
	}

	public String getPenum05() {
		return penum05;
	}

	public void setPenum05(String penum05) {
		this.penum05 = penum05;
	}

	public String getPenum06() {
		return penum06;
	}

	public void setPenum06(String penum06) {
		this.penum06 = penum06;
	}

	public String getPenum07() {
		return penum07;
	}

	public void setPenum07(String penum07) {
		this.penum07 = penum07;
	}

	public String getPenum08() {
		return penum08;
	}

	public void setPenum08(String penum08) {
		this.penum08 = penum08;
	}

	public String getPenum09() {
		return penum09;
	}

	public void setPenum09(String penum09) {
		this.penum09 = penum09;
	}

	public String getPenum10() {
		return penum10;
	}

	public void setPenum10(String penum10) {
		this.penum10 = penum10;
	}

	public String getPenum11() {
		return penum11;
	}

	public void setPenum11(String penum11) {
		this.penum11 = penum11;
	}

	public String getPenum12() {
		return penum12;
	}

	public void setPenum12(String penum12) {
		this.penum12 = penum12;
	}

	public String getPenum13() {
		return penum13;
	}

	public void setPenum13(String penum13) {
		this.penum13 = penum13;
	}

	public String getPenum14() {
		return penum14;
	}

	public void setPenum14(String penum14) {
		this.penum14 = penum14;
	}

	public String getPenum15() {
		return penum15;
	}

	public void setPenum15(String penum15) {
		this.penum15 = penum15;
	}

	public String getPenum16() {
		return penum16;
	}

	public void setPenum16(String penum16) {
		this.penum16 = penum16;
	}

	public String getPenum17() {
		return penum17;
	}

	public void setPenum17(String penum17) {
		this.penum17 = penum17;
	}

	public String getPenum18() {
		return penum18;
	}

	public void setPenum18(String penum18) {
		this.penum18 = penum18;
	}

	public String getPenum19() {
		return penum19;
	}

	public void setPenum19(String penum19) {
		this.penum19 = penum19;
	}

	public String getPenum20() {
		return penum20;
	}

	public void setPenum20(String penum20) {
		this.penum20 = penum20;
	}

	public String getPenum21() {
		return penum21;
	}

	public void setPenum21(String penum21) {
		this.penum21 = penum21;
	}

	public String getPenum22() {
		return penum22;
	}

	public void setPenum22(String penum22) {
		this.penum22 = penum22;
	}

	public String getPenum23() {
		return penum23;
	}

	public void setPenum23(String penum23) {
		this.penum23 = penum23;
	}

	public String getPenum24() {
		return penum24;
	}

	public void setPenum24(String penum24) {
		this.penum24 = penum24;
	}

	public String getPenum25() {
		return penum25;
	}

	public void setPenum25(String penum25) {
		this.penum25 = penum25;
	}

	public String getPenum26() {
		return penum26;
	}

	public void setPenum26(String penum26) {
		this.penum26 = penum26;
	}

	public String getPenum27() {
		return penum27;
	}

	public void setPenum27(String penum27) {
		this.penum27 = penum27;
	}

	public String getPenum28() {
		return penum28;
	}

	public void setPenum28(String penum28) {
		this.penum28 = penum28;
	}

	public String getPenum29() {
		return penum29;
	}

	public void setPenum29(String penum29) {
		this.penum29 = penum29;
	}

	public String getPenum30() {
		return penum30;
	}

	public void setPenum30(String penum30) {
		this.penum30 = penum30;
	}

	public String getPenum31() {
		return penum31;
	}

	public void setPenum31(String penum31) {
		this.penum31 = penum31;
	}

	public String getPenum32() {
		return penum32;
	}

	public void setPenum32(String penum32) {
		this.penum32 = penum32;
	}

	public String getPenum33() {
		return penum33;
	}

	public void setPenum33(String penum33) {
		this.penum33 = penum33;
	}

	public String getPenum34() {
		return penum34;
	}

	public void setPenum34(String penum34) {
		this.penum34 = penum34;
	}

	public String getPenum35() {
		return penum35;
	}

	public void setPenum35(String penum35) {
		this.penum35 = penum35;
	}

	public String getPenum36() {
		return penum36;
	}

	public void setPenum36(String penum36) {
		this.penum36 = penum36;
	}

	public String getPenum37() {
		return penum37;
	}

	public void setPenum37(String penum37) {
		this.penum37 = penum37;
	}

	public String getPenum38() {
		return penum38;
	}

	public void setPenum38(String penum38) {
		this.penum38 = penum38;
	}

	public String getPenum39() {
		return penum39;
	}

	public void setPenum39(String penum39) {
		this.penum39 = penum39;
	}

	public String getPenum40() {
		return penum40;
	}

	public void setPenum40(String penum40) {
		this.penum40 = penum40;
	}

	public String getPenum41() {
		return penum41;
	}

	public void setPenum41(String penum41) {
		this.penum41 = penum41;
	}

	public String getPenum42() {
		return penum42;
	}

	public void setPenum42(String penum42) {
		this.penum42 = penum42;
	}

	public String getPenum43() {
		return penum43;
	}

	public void setPenum43(String penum43) {
		this.penum43 = penum43;
	}

	public String getPenum44() {
		return penum44;
	}

	public void setPenum44(String penum44) {
		this.penum44 = penum44;
	}

	public String getPenum45() {
		return penum45;
	}

	public void setPenum45(String penum45) {
		this.penum45 = penum45;
	}

	public String getPenum46() {
		return penum46;
	}

	public void setPenum46(String penum46) {
		this.penum46 = penum46;
	}

	public String getPenum47() {
		return penum47;
	}

	public void setPenum47(String penum47) {
		this.penum47 = penum47;
	}

	public String getPenum48() {
		return penum48;
	}

	public void setPenum48(String penum48) {
		this.penum48 = penum48;
	}

	public String getPenum49() {
		return penum49;
	}

	public void setPenum49(String penum49) {
		this.penum49 = penum49;
	}

	public String getPenum50() {
		return penum50;
	}

	public void setPenum50(String penum50) {
		this.penum50 = penum50;
	}

	/**
	 * @return the bancoPPALRepaginacao
	 */
	public String getBancoPPALRepaginacao() {
		return bancoPPALRepaginacao;
	}

	/**
	 * @param bancoPPALRepaginacao
	 *            the bancoPPALRepaginacao to set
	 */
	public void setBancoPPALRepaginacao(String bancoPPALRepaginacao) {
		this.bancoPPALRepaginacao = bancoPPALRepaginacao;
	}

	/**
	 * @return the agenciaPPALRepaginacao
	 */
	public String getAgenciaPPALRepaginacao() {
		return agenciaPPALRepaginacao;
	}

	/**
	 * @param agenciaPPALRepaginacao
	 *            the agenciaPPALRepaginacao to set
	 */
	public void setAgenciaPPALRepaginacao(String agenciaPPALRepaginacao) {
		this.agenciaPPALRepaginacao = agenciaPPALRepaginacao;
	}

	/**
	 * @return the numeroContaPPALRepaginacao
	 */
	public String getNumeroContaPPALRepaginacao() {
		return numeroContaPPALRepaginacao;
	}

	/**
	 * @param numeroContaPPALRepaginacao
	 *            the numeroContaPPALRepaginacao to set
	 */
	public void setNumeroContaPPALRepaginacao(String numeroContaPPALRepaginacao) {
		this.numeroContaPPALRepaginacao = numeroContaPPALRepaginacao;
	}

	/**
	 * @return the bancoDEBRepaginacao
	 */
	public String getBancoDEBRepaginacao() {
		return bancoDEBRepaginacao;
	}

	/**
	 * @param bancoDEBRepaginacao
	 *            the bancoDEBRepaginacao to set
	 */
	public void setBancoDEBRepaginacao(String bancoDEBRepaginacao) {
		this.bancoDEBRepaginacao = bancoDEBRepaginacao;
	}

	/**
	 * @return the agenciaDEBRepaginacao
	 */
	public String getAgenciaDEBRepaginacao() {
		return agenciaDEBRepaginacao;
	}

	/**
	 * @param agenciaDEBRepaginacao
	 *            the agenciaDEBRepaginacao to set
	 */
	public void setAgenciaDEBRepaginacao(String agenciaDEBRepaginacao) {
		this.agenciaDEBRepaginacao = agenciaDEBRepaginacao;
	}

	/**
	 * @return the numeroContaDEBRepaginacao
	 */
	public String getNumeroContaDEBRepaginacao() {
		return numeroContaDEBRepaginacao;
	}

	/**
	 * @param numeroContaDEBRepaginacao
	 *            the numeroContaDEBRepaginacao to set
	 */
	public void setNumeroContaDEBRepaginacao(String numeroContaDEBRepaginacao) {
		this.numeroContaDEBRepaginacao = numeroContaDEBRepaginacao;
	}

}
