package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class ChequesTaloesBloqueadosDTO implements Serializable {
	

	private static final long serialVersionUID = -1490079726094849176L;
	
	private String folhaInicial;
	private String folhaFinal; 
	
	
	public ChequesTaloesBloqueadosDTO() { 
	}
	
	public ChequesTaloesBloqueadosDTO(String folhaInicial, String folhaFinal) { 
		this.folhaInicial = folhaInicial;
		this.folhaFinal = folhaFinal;
	}
	/**
	 * @return the folhaInicial
	 */
	public String getFolhaInicial() {
		return folhaInicial;
	}
	/**
	 * @param folhaInicial the folhaInicial to set
	 */
	public void setFolhaInicial(String folhaInicial) {
		this.folhaInicial = folhaInicial;
	}
	/**
	 * @return the folhaFinal
	 */
	public String getFolhaFinal() {
		return folhaFinal;
	}
	/**
	 * @param folhaFinal the folhaFinal to set
	 */
	public void setFolhaFinal(String folhaFinal) {
		this.folhaFinal = folhaFinal;
	}
	
	

}
