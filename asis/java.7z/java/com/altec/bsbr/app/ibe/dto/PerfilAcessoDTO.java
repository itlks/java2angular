package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class PerfilAcessoDTO implements Serializable {

	private static final long serialVersionUID = -3128985036074670419L;
	
	private Integer numeroSeqPerfilAcesso;
	private String nomePerfilAcesso;
	private String descricaoPerfilAcesso;	
	private Integer contador;
	private boolean perfilAcessoSelecionado;
	private boolean podeExcluir =  false;
	
	
	public Integer getNumeroSeqPerfilAcesso() {
		return numeroSeqPerfilAcesso;
	}
	
	public void setNumeroSeqPerfilAcesso(Integer numeroSeqPerfilAcesso) {
		this.numeroSeqPerfilAcesso = numeroSeqPerfilAcesso;
	}
	
	public String getNomePerfilAcesso() {
		return nomePerfilAcesso;
	}
	
	public void setNomePerfilAcesso(String nomePerfilAcesso) {
		this.nomePerfilAcesso = nomePerfilAcesso;
	}
	
	public String getDescricaoPerfilAcesso() {
		return descricaoPerfilAcesso;
	}
	
	public void setDescricaoPerfilAcesso(String descricaoPerfilAcesso) {
		this.descricaoPerfilAcesso = descricaoPerfilAcesso;
	}
	
	public Integer getContador() {
		return contador;
	}
	
	public void setContador(Integer contador) {
		this.contador = contador;
	}

	public boolean isPerfilAcessoSelecionado() {
		return perfilAcessoSelecionado;
	}

	public void setPerfilAcessoSelecionado(boolean perfilAcessoSelecionado) {
		this.perfilAcessoSelecionado = perfilAcessoSelecionado;
	}

	public boolean isPodeExcluir() {
		return podeExcluir;
	}

	public void setPodeExcluir(boolean podeExcluir) {
		this.podeExcluir = podeExcluir;
	}
	
	
		
}
