package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ListaPosicaoConsolidadaPoupancaDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5815897973274284306L;
	
	private List<PosicaoConsolidadaDTO> posicaoConsolidada = new ArrayList<PosicaoConsolidadaDTO>();

	public List<PosicaoConsolidadaDTO> getPosicaoConsolidada() {
		return posicaoConsolidada;
	}

	public void setPosicaoConsolidada(List<PosicaoConsolidadaDTO> posicaoConsolidada) {
		this.posicaoConsolidada = posicaoConsolidada;
	}

}
