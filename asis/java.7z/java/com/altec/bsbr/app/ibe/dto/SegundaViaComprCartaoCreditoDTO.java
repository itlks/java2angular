package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;

public class SegundaViaComprCartaoCreditoDTO  extends GenericDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String banco;
	private String agencia;
	private String conta;		
	private String codigoUsuario;
	private String hostAddress;
	private String canal;
	
	private String dataInicial;
	private String dataFinal;
	
	private String codigoComprovante;
	private String canalPagamento;
	
	private String favorecido;
	private String numeroCartao;
	private String dataVencimento;
	private BigDecimal valorFatura;
	private BigDecimal valorPago;
	private String dataPagamento;
	private String horaPagamento;
	private String dataTransacao;
	private String autenticacaoBancaria;
	
	private String cartao;
	private BigDecimal valorAPagar;
	
	private boolean selecionado;
	
	public SegundaViaComprCartaoCreditoDTO() {	
	}
		
	public String getCodigoComprovante() {
		return codigoComprovante;
	}

	public void setCodigoComprovante(String codigoComprovante) {
		this.codigoComprovante = codigoComprovante;
	}

	public String getCanal() {
		return canal;
	}
	public void setCanal(String canal) {
		this.canal = canal;
	}

	public boolean isSelecionado() {
		return selecionado;
	}

	public void setSelecionado(boolean selecionado) {
		this.selecionado = selecionado;
	}

	
	
	public String getDataInicial() {
		return dataInicial;
	}

	public void setDataInicial(String dataInicial) {
		this.dataInicial = dataInicial;
	}

	public String getDataFinal() {
		return dataFinal;
	}

	public void setDataFinal(String dataFinal) {
		this.dataFinal = dataFinal;
	}

	public String getFavorecido() {
		return favorecido;
	}

	public void setFavorecido(String favorecido) {
		this.favorecido = favorecido;
	}

	public String getNumeroCartao() {
		return numeroCartao;
	}
	
	public String getNumeroCartaoMascarado(){
		if (this.numeroCartao == null) {
			return null;
		}
		else if (this.numeroCartao.length()==16) {
			return this.numeroCartao == null ? null : this.numeroCartao.replaceAll("\\b(\\d{4})(\\d{4})(\\d{4})(\\d{4})", "**** **** **** $4");	
		}
		else if (this.numeroCartao.length()==15) {
			return this.numeroCartao == null ? null : this.numeroCartao.replaceAll("\\b(\\d{3})(\\d{4})(\\d{4})(\\d{4})", "*** **** **** $4");
		}
		return this.numeroCartao;
	}

	public void setNumeroCartao(String numeroCartao) {
		this.numeroCartao = numeroCartao;
	}

	public String getDataVencimento() {
		return dataVencimento;
	}

	public void setDataVencimento(String dataVencimento) {
		this.dataVencimento = dataVencimento;
	}

	public BigDecimal getValorFatura() {
		return valorFatura;
	}

	public void setValorFatura(BigDecimal valorFatura) {
		this.valorFatura = valorFatura;
	}

	public BigDecimal getValorPago() {
		return valorPago;
	}

	public void setValorPago(BigDecimal valorPago) {
		this.valorPago = valorPago;
	}

	public String getDataPagamento() {
		return dataPagamento;
	}

	public void setDataPagamento(String dataPagamento) {
		this.dataPagamento = dataPagamento;
	}

	public String getDataTransacao() {
		return dataTransacao;
	}

	public void setDataTransacao(String dataTransacao) {
		this.dataTransacao = dataTransacao;
	}

	public String getAutenticacaoBancaria() {
		return autenticacaoBancaria;
	}

	public void setAutenticacaoBancaria(String autenticacaoBancaria) {
		this.autenticacaoBancaria = autenticacaoBancaria;
	}

	public String getCartao() {
		return cartao;
	}

	public void setCartao(String cartao) {
		this.cartao = cartao;
	}

	public BigDecimal getValorAPagar() {
		return valorAPagar;
	}

	public void setValorAPagar(BigDecimal valorAPagar) {
		this.valorAPagar = valorAPagar;
	}

	
	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getConta() {
		return conta;
	}

	public void setConta(String conta) {
		this.conta = conta;
	}

	public String getCanalPagamento() {
		return canalPagamento;
	}

	public void setCanalPagamento(String canalPagamento) {
		this.canalPagamento = canalPagamento;
	}

	public String getCanalPagamentoCaseSensitive() {
		String lower = canalPagamento.toLowerCase();
		StringBuilder retorno=new StringBuilder();
		
		String split[]= lower.split(" ");		
		for (String palavra: split) {
			StringBuilder sPalavra=new StringBuilder(palavra);
			Character c = palavra.charAt(0);		
			Character c1 = Character.toUpperCase(c);
			sPalavra = sPalavra.replace(0, 1, c1.toString());
			retorno.append(sPalavra);
			retorno.append(" ");
		}			
	
		return retorno.toString().trim(); 
	}

	
	public String getCodigoUsuario() {
		return codigoUsuario;
	}

	public void setCodigoUsuario(String codigoUsuario) {
		this.codigoUsuario = codigoUsuario;
	}

	public String getHostAddress() {
		return hostAddress;
	}

	public void setHostAddress(String hostAddress) {
		this.hostAddress = hostAddress;
	}
	
	public String getHoraPagamento() {
		return horaPagamento;
	}

	public void setHoraPagamento(String horaPagamento) {
		this.horaPagamento = horaPagamento;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((agencia == null) ? 0 : agencia.hashCode());
		result = prime * result + ((autenticacaoBancaria == null) ? 0 : autenticacaoBancaria.hashCode());
		result = prime * result + ((banco == null) ? 0 : banco.hashCode());
		result = prime * result + ((canal == null) ? 0 : canal.hashCode());
		result = prime * result + ((canalPagamento == null) ? 0 : canalPagamento.hashCode());
		result = prime * result + ((cartao == null) ? 0 : cartao.hashCode());
		result = prime * result + ((codigoComprovante == null) ? 0 : codigoComprovante.hashCode());
		result = prime * result + ((codigoUsuario == null) ? 0 : codigoUsuario.hashCode());
		result = prime * result + ((conta == null) ? 0 : conta.hashCode());
		result = prime * result + ((dataFinal == null) ? 0 : dataFinal.hashCode());
		result = prime * result + ((dataTransacao == null) ? 0 : dataTransacao.hashCode());
		result = prime * result + ((dataInicial == null) ? 0 : dataInicial.hashCode());
		result = prime * result + ((dataPagamento == null) ? 0 : dataPagamento.hashCode());
		result = prime * result + ((dataVencimento == null) ? 0 : dataVencimento.hashCode());
		result = prime * result + ((favorecido == null) ? 0 : favorecido.hashCode());
		result = prime * result + ((horaPagamento == null) ? 0 : horaPagamento.hashCode());
		result = prime * result + ((hostAddress == null) ? 0 : hostAddress.hashCode());
		result = prime * result + ((numeroCartao == null) ? 0 : numeroCartao.hashCode());
		result = prime * result + (selecionado ? 1231 : 1237);
		result = prime * result + ((valorAPagar == null) ? 0 : valorAPagar.hashCode());
		result = prime * result + ((valorFatura == null) ? 0 : valorFatura.hashCode());
		result = prime * result + ((valorPago == null) ? 0 : valorPago.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof SegundaViaComprCartaoCreditoDTO)) {
			return false;
		}
		SegundaViaComprCartaoCreditoDTO other = (SegundaViaComprCartaoCreditoDTO) obj;
		if (agencia == null) {
			if (other.agencia != null) {
				return false;
			}
		} else if (!agencia.equals(other.agencia)) {
			return false;
		}
		if (autenticacaoBancaria == null) {
			if (other.autenticacaoBancaria != null) {
				return false;
			}
		} else if (!autenticacaoBancaria.equals(other.autenticacaoBancaria)) {
			return false;
		}
		if (banco == null) {
			if (other.banco != null) {
				return false;
			}
		} else if (!banco.equals(other.banco)) {
			return false;
		}
		if (canal == null) {
			if (other.canal != null) {
				return false;
			}
		} else if (!canal.equals(other.canal)) {
			return false;
		}
		if (canalPagamento == null) {
			if (other.canalPagamento != null) {
				return false;
			}
		} else if (!canalPagamento.equals(other.canalPagamento)) {
			return false;
		}
		if (cartao == null) {
			if (other.cartao != null) {
				return false;
			}
		} else if (!cartao.equals(other.cartao)) {
			return false;
		}
		if (codigoComprovante == null) {
			if (other.codigoComprovante != null) {
				return false;
			}
		} else if (!codigoComprovante.equals(other.codigoComprovante)) {
			return false;
		}
		if (codigoUsuario == null) {
			if (other.codigoUsuario != null) {
				return false;
			}
		} else if (!codigoUsuario.equals(other.codigoUsuario)) {
			return false;
		}
		if (conta == null) {
			if (other.conta != null) {
				return false;
			}
		} else if (!conta.equals(other.conta)) {
			return false;
		}
		if (dataFinal == null) {
			if (other.dataFinal != null) {
				return false;
			}
		} else if (!dataFinal.equals(other.dataFinal)) {
			return false;
		}
		if (dataTransacao == null) {
			if (other.dataTransacao != null) {
				return false;
			}
		} else if (!dataTransacao.equals(other.dataTransacao)) {
			return false;
		}
		if (dataInicial == null) {
			if (other.dataInicial != null) {
				return false;
			}
		} else if (!dataInicial.equals(other.dataInicial)) {
			return false;
		}
		if (dataPagamento == null) {
			if (other.dataPagamento != null) {
				return false;
			}
		} else if (!dataPagamento.equals(other.dataPagamento)) {
			return false;
		}
		if (dataVencimento == null) {
			if (other.dataVencimento != null) {
				return false;
			}
		} else if (!dataVencimento.equals(other.dataVencimento)) {
			return false;
		}
		if (favorecido == null) {
			if (other.favorecido != null) {
				return false;
			}
		} else if (!favorecido.equals(other.favorecido)) {
			return false;
		}
		if (horaPagamento == null) {
			if (other.horaPagamento != null) {
				return false;
			}
		} else if (!horaPagamento.equals(other.horaPagamento)) {
			return false;
		}
		if (hostAddress == null) {
			if (other.hostAddress != null) {
				return false;
			}
		} else if (!hostAddress.equals(other.hostAddress)) {
			return false;
		}
		if (numeroCartao == null) {
			if (other.numeroCartao != null) {
				return false;
			}
		} else if (!numeroCartao.equals(other.numeroCartao)) {
			return false;
		}
		if (selecionado != other.selecionado) {
			return false;
		}
		if (valorAPagar == null) {
			if (other.valorAPagar != null) {
				return false;
			}
		} else if (!valorAPagar.equals(other.valorAPagar)) {
			return false;
		}
		if (valorFatura == null) {
			if (other.valorFatura != null) {
				return false;
			}
		} else if (!valorFatura.equals(other.valorFatura)) {
			return false;
		}
		if (valorPago == null) {
			if (other.valorPago != null) {
				return false;
			}
		} else if (!valorPago.equals(other.valorPago)) {
			return false;
		}
		return true;
	}

	
	
	
}
