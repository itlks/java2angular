
package com.altec.bsbr.app.ibe.dto.investimentos.posicaomensal;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;

public class InvestimentosCMPosicaoRequestDTO implements Serializable
{

	//private String personNumber;
    private String bankCode;
    private String agencyCode;
    private String accountNumber;
    private String referenceDate;
    private String recallContract;
    private String sequenceReexecution;
    private String movimentNumberReexecution;
    private String maximumNumberRecords;
    private String reexecutionIndicator;
    private final static long serialVersionUID = -6977731017299844837L;

    /**
     * No args constructor for use in serialization
     * 
     */
    public InvestimentosCMPosicaoRequestDTO() {
    }

    /**
     * 
     * @param bankCode
     * @param agencyCode
     * @param personNumber
     * @param accountNumber
     */
    public InvestimentosCMPosicaoRequestDTO(String bankCode, String agencyCode, String accountNumber,
			String referenceDate, String recallContract, String sequenceReexecution, String movimentNumberReexecution,
			String maximumNumberRecords, String reexecutionIndicator) {
		super();
		this.bankCode = bankCode;
		this.agencyCode = agencyCode;
		this.accountNumber = accountNumber;
		this.referenceDate = referenceDate;
		this.recallContract = recallContract;
		this.sequenceReexecution = sequenceReexecution;
		this.movimentNumberReexecution = movimentNumberReexecution;
		this.maximumNumberRecords = maximumNumberRecords;
		this.reexecutionIndicator = reexecutionIndicator;
	}
    
    public String getBankCode() {
        return bankCode;
    }

	public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    public InvestimentosCMPosicaoRequestDTO withBankCode(String bankCode) {
        this.bankCode = bankCode;
        return this;
    }

    public String getAgencyCode() {
        return agencyCode;
    }

    public void setAgencyCode(String agencyCode) {
        this.agencyCode = agencyCode;
    }

    public InvestimentosCMPosicaoRequestDTO withAgencyCode(String agencyCode) {
        this.agencyCode = agencyCode;
        return this;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public InvestimentosCMPosicaoRequestDTO withAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
        return this;
    }

    public String getReferenceDate() {
		return referenceDate;
	}

	public void setReferenceDate(String referenceDate) {
		this.referenceDate = referenceDate;
	}

	public String getRecallContract() {
		return recallContract;
	}

	public void setRecallContract(String recallContract) {
		this.recallContract = recallContract;
	}

	public String getSequenceReexecution() {
		return sequenceReexecution;
	}

	public void setSequenceReexecution(String sequenceReexecution) {
		this.sequenceReexecution = sequenceReexecution;
	}

	public String getMovimentNumberReexecution() {
		return movimentNumberReexecution;
	}

	public void setMovimentNumberReexecution(String movimentNumberReexecution) {
		this.movimentNumberReexecution = movimentNumberReexecution;
	}

	public String getMaximumNumberRecords() {
		return maximumNumberRecords;
	}

	public void setMaximumNumberRecords(String maximumNumberRecords) {
		this.maximumNumberRecords = maximumNumberRecords;
	}

	public String getReexecutionIndicator() {
		return reexecutionIndicator;
	}

	public void setReexecutionIndicator(String reexecutionIndicator) {
		this.reexecutionIndicator = reexecutionIndicator;
	}

//	public String getPersonNumber() {
//		return personNumber;
//	}
//
//	public void setPersonNumber(String personNumber) {
//		this.personNumber = personNumber;
//	}

	@Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }



}
