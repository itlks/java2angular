package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.Date;

import com.altec.bsbr.app.ibe.web.jsf.attributes.AtributosDaAplicacao;
import com.altec.bsbr.app.ibe.web.jsf.attributes.AtributosDaSessao;

public class ConsultaAutorizacoesCanceladasDTO implements Serializable{
	private static final long serialVersionUID = 319600724876951910L;
	
	public final String SITU = "C"; 
	
	private AtributosDaSessao session;
	private AtributosDaAplicacao aplicacao;
	private Date dataDe;
	private Date dataAte;
	private long codGrupo;
	private Date dataCancelamento;

	public ConsultaAutorizacoesCanceladasDTO(){
		//Utilizado na classe AutorizacoesConsultarDadosBBean
	}
	
	public ConsultaAutorizacoesCanceladasDTO(AtributosDaSessao session, AtributosDaAplicacao aplicacao, Date dataDe,
			Date dataAte) {
		super();
		this.session = session;
		this.aplicacao = aplicacao;
		this.dataDe = dataDe;
		this.dataAte = dataAte;
	}

	public AtributosDaSessao getSession() {
		return session;
	}
	public void setSession(AtributosDaSessao session) {
		this.session = session;
	}
	public AtributosDaAplicacao getAplicacao() {
		return aplicacao;
	}
	public void setAplicacao(AtributosDaAplicacao aplicacao) {
		this.aplicacao = aplicacao;
	}
	public Date getDataDe() {
		return dataDe;
	}
	public void setDataDe(Date dataDe) {
		this.dataDe = dataDe;
	}
	public Date getDataAte() {
		return dataAte;
	}
	public void setDataAte(Date dataAte) {
		this.dataAte = dataAte;
	}

	public long getCodGrupo() {
		return codGrupo;
	}

	public void setCodGrupo(long codGrupo) {
		this.codGrupo = codGrupo;
	}

	public Date getDataCancelamento() {
		return dataCancelamento;
	}

	public void setDataCancelamento(Date dataCancelamento) {
		this.dataCancelamento = dataCancelamento;
	}

}
