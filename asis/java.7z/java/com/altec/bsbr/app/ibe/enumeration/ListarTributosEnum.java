package com.altec.bsbr.app.ibe.enumeration;

import com.altec.bsbr.app.ibe.util.UtilFunction;

public enum ListarTributosEnum {
	
    IPVA (0, "IPVA", "8"),
    DPVAT(1, "DPVAT", "9"),
	LICENCIAMENTO(2, "Licenciamento", "2"),
	SEGVIA(3, "2� Via de Licenciamento", "4"),
	TRANSFERENCIA(4, "Transfer�ncia", "1"),
	SEGVIA_TRANSF(5, "2� Via de Transfer�ncia","5"),
	MULTAS_TRANSITO(6, "Multas de Tr�nsito", "10"),
	DEBITO_PENDENTE(7, "D�bitos Pendentes", "7"),
	REGISTRO_ESTADO(8, "1� Registro no Estado","6"),
	MULTAS_RENAINF(9, "Multas Renainf", "11"),
	TAXA(10, "Taxa Detran", "12"),
	TAXA_LICENCIAMENTO(11, "Taxa Licenciamento", "13");
	
	private Integer codigo;
	private String nome;
	private String codigoDeparaSeFaz;
	
	private ListarTributosEnum (Integer codigo, String nome, String codigoDeparaSeFaz) {
		this.codigo = codigo;
		this.nome = nome;
		this.codigoDeparaSeFaz = codigoDeparaSeFaz;
	}
	
	public Integer getCodigo() {
		return codigo;
	}
	
	public String getNome() {
		return nome;
	}
	
	public String getCodigoDeparaSeFaz() {
		return codigoDeparaSeFaz;
	}
	
	public static ListarTributosEnum findByCodigo(Integer codigo) {
		ListarTributosEnum retorno = null;

		if (UtilFunction.isNotBlankOrNull(codigo)) {
			for (ListarTributosEnum item : values()) {
				if (item.getCodigo().equals(codigo)) {
					retorno = item;
					break;
				}
			}
		}

		return retorno;
	}

}