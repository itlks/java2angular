package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class SegundaViaCodBarrasVeiculos implements Serializable {

	private static final long serialVersionUID = 1L;

	private List<String> segundaViaCodBarrasVeiculosList = new ArrayList<String>();

	public List<String> getSegundaViaCodBarrasVeiculosList() {
		return segundaViaCodBarrasVeiculosList;
	}

	public void setSegundaViaCodBarrasVeiculosList(List<String> segundaViaCodBarrasVeiculosList) {
		this.segundaViaCodBarrasVeiculosList = segundaViaCodBarrasVeiculosList;
	}

}
