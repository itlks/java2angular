package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class ExtratoMovimentacaoDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5378970033135046601L;
	private String canal;
	private String banco;
	private String agencia;
	private String conta;
	private String transacao;
	private String dataAtual;
	private String fundo;
	private String quantidadeDias;
	private String modeloWeb;
	private String penumper;
	private String indicadorRestart;
	private String itemRestart;
	private String pagina;
	public Integer periodo;

	public String getCanal() {
		return canal;
	}

	public void setCanal(String canal) {
		this.canal = canal;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = "Santander";
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getConta() {
		return conta;
	}

	public void setConta(String conta) {
		this.conta = conta;
	}

	public String getTransacao() {
		return transacao;
	}

	public void setTransacao(String transacao) {
		this.transacao = transacao;
	}

	public String getFundo() {
		return fundo;
	}

	public void setFundo(String fundo) {
		this.fundo = fundo;
	}

	public String getQuantidadeDias() {
		return quantidadeDias;
	}

	public void setQuantidadeDias(String quantidadeDias) {
		this.quantidadeDias = quantidadeDias;
	}

	public String getModeloWeb() {
		return modeloWeb;
	}

	public void setModeloWeb(String modeloWeb) {
		this.modeloWeb = modeloWeb;
	}

	public String getPenumper() {
		return penumper;
	}

	public void setPenumper(String penumper) {
		this.penumper = penumper;
	}

	public String getIndicadorRestart() {
		return indicadorRestart;
	}

	public void setIndicadorRestart(String indicadorRestart) {
		this.indicadorRestart = indicadorRestart;
	}

	public String getItemRestart() {
		return itemRestart;
	}

	public void setItemRestart(String itemRestart) {
		this.itemRestart = itemRestart;
	}

	public String getPagina() {
		return pagina;
	}

	public void setPagina(String pagina) {
		this.pagina = pagina;
	}

	public String getDataAtual() {
		return dataAtual;
	}

	public void setDataAtual(String dataAtual) {
		this.dataAtual = dataAtual;
	}

	public Integer getPeriodo() {
		return periodo;
	}

	public void setTempoPeriodo(Integer periodo) {
		this.periodo = periodo;
	}
	
	
}

