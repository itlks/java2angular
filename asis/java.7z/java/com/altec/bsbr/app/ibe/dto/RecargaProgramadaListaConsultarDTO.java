package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.altec.bsbr.app.ibe.anotation.Hash;
import com.altec.bsbr.app.ibe.dto.pendencia.RetornoConsultaPendencia;
import com.altec.bsbr.fw.converter.BigDecimalConverter;
import com.altec.bsbr.fw.converter.NumberConverter;

public class RecargaProgramadaListaConsultarDTO implements Serializable {

	/**
	* 
	 */
	private static final long serialVersionUID = 2077083052364699360L;

	private String nomeOperadora;
	private String numeroDdd;
	private String prefixoDddTelefone;
	private String periodicidade;
	private String descricaoPeriodicidade;
	private Integer situacao;
	private String descSituacao;
	private BigDecimal valor;
	private Date dataInicial;
	private Date dataInclusaoProgramacao;
	private Date dataProxParcela;
	private Date prazo;
	private String canal;
	private Date dataCancelamento;
	private String motivoCancelamento;
	private String telefoneFormatado;
	private String numeroTelefoneFormatado;
    @Hash(position=1)
	private Integer numeroTelefone;
	private RecargaProgamacaoDTO programacao = new RecargaProgamacaoDTO();
	private String tpCancelamento;
	private boolean mostrarBotoes;
	private boolean exluirProgramacao;
	private boolean programacaoProxima;
	private String dataformatada;
	private BancoDTO contratoOperadora;
	RetornoConsultaPendencia consultarPendencia = new RetornoConsultaPendencia();
	private String numeroProtocolo;
	private String numeroTransacao;
	private Date dataHoraTransacao;
	private String digitoVerificador;
	private String indAgendamento;
	private String indSmsAgendamento;

	public String prefixoDddEmpresa;

	public String getNomeOperadora() {
		return nomeOperadora;
	}

	public void setNomeOperadora(String nomeOperadora) {
		this.nomeOperadora = nomeOperadora;
	}

	public String getPrefixoDddTelefone() {
		return prefixoDddTelefone;
	}

	public void setPrefixoDddTelefone(String prefixoDddTelefone) {
		this.prefixoDddTelefone = prefixoDddTelefone;
	}

	public String getPeriodicidade() {
		return periodicidade;
	}

	public void setPeriodicidade(String periodicidade) {
		this.periodicidade = periodicidade;
	}

	public Integer getSituacao() {
		return situacao;
	}

	public void setSituacao(Integer situacao) {
		this.situacao = situacao;
	}

	public BigDecimal getValor() {
		return valor;
	}

	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}

	public Date getDataInicial() {
		return dataInicial;
	}

	public void setDataInicial(Date dataInicial) {
		this.dataInicial = dataInicial;
	}

	public Date getDataInclusaoProgramacao() {
		return dataInclusaoProgramacao;
	}

	public void setDataInclusaoProgramacao(Date dataInclusaoProgramacao) {
		this.dataInclusaoProgramacao = dataInclusaoProgramacao;
	}

	public Date getPrazo() {
		return prazo;
	}

	public void setPrazo(Date prazo) {
		this.prazo = prazo;
	}

	public String getCanal() {
		return canal;
	}

	public void setCanal(String canal) {
		this.canal = canal;
	}

	public Date getDataCancelamento() {
		return dataCancelamento;
	}

	public void setDataCancelamento(Date dataCancelamento) {
		this.dataCancelamento = dataCancelamento;
	}

	public String getMotivoCancelamento() {
		return motivoCancelamento;
	}

	public void setMotivoCancelamento(String motivoCancelamento) {
		this.motivoCancelamento = motivoCancelamento;
	}

	public String getNumeroTelefoneFormatado() {
		return numeroTelefoneFormatado;
	}

	public void setNumeroTelefoneFormatado(String numeroTelefoneFormatado) {
		this.numeroTelefoneFormatado = numeroTelefoneFormatado;
	}

	public String getDescSituacao() {
		return descSituacao;
	}

	public void setDescSituacao(String descSituacao) {
		this.descSituacao = descSituacao;
	}

	public RecargaProgamacaoDTO getProgramacao() {
		return programacao;
	}

	public void setProgramacao(RecargaProgamacaoDTO programacao) {
		this.programacao = programacao;
	}

	public boolean isExluirProgramacao() {
		return exluirProgramacao;
	}

	public void setExluirProgramacao(boolean exluirProgramacao) {
		this.exluirProgramacao = exluirProgramacao;
	}

	public boolean isProgramacaoProxima() {
		return programacaoProxima;
	}

	public void setProgramacaoProxima(boolean programacaoProxima) {
		this.programacaoProxima = programacaoProxima;
	}

	public boolean isMostrarBotoes() {
		return mostrarBotoes;
	}

	public void setMostrarBotoes(boolean mostrarBotoes) {
		this.mostrarBotoes = mostrarBotoes;
	}

	public String getDataformatada() {
		return dataformatada;
	}

	public void setDataformatada(String dataformatada) {
		this.dataformatada = dataformatada;
	}

	public String getTpCancelamento() {
		return tpCancelamento;
	}

	public void setTpCancelamento(String tpCancelamento) {
		this.tpCancelamento = tpCancelamento;
	}

	public Integer getNumeroTelefone() {
		return numeroTelefone;
	}

	public void setNumeroTelefone(Integer numeroTelefone) {
		this.numeroTelefone = numeroTelefone;
	}

	public BancoDTO getContratoOperadora() {
		return contratoOperadora;
	}

	public void setContratoOperadora(BancoDTO contratoOperadora) {
		this.contratoOperadora = contratoOperadora;
	}

	public String getNumeroDdd() {
		return numeroDdd;
	}

	public void setNumeroDdd(String numeroDdd) {
		this.numeroDdd = numeroDdd;
	}

	public String getNumeroProtocolo() {
		return numeroProtocolo;
	}

	public void setNumeroProtocolo(String numeroProtocolo) {
		this.numeroProtocolo = numeroProtocolo;
	}

	public String getNumeroTransacao() {
		return numeroTransacao;
	}

	public void setNumeroTransacao(String numeroTransacao) {
		this.numeroTransacao = numeroTransacao;
	}

	public String getPrefixoDddEmpresa() {
		return prefixoDddEmpresa;
	}

	public void setPrefixoDddEmpresa(String prefixoDddEmpresa) {
		this.prefixoDddEmpresa = prefixoDddEmpresa;
	}

	public RetornoConsultaPendencia getConsultarPendencia() {
		return consultarPendencia;
	}

	public void setConsultarPendencia(RetornoConsultaPendencia consultarPendencia) {
		this.consultarPendencia = consultarPendencia;
	}

	public String getDescricaoPeriodicidade() {
		return descricaoPeriodicidade;
	}

	public void setDescricaoPeriodicidade(String descricaoPeriodicidade) {
		this.descricaoPeriodicidade = descricaoPeriodicidade;
	}

	public String getDigitoVerificador() {
		return digitoVerificador;
	}

	public void setDigitoVerificador(String digitoVerificador) {
		this.digitoVerificador = digitoVerificador;
	}

	public Date getDataHoraTransacao() {
		return dataHoraTransacao;
	}

	public void setDataHoraTransacao(Date dataHoraTransacao) {
		this.dataHoraTransacao = dataHoraTransacao;
	}

	public String getIndAgendamento() {
		return indAgendamento;
	}

	public void setIndAgendamento(String indAgendamento) {
		this.indAgendamento = indAgendamento;
	}

	public String getIndSmsAgendamento() {
		return indSmsAgendamento;
	}

	public void setIndSmsAgendamento(String indSmsAgendamento) {
		this.indSmsAgendamento = indSmsAgendamento;
	}

	public Date getDataProxParcela() {
		return dataProxParcela;
	}

	public void setDataProxParcela(Date dataProxParcela) {
		this.dataProxParcela = dataProxParcela;
	}

	public String getTelefoneFormatado() {
		return telefoneFormatado;
	}

	public void setTelefoneFormatado(String telefoneFormatado) {
		this.telefoneFormatado = telefoneFormatado;
	}

}
