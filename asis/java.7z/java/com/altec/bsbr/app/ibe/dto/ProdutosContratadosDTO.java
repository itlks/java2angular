package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;

public class ProdutosContratadosDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8581797345778504396L;

	private String produto;
	private String prazo;
	private String codBandeira;
	private String descBandeira;
	private BigDecimal vlTarifa;
	private BigDecimal taxa;
	private String cnpjEstabelecimento;
	private String codEstabelecimento;

	private String prazoFormatado;

	public String getProduto() {
		return produto;
	}

	public void setProduto(String produto) {
		this.produto = produto;
	}

	public String getPrazo() {
		return prazo;
	}

	public void setPrazo(String prazo) {
		this.prazo = prazo;
	}

	public BigDecimal getVlTarifa() {
		return vlTarifa;
	}

	public void setVlTarifa(BigDecimal vlTarifa) {
		this.vlTarifa = vlTarifa;
	}

	public BigDecimal getTaxa() {
		return taxa;
	}

	public void setTaxa(BigDecimal taxa) {
		this.taxa = taxa;
	}

	public String getCodBandeira() {
		return codBandeira;
	}

	public void setCodBandeira(String codBandeira) {
		this.codBandeira = codBandeira;
	}

	public String getDescBandeira() {
		return descBandeira;
	}

	public void setDescBandeira(String descBandeira) {
		this.descBandeira = descBandeira;
	}

	public String getCodEstabelecimento() {
		return codEstabelecimento;
	}

	public void setCodEstabelecimento(String codEstabelecimento) {
		this.codEstabelecimento = codEstabelecimento;
	}

	public String getPrazoFormatado() {
		return prazoFormatado;
	}

	public void setPrazoFormatado(String prazoFormatado) {
		this.prazoFormatado = prazoFormatado;
	}

	public String getCnpjEstabelecimento() {
		return cnpjEstabelecimento;
	}

	public void setCnpjEstabelecimento(String cnpjEstabelecimento) {
		this.cnpjEstabelecimento = cnpjEstabelecimento;
	}

}
