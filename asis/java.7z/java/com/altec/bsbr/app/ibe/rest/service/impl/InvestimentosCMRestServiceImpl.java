package com.altec.bsbr.app.ibe.rest.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.altec.bsbr.app.ibe.dto.investimentos.posicaomensal.AltairMessage;
import com.altec.bsbr.app.ibe.dto.investimentos.posicaomensal.AltairWarning;
import com.altec.bsbr.app.ibe.dto.investimentos.posicaomensal.InvestimentosCMPosicaoRequestDTO;
import com.altec.bsbr.app.ibe.dto.investimentos.posicaomensal.InvestimentosCMPosicaoResponseDTO;
import com.altec.bsbr.app.ibe.rest.hub.HubRest;
import com.altec.bsbr.app.ibe.rest.hub.dto.HubRestResourceDTO;
import com.altec.bsbr.app.ibe.rest.service.InvestimentosCMRestService;

/**
 * 
 * @author x187169 - Julio R.G. Leme
 * @since 2017-03-22
 * @version 1.0
 * <p>Implementacao de Servico Rest para a funcionalidade de Investimentos - Consulta Posicao Mensal Conta Max e Extrato</p>
 * <p>F-532 / F-533</p>
 *
 */
@Service
public class InvestimentosCMRestServiceImpl implements InvestimentosCMRestService {
	
	public static final Logger LOGGER = LoggerFactory.getLogger(InvestimentosCMRestServiceImpl.class);
	
	@Autowired private HubRest hubRest;
	@Autowired @Qualifier("contaMaxEmpresarial") private HubRestResourceDTO resource;
	
	@Override
	public InvestimentosCMPosicaoResponseDTO consultaPosicaoMensal(InvestimentosCMPosicaoRequestDTO request) {
		InvestimentosCMPosicaoResponseDTO investimentosCMPosicaoResponseDTO = new InvestimentosCMPosicaoResponseDTO();
		try {
			
			ResponseEntity<InvestimentosCMPosicaoResponseDTO> response = hubRest.postForEntity(resource.getUrl(), request, InvestimentosCMPosicaoResponseDTO.class);
			if ( response.getStatusCode().value() == 200 ){
				investimentosCMPosicaoResponseDTO = response.getBody();
				LOGGER.debug("CONSULTA DE POSICAO MENSAL CONTA MAX HubRest Consultado com SUCESSO !!!!");
			}
		} catch (Exception e) {
			AltairMessage altairMessage = investimentosCMPosicaoResponseDTO.getAltairMessage().get(0);
			String msg = e.getMessage();
			AltairWarning altairWarning = altairMessage.getAltairWarning().get(0);
			altairWarning.setWarningMessage(msg);
			String msgError = altairWarning.getWarningMessage();
			LOGGER.error("Exception [InvestimentoHomeRestServiceImpl] consultarInvestimentosContaMax : [{}]" , msgError);
		}
		return investimentosCMPosicaoResponseDTO;
	}

}