package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class ConsContratoMRSDTO extends GenericDTO implements Serializable{

	private static final long serialVersionUID = 7974154163482336718L;
	
	private String codigoMensajeOk;
    private String contrMRS;
    private String pan;
    private String nomePort;
    
    private String codigoBanco;
    private String codigoAgencia;
    private String numeroContrato;
    
    @SuppressWarnings("unused")
	private String concatContrato;
    
    private String cnpj;
	
    
	public String getConcatContrato() {
		return codigoBanco + codigoAgencia + numeroContrato;
	}

	public String getCodigoMensajeOk() {
		return codigoMensajeOk;
	}
	public void setCodigoMensajeOk(String codigoMensajeOk) {
		this.codigoMensajeOk = codigoMensajeOk;
	}

	public String getContrMRS() {
		return contrMRS;
	}
	public void setContrMRS(String contrMRS) {
		this.contrMRS = contrMRS;
	}
	public String getPan() {
		return pan;
	}
	public void setPan(String pan) {
		this.pan = pan;
	}
	public String getNomePort() {
		return nomePort;
	}
	public void setNomePort(String nomePort) {
		this.nomePort = nomePort;
	}
	public String getCodigoBanco() {
		return codigoBanco;
	}
	public void setCodigoBanco(String codigoBanco) {
		this.codigoBanco = codigoBanco;
	}
	public String getCodigoAgencia() {
		return codigoAgencia;
	}
	public void setCodigoAgencia(String codigoAgencia) {
		this.codigoAgencia = codigoAgencia;
	}
	public String getNumeroContrato() {
		return numeroContrato;
	}
	public void setNumeroContrato(String numeroContrato) {
		this.numeroContrato = numeroContrato;
	}
	public String getCnpj() {
		return cnpj;
	}
	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}
    
}
