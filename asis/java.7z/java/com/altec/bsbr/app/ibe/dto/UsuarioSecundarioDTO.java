package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.List;

import com.altec.bsbr.app.ibe.util.WSFormat;
import com.altec.bsbr.app.ibe.util.WSFormat.Position;

public class UsuarioSecundarioDTO implements Serializable{

	private static final long serialVersionUID = 3563815215242904789L;
	
	private Integer idUsuario;
	private String nomeUsuario;
	private String nomeLogon;
	private String nomeArea;
	private String nrCpf;
	private String inAcesMobl;
	private String nrTelefone;
	private String nrCelular;
	private String habilitado;
	private String novaSenha;
	private String senhaConfirmacao;
	private String senhaHash;
	private String novaAssinatura;
	private String confirmacaoAssinatura;
	private String assinaturaHash;
	private List<UsuarioAtribuirPerfilDTO> listaPerfilAtribuidos;
	private int pendenciaAcesso;
	private int pendenciaAutorizacao;
	private String altAcesso;
	private String altAutorizacao;
	private String msgErroJavaStript;
	private String voltar;
	
	public String getVoltar() {
		return voltar;
	}

	public void setVoltar(String voltar) {
		this.voltar = voltar;
	}

	public Integer getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}

	public String getNomeUsuario() {
		return nomeUsuario;
	}

	public void setNomeUsuario(String nomeUsuario) {
		this.nomeUsuario = nomeUsuario;
	}

	public String getNomeLogon() {
		return nomeLogon;
	}

	public void setNomeLogon(String nomeLogon) {
		this.nomeLogon = nomeLogon;
	}

	public String getNomeArea() {
		return nomeArea;
	}

	public void setNomeArea(String nomeArea) {
		this.nomeArea = nomeArea;
	}

	public String getNrCpf() {
		return WSFormat.getFormatString(this.nrCpf, 11, "0", Position.RIGHT);
	}

	public void setNrCpf(String nrCpf) {
		this.nrCpf = nrCpf;
	}

	public String getInAcesMobl() {
		return inAcesMobl;
	}

	public void setInAcesMobl(String inAcesMobl) {
		this.inAcesMobl = inAcesMobl;
	}

	public String getNrTelefone() {
		return nrTelefone;
	}

	public void setNrTelefone(String nrTelefone) {
		this.nrTelefone = nrTelefone;
	}

	public String getNrCelular() {
		return nrCelular;
	}

	public void setNrCelular(String nrCelular) {
		this.nrCelular = nrCelular;
	}

	public String getHabilitado() {
		return habilitado;
	}

	

	public void setHabilitado(String habilitado) {
		this.habilitado = habilitado;
	}

	public String getNovaSenha() {
		return novaSenha;
	}

	public void setNovaSenha(String novaSenha) {
		this.novaSenha = novaSenha;
	}
	
	public String getSenhaConfirmacao() {
		return senhaConfirmacao;
	}

	public void setSenhaConfirmacao(String senhaConfirmacao) {
		this.senhaConfirmacao = senhaConfirmacao;
	}

	public String getSenhaHash() {
		return senhaHash;
	}

	public void setSenhaHash(String senhaHash) {
		this.senhaHash = senhaHash;
	}
	
	public String getNovaAssinatura() {
		return novaAssinatura;
	}

	public void setNovaAssinatura(String novaAssinatura) {
		this.novaAssinatura = novaAssinatura;
	}

	

	public String getConfirmacaoAssinatura() {
		return confirmacaoAssinatura;
	}

	public int getPendenciaAcesso() {
		return pendenciaAcesso;
	}

	public void setPendenciaAcesso(int pendenciaAcesso) {
		this.pendenciaAcesso = pendenciaAcesso;
	}

	public int getPendenciaAutorizacao() {
		return pendenciaAutorizacao;
	}

	public void setPendenciaAutorizacao(int pendenciaAutorizacao) {
		this.pendenciaAutorizacao = pendenciaAutorizacao;
	}

	public void setConfirmacaoAssinatura(String confirmacaoAssinatura) {
		this.confirmacaoAssinatura = confirmacaoAssinatura;
	}

	public String getAssinaturaHash() {
		return assinaturaHash;
	}

	public void setAssinaturaHash(String assinaturaHash) {
		this.assinaturaHash = assinaturaHash;
	}

	public String getMsgErroJavaStript() {
		return msgErroJavaStript;
	}

	public void setMsgErroJavaStript(String msgErroJavaStript) {
		this.msgErroJavaStript = msgErroJavaStript;
	}

	public List<UsuarioAtribuirPerfilDTO> getListaPerfilAtribuidos() {
		return listaPerfilAtribuidos;
	}

	public void setListaPerfilAtribuidos(List<UsuarioAtribuirPerfilDTO> listaPerfilAtribuidos) {
		this.listaPerfilAtribuidos = listaPerfilAtribuidos;
	}

	public String getAltAcesso() {
		return altAcesso;
	}

	public void setAltAcesso(String altAcesso) {
		this.altAcesso = altAcesso;
	}

	public String getAltAutorizacao() {
		return altAutorizacao;
	}

	public void setAltAutorizacao(String altAutorizacao) {
		this.altAutorizacao = altAutorizacao;
	}
}
