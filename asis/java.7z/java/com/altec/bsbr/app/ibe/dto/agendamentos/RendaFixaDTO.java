package com.altec.bsbr.app.ibe.dto.agendamentos;

public class RendaFixaDTO {

	private String numeroDoContratoCDB;
	private String taxaDoCdb;
	private String prazoDoCdb;
	
	
	
	public String getNumeroDoContratoCDB() {
		return numeroDoContratoCDB;
	}
	public void setNumeroDoContratoCDB(String numeroDoContratoCDB) {
		this.numeroDoContratoCDB = numeroDoContratoCDB;
	}
	public String getTaxaDoCdb() {
		return taxaDoCdb;
	}
	public void setTaxaDoCdb(String taxaDoCdb) {
		this.taxaDoCdb = taxaDoCdb;
	}
	public String getPrazoDoCdb() {
		return prazoDoCdb;
	}
	public void setPrazoDoCdb(String prazoDoCdb) {
		this.prazoDoCdb = prazoDoCdb;
	}
	
}
