package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class ItemMenuDetalheAcesso implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	private String idMenu;
	private String descricao;
	
	
	/**
	 * ItemMenuDetalheAcesso
	 */
	public ItemMenuDetalheAcesso() {}
	
	
	/**
	 * ItemMenuDetalheAcesso
	 * @param idMenu
	 * @param descricao
	 */
	public ItemMenuDetalheAcesso(String idMenu, String descricao) {
		super();
		this.idMenu = idMenu;
		this.descricao = descricao;
	}


	/**
	 * @return the idMenu
	 */
	public String getIdMenu() {
		return idMenu;
	}

	/**
	 * @param idMenu
	 *            the idMenu to set
	 */
	public void setIdMenu(String idMenu) {
		this.idMenu = idMenu;
	}

	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}

	/**
	 * @param descricao
	 *            the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

}