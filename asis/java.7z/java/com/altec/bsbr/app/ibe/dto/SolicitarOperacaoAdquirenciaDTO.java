package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import com.altec.bsbr.app.ibe.anotation.Hash;
import com.altec.bsbr.app.ibe.dto.clsrecebiveisantec.PLFormalizaFluxosCartoesSaidaDTO;
import com.altec.bsbr.app.ibe.dto.clsrecebiveisantec.PLSelecaoFluxosCartoesSaidaDTO;
import com.altec.bsbr.app.ibe.enumeration.ListaBandeiraOperacaoAdquirenciaEnum;

public class SolicitarOperacaoAdquirenciaDTO implements Serializable {

	private static final long serialVersionUID = 9108686522815252296L;
	
	/**
	 * Atributos ordenados por p�gina
	 */
	// Consulta
	@Hash(position = 1)
	private String estabelecimento;
	
	private ListaBandeiraOperacaoAdquirenciaEnum bandeiraSelecionada;
	// Contrata��o
	private String tipoBandeiraSelecionada;
	private BigDecimal vlrTotDisponivel;
	private BigDecimal vlrSelecionado;
	private List<ListaPLConsultaFluxoCartoesDTO> listaPLConsultaFluxoCartoesVisa;
	private List<ListaPLConsultaFluxoCartoesDTO> listaPLConsultaFluxoCartoesMaster;
	private List<ListaPLConsultaFluxoCartoesDTO> listaPLConsultaFluxoCartoesVisaSelecionados;
	private List<ListaPLConsultaFluxoCartoesDTO> listaPLConsultaFluxoCartoesMasterSelecionados;
	// Resumo (Confirma��o)
	private PLSelecaoFluxosCartoesSaidaDTO plSelecaoFluxosCartoesSaidaDTO;
	private String nrOperacao;
	private String flagErro;
	private String tipoDocumento;
	private String nrDocumento;
	private String penumper;
	private String nomeCliente;
	private String dataOperacao;
	private String prazoMedioEmDias;
	private String dataUltimoVcto;
	private BigDecimal tarifaOperacao;
	private BigDecimal taxaOperacaoNominal;
	private BigDecimal vlrBruto;
	private BigDecimal vlrIOF;
	private BigDecimal jurosDevidos;
	private BigDecimal vlrLiquido;

	private List<ListaPLSelecaoFluxosCartoesSubTotalDTO> listaPLSelecaoFluxosCartoesSubTotalDTO;
	private BigDecimal vlrTotal;
	// Comprovante
	private PLFormalizaFluxosCartoesSaidaDTO plFormalizaFluxosCartoesSaidaDTO;
	
	private String autenticacaoBancaria;
	private String dataHoraTransacao;
	private String autenticacaoDigital;
	
	// Resumo

	private String resumoNrOperacao;
	private String resumoNomeCliente;
	private String resumoTipoDocumento;
	private String resumoNumeroDocumento;
	private String resumoNumeroAgencia;
	private String resumoNomeAgencia;
	private String resumoContaCorrente;
	
	private String resumoDataOperacao;
	private BigDecimal resumoPrazoMedioEmDias;
	private String resumoDataUltimoVcto;
	private BigDecimal resumoTaxaAntecipacao;
	
	private BigDecimal resumoValorOperacao;
	private BigDecimal resumoValorTaxaAntecipacao;
	private BigDecimal resumoTarifaContratacao;
	private BigDecimal resumoVlrIOF;
	private BigDecimal resumoValorLiquido;
	
	private String resumoAutenticacaoBancaria;

	private List<ListaResumoOperSubTotalDTO> listaResumoOperSubTotalDTO;
	/**
	 * Getters e Setters respectivos 
	 */

	public String getEstabelecimento() {
		return estabelecimento;
	}
	public void setEstabelecimento(String estabelecimento) {
		this.estabelecimento = estabelecimento;
	}
	public ListaBandeiraOperacaoAdquirenciaEnum getBandeiraSelecionada() {
		return bandeiraSelecionada;
	}
	public void setBandeiraSelecionada(ListaBandeiraOperacaoAdquirenciaEnum bandeiraSelecionada) {
		this.bandeiraSelecionada = bandeiraSelecionada;
	}
	public String getTipoBandeiraSelecionada() {
		return tipoBandeiraSelecionada;
	}
	public void setTipoBandeiraSelecionada(String tipoBandeiraSelecionada) {
		this.tipoBandeiraSelecionada = tipoBandeiraSelecionada;
	}
	public BigDecimal getVlrTotDisponivel() {
		return vlrTotDisponivel;
	}
	public void setVlrTotDisponivel(BigDecimal vlrTotDisponivel) {
		this.vlrTotDisponivel = vlrTotDisponivel;
	}
	public BigDecimal getVlrSelecionado() {
		return vlrSelecionado;
	}
	public void setVlrSelecionado(BigDecimal vlrSelecionado) {
		this.vlrSelecionado = vlrSelecionado;
	}
	public List<ListaPLConsultaFluxoCartoesDTO> getListaPLConsultaFluxoCartoesVisa() {
		return listaPLConsultaFluxoCartoesVisa;
	}
	public void setListaPLConsultaFluxoCartoesVisa(List<ListaPLConsultaFluxoCartoesDTO> listaPLConsultaFluxoCartoesVisa) {
		this.listaPLConsultaFluxoCartoesVisa = listaPLConsultaFluxoCartoesVisa;
	}
	public List<ListaPLConsultaFluxoCartoesDTO> getListaPLConsultaFluxoCartoesMaster() {
		return listaPLConsultaFluxoCartoesMaster;
	}
	public void setListaPLConsultaFluxoCartoesMaster(
			List<ListaPLConsultaFluxoCartoesDTO> listaPLConsultaFluxoCartoesMaster) {
		this.listaPLConsultaFluxoCartoesMaster = listaPLConsultaFluxoCartoesMaster;
	}
	public List<ListaPLConsultaFluxoCartoesDTO> getListaPLConsultaFluxoCartoesVisaSelecionados() {
		return listaPLConsultaFluxoCartoesVisaSelecionados;
	}
	public void setListaPLConsultaFluxoCartoesVisaSelecionados(
			List<ListaPLConsultaFluxoCartoesDTO> listaPLConsultaFluxoCartoesVisaSelecionados) {
		this.listaPLConsultaFluxoCartoesVisaSelecionados = listaPLConsultaFluxoCartoesVisaSelecionados;
	}
	public List<ListaPLConsultaFluxoCartoesDTO> getListaPLConsultaFluxoCartoesMasterSelecionados() {
		return listaPLConsultaFluxoCartoesMasterSelecionados;
	}
	public void setListaPLConsultaFluxoCartoesMasterSelecionados(
			List<ListaPLConsultaFluxoCartoesDTO> listaPLConsultaFluxoCartoesMasterSelecionados) {
		this.listaPLConsultaFluxoCartoesMasterSelecionados = listaPLConsultaFluxoCartoesMasterSelecionados;
	}
	public PLSelecaoFluxosCartoesSaidaDTO getPlSelecaoFluxosCartoesSaidaDTO() {
		return plSelecaoFluxosCartoesSaidaDTO;
	}
	public void setPlSelecaoFluxosCartoesSaidaDTO(PLSelecaoFluxosCartoesSaidaDTO plSelecaoFluxosCartoesSaidaDTO) {
		this.plSelecaoFluxosCartoesSaidaDTO = plSelecaoFluxosCartoesSaidaDTO;
	}
	public String getNrOperacao() {
		return nrOperacao;
	}
	public void setNrOperacao(String nrOperacao) {
		this.nrOperacao = nrOperacao;
	}
	public String getFlagErro() {
		return flagErro;
	}
	public void setFlagErro(String flagErro) {
		this.flagErro = flagErro;
	}
	public String getTipoDocumento() {
		return tipoDocumento;
	}
	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}
	public String getNrDocumento() {
		return nrDocumento;
	}
	public void setNrDocumento(String nrDocumento) {
		this.nrDocumento = nrDocumento;
	}
	public String getPenumper() {
		return penumper;
	}
	public void setPenumper(String penumper) {
		this.penumper = penumper;
	}
	public String getNomeCliente() {
		return nomeCliente;
	}
	public void setNomeCliente(String nomeCliente) {
		this.nomeCliente = nomeCliente;
	}
	public String getDataOperacao() {
		return dataOperacao;
	}
	public void setDataOperacao(String dataOperacao) {
		this.dataOperacao = dataOperacao;
	}
	public String getPrazoMedioEmDias() {
		return prazoMedioEmDias;
	}
	public void setPrazoMedioEmDias(String prazoMedioEmDias) {
		this.prazoMedioEmDias = prazoMedioEmDias;
	}
	public String getDataUltimoVcto() {
		return dataUltimoVcto;
	}
	public void setDataUltimoVcto(String dataUltimoVcto) {
		this.dataUltimoVcto = dataUltimoVcto;
	}
	public BigDecimal getTarifaOperacao() {
		return tarifaOperacao;
	}
	public void setTarifaOperacao(BigDecimal tarifaOperacao) {
		this.tarifaOperacao = tarifaOperacao;
	}
	public BigDecimal getTaxaOperacaoNominal() {
		return taxaOperacaoNominal;
	}
	public void setTaxaOperacaoNominal(BigDecimal taxaOperacaoNominal) {
		this.taxaOperacaoNominal = taxaOperacaoNominal;
	}
	public BigDecimal getVlrBruto() {
		return vlrBruto;
	}
	public void setVlrBruto(BigDecimal vlrBruto) {
		this.vlrBruto = vlrBruto;
	}
	public BigDecimal getVlrIOF() {
		return vlrIOF;
	}
	public void setVlrIOF(BigDecimal vlrIOF) {
		this.vlrIOF = vlrIOF;
	}
	public BigDecimal getJurosDevidos() {
		return jurosDevidos;
	}
	public void setJurosDevidos(BigDecimal jurosDevidos) {
		this.jurosDevidos = jurosDevidos;
	}
	public BigDecimal getVlrLiquido() {
		return vlrLiquido;
	}
	public void setVlrLiquido(BigDecimal vlrLiquido) {
		this.vlrLiquido = vlrLiquido;
	}
	public List<ListaPLSelecaoFluxosCartoesSubTotalDTO> getListaPLSelecaoFluxosCartoesSubTotalDTO() {
		return listaPLSelecaoFluxosCartoesSubTotalDTO;
	}
	public void setListaPLSelecaoFluxosCartoesSubTotalDTO(List<ListaPLSelecaoFluxosCartoesSubTotalDTO> listaPLSelecaoFluxosCartoesSubTotalDTO) {
		this.listaPLSelecaoFluxosCartoesSubTotalDTO = listaPLSelecaoFluxosCartoesSubTotalDTO;
	}
	public BigDecimal getVlrTotal() {
		return vlrTotal;
	}
	public void setVlrTotal(BigDecimal vlrTotal) {
		this.vlrTotal = vlrTotal;
	}
	public PLFormalizaFluxosCartoesSaidaDTO getPlFormalizaFluxosCartoesSaidaDTO() {
		return plFormalizaFluxosCartoesSaidaDTO;
	}
	public void setPlFormalizaFluxosCartoesSaidaDTO(PLFormalizaFluxosCartoesSaidaDTO plFormalizaFluxosCartoesSaidaDTO) {
		this.plFormalizaFluxosCartoesSaidaDTO = plFormalizaFluxosCartoesSaidaDTO;
	}
	public String getAutenticacaoBancaria() {
		return autenticacaoBancaria;
	}
	public void setAutenticacaoBancaria(String autenticacaoBancaria) {
		this.autenticacaoBancaria = autenticacaoBancaria;
	}
	public String getDataHoraTransacao() {
		return dataHoraTransacao;
	}
	public void setDataHoraTransacao(String dataHoraTransacao) {
		this.dataHoraTransacao = dataHoraTransacao;
	}
	public String getAutenticacaoDigital() {
		return autenticacaoDigital;
	}
	public void setAutenticacaoDigital(String autenticacaoDigital) {
		this.autenticacaoDigital = autenticacaoDigital;
	}
	public String getResumoNrOperacao() {
		return resumoNrOperacao;
	}
	public void setResumoNrOperacao(String resumoNrOperacao) {
		this.resumoNrOperacao = resumoNrOperacao;
	}
	public String getResumoNomeCliente() {
		return resumoNomeCliente;
	}
	public void setResumoNomeCliente(String resumoNomeCliente) {
		this.resumoNomeCliente = resumoNomeCliente;
	}
	public String getResumoTipoDocumento() {
		return resumoTipoDocumento;
	}
	public void setResumoTipoDocumento(String resumoTipoDocumento) {
		this.resumoTipoDocumento = resumoTipoDocumento;
	}
	public String getResumoNumeroDocumento() {
		return resumoNumeroDocumento;
	}
	public void setResumoNumeroDocumento(String resumoNumeroDocumento) {
		this.resumoNumeroDocumento = resumoNumeroDocumento;
	}
	public String getResumoNumeroAgencia() {
		return resumoNumeroAgencia;
	}
	public void setResumoNumeroAgencia(String resumoNumeroAgencia) {
		this.resumoNumeroAgencia = resumoNumeroAgencia;
	}
	public String getResumoNomeAgencia() {
		return resumoNomeAgencia;
	}
	public void setResumoNomeAgencia(String resumoNomeAgencia) {
		this.resumoNomeAgencia = resumoNomeAgencia;
	}
	public String getResumoContaCorrente() {
		return resumoContaCorrente;
	}
	public void setResumoContaCorrente(String resumoContaCorrente) {
		this.resumoContaCorrente = resumoContaCorrente;
	}
	public String getResumoDataOperacao() {
		return resumoDataOperacao;
	}
	public void setResumoDataOperacao(String resumoDataOperacao) {
		this.resumoDataOperacao = resumoDataOperacao;
	}
	public BigDecimal getResumoPrazoMedioEmDias() {
		return resumoPrazoMedioEmDias;
	}
	public void setResumoPrazoMedioEmDias(BigDecimal resumoPrazoMedioEmDias) {
		this.resumoPrazoMedioEmDias = resumoPrazoMedioEmDias;
	}
	public String getResumoDataUltimoVcto() {
		return resumoDataUltimoVcto;
	}
	public void setResumoDataUltimoVcto(String resumoDataUltimoVcto) {
		this.resumoDataUltimoVcto = resumoDataUltimoVcto;
	}
	public BigDecimal getResumoTaxaAntecipacao() {
		return resumoTaxaAntecipacao;
	}
	public void setResumoTaxaAntecipacao(BigDecimal resumoTaxaAntecipacao) {
		this.resumoTaxaAntecipacao = resumoTaxaAntecipacao;
	}
	public BigDecimal getResumoValorOperacao() {
		return resumoValorOperacao;
	}
	public void setResumoValorOperacao(BigDecimal resumoValorOperacao) {
		this.resumoValorOperacao = resumoValorOperacao;
	}
	public BigDecimal getResumoValorTaxaAntecipacao() {
		return resumoValorTaxaAntecipacao;
	}
	public void setResumoValorTaxaAntecipacao(BigDecimal resumoValorTaxaAntecipacao) {
		this.resumoValorTaxaAntecipacao = resumoValorTaxaAntecipacao;
	}
	public BigDecimal getResumoTarifaContratacao() {
		return resumoTarifaContratacao;
	}
	public void setResumoTarifaContratacao(BigDecimal resumoTarifaContratacao) {
		this.resumoTarifaContratacao = resumoTarifaContratacao;
	}
	public BigDecimal getResumoVlrIOF() {
		return resumoVlrIOF;
	}
	public void setResumoVlrIOF(BigDecimal resumoVlrIOF) {
		this.resumoVlrIOF = resumoVlrIOF;
	}
	public BigDecimal getResumoValorLiquido() {
		return resumoValorLiquido;
	}
	public void setResumoValorLiquido(BigDecimal resumoValorLiquido) {
		this.resumoValorLiquido = resumoValorLiquido;
	}
	public String getResumoAutenticacaoBancaria() {
		return resumoAutenticacaoBancaria;
	}
	public void setResumoAutenticacaoBancaria(String resumoAutenticacaoBancaria) {
		this.resumoAutenticacaoBancaria = resumoAutenticacaoBancaria;
	}
	public List<ListaResumoOperSubTotalDTO> getListaResumoOperSubTotalDTO() {
		return listaResumoOperSubTotalDTO;
	}
	public void setListaResumoOperSubTotalDTO(List<ListaResumoOperSubTotalDTO> listaResumoOperSubTotalDTO) {
		this.listaResumoOperSubTotalDTO = listaResumoOperSubTotalDTO;
	}

}
