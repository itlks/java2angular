package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class CampoTabelaDTO implements Serializable {

	private static final long serialVersionUID = -4328581064956758112L;

	private int prioridade;
	private String descricaoCampo;
	private String valorCampo;
	private String tooltip;
	
	public CampoTabelaDTO(int prioridade, String descricao, String valor, String tooltip) {
		this.prioridade = prioridade;
		this.descricaoCampo = descricao;
		this.valorCampo = valor;
		this.tooltip = tooltip;
	}
	
	/**
	 * @return the descricaoCampo
	 */
	public String getDescricaoCampo() {
		return descricaoCampo;
	}
	/**
	 * @param descricaoCampo the descricaoCampo to set
	 */
	public void setDescricaoCampo(String descricaoCampo) {
		this.descricaoCampo = descricaoCampo;
	}
	/**
	 * @return the valorCampo
	 */
	public String getValorCampo() {
		return valorCampo;
	}
	/**
	 * @param valorCampo the valorCampo to set
	 */
	public void setValorCampo(String valorCampo) {
		this.valorCampo = valorCampo;
	}

	public int getPrioridade() {
		return prioridade;
	}

	public void setPrioridade(int prioridade) {
		this.prioridade = prioridade;
	}

	public String getTooltip() {
		return tooltip;
	}

	public void setTooltip(String tooltip) {
		this.tooltip = tooltip;
	}
}
