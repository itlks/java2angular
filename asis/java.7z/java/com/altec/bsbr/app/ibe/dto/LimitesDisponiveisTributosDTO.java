package com.altec.bsbr.app.ibe.dto;

public class LimitesDisponiveisTributosDTO {

	private String qtdeMaximaDiariaAutorizados;
	private String qtdeMaximaDiariaNaoAutorizados;
	private String valorMaximoDiarioAutorizado;
	private String valorMaximoDiarioNaoAutorizado;
	private String valorMaximoTransacao;
	private String valorMinimoTransacao;
	private String limiteGlobal;
	private String qtdeDisponivelAutorizado;
	private String valorDisponivelAutorizado;
	private String qtdeDisponivelNaoAutorizado;
	private String valorDisponivelNaoAutorizado;
	private String produto;
	private String subProduto;
	private String tipo;

	public String getQtdeMaximaDiariaAutorizados() {
		return qtdeMaximaDiariaAutorizados;
	}

	public void setQtdeMaximaDiariaAutorizados(String qtdeMaximaDiariaAutorizados) {
		this.qtdeMaximaDiariaAutorizados = qtdeMaximaDiariaAutorizados;
	}

	public String getQtdeMaximaDiariaNaoAutorizados() {
		return qtdeMaximaDiariaNaoAutorizados;
	}

	public void setQtdeMaximaDiariaNaoAutorizados(String qtdeMaximaDiariaNaoAutorizados) {
		this.qtdeMaximaDiariaNaoAutorizados = qtdeMaximaDiariaNaoAutorizados;
	}

	public String getValorMaximoDiarioAutorizado() {
		return valorMaximoDiarioAutorizado;
	}

	public void setValorMaximoDiarioAutorizado(String valorMaximoDiarioAutorizado) {
		this.valorMaximoDiarioAutorizado = valorMaximoDiarioAutorizado;
	}

	public String getValorMaximoDiarioNaoAutorizado() {
		return valorMaximoDiarioNaoAutorizado;
	}

	public void setValorMaximoDiarioNaoAutorizado(String valorMaximoDiarioNaoAutorizado) {
		this.valorMaximoDiarioNaoAutorizado = valorMaximoDiarioNaoAutorizado;
	}

	public String getValorMaximoTransacao() {
		return valorMaximoTransacao;
	}

	public void setValorMaximoTransacao(String valorMaximoTransacao) {
		this.valorMaximoTransacao = valorMaximoTransacao;
	}

	public String getValorMinimoTransacao() {
		return valorMinimoTransacao;
	}

	public void setValorMinimoTransacao(String valorMinimoTransacao) {
		this.valorMinimoTransacao = valorMinimoTransacao;
	}

	public String getLimiteGlobal() {
		return limiteGlobal;
	}

	public void setLimiteGlobal(String limiteGlobal) {
		this.limiteGlobal = limiteGlobal;
	}

	public String getQtdeDisponivelAutorizado() {
		return qtdeDisponivelAutorizado;
	}

	public void setQtdeDisponivelAutorizado(String qtdeDisponivelAutorizado) {
		this.qtdeDisponivelAutorizado = qtdeDisponivelAutorizado;
	}

	public String getValorDisponivelAutorizado() {
		return valorDisponivelAutorizado;
	}

	public void setValorDisponivelAutorizado(String valorDisponivelAutorizado) {
		this.valorDisponivelAutorizado = valorDisponivelAutorizado;
	}

	public String getQtdeDisponivelNaoAutorizado() {
		return qtdeDisponivelNaoAutorizado;
	}

	public void setQtdeDisponivelNaoAutorizado(String qtdeDisponivelNaoAutorizado) {
		this.qtdeDisponivelNaoAutorizado = qtdeDisponivelNaoAutorizado;
	}

	public String getValorDisponivelNaoAutorizado() {
		return valorDisponivelNaoAutorizado;
	}

	public void setValorDisponivelNaoAutorizado(String valorDisponivelNaoAutorizado) {
		this.valorDisponivelNaoAutorizado = valorDisponivelNaoAutorizado;
	}

	public String getProduto() {
		return produto;
	}

	public void setProduto(String produto) {
		this.produto = produto;
	}

	public String getSubProduto() {
		return subProduto;
	}

	public void setSubProduto(String subProduto) {
		this.subProduto = subProduto;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
}


