package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;

public class DetranTipoDeSubservicoDTO implements Serializable {

	private static final long serialVersionUID = -7074588513149776458L;

	private Integer tipoSubServico;
    private String idSubServico;
    private Integer tamanhoId;
    private String descricaoId;
    private String descricaoSubServico;
    private BigDecimal valor;
    private String flagCorreio;
    private BigDecimal valorCorreio;
    private BigDecimal valorTotal;
    private Integer codigoReceita;
    
    private String valorString;
    private String valorTotalString;
    private String valorCorreioString;
    
    public DetranTipoDeSubservicoDTO() {}
	
	public DetranTipoDeSubservicoDTO(Integer tipoSubServico, String idSubServico, Integer tamanhoId, String descricaoId,
			String descricaoSubServico, BigDecimal valor, String valorString, String flagCorreio, BigDecimal valorCorreio,
			String valorCorreioString,
			BigDecimal valorTotal, String valorTotalString, Integer codigoReceita) {
		super();
		this.tipoSubServico = tipoSubServico;
		this.idSubServico = idSubServico;
		this.tamanhoId = tamanhoId;
		this.descricaoId = descricaoId;
		this.descricaoSubServico = descricaoSubServico;
		this.valor = valor;
		this.valorString = valorString;
		this.flagCorreio = flagCorreio;
		this.valorCorreio = valorCorreio;
		this.valorCorreioString = valorCorreioString;
		this.valorTotal = valorTotal;
		this.valorTotalString = valorTotalString;
		this.codigoReceita = codigoReceita;
	}

	public Integer getTipoSubServico() {
		return tipoSubServico;
	}
	public void setTipoSubServico(Integer tipoSubServico) {
		this.tipoSubServico = tipoSubServico;
	}
	public String getIdSubServico() {
		return idSubServico;
	}
	public void setIdSubServico(String idSubServico) {
		this.idSubServico = idSubServico;
	}
	public Integer getTamanhoId() {
		return tamanhoId;
	}
	public void setTamanhoId(Integer tamanhoId) {
		this.tamanhoId = tamanhoId;
	}
	public String getDescricaoId() {
		return descricaoId;
	}
	public void setDescricaoId(String descricaoId) {
		this.descricaoId = descricaoId;
	}
	public String getDescricaoSubServico() {
		return descricaoSubServico;
	}
	public void setDescricaoSubServico(String descricaoSubServico) {
		this.descricaoSubServico = descricaoSubServico;
	}
	public BigDecimal getValor() {
		return valor;
	}
	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}
	public String getFlagCorreio() {
		return flagCorreio;
	}
	public void setFlagCorreio(String flagCorreio) {
		this.flagCorreio = flagCorreio;
	}
	public BigDecimal getValorCorreio() {
		return valorCorreio;
	}
	public void setValorCorreio(BigDecimal valorCorreio) {
		this.valorCorreio = valorCorreio;
	}
	public BigDecimal getValorTotal() {
		return valorTotal;
	}
	public void setValorTotal(BigDecimal valorTotal) {
		this.valorTotal = valorTotal;
	}
	public Integer getCodigoReceita() {
		return codigoReceita;
	}
	public void setCodigoReceita(Integer codigoReceita) {
		this.codigoReceita = codigoReceita;
	}

	public String getValorString() {
		return valorString;
	}

	public void setValorString(String valorString) {
		this.valorString = valorString;
	}

	public String getValorTotalString() {
		return valorTotalString;
	}

	public void setValorTotalString(String valorTotalString) {
		this.valorTotalString = valorTotalString;
	}

	public String getValorCorreioString() {
		return valorCorreioString;
	}

	public void setValorCorreioString(String valorCorreioString) {
		this.valorCorreioString = valorCorreioString;
	}
}
