package com.altec.bsbr.app.ibe.dto;

public class PosicaoConsolidadaContaDebitoDTO {
	private String entDebEntidadBr;
	private String entDebSucursalBr;
	private String entDebNroCuentaBr;
	private String valueCombo;
	
	public String getEntDebEntidadBr() {
		return entDebEntidadBr;
	}
	public void setEntDebEntidadBr(String entDebEntidadBr) {
		this.entDebEntidadBr = entDebEntidadBr;
	}
	public String getEntDebSucursalBr() {
		return entDebSucursalBr;
	}
	public void setEntDebSucursalBr(String entDebSucursalBr) {
		this.entDebSucursalBr = entDebSucursalBr;
	}
	public String getEntDebNroCuentaBr() {
		return entDebNroCuentaBr;
	}
	public void setEntDebNroCuentaBr(String entDebNroCuentaBr) {
		this.entDebNroCuentaBr = entDebNroCuentaBr;
	}
	public String getValueCombo() {
		return valueCombo;
	}
	public void setValueCombo(String valueCombo) {
		this.valueCombo = valueCombo;
	}
	
	
}
