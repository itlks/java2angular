package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class ConsultaOperacaoDTO implements Serializable {

      /**
      * 
       */
      private static final long serialVersionUID = 54421730889921763L;

      private String dataOperacao;
      private String numeroOpercao;
      private String valorOperacao;
      private String operacao;
      private String valorTotalOperacao;
      private String valorTotalDetalheOperacao;
      private String valorTotalResumoOperacao;
      private String condicaoPesquisa;
      private String autenticacaoBancaria;
      private String operacaoConsulta;
      
      private String detalheNumeroAgencia;
      private String detalheAgencia;
      private String detalhePrazoMedio;
      private String detalheTaxaOperacao;
      private String detalheValorOperacao;
      private String detalheCliente;
      private String detalheCanalContratacao;
      private String detalheValorJuros;
      private String detalheValorIOC;
      private String detalheValorTarifa;
      private String detalheValorCredito;
      private String detalheNomeAgencia;
      private String detalheNumeroDocumento;
      private String detalheDataOperacao;
      private String detalheNumeroOperacao;
      private String detalheNumeroConta;
      
      private String detalheTaxaAntecipacaoAM;
      private String detalheTaxaAntecipacaoRS;
      private String detalheValorBruto;
      private String detalheValorLiquido;
      private String detalheTarifaOperacao;
      
      private Boolean telaDetalhe;
      private String msgSemDetalhe;
      
      private String resumoNumeroAutenticacao;
      
      
      private String TSOEMBNROPER;
      private String TSOEMBDTOPER;
      private String TSOEMBVLOPER;
      

      public String getDataOperacao() {
            return dataOperacao;
      }

      public void setDataOperacao(String dataOperacao) {
            this.dataOperacao = dataOperacao;
      }

      public String getNumeroOpercao() {
            return numeroOpercao;
      }

      public void setNumeroOpercao(String numeroOpercao) {
            this.numeroOpercao = numeroOpercao;
      }

      public String getValorOperacao() {
            return valorOperacao;
      }

      public void setValorOperacao(String valorOperacao) {
            this.valorOperacao = valorOperacao;
      }
      
      /**
      * @return the valorTotalOperacao
      */
      public String getValorTotalOperacao() {
            if(valorTotalOperacao == null){
                  return "0";
            }
            return valorTotalOperacao;
      }

      /**
      * @param valorTotalOperacao the valorTotalOperacao to set
      */
      public void setValorTotalOperacao(String valorTotalOperacao) {
            this.valorTotalOperacao = valorTotalOperacao;
      }

      /**
      * @return the valorTotalDetalheOperacao
      */
      public String getValorTotalDetalheOperacao() {
            return valorTotalDetalheOperacao;
      }

      /**
      * @param valorTotalDetalheOperacao the valorTotalDetalheOperacao to set
      */
      public void setValorTotalDetalheOperacao(String valorTotalDetalheOperacao) {
            this.valorTotalDetalheOperacao = valorTotalDetalheOperacao;
      }

      /**
      * @return the operacao
      */
      public String getOperacao() {
            return operacao;
      }

      /**
      * @param operacao the operacao to set
      */
      public void setOperacao(String operacao) {
            this.operacao = operacao;
      }
      
      /**
      * @return the tSOEMBNROPER
      */
      public String getTSOEMBNROPER() {
            return TSOEMBNROPER;
      }

      /**
      * @param tSOEMBNROPER the tSOEMBNROPER to set
      */
      public void setTSOEMBNROPER(String tSOEMBNROPER) {
            TSOEMBNROPER = tSOEMBNROPER;
      }

      /**
      * @return the tSOEMBDTOPER
      */
      public String getTSOEMBDTOPER() {
            return TSOEMBDTOPER;
      }

      /**
      * @param tSOEMBDTOPER the tSOEMBDTOPER to set
      */
      public void setTSOEMBDTOPER(String tSOEMBDTOPER) {
            TSOEMBDTOPER = tSOEMBDTOPER;
      }

      /**
      * @return the tSOEMBVLOPER
      */
      public String getTSOEMBVLOPER() {
            return TSOEMBVLOPER;
      }

      /**
      * @param tSOEMBVLOPER the tSOEMBVLOPER to set
      */
      public void setTSOEMBVLOPER(String tSOEMBVLOPER) {
            TSOEMBVLOPER = tSOEMBVLOPER;
      }

      
      
      
      /**
      * @return the condicaoPesquisa
      */
      public String getCondicaoPesquisa() {
            return condicaoPesquisa;
      }

      /**
      * @param condicaoPesquisa the condicaoPesquisa to set
      */
      public void setCondicaoPesquisa(String condicaoPesquisa) {
            this.condicaoPesquisa = condicaoPesquisa;
      }

      
      
      /**
      * @return the valorTotalResumoOperacao
      */
      public String getValorTotalResumoOperacao() {
            if(valorTotalResumoOperacao == null){
                  return "0";
            }
            return valorTotalResumoOperacao;
      }

      /**
      * @param valorTotalResumoOperacao the valorTotalResumoOperacao to set
      */
      public void setValorTotalResumoOperacao(String valorTotalResumoOperacao) {
            this.valorTotalResumoOperacao = valorTotalResumoOperacao;
      }
      
      

      /**
      * @return the autenticacaoBancaria
      */
      public String getAutenticacaoBancaria() {
            return autenticacaoBancaria;
      }

      /**
      * @param autenticacaoBancaria the autenticacaoBancaria to set
      */
      public void setAutenticacaoBancaria(String autenticacaoBancaria) {
            this.autenticacaoBancaria = autenticacaoBancaria;
      }

      
      
      
      /**
      * @return the detalheNumeroAgencia
      */
      public String getDetalheNumeroAgencia() {
            return detalheNumeroAgencia;
      }

      /**
      * @param detalheNumeroAgencia the detalheNumeroAgencia to set
      */
      public void setDetalheNumeroAgencia(String detalheNumeroAgencia) {
            this.detalheNumeroAgencia = detalheNumeroAgencia;
      }

      /**
      * @return the detalheAgencia
      */
      public String getDetalheAgencia() {
            return detalheAgencia;
      }

      /**
      * @param detalheAgencia the detalheAgencia to set
      */
      public void setDetalheAgencia(String detalheAgencia) {
            this.detalheAgencia = detalheAgencia;
      }

      /**
      * @return the detalhePrazoMedio
      */
      public String getDetalhePrazoMedio() {
            return detalhePrazoMedio;
      }

      /**
      * @param detalhePrazoMedio the detalhePrazoMedio to set
      */
      public void setDetalhePrazoMedio(String detalhePrazoMedio) {
            this.detalhePrazoMedio = detalhePrazoMedio;
      }

      /**
      * @return the detalheTaxaOperacao
      */
      public String getDetalheTaxaOperacao() {
            return detalheTaxaOperacao;
      }

      /**
      * @param detalheTaxaOperacao the detalheTaxaOperacao to set
      */
      public void setDetalheTaxaOperacao(String detalheTaxaOperacao) {
            this.detalheTaxaOperacao = detalheTaxaOperacao;
      }

      /**
      * @return the detalheValorOperacao
      */
      public String getDetalheValorOperacao() {
            return detalheValorOperacao;
      }

      /**
      * @param detalheValorOperacao the detalheValorOperacao to set
      */
      public void setDetalheValorOperacao(String detalheValorOperacao) {
            this.detalheValorOperacao = detalheValorOperacao;
      }

      /**
      * @return the detalheCliente
      */
      public String getDetalheCliente() {
            return detalheCliente;
      }

      /**
      * @param detalheCliente the detalheCliente to set
      */
      public void setDetalheCliente(String detalheCliente) {
            this.detalheCliente = detalheCliente;
      }

      /**
      * @return the detalheCanalContratacao
      */
      public String getDetalheCanalContratacao() {
            return detalheCanalContratacao;
      }

      /**
      * @param detalheCanalContratacao the detalheCanalContratacao to set
      */
      public void setDetalheCanalContratacao(String detalheCanalContratacao) {
            this.detalheCanalContratacao = detalheCanalContratacao;
      }

      /**
      * @return the detalheValorJuros
      */
      public String getDetalheValorJuros() {
            return detalheValorJuros;
      }

      /**
      * @param detalheValorJuros the detalheValorJuros to set
      */
      public void setDetalheValorJuros(String detalheValorJuros) {
            this.detalheValorJuros = detalheValorJuros;
      }

      /**
      * @return the detalheValorIOC
      */
      public String getDetalheValorIOC() {
            return detalheValorIOC;
      }

      /**
      * @param detalheValorIOC the detalheValorIOC to set
      */
      public void setDetalheValorIOC(String detalheValorIOC) {
            this.detalheValorIOC = detalheValorIOC;
      }

      /**
      * @return the detalheValorTarifa
      */
      public String getDetalheValorTarifa() {
            return detalheValorTarifa;
      }

      /**
      * @param detalheValorTarifa the detalheValorTarifa to set
      */
      public void setDetalheValorTarifa(String detalheValorTarifa) {
            this.detalheValorTarifa = detalheValorTarifa;
      }

      /**
      * @return the detalheValorCredito
      */
      public String getDetalheValorCredito() {
            return detalheValorCredito;
      }

      /**
      * @param detalheValorCredito the detalheValorCredito to set
      */
      public void setDetalheValorCredito(String detalheValorCredito) {
            this.detalheValorCredito = detalheValorCredito;
      }

      /**
      * @return the operacaoConsulta
      */
      public String getOperacaoConsulta() {
            return operacaoConsulta;
      }

      /**
      * @param operacaoConsulta the operacaoConsulta to set
      */
      public void setOperacaoConsulta(String operacaoConsulta) {
            this.operacaoConsulta = operacaoConsulta;
      }

      /**
      * @return the detalheNomeAgencia
      */
      public String getDetalheNomeAgencia() {
            return detalheNomeAgencia;
      }

      /**
      * @param detalheNomeAgencia the detalheNomeAgencia to set
      */
      public void setDetalheNomeAgencia(String detalheNomeAgencia) {
            this.detalheNomeAgencia = detalheNomeAgencia;
      }

      /**
      * @return the detalheNumeroDocumento
      */
      public String getDetalheNumeroDocumento() {
            return detalheNumeroDocumento;
      }

      /**
      * @param detalheNumeroDocumento the detalheNumeroDocumento to set
      */
      public void setDetalheNumeroDocumento(String detalheNumeroDocumento) {
            this.detalheNumeroDocumento = detalheNumeroDocumento;
      }

      /**
      * @return the detalheDataOperacao
      */
      public String getDetalheDataOperacao() {
            return detalheDataOperacao;
      }

      /**
      * @param detalheDataOperacao the detalheDataOperacao to set
      */
      public void setDetalheDataOperacao(String detalheDataOperacao) {
            this.detalheDataOperacao = detalheDataOperacao;
      }

      /**
      * @return the detalheNumeroOperacao
      */
      public String getDetalheNumeroOperacao() {
            return detalheNumeroOperacao;
      }

      /**
      * @param detalheNumeroOperacao the detalheNumeroOperacao to set
      */
      public void setDetalheNumeroOperacao(String detalheNumeroOperacao) {
            this.detalheNumeroOperacao = detalheNumeroOperacao;
      }
      
      
      /**
      * @return the msgSemDetalhe
      */
      public String getMsgSemDetalhe() {
            return msgSemDetalhe;
      }

      /**
      * @param msgSemDetalhe the msgSemDetalhe to set
      */
      public void setMsgSemDetalhe(String msgSemDetalhe) {
            this.msgSemDetalhe = msgSemDetalhe;
      }

      /**
      * @return the resumoNumeroAutenticacao
      */
      public String getResumoNumeroAutenticacao() {
            return resumoNumeroAutenticacao;
      }

      /**
      * @param resumoNumeroAutenticacao the resumoNumeroAutenticacao to set
      */
      public void setResumoNumeroAutenticacao(String resumoNumeroAutenticacao) {
            this.resumoNumeroAutenticacao = resumoNumeroAutenticacao;
      }

      /**
      * @return the detalheTaxaAntecipacaoAM
      */
      public String getDetalheTaxaAntecipacaoAM() {
            return detalheTaxaAntecipacaoAM;
      }

      /**
      * @param detalheTaxaAntecipacaoAM the detalheTaxaAntecipacaoAM to set
      */
      public void setDetalheTaxaAntecipacaoAM(String detalheTaxaAntecipacaoAM) {
            this.detalheTaxaAntecipacaoAM = detalheTaxaAntecipacaoAM;
      }

      /**
      * @return the detalheTaxaAntecipacaoRS
      */
      public String getDetalheTaxaAntecipacaoRS() {
            return detalheTaxaAntecipacaoRS;
      }

      /**
      * @param detalheTaxaAntecipacaoRS the detalheTaxaAntecipacaoRS to set
      */
      public void setDetalheTaxaAntecipacaoRS(String detalheTaxaAntecipacaoRS) {
            this.detalheTaxaAntecipacaoRS = detalheTaxaAntecipacaoRS;
      }

      /**
      * @return the detalheValorBruto
      */
      public String getDetalheValorBruto() {
            return detalheValorBruto;
      }

      /**
      * @param detalheValorBruto the detalheValorBruto to set
      */
      public void setDetalheValorBruto(String detalheValorBruto) {
            this.detalheValorBruto = detalheValorBruto;
      }

      /**
      * @return the detalheValorLiquido
      */
      public String getDetalheValorLiquido() {
            return detalheValorLiquido;
      }

      /**
      * @param detalheValorLiquido the detalheValorLiquido to set
      */
      public void setDetalheValorLiquido(String detalheValorLiquido) {
            this.detalheValorLiquido = detalheValorLiquido;
      }

      /**
      * @return the detalheNumeroConta
      */
      public String getDetalheNumeroConta() {
            return detalheNumeroConta;
      }

      /**
      * @param detalheNumeroConta the detalheNumeroConta to set
      */
      public void setDetalheNumeroConta(String detalheNumeroConta) {
            this.detalheNumeroConta = detalheNumeroConta;
      }

      
      
      /**
      * @return the telaDetalhe
      */
      public Boolean getTelaDetalhe() {
            return telaDetalhe;
      }

      /**
      * @param telaDetalhe the telaDetalhe to set
      */
      public void setTelaDetalhe(Boolean telaDetalhe) {
            this.telaDetalhe = telaDetalhe;
      }

      /**
      * @return the detalheTarifaOperacao
      */
      public String getDetalheTarifaOperacao() {
            return detalheTarifaOperacao;
      }

      /**
      * @param detalheTarifaOperacao the detalheTarifaOperacao to set
      */
      public void setDetalheTarifaOperacao(String detalheTarifaOperacao) {
            this.detalheTarifaOperacao = detalheTarifaOperacao;
      }

      /* (non-Javadoc)
      * @see java.lang.Object#hashCode()
      */
      @Override
      public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + ((dataOperacao == null) ? 0 : dataOperacao.hashCode());
            result = prime * result + ((numeroOpercao == null) ? 0 : numeroOpercao.hashCode());
            result = prime * result + ((valorOperacao == null) ? 0 : valorOperacao.hashCode());
            return result;
      }

      /* (non-Javadoc)
      * @see java.lang.Object#equals(java.lang.Object)
      */
      @Override
      public boolean equals(Object obj) {
            if (this == obj)
                  return true;
            if (obj == null)
                  return false;
            if (getClass() != obj.getClass())
                  return false;
            ConsultaOperacaoDTO other = (ConsultaOperacaoDTO) obj;
            if (dataOperacao == null) {
                  if (other.dataOperacao != null)
                        return false;
            } else if (!dataOperacao.equals(other.dataOperacao))
                  return false;
            if (numeroOpercao == null) {
                  if (other.numeroOpercao != null)
                        return false;
            } else if (!numeroOpercao.equals(other.numeroOpercao))
                  return false;
            if (valorOperacao == null) {
                  if (other.valorOperacao != null)
                        return false;
            } else if (!valorOperacao.equals(other.valorOperacao))
                  return false;
            return true;
      }


}

