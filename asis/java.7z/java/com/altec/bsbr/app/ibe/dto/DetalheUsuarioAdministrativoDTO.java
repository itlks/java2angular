package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DetalheUsuarioAdministrativoDTO implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	
	public static final int INCLUIR_USUARIO_SECUNDARIO = 1;
	public static final int ALTERAR_PERFIL_ACESSO = 3;
	public static final int ALTERAR_PERFIL_AUTORIZACAO = 4;
	public static final int ALTERAR_PERFIL_ACESSO_USUARIO_SECUNDARIO = 7;
	public static final int ALTERAR_PERFIL_AUTORIZACAO_USUARIO_SECUNDARIO = 8;
	public static final int ALTERAR_RELACAO_CONVENIO_USUARIO_SECUNDARIO = 9;
	
	private String nomeUsuarioInclusao;
	private String codigoUsuarioPRVS;
	private String nomeLogin;
	private String nomeUsuario;
	private String nomeArea;
	private String numeroCPF;
	private String flagAcessoMobile;
	private String codigoBanco;
	private String codigoAgencia;
	private String numeroConta;
	private String nrSeqPefilAcessoSecundario;
	private String nomePerfil;
	private String descricaoPefil;
	private String nomePerfilAcesso;
	private String descricaoPefilAcesso;
	private String nrSeqPefilAutorizacaoSecundario;
	private String nomePerfilAutorizacao;
	private String descPerfilAutorizacao;
	private String codigoDDDTelefoneFixo;
	private String numeroTelefoneFixo;
	private String codigoDDDTelefoneCelular;
	private String numeroTelefoneCelular;
	private String codigoSituacaoCelular;
	
	private Map<String, List<DetalheAutorizacaoListaDTO>> detalhesAutorizacao;
	private List<DadosAcessoAutorizacao> dadosAcessoAutorizacao;
	private List<MenuDetalheAcessoDTO> menuAcesso;
		
	private Map<String, DetalheUsuarioConvenioDTO> detalheUsuarioConvenios;
	
	
	/**
	 * DetalheUsuarioAdministrativoDTO
	 */
	public DetalheUsuarioAdministrativoDTO() {
		setDetalhesAutorizacao(new HashMap<String, List<DetalheAutorizacaoListaDTO>>());
		setDetalheUsuarioConvenios(new HashMap<String, DetalheUsuarioConvenioDTO>());
		dadosAcessoAutorizacao = new ArrayList<DadosAcessoAutorizacao>();
	}
	

	/**
	 * @return the nomeUsuarioInclusao
	 */
	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}

	/**
	 * @param nomeUsuarioInclusao
	 *            the nomeUsuarioInclusao to set
	 */
	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}

	/**
	 * @return the codigoUsuarioPRVS
	 */
	public String getCodigoUsuarioPRVS() {
		return codigoUsuarioPRVS;
	}

	/**
	 * @param codigoUsuarioPRVS
	 *            the codigoUsuarioPRVS to set
	 */
	public void setCodigoUsuarioPRVS(String codigoUsuarioPRVS) {
		this.codigoUsuarioPRVS = codigoUsuarioPRVS;
	}

	/**
	 * @return the nomeLogin
	 */
	public String getNomeLogin() {
		return nomeLogin;
	}

	/**
	 * @param nomeLogin
	 *            the nomeLogin to set
	 */
	public void setNomeLogin(String nomeLogin) {
		this.nomeLogin = nomeLogin;
	}

	/**
	 * @return the nomeUsuario
	 */
	public String getNomeUsuario() {
		return nomeUsuario;
	}

	/**
	 * @param nomeUsuario
	 *            the nomeUsuario to set
	 */
	public void setNomeUsuario(String nomeUsuario) {
		this.nomeUsuario = nomeUsuario;
	}

	/**
	 * @return the nomeArea
	 */
	public String getNomeArea() {
		return nomeArea;
	}

	/**
	 * @param nomeArea
	 *            the nomeArea to set
	 */
	public void setNomeArea(String nomeArea) {
		this.nomeArea = nomeArea;
	}

	/**
	 * @return the numeroCPF
	 */
	public String getNumeroCPF() {
		return numeroCPF;
	}

	/**
	 * @param numeroCPF
	 *            the numeroCPF to set
	 */
	public void setNumeroCPF(String numeroCPF) {
		this.numeroCPF = numeroCPF;
	}

	/**
	 * @return the flagAcessoMobile
	 */
	public String getFlagAcessoMobile() {
		return flagAcessoMobile;
	}

	/**
	 * @param flagAcessoMobile
	 *            the flagAcessoMobile to set
	 */
	public void setFlagAcessoMobile(String flagAcessoMobile) {
		this.flagAcessoMobile = flagAcessoMobile;
	}

	/**
	 * @return the codigoBanco
	 */
	public String getCodigoBanco() {
		return codigoBanco;
	}

	/**
	 * @param codigoBanco
	 *            the codigoBanco to set
	 */
	public void setCodigoBanco(String codigoBanco) {
		this.codigoBanco = codigoBanco;
	}

	/**
	 * @return the codigoAgencia
	 */
	public String getCodigoAgencia() {
		return codigoAgencia;
	}

	/**
	 * @param codigoAgencia
	 *            the codigoAgencia to set
	 */
	public void setCodigoAgencia(String codigoAgencia) {
		this.codigoAgencia = codigoAgencia;
	}

	/**
	 * @return the numeroConta
	 */
	public String getNumeroConta() {
		return numeroConta;
	}

	/**
	 * @param numeroConta
	 *            the numeroConta to set
	 */
	public void setNumeroConta(String numeroConta) {
		this.numeroConta = numeroConta;
	}

	/**
	 * @return the nrSeqPefilAcessoSecundario
	 */
	public String getNrSeqPefilAcessoSecundario() {
		return nrSeqPefilAcessoSecundario;
	}

	/**
	 * @param nrSeqPefilAcessoSecundario
	 *            the nrSeqPefilAcessoSecundario to set
	 */
	public void setNrSeqPefilAcessoSecundario(String nrSeqPefilAcessoSecundario) {
		this.nrSeqPefilAcessoSecundario = nrSeqPefilAcessoSecundario;
	}


	/**
	 * @return the nomePerfilAcesso
	 */
	public String getNomePerfilAcesso() {
		return nomePerfilAcesso;
	}

	/**
	 * @param nomePerfilAcesso the nomePerfilAcesso to set
	 */
	public void setNomePerfilAcesso(String nomePerfilAcesso) {
		this.nomePerfilAcesso = nomePerfilAcesso;
	}


	/**
	 * @return the nrSeqPefilAutorizacaoSecundario
	 */
	public String getNrSeqPefilAutorizacaoSecundario() {
		return nrSeqPefilAutorizacaoSecundario;
	}

	/**
	 * @param nrSeqPefilAutorizacaoSecundario
	 *            the nrSeqPefilAutorizacaoSecundario to set
	 */
	public void setNrSeqPefilAutorizacaoSecundario(String nrSeqPefilAutorizacaoSecundario) {
		this.nrSeqPefilAutorizacaoSecundario = nrSeqPefilAutorizacaoSecundario;
	}

	/**
	 * @return the nomePefilAutorizacao
	 */
	public String getNomePerfilAutorizacao() {
		return nomePerfilAutorizacao;
	}

	/**
	 * @param nomePefilAutorizacao
	 *            the nomePefilAutorizacao to set
	 */
	public void setNomePerfilAutorizacao(String nomePerfilAutorizacao) {
		this.nomePerfilAutorizacao = nomePerfilAutorizacao;
	}

	/**
	 * @return the codigoDDDTelefoneFixo
	 */
	public String getCodigoDDDTelefoneFixo() {
		return codigoDDDTelefoneFixo;
	}

	/**
	 * @param codigoDDDTelefoneFixo
	 *            the codigoDDDTelefoneFixo to set
	 */
	public void setCodigoDDDTelefoneFixo(String codigoDDDTelefoneFixo) {
		this.codigoDDDTelefoneFixo = codigoDDDTelefoneFixo;
	}

	/**
	 * @return the numeroTelefoneFixo
	 */
	public String getNumeroTelefoneFixo() {
		return codigoDDDTelefoneFixo + numeroTelefoneFixo;
	}

	/**
	 * @param numeroTelefoneFixo
	 *            the numeroTelefoneFixo to set
	 */
	public void setNumeroTelefoneFixo(String numeroTelefoneFixo) {
		this.numeroTelefoneFixo = numeroTelefoneFixo;
	}

	/**
	 * @return the codigoDDDTelefoneCelular
	 */
	public String getCodigoDDDTelefoneCelular() {
		return codigoDDDTelefoneCelular;
	}

	/**
	 * @param codigoDDDTelefoneCelular
	 *            the codigoDDDTelefoneCelular to set
	 */
	public void setCodigoDDDTelefoneCelular(String codigoDDDTelefoneCelular) {
		this.codigoDDDTelefoneCelular = codigoDDDTelefoneCelular;
	}

	/**
	 * @return the numeroTelefoneCelular
	 */
	public String getNumeroTelefoneCelular() {
		return  codigoDDDTelefoneCelular + numeroTelefoneCelular;
	}

	/**
	 * @param numeroTelefoneCelular
	 *            the numeroTelefoneCelular to set
	 */
	public void setNumeroTelefoneCelular(String numeroTelefoneCelular) {
		this.numeroTelefoneCelular = numeroTelefoneCelular;
	}

	/**
	 * @return the codigoSituacaoCelular
	 */
	public String getCodigoSituacaoCelular() {
		return codigoSituacaoCelular;
	}

	/**
	 * @param codigoSituacaoCelular
	 *            the codigoSituacaoCelular to set
	 */
	public void setCodigoSituacaoCelular(String codigoSituacaoCelular) {
		this.codigoSituacaoCelular = codigoSituacaoCelular;
	}
	
	
	/**
	 * @param dadosAcessoAutorizacao the dadosAcessoAutorizacao to set
	 */
	public void setDadosAcessoAutorizacao(List<DadosAcessoAutorizacao> dadosAcessoAutorizacao) {
		this.dadosAcessoAutorizacao = dadosAcessoAutorizacao;
	}
	
	
	/**
	 * @return the descricaoPefilAcesso
	 */
	public String getDescricaoPefilAcesso() {
		return descricaoPefilAcesso;
	}


	/**
	 * @param descricaoPefilAcesso the descricaoPefilAcesso to set
	 */
	public void setDescricaoPefilAcesso(String descricaoPefilAcesso) {
		this.descricaoPefilAcesso = descricaoPefilAcesso;
	}


	/**
	 * @return the dadosAcessoAutorizacao
	 */
	public List<DadosAcessoAutorizacao> getDadosAcessoAutorizacao() {
		
		if (dadosAcessoAutorizacao.size() == 0) {
			dadosAcessoAutorizacao.add(new DadosAcessoAutorizacao(
										codigoAgencia + "." + numeroConta, 
										nomePerfilAcesso, 
										nomePerfilAutorizacao));
		}
		
		return dadosAcessoAutorizacao;
	}


	/**
	 * @return the detalhesAutorizacao
	 */
	public Map<String, List<DetalheAutorizacaoListaDTO>> getDetalhesAutorizacao() {		
		return detalhesAutorizacao;
	}


	/**
	 * @param detalhesAutorizacao the detalhesAutorizacao to set
	 */
	public void setDetalhesAutorizacao(Map<String, List<DetalheAutorizacaoListaDTO>> detalhesAutorizacao) {
		this.detalhesAutorizacao = detalhesAutorizacao;
	}
	

	/**
	 * @return the menuAcesso
	 */
	public List<MenuDetalheAcessoDTO> getMenuAcesso() {
		return menuAcesso;
	}


	/**
	 * @param menuAcesso the menuAcesso to set
	 */
	public void setMenuAcesso(List<MenuDetalheAcessoDTO> menuAcesso) {
		this.menuAcesso = menuAcesso;
	}
	

	/**
	 * @return the descPerfilAutorizacao
	 */
	public String getDescPerfilAutorizacao() {
		return descPerfilAutorizacao;
	}


	/**
	 * @param descPerfilAutorizacao the descPerfilAutorizacao to set
	 */
	public void setDescPerfilAutorizacao(String descPerfilAutorizacao) {
		this.descPerfilAutorizacao = descPerfilAutorizacao;
	}
	

	/**
	 * @return the nomePerfil
	 */
	public String getNomePerfil() {
		return nomePerfil;
	}


	/**
	 * @param nomePerfil the nomePerfil to set
	 */
	public void setNomePerfil(String nomePerfil) {
		this.nomePerfil = nomePerfil;
	}


	/**
	 * @return the descricaoPefil
	 */
	public String getDescricaoPefil() {
		return descricaoPefil;
	}


	/**
	 * @param descricaoPefil the descricaoPefil to set
	 */
	public void setDescricaoPefil(String descricaoPefil) {
		this.descricaoPefil = descricaoPefil;
	}


	public Map<String, DetalheUsuarioConvenioDTO> getDetalheUsuarioConvenios() {
		return detalheUsuarioConvenios;
	}


	public void setDetalheUsuarioConvenios(Map<String, DetalheUsuarioConvenioDTO> detalheUsuarioConvenios) {
		this.detalheUsuarioConvenios = detalheUsuarioConvenios;
	}
	
}