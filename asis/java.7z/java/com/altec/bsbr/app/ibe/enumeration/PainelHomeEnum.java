package com.altec.bsbr.app.ibe.enumeration;

import java.util.ArrayList;
import java.util.List;

import com.altec.bsbr.app.ibe.dto.home.ProdutoSubProdutoInvestimentoDTO;

public enum PainelHomeEnum {
	
	MAQUINHAGETNET ("maquininhaGetNet",0,"66", "9000"),
	PAINELCOBRANCA ("painelCobranca",1,"19", "1938"),
	PAINELINVESTIMENTO ("painelInvestimento",2,"11","11"),
	CODIGODEBARRAS ("CodigoDeBarras",3,"","");

	private String descricao;
	private int posicao;
	private String produto;
	private String subproduto;
	private List<ProdutoSubProdutoInvestimentoDTO> listaProdutoInvestimento;;


	private PainelHomeEnum( String descricao, int posicao,String produto, String subproduto) {
		this.descricao=descricao;
		this.posicao=posicao;
		this.produto=produto;
		this.subproduto=subproduto;
		this.listaProdutoInvestimento = new ArrayList<ProdutoSubProdutoInvestimentoDTO>();
		listaProdutoInvestimento.add(new ProdutoSubProdutoInvestimentoDTO("35", ""));
		listaProdutoInvestimento.add(new ProdutoSubProdutoInvestimentoDTO("26", ""));
		listaProdutoInvestimento.add(new ProdutoSubProdutoInvestimentoDTO("51", ""));
	}
	
	public String getDescricao() {
		return descricao;
	}

	public int getPosicao() {
		return posicao;
	}

	public String getProduto() {
		return produto;
	}

	public String getSubproduto() {
		return subproduto;
	}
	
	public List<ProdutoSubProdutoInvestimentoDTO> getListaProdutoInvestimento() {
		return listaProdutoInvestimento;
	}

	
}
