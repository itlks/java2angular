package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;

public class SegundaViaComprTelefonePrePagoDTO  extends GenericDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String banco;
	private String agencia;
	private String conta;		
	private String codigoUsuario;
	private String hostAddress;
	private String canal;
	
	private String dataInicial;
	private String dataFinal;
	
	private String codigoComprovante;
	private String canalPagamento;
	
	private String operadora;
	private String codArea;
	private String numeroTelefone;
	private String protocolo;
	private String numeroTransacao;
	private BigDecimal valorPago;
	private String dataPagamento;
	private String horaPagamento;
	private String dataTransacao;
	private String autenticacaoBancaria;
	
	private String Nio;
	private Integer MaxSeqNio;
	private String Tabela;
	
	private String dataMov;
	private String seqArre;
	
	private boolean selecionado;
	

	public String getCodArea() {
		return codArea;
	}

	public void setCodArea(String codArea) {
		this.codArea = codArea;
	}

	public String getNumeroTelefone() {
		return numeroTelefone;
	}

	public void setNumeroTelefone(String numeroTelefone) {
		this.numeroTelefone = numeroTelefone;
	}

	public String getProtocolo() {
		return protocolo;
	}

	public void setProtocolo(String protocolo) {
		this.protocolo = protocolo;
	}

	public String getNumeroTransacao() {
		return numeroTransacao;
	}

	public void setNumeroTransacao(String numeroTransacao) {
		this.numeroTransacao = numeroTransacao;
	}

	public String getNio() {
		return Nio;
	}

	public void setNio(String nio) {
		Nio = nio;
	}

	public Integer getMaxSeqNio() {
		return MaxSeqNio;
	}

	public void setMaxSeqNio(Integer maxSeqNio) {
		MaxSeqNio = maxSeqNio;
	}

	public String getTabela() {
		return Tabela;
	}

	public void setTabela(String tabela) {
		Tabela = tabela;
	}

	public SegundaViaComprTelefonePrePagoDTO() {	
	}
		
	public String getCodigoComprovante() {
		return codigoComprovante;
	}

	
	public void setCodigoComprovante(String codigoComprovante) {
		this.codigoComprovante = codigoComprovante;
	}

	public String getOperadora() {
		return operadora;
	}

	public void setOperadora(String operadora) {
		this.operadora = operadora;
	}

	public String getCanal() {
		return canal;
	}
	public void setCanal(String canal) {
		this.canal = canal;
	}

	public boolean isSelecionado() {
		return selecionado;
	}

	public void setSelecionado(boolean selecionado) {
		this.selecionado = selecionado;
	}

	
	
	public String getDataInicial() {
		return dataInicial;
	}

	public void setDataInicial(String dataInicial) {
		this.dataInicial = dataInicial;
	}

	public String getDataFinal() {
		return dataFinal;
	}

	public void setDataFinal(String dataFinal) {
		this.dataFinal = dataFinal;
	}

	public BigDecimal getValorPago() {
		return valorPago;
	}

	public void setValorPago(BigDecimal valorPago) {
		this.valorPago = valorPago;
	}

	public String getDataPagamento() {
		return dataPagamento;
	}

	public void setDataPagamento(String dataPagamento) {
		this.dataPagamento = dataPagamento;
	}

	public String getDataTransacao() {
		return dataTransacao;
	}

	public void setDataTransacao(String dataTransacao) {
		this.dataTransacao = dataTransacao;
	}

	public String getAutenticacaoBancaria() {
		return autenticacaoBancaria;
	}

	public void setAutenticacaoBancaria(String autenticacaoBancaria) {
		this.autenticacaoBancaria = autenticacaoBancaria;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getConta() {
		return conta;
	}

	public void setConta(String conta) {
		this.conta = conta;
	}

	public String getCanalPagamento() {
		return canalPagamento;
	}

	public void setCanalPagamento(String canalPagamento) {
		this.canalPagamento = canalPagamento;
	}

	public String getCanalPagamentoCaseSensitive() {
		String lower = canalPagamento.toLowerCase();
		StringBuilder retorno=new StringBuilder();
		
		String split[]= lower.split(" ");		
		for (String palavra: split) {
			StringBuilder sPalavra=new StringBuilder(palavra);
			Character c = palavra.charAt(0);		
			Character c1 = Character.toUpperCase(c);
			sPalavra = sPalavra.replace(0, 1, c1.toString());
			retorno.append(sPalavra);
			retorno.append(" ");
		}			
	
		return retorno.toString().trim(); 
	}

	
	public String getCodigoUsuario() {
		return codigoUsuario;
	}

	public void setCodigoUsuario(String codigoUsuario) {
		this.codigoUsuario = codigoUsuario;
	}

	public String getHostAddress() {
		return hostAddress;
	}

	public void setHostAddress(String hostAddress) {
		this.hostAddress = hostAddress;
	}
	
	public String getHoraPagamento() {
		return horaPagamento;
	}

	public void setHoraPagamento(String horaPagamento) {
		this.horaPagamento = horaPagamento;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((agencia == null) ? 0 : agencia.hashCode());
		result = prime * result + ((autenticacaoBancaria == null) ? 0 : autenticacaoBancaria.hashCode());
		result = prime * result + ((banco == null) ? 0 : banco.hashCode());
		result = prime * result + ((canal == null) ? 0 : canal.hashCode());
		result = prime * result + ((canalPagamento == null) ? 0 : canalPagamento.hashCode());
		result = prime * result + ((codigoComprovante == null) ? 0 : codigoComprovante.hashCode());
		result = prime * result + ((codigoUsuario == null) ? 0 : codigoUsuario.hashCode());
		result = prime * result + ((conta == null) ? 0 : conta.hashCode());
		result = prime * result + ((dataFinal == null) ? 0 : dataFinal.hashCode());
		result = prime * result + ((dataTransacao == null) ? 0 : dataTransacao.hashCode());
		result = prime * result + ((dataInicial == null) ? 0 : dataInicial.hashCode());
		result = prime * result + ((dataPagamento == null) ? 0 : dataPagamento.hashCode());
		result = prime * result + ((horaPagamento == null) ? 0 : horaPagamento.hashCode());
		result = prime * result + ((hostAddress == null) ? 0 : hostAddress.hashCode());
		result = prime * result + (selecionado ? 1231 : 1237);
		result = prime * result + ((valorPago == null) ? 0 : valorPago.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof SegundaViaComprTelefonePrePagoDTO)) {
			return false;
		}
		SegundaViaComprTelefonePrePagoDTO other = (SegundaViaComprTelefonePrePagoDTO) obj;
		if (agencia == null) {
			if (other.agencia != null) {
				return false;
			}
		} else if (!agencia.equals(other.agencia)) {
			return false;
		}
		if (autenticacaoBancaria == null) {
			if (other.autenticacaoBancaria != null) {
				return false;
			}
		} else if (!autenticacaoBancaria.equals(other.autenticacaoBancaria)) {
			return false;
		}
		if (banco == null) {
			if (other.banco != null) {
				return false;
			}
		} else if (!banco.equals(other.banco)) {
			return false;
		}
		if (canal == null) {
			if (other.canal != null) {
				return false;
			}
		} else if (!canal.equals(other.canal)) {
			return false;
		}
		if (canalPagamento == null) {
			if (other.canalPagamento != null) {
				return false;
			}
		} else if (!canalPagamento.equals(other.canalPagamento)) {
			return false;
		}
		if (codigoComprovante == null) {
			if (other.codigoComprovante != null) {
				return false;
			}
		} else if (!codigoComprovante.equals(other.codigoComprovante)) {
			return false;
		}
		if (codigoUsuario == null) {
			if (other.codigoUsuario != null) {
				return false;
			}
		} else if (!codigoUsuario.equals(other.codigoUsuario)) {
			return false;
		}
		if (conta == null) {
			if (other.conta != null) {
				return false;
			}
		} else if (!conta.equals(other.conta)) {
			return false;
		}
		if (dataFinal == null) {
			if (other.dataFinal != null) {
				return false;
			}
		} else if (!dataFinal.equals(other.dataFinal)) {
			return false;
		}
		if (dataTransacao == null) {
			if (other.dataTransacao != null) {
				return false;
			}
		} else if (!dataTransacao.equals(other.dataTransacao)) {
			return false;
		}
		if (dataInicial == null) {
			if (other.dataInicial != null) {
				return false;
			}
		} else if (!dataInicial.equals(other.dataInicial)) {
			return false;
		}
		if (dataPagamento == null) {
			if (other.dataPagamento != null) {
				return false;
			}
		} else if (!dataPagamento.equals(other.dataPagamento)) {
			return false;
		}
		if (horaPagamento == null) {
			if (other.horaPagamento != null) {
				return false;
			}
		} else if (!horaPagamento.equals(other.horaPagamento)) {
			return false;
		}
		if (hostAddress == null) {
			if (other.hostAddress != null) {
				return false;
			}
		} else if (!hostAddress.equals(other.hostAddress)) {
			return false;
		}
		if (selecionado != other.selecionado) {
			return false;
		}
		if (valorPago == null) {
			if (other.valorPago != null) {
				return false;
			}
		} else if (!valorPago.equals(other.valorPago)) {
			return false;
		}
		return true;
	}

	public String getDataMov() {
		return dataMov;
	}

	public void setDataMov(String dataMov) {
		this.dataMov = dataMov;
	}

	public String getSeqArre() {
		return seqArre;
	}

	public void setSeqArre(String seqArre) {
		this.seqArre = seqArre;
	}

}
