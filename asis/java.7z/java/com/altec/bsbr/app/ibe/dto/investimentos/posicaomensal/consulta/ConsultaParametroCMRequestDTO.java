package com.altec.bsbr.app.ibe.dto.investimentos.posicaomensal.consulta;

import java.io.Serializable;

public class ConsultaParametroCMRequestDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String dateOperation;

	public String getDateOperation() {
		return dateOperation;
	}

	public void setDateOperation(String dataOperacao) {
		this.dateOperation = dataOperacao;
	}

}
