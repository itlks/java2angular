package com.altec.bsbr.app.ibe.rest.service;

import com.altec.bsbr.app.ibe.dto.investimentos.posicaomensal.InvestimentosCMPosicaoRequestDTO;
import com.altec.bsbr.app.ibe.dto.investimentos.posicaomensal.InvestimentosCMPosicaoResponseDTO;

/**
 * 
 * @author x187169 - Julio R.G. Leme
 * @since 2017-03-22
 * @version 1.0
 * <p>Servico Rest para a funcionalidade de Investimentos - Consulta Posicao Mensal Conta Max e Extrato</p>
 * <p>F-532 / F-533</p>
 *
 */
public interface InvestimentosCMRestService {
	
	public InvestimentosCMPosicaoResponseDTO consultaPosicaoMensal(InvestimentosCMPosicaoRequestDTO request);
	
}