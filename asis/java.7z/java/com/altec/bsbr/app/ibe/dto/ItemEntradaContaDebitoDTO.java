package com.altec.bsbr.app.ibe.dto;

public class ItemEntradaContaDebitoDTO {
	private String concatBancAgnCnt;

	/**
	 * @return the concatBancAgnCnt
	 */
	public String getConcatBancAgnCnt() {
		return concatBancAgnCnt;
	}

	/**
	 * @param concatBancAgnCnt the concatBancAgnCnt to set
	 */
	public void setConcatBancAgnCnt(String concatBancAgnCnt) {
		this.concatBancAgnCnt = concatBancAgnCnt;
	}
}
