package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class OperacaoVisaDTO implements Serializable {
	
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3014600670544310883L;
	private Long numOperacao;
	private Date dtOperacao;
	private BigDecimal vlOperacao;
	
	public Long getNumOperacao() {
		return numOperacao;
	}
	public void setNumOperacao(Long numOperacao) {
		this.numOperacao = numOperacao;
	}
	public Date getDtOperacao() {
		return dtOperacao;
	}
	public void setDtOperacao(Date dtOperacao) {
		this.dtOperacao = dtOperacao;
	}
	public BigDecimal getVlOperacao() {
		return vlOperacao;
	}
	public void setVlOperacao(BigDecimal vlOperacao) {
		this.vlOperacao = vlOperacao;
	}
	
	

}
