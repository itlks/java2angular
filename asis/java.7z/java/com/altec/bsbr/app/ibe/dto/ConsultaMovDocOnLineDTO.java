package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.xml.datatype.XMLGregorianCalendar;

public class ConsultaMovDocOnLineDTO implements Serializable {
	
	private static final long serialVersionUID = -9043219136729516799L;
	private List<MovimentoDocOnLineDTO> movDocOnLineDebitoList;
	private List<MovimentoDocOnLineDTO> movDocOnLineCreditoList;
	private BigDecimal movDocOnLineDebitoTotal;
	private BigDecimal movDocOnLineCreditoTotal;
	private String dataHoraTransacao;
	private Date dataAdesao;
	private String chaveAutenticacao;
	private String status;
	private String tipoCadastro;
	private String indRegPermanente;
	private String valLimites;
	private String indAtivacaoAutomat;
	private String indContaConjunta;
	private String nomeTitular1;
	private XMLGregorianCalendar dataInclusao; 
	private XMLGregorianCalendar dataUltimaUtilizacao; 
	private String indObrigatorio;
	private String numDoc1;
	private String tipoDoc;
	private String indMesmaTitularidade;
	private String codErro;
	
    
	/**
	 * @return the movDocOnLineDebitoList
	 */
	public List<MovimentoDocOnLineDTO> getMovDocOnLineDebitoList() {
		return movDocOnLineDebitoList;
	}
	/**
	 * @param movDocOnLineDebitoList the movDocOnLineDebitoList to set
	 */
	public void setMovDocOnLineDebitoList(List<MovimentoDocOnLineDTO> movDocOnLineDebitoList) {
		this.movDocOnLineDebitoList = movDocOnLineDebitoList;
	}
	/**
	 * @return the movDocOnLineCreditoList
	 */
	public List<MovimentoDocOnLineDTO> getMovDocOnLineCreditoList() {
		return movDocOnLineCreditoList;
	}
	/**
	 * @param movDocOnLineCreditoList the movDocOnLineCreditoList to set
	 */
	public void setMovDocOnLineCreditoList(List<MovimentoDocOnLineDTO> movDocOnLineCreditoList) {
		this.movDocOnLineCreditoList = movDocOnLineCreditoList;
	}
	/**
	 * @return the dataHoraTransacao
	 */
	public String getDataHoraTransacao() {
		return dataHoraTransacao;
	}
	/**
	 * @param dataHoraTransacao the dataHoraTransacao to set
	 */
	public void setDataHoraTransacao(String dataHoraTransacao) {
		this.dataHoraTransacao = dataHoraTransacao;
	}
	/**
	 * @return the dataAdesao
	 */
	public Date getDataAdesao() {
		return dataAdesao;
	}
	/**
	 * @param dataAdesao the dataAdesao to set
	 */
	public void setDataAdesao(Date dataAdesao) {
		this.dataAdesao = dataAdesao;
	}
	/**
	 * @return the chaveAutenticacao
	 */
	public String getChaveAutenticacao() {
		return chaveAutenticacao;
	}
	/**
	 * @param chaveAutenticacao the chaveAutenticacao to set
	 */
	public void setChaveAutenticacao(String chaveAutenticacao) {
		this.chaveAutenticacao = chaveAutenticacao;
	}
	/**
	 * @return the movDocOnLineDebitoTotal
	 */
	public BigDecimal getMovDocOnLineDebitoTotal() {
		return movDocOnLineDebitoTotal;
	}
	/**
	 * @param movDocOnLineDebitoTotal the movDocOnLineDebitoTotal to set
	 */
	public void setMovDocOnLineDebitoTotal(BigDecimal movDocOnLineDebitoTotal) {
		this.movDocOnLineDebitoTotal = movDocOnLineDebitoTotal;
	}
	/**
	 * @return the movDocOnLineCreditoTotal
	 */
	public BigDecimal getMovDocOnLineCreditoTotal() {
		return movDocOnLineCreditoTotal;
	}
	/**
	 * @param movDocOnLineCreditoTotal the movDocOnLineCreditoTotal to set
	 */
	public void setMovDocOnLineCreditoTotal(BigDecimal movDocOnLineCreditoTotal) {
		this.movDocOnLineCreditoTotal = movDocOnLineCreditoTotal;
	}
	
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the tipoCadastro
	 */
	public String getTipoCadastro() {
		return tipoCadastro;
	}
	/**
	 * @param tipoCadastro the tipoCadastro to set
	 */
	public void setTipoCadastro(String tipoCadastro) {
		this.tipoCadastro = tipoCadastro;
	}
	/**
	 * @return the indRegPermanente
	 */
	public String getIndRegPermanente() {
		return indRegPermanente;
	}
	/**
	 * @param indRegPermanente the indRegPermanente to set
	 */
	public void setIndRegPermanente(String indRegPermanente) {
		this.indRegPermanente = indRegPermanente;
	}
	/**
	 * @return the valLimites
	 */
	public String getValLimites() {
		return valLimites;
	}
	/**
	 * @param valLimites the valLimites to set
	 */
	public void setValLimites(String valLimites) {
		this.valLimites = valLimites;
	}
	/**
	 * @return the indAtivacaoAutomat
	 */
	public String getIndAtivacaoAutomat() {
		return indAtivacaoAutomat;
	}
	/**
	 * @param indAtivacaoAutomat the indAtivacaoAutomat to set
	 */
	public void setIndAtivacaoAutomat(String indAtivacaoAutomat) {
		this.indAtivacaoAutomat = indAtivacaoAutomat;
	}
	/**
	 * @return the indContaConjunta
	 */
	public String getIndContaConjunta() {
		return indContaConjunta;
	}
	/**
	 * @param indContaConjunta the indContaConjunta to set
	 */
	public void setIndContaConjunta(String indContaConjunta) {
		this.indContaConjunta = indContaConjunta;
	}
	/**
	 * @return the nomeTitular1
	 */
	public String getNomeTitular1() {
		return nomeTitular1;
	}
	/**
	 * @param nomeTitular1 the nomeTitular1 to set
	 */
	public void setNomeTitular1(String nomeTitular1) {
		this.nomeTitular1 = nomeTitular1;
	}
	/**
	 * @return the dataInclusao
	 */
	public XMLGregorianCalendar getDataInclusao() {
		return dataInclusao;
	}
	/**
	 * @param dataInclusao the dataInclusao to set
	 */
	public void setDataInclusao(XMLGregorianCalendar dataInclusao) {
		this.dataInclusao = dataInclusao;
	}
	/**
	 * @return the dataUltimaUtilizacao
	 */
	public XMLGregorianCalendar getDataUltimaUtilizacao() {
		return dataUltimaUtilizacao;
	}
	/**
	 * @param dataUltimaUtilizacao the dataUltimaUtilizacao to set
	 */
	public void setDataUltimaUtilizacao(XMLGregorianCalendar dataUltimaUtilizacao) {
		this.dataUltimaUtilizacao = dataUltimaUtilizacao;
	}
	/**
	 * @return the indObrigatorio
	 */
	public String getIndObrigatorio() {
		return indObrigatorio;
	}
	/**
	 * @param indObrigatorio the indObrigatorio to set
	 */
	public void setIndObrigatorio(String indObrigatorio) {
		this.indObrigatorio = indObrigatorio;
	}
	/**
	 * @return the numDoc1
	 */
	public String getNumDoc1() {
		return numDoc1;
	}
	/**
	 * @param numDoc1 the numDoc1 to set
	 */
	public void setNumDoc1(String numDoc1) {
		this.numDoc1 = numDoc1;
	}
	/**
	 * @return the tipoDoc
	 */
	public String getTipoDoc() {
		return tipoDoc;
	}
	/**
	 * @param tipoDoc the tipoDoc to set
	 */
	public void setTipoDoc(String tipoDoc) {
		this.tipoDoc = tipoDoc;
	}
	/**
	 * @return the indMesmaTitularidade
	 */
	public String getIndMesmaTitularidade() {
		return indMesmaTitularidade;
	}
	/**
	 * @param indMesmaTitularidade the indMesmaTitularidade to set
	 */
	public void setIndMesmaTitularidade(String indMesmaTitularidade) {
		this.indMesmaTitularidade = indMesmaTitularidade;
	}
	/**
	 * @return the codErro
	 */
	public String getCodErro() {
		return codErro;
	}
	/**
	 * @param codErro the codErro to set
	 */
	public void setCodErro(String codErro) {
		this.codErro = codErro;
	}

}
