package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class ListaAgendamentoDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6669810834239807397L;
	private String numeroProtocolo;
	private String tipoOperacao;
	private String transacao;
	private String situacao;
	private String dataSolicitacao;
	private String horaSolicitacao;
	private String dataAgendada;
	private String horaAgendada;
	private BigDecimal valor;
	private Date dataHoraSolicitacao;
	private Date dataAgendadaFormatada;
	private String motivo;
	
	public String getTipoOperacao() {
		return tipoOperacao;
	}
	public void setTipoOperacao(String tipoOperacao) {
		this.tipoOperacao = tipoOperacao;
	}
	public String getTransacao() {
		return transacao;
	}
	public void setTransacao(String transacao) {
		this.transacao = transacao;
	}
	public String getSituacao() {
		return situacao;
	}
	public void setSituacao(String situacao) {
		this.situacao = situacao;
	}
	public String getDataSolicitacao() {
		return dataSolicitacao;
	}
	public void setDataSolicitacao(String dataSolicitacao) {
		this.dataSolicitacao = dataSolicitacao;
	}
	public String getHoraSolicitacao() {
		return horaSolicitacao;
	}
	public void setHoraSolicitacao(String horaSolicitacao) {
		this.horaSolicitacao = horaSolicitacao;
	}
	public String getDataAgendada() {
		return dataAgendada;
	}
	public void setDataAgendada(String dataAgendada) {
		this.dataAgendada = dataAgendada;
	}
	public String getHoraAgendada() {
		return horaAgendada;
	}
	public void setHoraAgendada(String horaAgendada) {
		this.horaAgendada = horaAgendada;
	}
	public BigDecimal getValor() {
		return valor;
	}
	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}
	public Date getDataHoraSolicitacao() {
		return dataHoraSolicitacao;
	}
	public void setDataHoraSolicitacao(Date dataHoraSolicitacao) {
		this.dataHoraSolicitacao = dataHoraSolicitacao;
	}
	public Date getDataAgendadaFormatada() {
		return dataAgendadaFormatada;
	}
	public void setDataAgendadaFormatada(Date dataAgendadaFormatada) {
		this.dataAgendadaFormatada = dataAgendadaFormatada;
	}
	public String getMotivo() {
		return motivo;
	}
	public void setMotivo(String motivo) {
		this.motivo = motivo;
	}
	public String getNumeroProtocolo() {
		return numeroProtocolo;
	}
	public void setNumeroProtocolo(String numeroProtocolo) {
		this.numeroProtocolo = numeroProtocolo;
	}
}
