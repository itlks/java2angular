package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class ConsorcioDadosGrupoDTO implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	private String nomeCliente;
	private String grupo;
	private String cnpj;
	private String bem;
	private String cota;
	private String prazo;
	private String dataPrimeiraAssembleia;
	private String dataLanceEmbutido;
	private String dataEncerramentoPrevisto;
	private String dataSituacaoGrupo;
	private String numeroParticipantes;
	private String situGrupo;
	private String modalidade;
	private String codigoProduto;
	private String nomeProduto;
	private String tipoSorteio;
	private String multa;
	private String juros;
	private String flagLanceLivre;
	private String flagLanceDiluido;
	private String flagLanceEmbutido;
	private String lanceMaximo;

	/**
	 * @return the nomeCliente
	 */
	public String getNomeCliente() {
		return nomeCliente;
	}

	/**
	 * @param nomeCliente
	 *            the nomeCliente to set
	 */
	public void setNomeCliente(String nomeCliente) {
		this.nomeCliente = nomeCliente;
	}

	/**
	 * @return the grupo
	 */
	public String getGrupo() {
		return grupo;
	}

	/**
	 * @param grupo
	 *            the grupo to set
	 */
	public void setGrupo(String grupo) {
		this.grupo = grupo;
	}

	/**
	 * @return the bem
	 */
	public String getBem() {
		return bem;
	}

	/**
	 * @param bem
	 *            the bem to set
	 */
	public void setBem(String bem) {
		this.bem = bem;
	}

	/**
	 * @return the cota
	 */
	public String getCota() {
		return cota;
	}

	/**
	 * @param cota
	 *            the cota to set
	 */
	public void setCota(String cota) {
		this.cota = cota;
	}

	/**
	 * @return the prazo
	 */
	public String getPrazo() {
		return prazo;
	}

	/**
	 * @param prazo
	 *            the prazo to set
	 */
	public void setPrazo(String prazo) {
		this.prazo = prazo;
	}

	/**
	 * @return the dataPrimeiraAssembleia
	 */
	public String getDataPrimeiraAssembleia() {
		return dataPrimeiraAssembleia;
	}

	/**
	 * @param dataPrimeiraAssembleia
	 *            the dataPrimeiraAssembleia to set
	 */
	public void setDataPrimeiraAssembleia(String dataPrimeiraAssembleia) {
		this.dataPrimeiraAssembleia = dataPrimeiraAssembleia;
	}

	/**
	 * @return the dataLanceEmbutido
	 */
	public String getDataLanceEmbutido() {
		return dataLanceEmbutido;
	}

	/**
	 * @param dataLanceEmbutido
	 *            the dataLanceEmbutido to set
	 */
	public void setDataLanceEmbutido(String dataLanceEmbutido) {
		this.dataLanceEmbutido = dataLanceEmbutido;
	}

	/**
	 * @return the numeroParticipantes
	 */
	public String getNumeroParticipantes() {
		return numeroParticipantes;
	}

	/**
	 * @param numeroParticipantes
	 *            the numeroParticipantes to set
	 */
	public void setNumeroParticipantes(String numeroParticipantes) {
		this.numeroParticipantes = numeroParticipantes;
	}

	/**
	 * @return the dataEncerramentoPrevisto
	 */
	public String getDataEncerramentoPrevisto() {
		return dataEncerramentoPrevisto;
	}

	/**
	 * @param dataEncerramentoPrevisto
	 *            the dataEncerramentoPrevisto to set
	 */
	public void setDataEncerramentoPrevisto(String dataEncerramentoPrevisto) {
		this.dataEncerramentoPrevisto = dataEncerramentoPrevisto;
	}

	/**
	 * @return the situGrupo
	 */
	public String getSituGrupo() {
		return situGrupo;
	}

	/**
	 * @param situGrupo
	 *            the situGrupo to set
	 */
	public void setSituGrupo(String situGrupo) {
		this.situGrupo = situGrupo;
	}

	/**
	 * @return the modalidade
	 */
	public String getModalidade() {
		return modalidade;
	}

	/**
	 * @param modalidade
	 *            the modalidade to set
	 */
	public void setModalidade(String modalidade) {
		this.modalidade = modalidade;
	}

	/**
	 * @return the cnpj
	 */
	public String getCnpj() {
		return cnpj;
	}

	/**
	 * @param cnpj
	 *            the cnpj to set
	 */
	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	/**
	 * @return the dataSituacaoGrupo
	 */
	public String getDataSituacaoGrupo() {
		return dataSituacaoGrupo;
	}

	/**
	 * @param dataSituacaoGrupo
	 *            the dataSituacaoGrupo to set
	 */
	public void setDataSituacaoGrupo(String dataSituacaoGrupo) {
		this.dataSituacaoGrupo = dataSituacaoGrupo;
	}

	/**
	 * @return the codigoProduto
	 */
	public String getCodigoProduto() {
		return codigoProduto;
	}

	/**
	 * @param codigoProduto
	 *            the codigoProduto to set
	 */
	public void setCodigoProduto(String codigoProduto) {
		this.codigoProduto = codigoProduto;
	}

	/**
	 * @return the nomeProduto
	 */
	public String getNomeProduto() {
		return nomeProduto;
	}

	/**
	 * @param nomeProduto
	 *            the nomeProduto to set
	 */
	public void setNomeProduto(String nomeProduto) {
		this.nomeProduto = nomeProduto;
	}

	/**
	 * @return the tipoSorteio
	 */
	public String getTipoSorteio() {
		return tipoSorteio;
	}

	/**
	 * @param tipoSorteio
	 *            the tipoSorteio to set
	 */
	public void setTipoSorteio(String tipoSorteio) {
		this.tipoSorteio = tipoSorteio;
	}

	/**
	 * @return the multa
	 */
	public String getMulta() {
		return multa;
	}

	/**
	 * @param multa
	 *            the multa to set
	 */
	public void setMulta(String multa) {
		this.multa = multa;
	}

	/**
	 * @return the juros
	 */
	public String getJuros() {
		return juros;
	}

	/**
	 * @param juros
	 *            the juros to set
	 */
	public void setJuros(String juros) {
		this.juros = juros;
	}

	/**
	 * @return the flagLanceLivre
	 */
	public String getFlagLanceLivre() {
		return flagLanceLivre;
	}

	/**
	 * @param flagLanceLivre
	 *            the flagLanceLivre to set
	 */
	public void setFlagLanceLivre(String flagLanceLivre) {
		this.flagLanceLivre = flagLanceLivre;
	}

	/**
	 * @return the flagLanceDiluido
	 */
	public String getFlagLanceDiluido() {
		return flagLanceDiluido;
	}

	/**
	 * @param flagLanceDiluido
	 *            the flagLanceDiluido to set
	 */
	public void setFlagLanceDiluido(String flagLanceDiluido) {
		this.flagLanceDiluido = flagLanceDiluido;
	}

	/**
	 * @return the flagLanceEmbutido
	 */
	public String getFlagLanceEmbutido() {
		return flagLanceEmbutido;
	}

	/**
	 * @param flagLanceEmbutido
	 *            the flagLanceEmbutido to set
	 */
	public void setFlagLanceEmbutido(String flagLanceEmbutido) {
		this.flagLanceEmbutido = flagLanceEmbutido;
	}

	/**
	 * @return the lanceMaximo
	 */
	public String getLanceMaximo() {
		return lanceMaximo;
	}

	/**
	 * @param lanceMaximo
	 *            the lanceMaximo to set
	 */
	public void setLanceMaximo(String lanceMaximo) {
		this.lanceMaximo = lanceMaximo;
	}

}
