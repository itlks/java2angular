package com.altec.bsbr.app.ibe.dto;

import com.altec.bsbr.app.ibe.tributos.dto.TributoGareSPRequestDTO;

public class GareDRSPWebDTO {

	private TributoGareSPRequestDTO entrada;
	
	public TributoGareSPRequestDTO getEntrada() {
		return entrada;
	}

	public void setEntrada(TributoGareSPRequestDTO entrada) {
		this.entrada = entrada;
	}
	
}
