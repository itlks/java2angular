package com.altec.bsbr.app.ibe.parser.perfil;

/**
 * Exception que sera lancada caso ocorra algum erro no
 * parse do XML de mapeamento de formatos do PS7.
 *
 * @author Marcelo Ohashi
 * @version 1.0
 * @since 1.0
 */
@SuppressWarnings("serial")
public class DataParserException extends Exception {

    /**
     *
     * @param cause
     */
    public DataParserException(Throwable cause) {
        super(cause);
    }
    
}
