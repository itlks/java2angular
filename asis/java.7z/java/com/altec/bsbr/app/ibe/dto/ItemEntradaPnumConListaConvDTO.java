package com.altec.bsbr.app.ibe.dto;

public class ItemEntradaPnumConListaConvDTO {
	private String penump;

	/**
	 * @return the penump
	 */
	public String getPenump() {
		return penump;
	}

	/**
	 * @param penump the penump to set
	 */
	public void setPenump(String penump) {
		this.penump = penump;
	}
	
	
}
