package com.altec.bsbr.app.ibe.dto.investimentos.posicaomensal;

import java.io.Serializable;

/**
 * 
 * @author x187169 - Julio R.G. Leme
 * @since 2017-03-22
 * @version 1.0
 * <p>	DTO WEB para a funcionalidade de Investimentos - Consulta Posicao Mensal Conta Max F-532 </p>
 *
 */
public class SaidaPosicaoMensalDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String anoMesReferencia;
	private String valorBrutoAnterior;
	private String valorAplicacao;
	private String valorResgate;
	private String valorRendimento;
	private String valorBrutoFim;
	private String valorLiquidoFinal;
	private String valorIOF;
	private String valorIR;

	/**
	 * getters and setters
	 */
	public String getAnoMesReferencia() {
		return anoMesReferencia;
	}

	public String getValorBrutoAnterior() {
		return valorBrutoAnterior;
	}

	public String getValorAplicacao() {
		return valorAplicacao;
	}

	public String getValorResgate() {
		return valorResgate;
	}

	public String getValorRendimento() {
		return valorRendimento;
	}

	public String getValorBrutoFim() {
		return valorBrutoFim;
	}

	public String getValorLiquidoFinal() {
		return valorLiquidoFinal;
	}

	public void setAnoMesReferencia(String anoMesReferencia) {
		this.anoMesReferencia = anoMesReferencia;
	}

	public void setValorBrutoAnterior(String valorBrutoAnterior) {
		this.valorBrutoAnterior = valorBrutoAnterior;
	}

	public void setValorAplicacao(String valorAplicacao) {
		this.valorAplicacao = valorAplicacao;
	}

	public void setValorResgate(String valorResgate) {
		this.valorResgate = valorResgate;
	}

	public void setValorRendimento(String valorRendimento) {
		this.valorRendimento = valorRendimento;
	}

	public void setValorBrutoFim(String valorBrutoFim) {
		this.valorBrutoFim = valorBrutoFim;
	}

	public void setValorLiquidoFinal(String valorLiquidoFinal) {
		this.valorLiquidoFinal = valorLiquidoFinal;
	}

	public String getValorIOF() {
		return valorIOF;
	}

	public void setValorIOF(String valorIOF) {
		this.valorIOF = valorIOF;
	}

	public String getValorIR() {
		return valorIR;
	}

	public void setValorIR(String valorIR) {
		this.valorIR = valorIR;
	}

}
