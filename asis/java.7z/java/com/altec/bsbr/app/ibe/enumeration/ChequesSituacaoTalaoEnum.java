package com.altec.bsbr.app.ibe.enumeration;

public enum ChequesSituacaoTalaoEnum {
	
	SIT("", " ", ""), 
	SIT_1("1", "SOLICITADO", "BLOQUEADO"),
	SIT_2("2", "FABRICACAO", "BLOQUEADO"),
	SIT_3("3", "POSTADO", "BLOQUEADO"),
	SIT_4("4", "RECEBIDO", "BLOQUEADO"),	
	SIT_5("5", "EXPEDIDO", "BLOQUEADO"),	
	SIT_7("6", "DEVOLVIDO AGENCIA", "BLOQUEADO"),
	
	
	SIT_E("E", "RECEBIDO", "DESBLOQUEADO"),
	SIT_P("P", "EXPEDIDO", "BLOQUEADO"),
	SIT_O("O", "DISPONIVEL AGENCIA", "BLOQUEADO"),
	SIT_D("D", "CANCELADO", "BLOQUEADO"),
	SIT_Q("Q", "SUSTADO", "DESBLOQUEADO"),
	SIT_T("T", "UTILIZADO", "DESBLOQUEADO");
	
	private String value;
	private String situacao;
	private String observacao;
	
	private ChequesSituacaoTalaoEnum(String value, String situacao, String observacao){
		this.value = value;
		this.situacao = situacao;
		this.observacao = observacao;
	}
	
	public static String findSituacaoByValue(String value){
		String retorno = "";
		
		for(ChequesSituacaoTalaoEnum item : ChequesSituacaoTalaoEnum.values()){
			if(item.getValue().equalsIgnoreCase(value)){
				retorno = item.getSituacao();
				break;
			}
		}
		
		return retorno;
	}
	
	
	public static String findObservacaoByValue(String value){
		String retorno = "";
		
		for(ChequesSituacaoTalaoEnum item : ChequesSituacaoTalaoEnum.values()){
			if(item.getValue().equalsIgnoreCase(value)){
				retorno = item.getObservacao();
				break;
			}
		}
		
		return retorno;
	}

	public String getSituacao() {
		return situacao;
	}

	public String getObservacao() {
		return observacao;
	}

	public String getValue() {
		return value;
	}
}
