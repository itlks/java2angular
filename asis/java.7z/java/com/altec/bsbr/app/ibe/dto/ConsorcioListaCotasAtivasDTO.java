package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.List;

public class ConsorcioListaCotasAtivasDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6068724848185205709L;
	
	private String cliente;
	private String cnpj;
	private String grupo;
	private String cota;
	private String bem;
	private String codBem;
	private List<ItemConsorcioListaCotasAtivasDTO> listaDTO;
	private ItemConsorcioListaCotasAtivasDTO itemSelecionado;
		
	/**
	 * @return the itemSelecionado
	 */
	public ItemConsorcioListaCotasAtivasDTO getItemSelecionado() {
		return itemSelecionado;
	}
	/**
	 * @param itemSelecionado the itemSelecionado to set
	 */
	public void setItemSelecionado(ItemConsorcioListaCotasAtivasDTO itemSelecionado) {
		this.itemSelecionado = itemSelecionado;
	}
	/**
	 * @return the listaDTO
	 */
	public List<ItemConsorcioListaCotasAtivasDTO> getListaDTO() {
		return listaDTO;
	}
	/**
	 * @param listaDTO the listaDTO to set
	 */
	public void setListaDTO(List<ItemConsorcioListaCotasAtivasDTO> listaDTO) {
		this.listaDTO = listaDTO;
	}
	/**
	 * @return the cliente
	 */
	public String getCliente() {
		return cliente;
	}
	/**
	 * @param cliente the cliente to set
	 */
	public void setCliente(String cliente) {
		this.cliente = cliente;
	}
	/**
	 * @return the cnpj
	 */
	public String getCnpj() {
		return cnpj;
	}
	/**
	 * @param cnpj the cnpj to set
	 */
	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}
	/**
	 * @return the grupo
	 */
	public String getGrupo() {
		return grupo;
	}
	/**
	 * @param grupo the grupo to set
	 */
	public void setGrupo(String grupo) {
		this.grupo = grupo;
	}
	/**
	 * @return the cota
	 */
	public String getCota() {
		return cota;
	}
	/**
	 * @param cota the cota to set
	 */
	public void setCota(String cota) {
		this.cota = cota;
	}
	/**
	 * @return the bem
	 */
	public String getBem() {
		return bem;
	}
	/**
	 * @param bem the bem to set
	 */
	public void setBem(String bem) {
		this.bem = bem;
	}
	public String getCodBem() {
		return codBem;
	}
	public void setCodBem(String codBem) {
		this.codBem = codBem;
	}
	
}
