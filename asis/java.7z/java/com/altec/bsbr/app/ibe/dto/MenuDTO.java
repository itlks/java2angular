package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class MenuDTO implements Serializable {

	private static final long serialVersionUID = -2408064392055505967L;

	private Integer idItemMenu;         
	private Integer idItemMenuPrin;     
	private String noItemMenu;         
	private Integer coColunaMenu;      
	private String coCamiPagina;       
	private String inInclExcl;
	private String coCamiBanner;
	private String coCamiBannerLink;
	private String obrAssinatura;

	public MenuDTO() {
		super();
	}
	public Integer getIdItemMenu() {
		return idItemMenu;
	}
	public void setIdItemMenu(Integer idItemMenu) {
		this.idItemMenu = idItemMenu;
	}
	public Integer getIdItemMenuPrin() {
		return idItemMenuPrin;
	}
	public void setIdItemMenuPrin(Integer idItemMenuPrin) {
		this.idItemMenuPrin = idItemMenuPrin;
	}
	public String getNoItemMenu() {
		return noItemMenu;
	}
	public void setNoItemMenu(String noItemMenu) {
		this.noItemMenu = noItemMenu;
	}
	public Integer getCoColunaMenu() {
		return coColunaMenu;
	}
	public void setCoColunaMenu(Integer coColunaMenu) {
		this.coColunaMenu = coColunaMenu;
	}
	public String getCoCamiPagina() {
		return coCamiPagina;
	}
	public void setCoCamiPagina(String coCamiPagina) {
		this.coCamiPagina = coCamiPagina;
	}
	public String getInInclExcl() {
		return inInclExcl;
	}
	public void setInInclExcl(String inInclExcl) {
		this.inInclExcl = inInclExcl;
	}
	public String getCoCamiBanner() {
		return coCamiBanner;
	}
	public void setCoCamiBanner(String coCamiBanner) {
		this.coCamiBanner = coCamiBanner;
	}
	public String getCoCamiBannerLink() {
		return coCamiBannerLink;
	}
	public void setCoCamiBannerLink(String coCamiBannerLink) {
		this.coCamiBannerLink = coCamiBannerLink;
	}
	
	public String getObrAssinatura() {
		return obrAssinatura;
	}
	public void setObrAssinatura(String obrAssinatura) {
		this.obrAssinatura = obrAssinatura;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((coCamiBanner == null) ? 0 : coCamiBanner.hashCode());
		result = prime * result + ((coCamiBannerLink == null) ? 0 : coCamiBannerLink.hashCode());
		result = prime * result + ((coCamiPagina == null) ? 0 : coCamiPagina.hashCode());
		result = prime * result + ((coColunaMenu == null) ? 0 : coColunaMenu.hashCode());
		result = prime * result + ((idItemMenu == null) ? 0 : idItemMenu.hashCode());
		result = prime * result + ((idItemMenuPrin == null) ? 0 : idItemMenuPrin.hashCode());
		result = prime * result + ((inInclExcl == null) ? 0 : inInclExcl.hashCode());
		result = prime * result + ((noItemMenu == null) ? 0 : noItemMenu.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MenuDTO other = (MenuDTO) obj;
		if (coCamiBanner == null) {
			if (other.coCamiBanner != null)
				return false;
		} else if (!coCamiBanner.equals(other.coCamiBanner))
			return false;
		if (coCamiBannerLink == null) {
			if (other.coCamiBannerLink != null)
				return false;
		} else if (!coCamiBannerLink.equals(other.coCamiBannerLink))
			return false;
		if (coCamiPagina == null) {
			if (other.coCamiPagina != null)
				return false;
		} else if (!coCamiPagina.equals(other.coCamiPagina))
			return false;
		if (coColunaMenu == null) {
			if (other.coColunaMenu != null)
				return false;
		} else if (!coColunaMenu.equals(other.coColunaMenu))
			return false;
		if (idItemMenu == null) {
			if (other.idItemMenu != null)
				return false;
		} else if (!idItemMenu.equals(other.idItemMenu))
			return false;
		if (idItemMenuPrin == null) {
			if (other.idItemMenuPrin != null)
				return false;
		} else if (!idItemMenuPrin.equals(other.idItemMenuPrin))
			return false;
		if (inInclExcl == null) {
			if (other.inInclExcl != null)
				return false;
		} else if (!inInclExcl.equals(other.inInclExcl))
			return false;
		if (noItemMenu == null) {
			if (other.noItemMenu != null)
				return false;
		} else if (!noItemMenu.equals(other.noItemMenu))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return getNoItemMenu();
	}

}
