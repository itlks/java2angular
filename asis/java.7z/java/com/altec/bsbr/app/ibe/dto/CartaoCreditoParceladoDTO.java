package com.altec.bsbr.app.ibe.dto;

public class CartaoCreditoParceladoDTO {

	private String tipoCartao;
	private String numeroCartao;
	private String nomeGravadoCartao;
	private String descricaoCartao;
	private String imagemBandeira;
	private String descrBandeira;

	
	public String getTipoCartao() {
		return tipoCartao;
	}
	public void setTipoCartao(String tipoCartao) {
		this.tipoCartao = tipoCartao;
	}
	public String getNumeroCartao() {
		return numeroCartao;
	}
	public void setNumeroCartao(String numeroCartao) {
		this.numeroCartao = numeroCartao;
	}
	public String getNomeGravadoCartao() {
		return nomeGravadoCartao;
	}
	public void setNomeGravadoCartao(String nomeGravadoCartao) {
		this.nomeGravadoCartao = nomeGravadoCartao;
	}
	public String getDescricaoCartao() {
		return descricaoCartao;
	}
	public void setDescricaoCartao(String descricaoCartao) {
		this.descricaoCartao = descricaoCartao;
	}
	public String getImagemBandeira() {
		return imagemBandeira;
	}
	public void setImagemBandeira(String imagemBandeira) {
		this.imagemBandeira = imagemBandeira;
	}
	public String getDescrBandeira() {
		return descrBandeira;
	}
	public void setDescrBandeira(String descrBandeira) {
		this.descrBandeira = descrBandeira;
	}
	
	public String getNumeroCartaoFormatado(){
		String nrCartao = getNumeroCartao();
		StringBuilder retorno = new StringBuilder();
		
		return retorno.append("XXXX.XXXX.XXXX.").append(nrCartao.substring(12, 16)).toString();
	}
}
