package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class LimitesUtilResponseDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private int retCode;

	private List<ItemLimitesUtilResponseDTO> listaLimitesUtilizado = new ArrayList<ItemLimitesUtilResponseDTO>();

	public LimitesUtilResponseDTO() {
	}

	public List<ItemLimitesUtilResponseDTO> getListaLimitesUtilizado() {
		return listaLimitesUtilizado;
	}

	public void setListaLimitesUtilizado(List<ItemLimitesUtilResponseDTO> listaLimitesUtilizado) {
		this.listaLimitesUtilizado = listaLimitesUtilizado;
	}

	public int getRetCode() {
		return retCode;
	}

	public void setRetCode(int retCode) {
		this.retCode = retCode;
	}

}