package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

import com.altec.bsbr.app.ibe.dto.buscaagencia.ErrosDTO;

public class BuscaNomesAgenciaDTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1618883810139300227L;
	
	private String saida;
	private String strNomeAgeOrigem;
	private String strNomeAgeDest;
	private String strErro;
	private String strErroTecnica;
	private Long lngRetCode;
	private ErrosDTO erros;
	public String getSaida() {
		return saida;
	}
	public void setSaida(String saida) {
		this.saida = saida;
	}
	public String getStrNomeAgeOrigem() {
		return strNomeAgeOrigem;
	}
	public void setStrNomeAgeOrigem(String strNomeAgeOrigem) {
		this.strNomeAgeOrigem = strNomeAgeOrigem;
	}
	public String getStrNomeAgeDest() {
		return strNomeAgeDest;
	}
	public void setStrNomeAgeDest(String strNomeAgeDest) {
		this.strNomeAgeDest = strNomeAgeDest;
	}
	public String getStrErro() {
		return strErro;
	}
	public void setStrErro(String strErro) {
		this.strErro = strErro;
	}
	public String getStrErroTecnica() {
		return strErroTecnica;
	}
	public void setStrErroTecnica(String strErroTecnica) {
		this.strErroTecnica = strErroTecnica;
	}
	public Long getLngRetCode() {
		return lngRetCode;
	}
	public void setLngRetCode(Long lngRetCode) {
		this.lngRetCode = lngRetCode;
	}
	public ErrosDTO getErros() {
		return erros;
	}
	public void setErros(ErrosDTO erros) {
		this.erros = erros;
	}

	
}
