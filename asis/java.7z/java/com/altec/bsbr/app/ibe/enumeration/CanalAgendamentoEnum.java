package com.altec.bsbr.app.ibe.enumeration;

public enum CanalAgendamentoEnum {
	
	INTERNET_BANKING(1,"Internet Banking"),
	SUPER_LINHA(2,"Superlinha"),
	AUTO_ATENDIMENTO(3,"Auto Atendimento"),
	HOME_BANKING(4,"Home Banking"),
	CAIXA(5,"Caixa"),
	WAP(6,"WAP"),
	RETAGUARDA(7,"Retaguarda"),
	AUTO_ATENDIMENTO_SANTANDER(8,"Auto-Atendimento Santander"),
	SANTANDER_CAPITALIZACAO(9,"Santander Capitaliza��o"),
	SAC(10,"SAC"),
	TERMINAL_FINANCEIRO(25,"Terminal Financeiro"),
	HOST(90,"Host"),
	POS(48,"POS"),
	NAO_IDENTIFICADO(0,"N�o identificado");
	
	private int id;
	private String descricao;
	
	private CanalAgendamentoEnum(int id, String descricao) {
		this.id = id;
		this.descricao = descricao;
	}

	public int getId() {
		return id;
	}

	public String getDescricao() {
		return descricao;
	}
	
	public static CanalAgendamentoEnum findById(int id){
		CanalAgendamentoEnum retorno = null;
		
		for (CanalAgendamentoEnum canal: values()) {
			if (canal.getId() == id) {
				retorno = canal;
				break;
			}
		}
		
		return retorno == null ? NAO_IDENTIFICADO : retorno;
	}

}
