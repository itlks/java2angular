package com.altec.bsbr.app.ibe.dto.investimentos.posicaomensal.consulta;

import java.io.Serializable;
import java.util.List;

public class SaidaConsultaParametroDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String dataOper;
	private String valorMinConta;
	private String valorMinProduto;
	private List<String> anoMesReferencia;

	public String getDataOper() {
		return dataOper;
	}

	public void setDataOper(String dataOper) {
		this.dataOper = dataOper;
	}

	public String getValorMinConta() {
		return valorMinConta;
	}

	public void setValorMinConta(String valorMinConta) {
		this.valorMinConta = valorMinConta;
	}

	public String getValorMinProduto() {
		return valorMinProduto;
	}

	public void setValorMinProduto(String valorMinProduto) {
		this.valorMinProduto = valorMinProduto;
	}

	public List<String> getAnoMesReferencia() {
		return anoMesReferencia;
	}

	public void setAnoMesReferencia(List<String> anoMesReferencia) {
		this.anoMesReferencia = anoMesReferencia;
	}

}
