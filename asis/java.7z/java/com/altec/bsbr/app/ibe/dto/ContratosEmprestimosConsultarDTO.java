package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * @author x185816
 *
 */
public class ContratosEmprestimosConsultarDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 6660773043346049593L;

	private String numeroContrato;
	private String produto;
	private String subProduto;
	private String valorEmprestimo;
	private String numeroParcelas;
	private Date inicio;
	private Date venciomentoFinal;
	private String nome;

	public ContratosEmprestimosConsultarDTO() {

	}

	public String getNumeroContrato() {
		return numeroContrato;
	}

	public void setNumeroContrato(String numeroContrato) {
		this.numeroContrato = numeroContrato;
	}

	public String getProduto() {
		return produto;
	}

	public void setProduto(String produto) {
		this.produto = produto;
	}

	public String getValorEmprestimo() {
		return valorEmprestimo;
	}

	public void setValorEmprestimo(String valorEmprestimo) {
		this.valorEmprestimo = valorEmprestimo;
	}

	public String getNumeroParcelas() {
		return numeroParcelas;
	}

	public void setNumeroParcelas(String numeroParcelas) {
		this.numeroParcelas = numeroParcelas;
	}

	public Date getInicio() {
		return inicio;
	}

	public void setInicio(Date inicio) {
		this.inicio = inicio;
	}

	public Date getVenciomentoFinal() {
		return venciomentoFinal;
	}

	public void setVenciomentoFinal(Date venciomentoFinal) {
		this.venciomentoFinal = venciomentoFinal;
	}

	public String getSubProduto() {
		return subProduto;
	}

	public void setSubProduto(String subProduto) {
		this.subProduto = subProduto;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
}