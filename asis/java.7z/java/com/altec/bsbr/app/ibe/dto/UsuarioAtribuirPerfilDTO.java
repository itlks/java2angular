package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class UsuarioAtribuirPerfilDTO implements Serializable {

	private static final long serialVersionUID = 4415861601246014287L;

	private String agencia;
	private String conta;
	private String banco;
	private String perfilAcesso;
	private String perfilAutorizacao;
	private String descricaoPerfilAcesso;
	private String descricaoPerfilAutorizacao;
	
	public UsuarioAtribuirPerfilDTO() {}

	
	public String getPerfilAcesso() {
		return perfilAcesso;
	}

	public void setPerfilAcesso(String perfilAcesso) {
		this.perfilAcesso = perfilAcesso;
	}

	public String getPerfilAutorizacao() {
		return perfilAutorizacao;
	}

	public void setPerfilAutorizacao(String perfilAutorizacao) {
		this.perfilAutorizacao = perfilAutorizacao;
	}


	public String getAgencia() {
		return agencia;
	}


	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}


	public String getConta() {
		return conta;
	}


	public void setConta(String conta) {
		this.conta = conta;
	}


	public String getBanco() {
		return banco;
	}


	public void setBanco(String banco) {
		this.banco = banco;
	}


	public String getDescricaoPerfilAcesso() {
		return descricaoPerfilAcesso;
	}


	public void setDescricaoPerfilAcesso(String descricaoPerfilAcesso) {
		this.descricaoPerfilAcesso = descricaoPerfilAcesso;
	}


	public String getDescricaoPerfilAutorizacao() {
		return descricaoPerfilAutorizacao;
	}


	public void setDescricaoPerfilAutorizacao(String descricaoPerfilAutorizacao) {
		this.descricaoPerfilAutorizacao = descricaoPerfilAutorizacao;
	}

	
	
	
}
