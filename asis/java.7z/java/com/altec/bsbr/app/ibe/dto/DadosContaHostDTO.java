package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class DadosContaHostDTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8864408936847095134L;
	private String OECDPAR0084;
	private String OENMPAR0084;
	private String OECDIDTPARRF0084;
	private String OECDTPPES0084;
	private String OESTPAR0084;
	private String OEIDTTTLPAR0084;
	private String OECDPAR20084;
	private String OENMPAR20084;
	private String OECDCPFPF20084;
	private String OECDTPPES20084;
	private String OESTPAR20084;
	private String OETPCC0084;
	private String OECDSITCC0084;
	private String OETPUORCC0084;
	private String OECDUORCC0084;
	private String OECDGRCTBCC0084;
	private String OECDNVLCTBCC0084;
	private String OEFUNCIONARIOPMSP;
	private String OEADESAOPMSP;
	private String OEDTAULTABORDAGEMPMSP;
	private String OEIDENTIDADE0110;
	public String getOECDPAR0084() {
		return OECDPAR0084;
	}
	public void setOECDPAR0084(String oECDPAR0084) {
		OECDPAR0084 = oECDPAR0084;
	}
	public String getOENMPAR0084() {
		return OENMPAR0084;
	}
	public void setOENMPAR0084(String oENMPAR0084) {
		OENMPAR0084 = oENMPAR0084;
	}
	public String getOECDIDTPARRF0084() {
		return OECDIDTPARRF0084;
	}
	public void setOECDIDTPARRF0084(String oECDIDTPARRF0084) {
		OECDIDTPARRF0084 = oECDIDTPARRF0084;
	}
	public String getOECDTPPES0084() {
		return OECDTPPES0084;
	}
	public void setOECDTPPES0084(String oECDTPPES0084) {
		OECDTPPES0084 = oECDTPPES0084;
	}
	public String getOESTPAR0084() {
		return OESTPAR0084;
	}
	public void setOESTPAR0084(String oESTPAR0084) {
		OESTPAR0084 = oESTPAR0084;
	}
	public String getOEIDTTTLPAR0084() {
		return OEIDTTTLPAR0084;
	}
	public void setOEIDTTTLPAR0084(String oEIDTTTLPAR0084) {
		OEIDTTTLPAR0084 = oEIDTTTLPAR0084;
	}
	public String getOECDPAR20084() {
		return OECDPAR20084;
	}
	public void setOECDPAR20084(String oECDPAR20084) {
		OECDPAR20084 = oECDPAR20084;
	}
	public String getOENMPAR20084() {
		return OENMPAR20084;
	}
	public void setOENMPAR20084(String oENMPAR20084) {
		OENMPAR20084 = oENMPAR20084;
	}
	public String getOECDCPFPF20084() {
		return OECDCPFPF20084;
	}
	public void setOECDCPFPF20084(String oECDCPFPF20084) {
		OECDCPFPF20084 = oECDCPFPF20084;
	}
	public String getOECDTPPES20084() {
		return OECDTPPES20084;
	}
	public void setOECDTPPES20084(String oECDTPPES20084) {
		OECDTPPES20084 = oECDTPPES20084;
	}
	public String getOESTPAR20084() {
		return OESTPAR20084;
	}
	public void setOESTPAR20084(String oESTPAR20084) {
		OESTPAR20084 = oESTPAR20084;
	}
	public String getOETPCC0084() {
		return OETPCC0084;
	}
	public void setOETPCC0084(String oETPCC0084) {
		OETPCC0084 = oETPCC0084;
	}
	public String getOECDSITCC0084() {
		return OECDSITCC0084;
	}
	public void setOECDSITCC0084(String oECDSITCC0084) {
		OECDSITCC0084 = oECDSITCC0084;
	}
	public String getOETPUORCC0084() {
		return OETPUORCC0084;
	}
	public void setOETPUORCC0084(String oETPUORCC0084) {
		OETPUORCC0084 = oETPUORCC0084;
	}
	public String getOECDUORCC0084() {
		return OECDUORCC0084;
	}
	public void setOECDUORCC0084(String oECDUORCC0084) {
		OECDUORCC0084 = oECDUORCC0084;
	}
	public String getOECDGRCTBCC0084() {
		return OECDGRCTBCC0084;
	}
	public void setOECDGRCTBCC0084(String oECDGRCTBCC0084) {
		OECDGRCTBCC0084 = oECDGRCTBCC0084;
	}
	public String getOECDNVLCTBCC0084() {
		return OECDNVLCTBCC0084;
	}
	public void setOECDNVLCTBCC0084(String oECDNVLCTBCC0084) {
		OECDNVLCTBCC0084 = oECDNVLCTBCC0084;
	}
	public String getOEFUNCIONARIOPMSP() {
		return OEFUNCIONARIOPMSP;
	}
	public void setOEFUNCIONARIOPMSP(String oEFUNCIONARIOPMSP) {
		OEFUNCIONARIOPMSP = oEFUNCIONARIOPMSP;
	}
	public String getOEADESAOPMSP() {
		return OEADESAOPMSP;
	}
	public void setOEADESAOPMSP(String oEADESAOPMSP) {
		OEADESAOPMSP = oEADESAOPMSP;
	}
	public String getOEDTAULTABORDAGEMPMSP() {
		return OEDTAULTABORDAGEMPMSP;
	}
	public void setOEDTAULTABORDAGEMPMSP(String oEDTAULTABORDAGEMPMSP) {
		OEDTAULTABORDAGEMPMSP = oEDTAULTABORDAGEMPMSP;
	}
	public String getOEIDENTIDADE0110() {
		return OEIDENTIDADE0110;
	}
	public void setOEIDENTIDADE0110(String oEIDENTIDADE0110) {
		OEIDENTIDADE0110 = oEIDENTIDADE0110;
	}
}
