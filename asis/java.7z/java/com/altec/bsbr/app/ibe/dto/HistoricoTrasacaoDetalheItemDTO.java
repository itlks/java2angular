package com.altec.bsbr.app.ibe.dto;

public class HistoricoTrasacaoDetalheItemDTO {

	private String transacao;
	private String agenciaConta;
	private String valor;
	private String statusPendencia;
	private String codigoTransacao;
	private String timeStamp;

	/**
	 * @return the transacao
	 */
	public String getTransacao() {
		return transacao;
	}

	/**
	 * @param transacao
	 *            the transacao to set
	 */
	public void setTransacao(String transacao) {
		this.transacao = transacao;
	}

	/**
	 * @return the agenciaConta
	 */
	public String getAgenciaConta() {
		return agenciaConta;
	}

	/**
	 * @param agenciaConta
	 *            the agenciaConta to set
	 */
	public void setAgenciaConta(String agenciaConta) {
		if(!agenciaConta.isEmpty()){
			this.agenciaConta = agenciaConta.substring(4,8).concat(agenciaConta.substring(11));
		}
	}

	/**
	 * @return the valor
	 */
	public String getValor() {
		return valor;
	}

	/**
	 * @param valor
	 *            the valor to set
	 */
	public void setValor(String valor) {
		this.valor = valor;
	}

	/**
	 * @return the statusPendencia
	 */
	public String getStatusPendencia() {
		return statusPendencia;
	}

	/**
	 * @param statusPendencia
	 *            the statusPendencia to set
	 */
	public void setStatusPendencia(String statusPendencia) {
		this.statusPendencia = statusPendencia;
	}

	/**
	 * @return the codigoTransacao
	 */
	public String getCodigoTransacao() {
		return codigoTransacao;
	}

	/**
	 * @param codigoTransacao
	 *            the codigoTransacao to set
	 */
	public void setCodigoTransacao(String codigoTransacao) {
		this.codigoTransacao = codigoTransacao;
	}

	/**
	 * @return the timeStamp
	 */
	public String getTimeStamp() {
		return timeStamp;
	}

	/**
	 * @param timeStamp
	 *            the timeStamp to set
	 */
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

}