package com.altec.bsbr.app.ibe.enumeration;

public enum UsuarioSecundarioAlterarEnum {
	
	ALTERAR_ASSINATURA_DE_USUARIO_SECUNDARIO 				(6),
	ALTERAR_SENHA_DE_USUARIO_SECUNDARIO 						(5),
	ALTERAR_PERFIL_DE_ACESSO_USUARIO_SECUNDARIO 					(7),
	ALTERAR_PERFIL_DE_AUTORIZACAO_USUARIO_SECUNDARIO				(8),
	ALTERAR_RELACAO_CONVENIO_USUARIO_SECUNDARIO					(9),
	ALTERAR_USUARIO_SECUNDARIO					(2),
	INCLUIR_USUARIO_SECUNDARIO					(1);

	
	private int codTransacao;

	private UsuarioSecundarioAlterarEnum(int codTransacao) {
		this.codTransacao = codTransacao;
	}
	
	public int getCodTransacao() {
		return codTransacao;
	}

	private void setCodTransacao(int codTransacao) {
		this.codTransacao = codTransacao;
	}

	

	
}
