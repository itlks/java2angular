package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class MobileTokenServicoDTO implements Serializable {
	
	private static final long serialVersionUID = 790517623566731651L;
	
	private boolean ativo;
	private String autenticacaoBancaria;
	private String dataHoraTransacao;
	private String contaCorrente;

	public MobileTokenServicoDTO(){
		this.ativo = false;
	}

	public boolean isAtivo() {
		return ativo;
	}
	public void setAtivo(boolean ativo) {
		this.ativo = ativo;
	}
	public String getAutenticacaoBancaria() {
		return autenticacaoBancaria;
	}
	public void setAutenticacaoBancaria(String autenticacaoBancaria) {
		this.autenticacaoBancaria = autenticacaoBancaria;
	}
	public String getDataHoraTransacao() {
		return dataHoraTransacao;
	}
	public void setDataHoraTransacao(String dataHoraTransacao) {
		this.dataHoraTransacao = dataHoraTransacao;
	}
	public String getContaCorrente() {
		return contaCorrente;
	}
	public void setContaCorrente(String contaCorrente) {
		this.contaCorrente = contaCorrente;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (ativo ? 1231 : 1237);
		result = prime * result + ((autenticacaoBancaria == null) ? 0 : autenticacaoBancaria.hashCode());
		result = prime * result + ((contaCorrente == null) ? 0 : contaCorrente.hashCode());
		result = prime * result + ((dataHoraTransacao == null) ? 0 : dataHoraTransacao.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		boolean retorno = true;
		if (this == obj)
			retorno = true;
		if (obj == null){
			retorno = false;
		}else{
			if (getClass() != obj.getClass()){
				retorno = false;
			}
		}
		MobileTokenServicoDTO other = (MobileTokenServicoDTO) obj;
		if(other!=null){
			if (ativo != other.ativo)
				retorno = false;
			if (autenticacaoBancaria == null) {
				if (other.autenticacaoBancaria != null)
					retorno = false;
			} else if (!autenticacaoBancaria.equals(other.autenticacaoBancaria))
				retorno = false;
			if (contaCorrente == null) {
				if (other.contaCorrente != null)
					retorno = false;
			} else if (!contaCorrente.equals(other.contaCorrente))
				retorno = false;
		}
		compararDataHoraTransacao(dataHoraTransacao, other, retorno);
			return retorno;
	}
	
	private boolean compararDataHoraTransacao(String dataHoraTransacao, MobileTokenServicoDTO other, boolean retorno) {
		if (dataHoraTransacao == null) {
			if (other.dataHoraTransacao != null)
				retorno = false;
		} else if (!dataHoraTransacao.equals(other.dataHoraTransacao))
			retorno = false;
		return retorno;
	}

	@Override
	public String toString() {
		StringBuilder retorno = new StringBuilder();
		
		retorno.append("MobileTokenServicoDTO [ativo=").append(ativo).append(", autenticacaoBancaria=")
		.append(autenticacaoBancaria).append(", dataHoraTransacao=").append(dataHoraTransacao)
		.append(", contaCorrente=").append(contaCorrente).append("]");
		
		return retorno.toString();
	}

}
