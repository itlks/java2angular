package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import com.altec.bsbr.app.ibe.anotation.Hash;
import com.altec.bsbr.app.ibe.hash.converter.BigDecimalConverter;

public class TransfValoresBasicoDTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1696016929173531209L;
	@Hash(position = 1)
	private String banco;
	@Hash(position = 2)
	private String ispb;
	@Hash(position = 3)
	private String agencia;
	@Hash(position = 4)
	private String conta;
	@Hash(position = 5, converter = BigDecimalConverter.class)
	private BigDecimal valor;

	public String getBanco() {
		return banco;
	}
	public void setBanco(String banco) {
		this.banco = banco;
	}
	public String getIspb() {
		return ispb;
	}
	public void setIspb(String ispb) {
		this.ispb = ispb;
	}
	public String getAgencia() {
		return agencia;
	}
	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}
	public String getConta() {
		return conta;
	}
	public void setConta(String conta) {
		this.conta = conta;
	}
	public BigDecimal getValor() {
		return valor;
	}
	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}
}
