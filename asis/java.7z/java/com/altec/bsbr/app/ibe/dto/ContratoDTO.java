package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.List;

public class ContratoDTO implements Serializable{

	private static final long serialVersionUID = 5232294491362278135L;
	
	public ContratoDTO(){}
	
	private String cnpj;
	private String agenciaAcesso;
	private String nomeAcesso;
	private String senhaAcesso;
	private UsuarioMasterDTO usuarioMaster;
	private UsuarioMasterDTO usuarioMasterAdicionalA;
	private UsuarioMasterDTO usuarioMasterAdicionalB;
	private UsuarioMasterDTO usuarioMasterAdicionalC;
	private List<ContaCorrenteReferencialDTO> contasGerenciadas;

	public String getCnpj() {
		return cnpj;
	}
	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}
	public String getAgenciaAcesso() {
		return agenciaAcesso;
	}
	public void setAgenciaAcesso(String agenciaAcesso) {
		this.agenciaAcesso = agenciaAcesso;
	}
	public String getNomeAcesso() {
		return nomeAcesso;
	}
	public void setNomeAcesso(String nomeAcesso) {
		this.nomeAcesso = nomeAcesso;
	}
	public String getSenhaAcesso() {
		return senhaAcesso;
	}
	public void setSenhaAcesso(String senhaAcesso) {
		this.senhaAcesso = senhaAcesso;
	}
	public UsuarioMasterDTO getUsuarioMaster() {
		return usuarioMaster;
	}
	public void setUsuarioMaster(UsuarioMasterDTO usuarioMaster) {
		this.usuarioMaster = usuarioMaster;
	}
	public UsuarioMasterDTO getUsuarioMasterAdicionalA() {
		return usuarioMasterAdicionalA;
	}
	public void setUsuarioMasterAdicionalA(UsuarioMasterDTO usuarioMasterAdicionalA) {
		this.usuarioMasterAdicionalA = usuarioMasterAdicionalA;
	}
	public UsuarioMasterDTO getUsuarioMasterAdicionalB() {
		return usuarioMasterAdicionalB;
	}
	public void setUsuarioMasterAdicionalB(UsuarioMasterDTO usuarioMasterAdicionalB) {
		this.usuarioMasterAdicionalB = usuarioMasterAdicionalB;
	}
	public UsuarioMasterDTO getUsuarioMasterAdicionalC() {
		return usuarioMasterAdicionalC;
	}
	public void setUsuarioMasterAdicionalC(UsuarioMasterDTO usuarioMasterAdicionalC) {
		this.usuarioMasterAdicionalC = usuarioMasterAdicionalC;
	}
	public List<ContaCorrenteReferencialDTO> getContasGerenciadas() {
		return contasGerenciadas;
	}
	public void setContasGerenciadas(List<ContaCorrenteReferencialDTO> contasGerenciadas) {
		this.contasGerenciadas = contasGerenciadas;
	}
	
}
