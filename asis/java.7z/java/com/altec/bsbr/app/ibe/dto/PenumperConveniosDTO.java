package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.List;

public class PenumperConveniosDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private List<ItemPenumperConveniosDTO> listaItemPenumper;
	private String codAviso;
	private String descAviso;

	public String getCodAviso() {
		return codAviso;
	}

	public void setCodAviso(String codAviso) {
		this.codAviso = codAviso;
	}

	public String getDescAviso() {
		return descAviso;
	}

	public void setDescAviso(String descAviso) {
		this.descAviso = descAviso;
	}

	public List<ItemPenumperConveniosDTO> getListaItemPenumper() {
		return listaItemPenumper;
	}

	public void setListaItemPenumper(List<ItemPenumperConveniosDTO> listaItemPenumper) {
		this.listaItemPenumper = listaItemPenumper;
	}

}
