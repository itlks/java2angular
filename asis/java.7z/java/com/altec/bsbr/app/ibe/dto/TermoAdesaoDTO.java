package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;


public class TermoAdesaoDTO implements Serializable {

	private static final long serialVersionUID = -1L;

	private String nome;
	private String nomeTitularConta;
	private String endereco;
	private String numero;
	private String complemento;
	private String bairro;
	private String cidade;
	private String uf;
	private String cep;
	private Integer tipoDocumento;
	private String cpfCnpj;
	private String contaPrincipal;
	private String agenciaPrincipal;
	private Integer seqEnder;
    private String categEnder;
    private String tipoEnder;
    private String indCorresp;
    private String descLograd;
    private String numImovel;
    private String descComplem;
    private String descBairro;
    private String codMunic;
    private String descMunic;
    private String codUf;
    private String descUf;
    private String codCep;
    private String data;
    private String cpf;
    private String telefone;
    
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public String getNumero() {
		return numero;
	}
	public void setNumero(String numero) {
		this.numero = numero;
	}
	public String getComplemento() {
		return complemento;
	}
	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}
	public String getBairro() {
		return bairro;
	}
	public void setBairro(String bairro) {
		this.bairro = bairro;
	}
	public String getCidade() {
		return cidade;
	}
	public void setCidade(String cidade) {
		this.cidade = cidade;
	}
	public String getUf() {
		return uf;
	}
	public void setUf(String uf) {
		this.uf = uf;
	}
	public String getCep() {
		return cep;
	}
	public void setCep(String cep) {
		this.cep = cep;
	}
	public Integer getTipoDocumento() {
		return tipoDocumento;
	}
	public void setTipoDocumento(Integer tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}
	public String getCpfCnpj() {
		return cpfCnpj;
	}
	public void setCpfCnpj(String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}
	public String getContaPrincipal() {
		return contaPrincipal;
	}
	public void setContaPrincipal(String contaPrincipal) {
		this.contaPrincipal = contaPrincipal;
	}
	public String getAgenciaPrincipal() {
		return agenciaPrincipal;
	}
	public void setAgenciaPrincipal(String agenciaPrincipal) {
		this.agenciaPrincipal = agenciaPrincipal;
	}
	public Integer getSeqEnder() {
		return seqEnder;
	}
	public void setSeqEnder(Integer seqEnder) {
		this.seqEnder = seqEnder;
	}
	public String getCategEnder() {
		return categEnder;
	}
	public void setCategEnder(String categEnder) {
		this.categEnder = categEnder;
	}
	public String getTipoEnder() {
		return tipoEnder;
	}
	public void setTipoEnder(String tipoEnder) {
		this.tipoEnder = tipoEnder;
	}
	public String getIndCorresp() {
		return indCorresp;
	}
	public void setIndCorresp(String indCorresp) {
		this.indCorresp = indCorresp;
	}
	public String getDescLograd() {
		return descLograd;
	}
	public void setDescLograd(String descLograd) {
		this.descLograd = descLograd;
	}
	public String getNumImovel() {
		return numImovel;
	}
	public void setNumImovel(String numImovel) {
		this.numImovel = numImovel;
	}
	public String getDescComplem() {
		return descComplem;
	}
	public void setDescComplem(String descComplem) {
		this.descComplem = descComplem;
	}
	public String getDescBairro() {
		return descBairro;
	}
	public void setDescBairro(String descBairro) {
		this.descBairro = descBairro;
	}
	public String getCodMunic() {
		return codMunic;
	}
	public void setCodMunic(String codMunic) {
		this.codMunic = codMunic;
	}
	public String getDescMunic() {
		return descMunic;
	}
	public void setDescMunic(String descMunic) {
		this.descMunic = descMunic;
	}
	public String getCodUf() {
		return codUf;
	}
	public void setCodUf(String codUf) {
		this.codUf = codUf;
	}
	public String getDescUf() {
		return descUf;
	}
	public void setDescUf(String descUf) {
		this.descUf = descUf;
	}
	public String getCodCep() {
		return codCep;
	}
	public void setCodCep(String codCep) {
		this.codCep = codCep;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public String getNomeTitularConta() {
		return nomeTitularConta;
	}
	public void setNomeTitularConta(String nomeTitularConta) {
		this.nomeTitularConta = nomeTitularConta;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	
}
