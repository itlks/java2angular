package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class Paginador implements Serializable {
   
	private static final long serialVersionUID = -1677783636260337157L;
	
	private String maxResults;
    private String index;
    private String nextIndex;
    private String totResults;
    private String paginas;
    private String indicadorPage;
    private String indicadorPageAnt = "0";
    private Boolean render = false;
    private String jsonRechamada;
    
    
    public void setMaxResults(String maxResults) {
        this.maxResults = maxResults;
    }
    public String getMaxResults() {
        return maxResults;
    }
    public void setIndex(String index) {
        this.index = index;
    }
    public String getIndex() {
        return index;
    }
    public void setNextIndex(String nextIndex) {
        this.nextIndex = nextIndex;
    }
    public String getNextIndex() {
        return nextIndex;
    }
    public void setTotResults(String totResults) {
        this.totResults = totResults;
    }
    public String getTotResults() {
        return totResults;
    }
    public void setPaginas(String paginas) {
        this.paginas = paginas;
    }
    public String getPaginas() {
        return paginas;
    }
    public void setIndicadorPage(String indicadorPage) {
	this.indicadorPage = indicadorPage;
    }
    public String getIndicadorPage() {
	return indicadorPage;
    }
    public void setIndicadorPageAnt(String indicadorPageAnt) {
        this.indicadorPageAnt = indicadorPageAnt;
    }
    public String getIndicadorPageAnt() {
        return indicadorPageAnt;
    }
    public Boolean getRender() {
        if(totResults != null){
            if(Integer.parseInt(totResults) > Integer.parseInt(maxResults)){
                render = true;
            }
        }
        return render;
    }
	public String getJsonRechamada() {
		return jsonRechamada;
	}
	public void setJsonRechamada(String jsonRechamada) {
		this.jsonRechamada = jsonRechamada;
	}
	
	
}
	
