package com.altec.bsbr.app.ibe.enumeration;

public enum CanalMovimentacaoEnum {
	APLICACAO_RESGATE("Aplica��o e Resgate"),
	APLICACAO_ADICIONAL_RESGATE("Aplica��o adicional e Resgate"),
	SOMENTE_RESGATE("Somente resgate"),
	SOMENTE_CONSULTA("Somente consulta"),
	NAO_DISPONIVEL("N�o dispon�vel"),
	SOMENTE_APLICACAO("Somente Aplica��o"),
	APLICACAO_INICIAL_RESGATE("Aplica��o Inicial e Resgate"),
	SOMENTE_APLICACAO_INICIAL("Somente Aplica��o Inicial"),
	SOMENTE_APLICACAO_ADICIONAL("Somente Aplica��o Adicional");

	private String descricao;

	public String getDescricao() {
		return descricao;
	}

	private CanalMovimentacaoEnum(String descricao) {
		this.descricao = descricao;
	}

	public static CanalMovimentacaoEnum findById(Integer id){
		CanalMovimentacaoEnum retorno = null;
		id = id -1;
		for (CanalMovimentacaoEnum canal: CanalMovimentacaoEnum.values()) {
			if(CanalMovimentacaoEnum.values().length < id || id < 0){
				retorno = CanalMovimentacaoEnum.NAO_DISPONIVEL;
				break;
			}
			else if (canal.ordinal() == id) {
				retorno = canal;
				break;
			}
		}
		return retorno;
	}

}
