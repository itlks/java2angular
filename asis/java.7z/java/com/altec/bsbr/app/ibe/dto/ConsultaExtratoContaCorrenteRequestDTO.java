package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.Date;

public class ConsultaExtratoContaCorrenteRequestDTO implements Serializable{

	private static final long serialVersionUID = -6495152751636715482L;
	
	private boolean outrosPeriodos;
	private boolean exibeListaLancamentos;
	private boolean exibeListaPeriodos;
	private Date dataInicial;
	private Date dataFinal;
	private Date outroPeridoDataInicial;
	private Date outroPeridoDataFinal;
	private Integer periodo;
	private boolean clicked;
	private Integer numCheque;
	private String tipoEnvio;
	private String porPeriodo;
	private Boolean exibeGrids;
	private Boolean exibeGridsEPeriodos;
	private boolean exibirDialog;
	private boolean isBotaoChequeDesabilitado;
	
	public boolean isOutrosPeriodos() {
		return this.outrosPeriodos;
	}
	public void setOutrosPeriodos(boolean outrosPeriodos) {
		this.outrosPeriodos = outrosPeriodos;
	}
	public boolean isExibeListaLancamentos() {
		return this.exibeListaLancamentos;
	}
	public void setExibeListaLancamentos(boolean exibeListaLancamentos) {
		this.exibeListaLancamentos = exibeListaLancamentos;
	}
	public boolean isExibeListaPeriodos() {
		return this.exibeListaPeriodos;
	}
	public void setExibeListaPeriodos(boolean exibeListaPeriodos) {
		this.exibeListaPeriodos = exibeListaPeriodos;
	}
	public Date getDataInicial() {
		return this.dataInicial;
	}
	public void setDataInicial(Date dataInicial) {
		this.dataInicial = dataInicial;
	}
	public Date getDataFinal() {
		return this.dataFinal;
	}
	public void setDataFinal(Date dataFinal) {
		this.dataFinal = dataFinal;
	}
	public Integer getPeriodo() {
		return this.periodo;
	}
	public void setPeriodo(Integer periodo) {
		this.periodo = periodo;
	}
	public boolean isClicked() {
		return this.clicked;
	}
	public void setClicked(boolean clicked) {
		this.clicked = clicked;
	}
	public Integer getNumCheque() {
		return this.numCheque;
	}
	public void setNumCheque(Integer numCheque) {
		this.numCheque = numCheque;
	}
	/**
	 * @return the outroPeridoDataInicial
	 */
	public Date getOutroPeridoDataInicial() {
		return this.outroPeridoDataInicial;
	}
	/**
	 * @param outroPeridoDataInicial the outroPeridoDataInicial to set
	 */
	public void setOutroPeridoDataInicial(Date outroPeridoDataInicial) {
		this.outroPeridoDataInicial = outroPeridoDataInicial;
	}
	/**
	 * @return the outroPeridoDataFinal
	 */
	public Date getOutroPeridoDataFinal() {
		return this.outroPeridoDataFinal;
	}
	/**
	 * @param outroPeridoDataFinal the outroPeridoDataFinal to set
	 */
	public void setOutroPeridoDataFinal(Date outroPeridoDataFinal) {
		this.outroPeridoDataFinal = outroPeridoDataFinal;
	}
	/**
	 * @return the porPeriodo
	 */
	public String getPorPeriodo() {
		return this.porPeriodo;
	}
	/**
	 * @param porPeriodo the porPeriodo to set
	 */
	public void setPorPeriodo(String porPeriodo) {
		this.porPeriodo = porPeriodo;
	}
	
	public String getTipoEnvio() {
		return this.tipoEnvio;
	}
	
	public void setTipoEnvio(String tipoEnvio) {
		this.tipoEnvio = tipoEnvio;
	}
	/**
	 * @return the exibirDialog
	 */
	public boolean isExibirDialog() {
		return this.exibirDialog;
	}
	/**
	 * @param exibirDialog the exibirDialog to set
	 */
	public void setExibirDialog(boolean exibirDialog) {
		this.exibirDialog = exibirDialog;
	}
	/**
	 * @return the exibeGrids
	 */
	public Boolean getExibeGrids() {
		return this.exibeGrids;
	}
	/**
	 * @param exibeGrids the exibeGrids to set
	 */
	public void setExibeGrids(Boolean exibeGrids) {
		this.exibeGrids = exibeGrids;
	}
	/**
	 * @return the exibeGridsEPeriodos
	 */
	public Boolean getExibeGridsEPeriodos() {
		return this.exibeGridsEPeriodos;
	}
	/**
	 * @param exibeGridsEPeriodos the exibeGridsEPeriodos to set
	 */
	public void setExibeGridsEPeriodos(Boolean exibeGridsEPeriodos) {
		this.exibeGridsEPeriodos = exibeGridsEPeriodos;
	}
	/**
	 * @return the isBotaoChequeDesabilitado
	 */
	public boolean isBotaoChequeDesabilitado() {
		return isBotaoChequeDesabilitado;
	}
	/**
	 * @param isBotaoChequeDesabilitado the isBotaoChequeDesabilitado to set
	 */
	public void setBotaoChequeDesabilitado(boolean isBotaoChequeDesabilitado) {
		this.isBotaoChequeDesabilitado = isBotaoChequeDesabilitado;
	}
	
}
