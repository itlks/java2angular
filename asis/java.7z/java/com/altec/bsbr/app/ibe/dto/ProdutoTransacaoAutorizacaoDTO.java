package com.altec.bsbr.app.ibe.dto;

public class ProdutoTransacaoAutorizacaoDTO {

	private String numeroTransacao;
	private String nomeTransacao;
	private String numeroGrupo;
	private String nomeGrupoServico;
	private String tipoTransacao;

	
	/**
	 * @return the numeroTransacao
	 */
	public String getNumeroTransacao() {
		return numeroTransacao;
	}

	/**
	 * @return the nomeTransacao
	 */
	public String getNomeTransacao() {
		return nomeTransacao;
	}

	/**
	 * @return the numeroGrupo
	 */
	public String getNumeroGrupo() {
		return numeroGrupo;
	}

	/**
	 * @return the nomeGrupoServico
	 */
	public String getNomeGrupoServico() {
		return nomeGrupoServico;
	}

	/**
	 * @return the tipoTransacao
	 */
	public String getTipoTransacao() {
		return tipoTransacao;
	}

	/**
	 * @param numeroTransacao
	 *            the numeroTransacao to set
	 */
	public void setNumeroTransacao(String numeroTransacao) {
		this.numeroTransacao = numeroTransacao;
	}

	/**
	 * @param nomeTransacao
	 *            the nomeTransacao to set
	 */
	public void setNomeTransacao(String nomeTransacao) {
		this.nomeTransacao = nomeTransacao;
	}

	/**
	 * @param numeroGrupo
	 *            the numeroGrupo to set
	 */
	public void setNumeroGrupo(String numeroGrupo) {
		this.numeroGrupo = numeroGrupo;
	}

	/**
	 * @param nomeGrupoServico
	 *            the nomeGrupoServico to set
	 */
	public void setNomeGrupoServico(String nomeGrupoServico) {
		this.nomeGrupoServico = nomeGrupoServico;
	}

	/**
	 * @param tipoTransacao
	 *            the tipoTransacao to set
	 */
	public void setTipoTransacao(String tipoTransacao) {
		this.tipoTransacao = tipoTransacao;
	}
	

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((nomeGrupoServico == null) ? 0 : nomeGrupoServico.hashCode());
		result = prime * result + ((nomeTransacao == null) ? 0 : nomeTransacao.hashCode());
		result = prime * result + ((numeroGrupo == null) ? 0 : numeroGrupo.hashCode());
		result = prime * result + ((numeroTransacao == null) ? 0 : numeroTransacao.hashCode());
		result = prime * result + ((tipoTransacao == null) ? 0 : tipoTransacao.hashCode());
		return result;
	}
	

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProdutoTransacaoAutorizacaoDTO other = (ProdutoTransacaoAutorizacaoDTO) obj;
		if (nomeGrupoServico == null) {
			if (other.nomeGrupoServico != null)
				return false;
		} else if (!nomeGrupoServico.equals(other.nomeGrupoServico))
			return false;
		if (nomeTransacao == null) {
			if (other.nomeTransacao != null)
				return false;
		} else if (!nomeTransacao.equals(other.nomeTransacao))
			return false;
		if (numeroGrupo == null) {
			if (other.numeroGrupo != null)
				return false;
		} else if (!numeroGrupo.equals(other.numeroGrupo))
			return false;
		if (numeroTransacao == null) {
			if (other.numeroTransacao != null)
				return false;
		} else if (!numeroTransacao.equals(other.numeroTransacao))
			return false;
		if (tipoTransacao == null) {
			if (other.tipoTransacao != null)
				return false;
		} else if (!tipoTransacao.equals(other.tipoTransacao))
			return false;
		return true;
	}

}