package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;

public class SegundaViaTransfMultaDTO implements Serializable{

	private static final long serialVersionUID = 1423157860244687266L;
	
	private	String 			autoInfracao;	
	private	String			numGuia;		
	private	String			codSegmento;	
	private	String			dataInfracao;	
	private	String			dataVcto;	
	private	BigDecimal		valorMuta;	
	private	String			dadosMulta;
	
	public SegundaViaTransfMultaDTO (){
		//
	}
	
	public SegundaViaTransfMultaDTO(String autoInfracao, String numGuia, String codSegmento, String dataInfracao, String dataVcto, BigDecimal valorMuta, String dadosMulta) {
		super();
		this.autoInfracao = autoInfracao;
		this.numGuia = numGuia;
		this.codSegmento = codSegmento;
		this.dataInfracao = dataInfracao;
		this.dataVcto = dataVcto;
		this.valorMuta = valorMuta;
		this.dadosMulta = dadosMulta;
	}

	public String getAutoInfracao() {
		return autoInfracao;
	}
	public void setAutoInfracao(String autoInfracao) {
		this.autoInfracao = autoInfracao;
	}
	public String getNumGuia() {
		return numGuia;
	}
	public void setNumGuia(String numGuia) {
		this.numGuia = numGuia;
	}
	public String getCodSegmento() {
		return codSegmento;
	}
	public void setCodSegmento(String codSegmento) {
		this.codSegmento = codSegmento;
	}
	public String getDataInfracao() {
		return dataInfracao;
	}
	public void setDataInfracao(String dataInfracao) {
		this.dataInfracao = dataInfracao;
	}
	public String getDataVcto() {
		return dataVcto;
	}
	public void setDataVcto(String dataVcto) {
		this.dataVcto = dataVcto;
	}
	public BigDecimal getValorMuta() {
		return valorMuta;
	}
	public void setValorMuta(BigDecimal valorMuta) {
		this.valorMuta = valorMuta;
	}
	public String getDadosMulta() {
		return dadosMulta;
	}
	public void setDadosMulta(String dadosMulta) {
		this.dadosMulta = dadosMulta;
	}	
	
}
