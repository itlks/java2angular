package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class ItemPenumperConveniosDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long cdcli;
	private Integer conve;
	private Long cdban;
	private String nmced;
	private String funct;
	private Integer agece;
	private Long ctace;

	public Long getCdcli() {
		return cdcli;
	}

	public void setCdcli(Long cdcli) {
		this.cdcli = cdcli;
	}

	public Integer getConve() {
		return conve;
	}

	public void setConve(Integer conve) {
		this.conve = conve;
	}

	public Long getCdban() {
		return cdban;
	}

	public void setCdban(Long cdban) {
		this.cdban = cdban;
	}

	public String getNmced() {
		return nmced;
	}

	public void setNmced(String nmced) {
		this.nmced = nmced;
	}

	public String getFunct() {
		return funct;
	}

	public void setFunct(String funct) {
		this.funct = funct;
	}

	public Integer getAgece() {
		return agece;
	}

	public void setAgece(Integer agece) {
		this.agece = agece;
	}

	public Long getCtace() {
		return ctace;
	}

	public void setCtace(Long ctace) {
		this.ctace = ctace;
	}

	public String agenciaContaFormatado() {
		StringBuilder agenciaConta = new StringBuilder();
		agenciaConta.append(getConve());
		agenciaConta.append(getCdban());
		return agenciaConta.toString();
	}

}
