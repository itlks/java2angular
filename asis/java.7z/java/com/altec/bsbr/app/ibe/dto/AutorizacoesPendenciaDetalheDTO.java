package com.altec.bsbr.app.ibe.dto;


public class AutorizacoesPendenciaDetalheDTO {
	
	
	private String codUsuarioUltimaAtu;
	private String nomeFavorecidoPendencia;
	private String descricaoProduto;
	private String imgTransacao;
	private String data;
	private String codigoTransacao;
	
	private String nomeGrupoServico;
	private String 	nomeTranzacao;
	private int nrSequGrupServ;
	private int nrSequTran;
	private int tpTranzacao;
	
	//sintetico
//	private String data;
//	private String codigoProduto;
//	private String descricaoProduto;
//	private String tipoPendencia;
//	private String convenio; 
//	private String quantidadePendencias;
//	private String valorPendencias;
//	private String quantidadePendenciasAssinadas;
//	private String codigoRemessa;
//	private boolean itemSelecionado;
//	private String analiticaConvenio;
//	
	//analitico
//	private Date dataHoraInclusao; 
//	private String codigoTransacao;
//	private Date dataPagamento;		
//	private int codigoProduto;		
//	private String contaConvenio;	
//	private String contaDebito;		
//	private int qtAssNecessario;	
//	private int qtAssPendente;		
//	private BigDecimal valorUsuarioPendencia; 
//	private String flagPermiteAutorizar;  
//	private String nomeFavorecidoPendencia; 
//	private String codUsuarioUltimaAtu; 	
//	private String imgTransacao;			
//	private boolean itemSelecionado;
	
	public AutorizacoesPendenciaDetalheDTO() {
		
//		pendenciasPorData = new ListaPendenciaAutorizacaoDTO();
//		
//		setPeriodoHoje(Calendar.getInstance());
//		setCheckBoxPendencia(Boolean.FALSE);
//		setQuantidadePendenciaSelecionadas(0);
//		setValorTotalPendenciaSelecionadas(BigDecimal.ZERO);
		
		setCodUsuarioUltimaAtu("x178130");
		setNomeFavorecidoPendencia("TEST");
		setDescricaoProduto("PRODUCT DESC");
		setImgTransacao("PAGAMENTO ETC...");
		setData("28/07/2016");
		
	}
	
	public String getCodUsuarioUltimaAtu() {
		return codUsuarioUltimaAtu;
	}


	public void setCodUsuarioUltimaAtu(String codUsuarioUltimaAtu) {
		this.codUsuarioUltimaAtu = codUsuarioUltimaAtu;
	}


	public String getNomeFavorecidoPendencia() {
		return nomeFavorecidoPendencia;
	}


	public void setNomeFavorecidoPendencia(String nomeFavorecidoPendencia) {
		this.nomeFavorecidoPendencia = nomeFavorecidoPendencia;
	}


	public String getDescricaoProduto() {
		return descricaoProduto;
	}


	public void setDescricaoProduto(String descricaoProduto) {
		this.descricaoProduto = descricaoProduto;
	}


	public String getImgTransacao() {
		return imgTransacao;
	}


	public void setImgTransacao(String imgTransacao) {
		this.imgTransacao = imgTransacao;
	}


	public String getData() {
		return data;
	}


	public void setData(String data) {
		this.data = data;
	}


	public String getCodigoTransacao() {
		return codigoTransacao;
	}


	public void setCodigoTransacao(String codigoTransacao) {
		this.codigoTransacao = codigoTransacao;
	}	

	
	
	public String getNomeGrupoServico() {
		return nomeGrupoServico;
	}

	public void setNomeGrupoServico(String nomeGrupoServico) {
		this.nomeGrupoServico = nomeGrupoServico;
	}

	public String getNomeTranzacao() {
		return nomeTranzacao;
	}

	public void setNomeTranzacao(String nomeTranzacao) {
		this.nomeTranzacao = nomeTranzacao;
	}

	public int getNrSequGrupServ() {
		return nrSequGrupServ;
	}

	public void setNrSequGrupServ(int nrSequGrupServ) {
		this.nrSequGrupServ = nrSequGrupServ;
	}

	public int getNrSequTran() {
		return nrSequTran;
	}

	public void setNrSequTran(int nrSequTran) {
		this.nrSequTran = nrSequTran;
	}

	public int getTpTranzacao() {
		return tpTranzacao;
	}

	public void setTpTranzacao(int tpTranzacao) {
		this.tpTranzacao = tpTranzacao;
	}

}
