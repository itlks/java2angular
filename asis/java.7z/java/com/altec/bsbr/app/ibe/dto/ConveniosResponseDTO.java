package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class ConveniosResponseDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String bancoEntidadBr;
	private String bancoSucursalBr;
	private String bancoNroCuentaBr;
	private String nomecon;
	private String ucomlot;
	private String pnumper;
	private String cdtpide;
	private String numiden;
	private String ctapral;
	private String entDebEntidadBr;
	private String entDebSucursalBr;
	private String entDebNroCuentaBr;
	private String indincl;
	private String indambl;
	private String indmod;
	private String indlist;
	private String indsac;
	private String indreim;
	private String tipaut;
	private String indordn;
	private String convori;

	public ConveniosResponseDTO() {

	}

	public String getBancoEntidadBr() {
		return bancoEntidadBr;
	}

	public void setBancoEntidadBr(String bancoEntidadBr) {
		this.bancoEntidadBr = bancoEntidadBr;
	}

	public String getBancoSucursalBr() {
		return bancoSucursalBr;
	}

	public void setBancoSucursalBr(String bancoSucursalBr) {
		this.bancoSucursalBr = bancoSucursalBr;
	}

	public String getBancoNroCuentaBr() {
		return bancoNroCuentaBr;
	}

	public void setBancoNroCuentaBr(String bancoNroCuentaBr) {
		this.bancoNroCuentaBr = bancoNroCuentaBr;
	}

	public String getNomecon() {
		return nomecon;
	}

	public void setNomecon(String nomecon) {
		this.nomecon = nomecon;
	}

	public String getUcomlot() {
		return ucomlot;
	}

	public void setUcomlot(String ucomlot) {
		this.ucomlot = ucomlot;
	}

	public String getPnumper() {
		return pnumper;
	}

	public void setPnumper(String pnumper) {
		this.pnumper = pnumper;
	}

	public String getCdtpide() {
		return cdtpide;
	}

	public void setCdtpide(String cdtpide) {
		this.cdtpide = cdtpide;
	}

	public String getNumiden() {
		return numiden;
	}

	public void setNumiden(String numiden) {
		this.numiden = numiden;
	}

	public String getCtapral() {
		return ctapral;
	}

	public void setCtapral(String ctapral) {
		this.ctapral = ctapral;
	}

	public String getEntDebEntidadBr() {
		return entDebEntidadBr;
	}

	public void setEntDebEntidadBr(String entDebEntidadBr) {
		this.entDebEntidadBr = entDebEntidadBr;
	}

	public String getEntDebSucursalBr() {
		return entDebSucursalBr;
	}

	public void setEntDebSucursalBr(String entDebSucursalBr) {
		this.entDebSucursalBr = entDebSucursalBr;
	}

	public String getEntDebNroCuentaBr() {
		return entDebNroCuentaBr;
	}

	public void setEntDebNroCuentaBr(String entDebNroCuentaBr) {
		this.entDebNroCuentaBr = entDebNroCuentaBr;
	}

	public String getIndincl() {
		return indincl;
	}

	public void setIndincl(String indincl) {
		this.indincl = indincl;
	}

	public String getIndambl() {
		return indambl;
	}

	public void setIndambl(String indambl) {
		this.indambl = indambl;
	}

	public String getIndmod() {
		return indmod;
	}

	public void setIndmod(String indmod) {
		this.indmod = indmod;
	}

	public String getIndlist() {
		return indlist;
	}

	public void setIndlist(String indlist) {
		this.indlist = indlist;
	}

	public String getIndsac() {
		return indsac;
	}

	public void setIndsac(String indsac) {
		this.indsac = indsac;
	}

	public String getIndreim() {
		return indreim;
	}

	public void setIndreim(String indreim) {
		this.indreim = indreim;
	}

	public String getTipaut() {
		return tipaut;
	}

	public void setTipaut(String tipaut) {
		this.tipaut = tipaut;
	}

	public String getIndordn() {
		return indordn;
	}

	public void setIndordn(String indordn) {
		this.indordn = indordn;
	}

	public String getConvori() {
		return convori;
	}

	public void setConvori(String convori) {
		this.convori = convori;
	}

	public String getNomeConcatenado() {
		if (getNomecon() != null) {
			StringBuilder nomeContatenado = new StringBuilder();
			nomeContatenado.append(getNomecon().substring(0, 4));
			nomeContatenado.append("-");
			nomeContatenado.append(getNomecon().substring(4, 8));
			nomeContatenado.append("-");
			nomeContatenado.append(getNomecon().substring(8, 20));
			return nomeContatenado.toString();
		} else {
			return null;
		}
	}

}
