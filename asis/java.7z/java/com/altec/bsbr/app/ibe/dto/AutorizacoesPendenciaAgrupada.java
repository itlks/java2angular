package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class AutorizacoesPendenciaAgrupada implements Comparable<AutorizacoesPendenciaAgrupada>, Serializable {

	private static final long serialVersionUID = 8249243571209752981L;

	private int codProduto;
	private String detalheAgrupamento;
	private String descricaoAgrupamento;
	private Boolean pendenciasSelecionadas;
	private Integer quantidadePendencias;
	private Integer quantidadePendenciasAgrupada;
	private BigDecimal valorTotalPendencias;
	private BigDecimal valorTotalPendenciasAgrupada;
	private Boolean flgPendenciasAgrupada;
	private String contaConvenioAnalitico;
	private Integer qtdPendenciasSelecionadasPorGrupo;
	private BigDecimal vlrTotalPendenciasPorGrupo;
	private String detalheAgrupamentoConvenio;
	private String convenioConfirmacaoRemessa;
	private List<AutorizacoesPendenciaDadosSinteticaDTO> pendencias;
	private List<AutorizacoesPendenciaDadosSinteticaDTO> pendenciasConfirmacao;

	public String getConvenioConfirmacaoRemessa() {
		return convenioConfirmacaoRemessa;
	}

	public void setConvenioConfirmacaoRemessa(String convenioConfirmacaoRemessa) {
		this.convenioConfirmacaoRemessa = convenioConfirmacaoRemessa;
	}

	/**
	 * @return the detalheAgrupamentoConvenio
	 */
	public String getDetalheAgrupamentoConvenio() {
		return detalheAgrupamentoConvenio;
	}

	/**
	 * @param detalheAgrupamentoConvenio
	 *            the detalheAgrupamentoConvenio to set
	 */
	public void setDetalheAgrupamentoConvenio(String detalheAgrupamentoConvenio) {
		this.detalheAgrupamentoConvenio = detalheAgrupamentoConvenio;
	}

	/**
	 * @return the convenio
	 */
	public int getCodProduto() {
		return codProduto;
	}

	/**
	 * @param convenio
	 *            the convenio to set
	 */
	public void setCodProduto(int codProduto) {
		this.codProduto = codProduto;
	}

	/**
	 * @return the qtdPendenciasSelecionadasPorGrupo
	 */
	public Integer getQtdPendenciasSelecionadasPorGrupo() {
		return qtdPendenciasSelecionadasPorGrupo;

//		Integer quantity = 0;
//		for (AutorizacoesPendenciaDadosSinteticaDTO p : pendencias) {
//			quantity += (UtilFunction.isNotBlankOrNull(p.getListaAnaliticaDTO()) ? p.getListaAnaliticaDTO().size() : 0);
//		}
//		return quantity;
	}

	/**
	 * @param qtdPendenciasSelecionadasPorGrupo
	 *            the qtdPendenciasSelecionadasPorGrupo to set
	 */
	public void setQtdPendenciasSelecionadasPorGrupo(Integer qtdPendenciasSelecionadasPorGrupo) {
		this.qtdPendenciasSelecionadasPorGrupo = qtdPendenciasSelecionadasPorGrupo;
	}

	/**
	 * @return the vlrTotalPendenciasPorGrupo
	 */
	public BigDecimal getVlrTotalPendenciasPorGrupo() {

		return vlrTotalPendenciasPorGrupo;
//		BigDecimal quantity = BigDecimal.ZERO;
//		for (AutorizacoesPendenciaDadosSinteticaDTO p : pendencias) {
//			if (UtilFunction.isNotBlankOrNull(p.getListaAnaliticaDTO())) {
//				for (AutorizacoesPendenciaDadosAnaliticaDTO analiticas : p.getListaAnaliticaDTO()) {
//					if (analiticas.isItemSelecionado()) {
//						quantity = quantity.add(analiticas.getValorUsuarioPendencia());
//					}
//				}
//			}
//		}
//		// String retorno = quantity.compareTo(BigDecimal.ZERO) == 0 ? "0,00" :
//		// UtilFunction.converterBigDecimalToString(quantity);
//		return quantity;
	}

	/**
	 * @param vlrTotalPendenciasPorGrupo
	 *            the vlrTotalPendenciasPorGrupo to set
	 */
	public void setVlrTotalPendenciasPorGrupo(BigDecimal vlrTotalPendenciasPorGrupo) {
		this.vlrTotalPendenciasPorGrupo = vlrTotalPendenciasPorGrupo;
	}

	/**
	 * @return the pendenciasConfirmacao
	 */
	public List<AutorizacoesPendenciaDadosSinteticaDTO> getPendenciasConfirmacao() {
		return pendenciasConfirmacao;
	}

	/**
	 * @param pendenciasConfirmacao
	 *            the pendenciasConfirmacao to set
	 */
	public void setPendenciasConfirmacao(List<AutorizacoesPendenciaDadosSinteticaDTO> pendenciasConfirmacao) {
		this.pendenciasConfirmacao = pendenciasConfirmacao;
	}

	/**
	 * AutorizacoesPendenciaAgrupada
	 */
	public AutorizacoesPendenciaAgrupada() {
		setPendenciasSelecionadas(Boolean.FALSE);
		setPendencias(new ArrayList<AutorizacoesPendenciaDadosSinteticaDTO>());
	}

	/**
	 * @return the pendenciasSelecionadas
	 */
	public Boolean getPendenciasSelecionadas() {
		return pendenciasSelecionadas;
	}

	/**
	 * @param pendenciasSelecionadas
	 *            the pendenciasSelecionadas to set
	 */
	public void setPendenciasSelecionadas(Boolean pendenciasSelecionadas) {
		this.pendenciasSelecionadas = pendenciasSelecionadas;
	}

	/**
	 * @return the pendencias
	 */
	public List<AutorizacoesPendenciaDadosSinteticaDTO> getPendencias() {
		return pendencias;
	}

	/**
	 * @param pendencias
	 *            the pendencias to set
	 */
	public void setPendencias(List<AutorizacoesPendenciaDadosSinteticaDTO> pendencias) {
		this.pendencias = pendencias;
	}

	/**
	 * @return the quantidadePendencias
	 */
	public Integer getQuantidadePendencias() {
		return quantidadePendencias;
	}

	/**
	 * @param quantidadePendencias
	 *            the quantidadePendencias to set
	 */
	public void setQuantidadePendencias(Integer quantidadePendencias) {
		this.quantidadePendencias = quantidadePendencias;
	}

	/**
	 * @return the valorTotalPendencias
	 */
	public BigDecimal getValorTotalPendencias() {
		return valorTotalPendencias;
	}

	/**
	 * @param valorTotalPendencias
	 *            the valorTotalPendencias to set
	 */
	public void setValorTotalPendencias(BigDecimal valorTotalPendencias) {
		this.valorTotalPendencias = valorTotalPendencias;
	}

	/**
	 * @return the descricaoAgrupamento
	 */
	public String getDescricaoAgrupamento() {
		return descricaoAgrupamento;
	}

	/**
	 * @param descricaoAgrupamento
	 *            the descricaoAgrupamento to set
	 */
	public void setDescricaoAgrupamento(String descricaoAgrupamento) {
		this.descricaoAgrupamento = descricaoAgrupamento;
	}

	/**
	 * @return the detalheAgrupamento
	 */
	public String getDetalheAgrupamento() {
		return detalheAgrupamento;
	}

	/**
	 * @param detalheAgrupamento
	 *            the detalheAgrupamento to set
	 */
	public void setDetalheAgrupamento(String detalheAgrupamento) {
		this.detalheAgrupamento = detalheAgrupamento;
	}

	public Integer getQuantidadePendenciasAgrupada() {
//		Integer quantity = 0;
//		for (AutorizacoesPendenciaDadosSinteticaDTO p : pendencias) {
//			quantity += Integer.parseInt(p.getQuantidadePendencias());
//		}
//		return quantity;
		return quantidadePendenciasAgrupada;
	}

	public void setQuantidadePendenciasAgrupada(Integer quantidadePendenciasAgrupada) {
		this.quantidadePendenciasAgrupada = quantidadePendenciasAgrupada;
	}

	public BigDecimal getValorTotalPendenciasAgrupada() {
//		BigDecimal quantity = BigDecimal.ZERO;
//		for (AutorizacoesPendenciaDadosSinteticaDTO p : pendencias) {
//			quantity = quantity.add(p.getValorPendencias());
//		}
////		String retorno = quantity.compareTo(BigDecimal.ZERO) == 0 ? "0,00"
////				: UtilFunction.convertBigDecimalToStringFormatoBR(quantity);
//		return quantity;
		return valorTotalPendenciasAgrupada;
	}

	public void setValorTotalPendenciasAgrupada(BigDecimal valorTotalPendenciasAgrupada) {
		this.valorTotalPendenciasAgrupada = valorTotalPendenciasAgrupada;
	}

	public Boolean getFlgPendenciasAgrupada() {
//		for (AutorizacoesPendenciaDadosSinteticaDTO p : pendencias) {
//			if (p.isFlgAutorizarSintetica() == true) {
//				return true;
//			}
//		}
//		return false;
		return flgPendenciasAgrupada;
	}

	public void setFlgPendenciasAgrupada(Boolean flgPendenciasAgrupada) {
		this.flgPendenciasAgrupada = flgPendenciasAgrupada;
	}

	public String getContaConvenioAnalitico() {
		return contaConvenioAnalitico;
	}

	public void setContaConvenioAnalitico(String contaConvenioAnalitico) {
		this.contaConvenioAnalitico = contaConvenioAnalitico;
	}

	@Override
	public int compareTo(AutorizacoesPendenciaAgrupada outro) {
		/*
		 * implementei somente comparacao por data, caso necessario implementar
		 * novo recurso
		 */
		if (outro.getDescricaoAgrupamento().length() == 10) {
			int outraDia = Integer.parseInt(outro.getDescricaoAgrupamento().substring(0, 2));
			int outraMes = Integer.parseInt(outro.getDescricaoAgrupamento().substring(3, 5));
			int outraAno = Integer.parseInt(outro.getDescricaoAgrupamento().substring(6, 10));

			Calendar outraData = Calendar.getInstance();
			outraData.set(Calendar.YEAR, outraAno);
			outraData.set(Calendar.MONTH, outraMes - 1);
			outraData.set(Calendar.DAY_OF_MONTH, outraDia);

			int estaDia = Integer.parseInt(descricaoAgrupamento.substring(0, 2));
			int estaMes = Integer.parseInt(descricaoAgrupamento.substring(3, 5));
			int estaAno = Integer.parseInt(descricaoAgrupamento.substring(6, 10));

			Calendar estaData = Calendar.getInstance();
			estaData.set(Calendar.YEAR, estaAno);
			estaData.set(Calendar.MONTH, estaMes - 1);
			estaData.set(Calendar.DAY_OF_MONTH, estaDia);


			if (estaData.after(outraData)) {
				return 1;
			} else if (estaData.before(outraData)) {
				return -1;
			}
		}
		return 0;
	}
}
