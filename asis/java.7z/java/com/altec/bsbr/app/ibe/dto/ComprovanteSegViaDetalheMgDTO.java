package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

import com.altec.bsbr.app.ibe.dto.fundos.CONTRATOBRType;

public class ComprovanteSegViaDetalheMgDTO implements Serializable{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private CONTRATOBRType contrato;
    private String canal;
    private Integer numDDDLlamada;
    private Integer numTelefonoLlamada;
    private String codNSU;
    private String nio;
    private Integer maxSeqNio;
    private String tabela;

	public CONTRATOBRType getContrato() {
		return contrato;
	}
	public void setContrato(CONTRATOBRType contrato) {
		this.contrato = contrato;
	}
	public String getCanal() {
		return canal;
	}
	public void setCanal(String canal) {
		this.canal = canal;
	}
	public Integer getNumDDDLlamada() {
		return numDDDLlamada;
	}
	public void setNumDDDLlamada(Integer numDDDLlamada) {
		this.numDDDLlamada = numDDDLlamada;
	}
	public Integer getNumTelefonoLlamada() {
		return numTelefonoLlamada;
	}
	public void setNumTelefonoLlamada(Integer numTelefonoLlamada) {
		this.numTelefonoLlamada = numTelefonoLlamada;
	}
	public String getCodNSU() {
		return codNSU;
	}
	public void setCodNSU(String codNSU) {
		this.codNSU = codNSU;
	}
	public String getNio() {
		return nio;
	}
	public void setNio(String nio) {
		this.nio = nio;
	}
	public Integer getMaxSeqNio() {
		return maxSeqNio;
	}
	public void setMaxSeqNio(Integer maxSeqNio) {
		this.maxSeqNio = maxSeqNio;
	}
	public String getTabela() {
		return tabela;
	}
	public void setTabela(String tabela) {
		this.tabela = tabela;
	}

}
