
package com.altec.bsbr.app.ibe.dto.investimentos.posicaomensal;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class AltairMessage implements Serializable
{

    private List<AltairWarning> altairWarning = new ArrayList<AltairWarning>();
    private final static long serialVersionUID = -1625899568100391385L;

    /**
     * No args constructor for use in serialization
     * 
     */
    public AltairMessage() {
    }

    /**
     * 
     * @param altairWarning
     */
    public AltairMessage(List<AltairWarning> altairWarning) {
        super();
        this.altairWarning = altairWarning;
    }

    public List<AltairWarning> getAltairWarning() {
        return altairWarning;
    }

    public void setAltairWarning(List<AltairWarning> altairWarning) {
        this.altairWarning = altairWarning;
    }

    public AltairMessage withAltairWarning(List<AltairWarning> altairWarning) {
        this.altairWarning = altairWarning;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(altairWarning).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof AltairMessage) == false) {
            return false;
        }
        AltairMessage rhs = ((AltairMessage) other);
        return new EqualsBuilder().append(altairWarning, rhs.altairWarning).isEquals();
    }

}
