package com.altec.bsbr.app.ibe.enumeration;

public enum OperacaoRecargaCelularEnum {
	
	INCLUSAO		("I"),
	ALTERACAO		("A"),
	CANCELAMENTO	("A");
	
	private String operacao;

	private OperacaoRecargaCelularEnum(String operacao) {
		this.operacao = operacao;
	}

	public String getOperacao() {
		return operacao;
	}
	
}
