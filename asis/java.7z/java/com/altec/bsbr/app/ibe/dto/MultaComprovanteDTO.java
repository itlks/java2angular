package com.altec.bsbr.app.ibe.dto;

import java.math.BigDecimal;

public class MultaComprovanteDTO {
	private Integer numGu;
	private String dtInf;
	private String atInf;
	private String dtVen;
	private Integer cdOAt;
	private BigDecimal vlMul;

	public String getAtInf() {
		return atInf;
	}

	public void setAtInf(String atInf) {
		this.atInf = atInf;
	}

	public Integer getNumGu() {
		return numGu;
	}

	public void setNumGu(Integer numGu) {
		this.numGu = numGu;
	}

	public String getDtInf() {
		return dtInf;
	}

	public void setDtInf(String dtInf) {
		this.dtInf = dtInf;
	}

	public String getDtVen() {
		return dtVen;
	}

	public void setDtVen(String dtVen) {
		this.dtVen = dtVen;
	}

	public BigDecimal getVlMul() {
		return vlMul;
	}

	public void setVlMul(BigDecimal vlMul) {
		this.vlMul = vlMul;
	}

	public Integer getCdOAt() {
		return cdOAt;
	}

	public void setCdOAt(Integer cdOAt) {
		this.cdOAt = cdOAt;
	}

}
