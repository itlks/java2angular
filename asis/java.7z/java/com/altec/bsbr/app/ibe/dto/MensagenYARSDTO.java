package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class MensagenYARSDTO  extends GenericDTO implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1852690021103638610L;
	private String cpibtplinha;
    private String cpibpulalinha;
    private String cpibdados;
    
    public MensagenYARSDTO () {
    	
    }
    
	public String getCpibtplinha() {
		return cpibtplinha;
	}
	
	public void setCpibtplinha(String cpibtplinha) {
		this.cpibtplinha = cpibtplinha;
	}
	
	public String getCpibpulalinha() {
		return cpibpulalinha;
	}
	
	public void setCpibpulalinha(String cpibpulalinha) {
		this.cpibpulalinha = cpibpulalinha;
	}
	
	public String getCpibdados() {
		return cpibdados;
	}
	
	public void setCpibdados(String cpibdados) {
		this.cpibdados = cpibdados;
	}
	
	public String getLabel() {
		if (this.cpibtplinha.equalsIgnoreCase("L1") 
				&& this.cpibdados != null
				&& this.cpibdados.length()>=24) {
			return this.cpibdados.substring(0,24);
		}
		return "";
	}
	
	public String getValor() {
		if (this.cpibtplinha.equalsIgnoreCase("L1") 
				&& this.cpibdados != null
				&& this.cpibdados.length() >= 25) {
			return this.cpibdados.substring(25,this.cpibdados.length());
		}
		return "";
	}
}
