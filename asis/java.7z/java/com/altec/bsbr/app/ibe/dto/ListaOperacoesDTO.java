package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class ListaOperacoesDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3124542751129280980L;

	private String TSOEMBNROPER;
	private String TSOEMBDTOPER;
	private String TSOEMBVLOPER;

	/**
	 * @return the tSOEMBNROPER
	 */
	public String getTSOEMBNROPER() {
		return TSOEMBNROPER;
	}

	/**
	 * @param tSOEMBNROPER
	 *            the tSOEMBNROPER to set
	 */
	public void setTSOEMBNROPER(String tSOEMBNROPER) {
		TSOEMBNROPER = tSOEMBNROPER;
	}

	/**
	 * @return the tSOEMBDTOPER
	 */
	public String getTSOEMBDTOPER() {
		return TSOEMBDTOPER;
	}

	/**
	 * @param tSOEMBDTOPER
	 *            the tSOEMBDTOPER to set
	 */
	public void setTSOEMBDTOPER(String tSOEMBDTOPER) {
		TSOEMBDTOPER = tSOEMBDTOPER;
	}

	/**
	 * @return the tSOEMBVLOPER
	 */
	public String getTSOEMBVLOPER() {
		return TSOEMBVLOPER;
	}

	/**
	 * @param tSOEMBVLOPER
	 *            the tSOEMBVLOPER to set
	 */
	public void setTSOEMBVLOPER(String tSOEMBVLOPER) {
		TSOEMBVLOPER = tSOEMBVLOPER;
	}

}
