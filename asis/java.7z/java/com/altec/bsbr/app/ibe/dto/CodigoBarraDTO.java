package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class CodigoBarraDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String bloco1;
	private String bloco2;
	private String bloco3;
	private String bloco4;
	private String cliente;
	private boolean agendarPagamento;
	private String dataPagamento;
	private String valor;
	private String empresa;
	private String autenticacao;
	private String dataTransacao;
	private String horaTransacao;
	
	public CodigoBarraDTO(){
		
	}
	
	public String getBloco1() {
		return bloco1;
	}
	public void setBloco1(String bloco1) {
		this.bloco1 = bloco1;
	}
	public String getBloco2() {
		return bloco2;
	}
	public void setBloco2(String bloco2) {
		this.bloco2 = bloco2;
	}
	public String getBloco3() {
		return bloco3;
	}
	public void setBloco3(String bloco3) {
		this.bloco3 = bloco3;
	}
	public String getBloco4() {
		return bloco4;
	}
	public void setBloco4(String bloco4) {
		this.bloco4 = bloco4;
	}
	public String getCliente() {
		return cliente;
	}
	public void setCliente(String cliente) {
		this.cliente = cliente;
	}
	public boolean isAgendarPagamento() {
		return agendarPagamento;
	}
	public void setAgendarPagamento(boolean agendarPagamento) {
		this.agendarPagamento = agendarPagamento;
	}
	
	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}

	public String getDataPagamento() {
		return dataPagamento;
	}

	public void setDataPagamento(String dataPagamento) {
		this.dataPagamento = dataPagamento;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	public String getAutenticacao() {
		return autenticacao;
	}

	public void setAutenticacao(String autenticacao) {
		this.autenticacao = autenticacao;
	}

	public String getDataTransacao() {
		return dataTransacao;
	}

	public void setDataTransacao(String dataTransacao) {
		this.dataTransacao = dataTransacao;
	}

	public String getHoraTransacao() {
		return horaTransacao;
	}

	public void setHoraTransacao(String horaTransacao) {
		this.horaTransacao = horaTransacao;
	}
	
}
