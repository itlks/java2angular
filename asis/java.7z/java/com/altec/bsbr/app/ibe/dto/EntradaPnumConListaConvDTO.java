package com.altec.bsbr.app.ibe.dto;

import java.util.ArrayList;

public class EntradaPnumConListaConvDTO {

	private ArrayList<ItemEntradaPnumConListaConvDTO> listaPenum = new ArrayList<ItemEntradaPnumConListaConvDTO>();

	/**
	 * @return the listaPenum
	 */
	public ArrayList<ItemEntradaPnumConListaConvDTO> getListaPenum() {
		return listaPenum;
	}

	/**
	 * @param listaPenum the listaPenum to set
	 */
	public void setListaPenum(ArrayList<ItemEntradaPnumConListaConvDTO> listaPenum) {
		this.listaPenum = listaPenum;
	}
	
}
