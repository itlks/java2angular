package com.altec.bsbr.app.ibe.dto.agendamentos;

public class GpsDTO {
	private String nomeDoContribuinte;
	private String codigoDoPagamento;
	private String competencia;
	private String identificador;
	private String valorDoInss;
	private String valorOutrasEntidades;
	private String atmMultasJuros;
	private String total;
	
	
	
	public String getNomeDoContribuinte() {
		return nomeDoContribuinte;
	}
	public void setNomeDoContribuinte(String nomeDoContribuinte) {
		this.nomeDoContribuinte = nomeDoContribuinte;
	}
	public String getCodigoDoPagamento() {
		return codigoDoPagamento;
	}
	public void setCodigoDoPagamento(String codigoDoPagamento) {
		this.codigoDoPagamento = codigoDoPagamento;
	}
	public String getCompetencia() {
		return competencia;
	}
	public void setCompetencia(String competencia) {
		this.competencia = competencia;
	}
	public String getIdentificador() {
		return identificador;
	}
	public void setIdentificador(String identificador) {
		this.identificador = identificador;
	}
	public String getValorDoInss() {
		return valorDoInss;
	}
	public void setValorDoInss(String valorDoInss) {
		this.valorDoInss = valorDoInss;
	}
	public String getValorOutrasEntidades() {
		return valorOutrasEntidades;
	}
	public void setValorOutrasEntidades(String valorOutrasEntidades) {
		this.valorOutrasEntidades = valorOutrasEntidades;
	}
	public String getAtmMultasJuros() {
		return atmMultasJuros;
	}
	public void setAtmMultasJuros(String atmMultasJuros) {
		this.atmMultasJuros = atmMultasJuros;
	}
	public String getTotal() {
		return total;
	}
	public void setTotal(String total) {
		this.total = total;
	}
	
	
	

}
