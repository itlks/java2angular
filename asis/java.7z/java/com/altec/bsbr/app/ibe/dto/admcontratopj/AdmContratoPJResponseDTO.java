package com.altec.bsbr.app.ibe.dto.admcontratopj;

import java.io.Serializable;

public class AdmContratoPJResponseDTO implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5017841708859789294L;

	private String total;
	
	private String idUsuarioMaster;
	
	private String codError;
	
	private String msgError;

	public AdmContratoPJResponseDTO(){}
	/**
	 * @return the intQtUsuario
	 */
	
	public String getMsgError() {
		return msgError;
	}

	/**
	 * @param msgError the msgError to set
	 */
	public void setMsgError(String msgError) {
		this.msgError = msgError;
	}
	public String getTotal() {
		return total;
	}
	public void setTotal(String total) {
		this.total = total;
	}
	public String getIdUsuarioMaster() {
		return idUsuarioMaster;
	}
	public void setIdUsuarioMaster(String idUsuarioMaster) {
		this.idUsuarioMaster = idUsuarioMaster;
	}
	public String getCodError() {
		return codError;
	}
	public void setCodError(String codError) {
		this.codError = codError;
	}


}