package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ListaPosicaoConsolidadaSaldoContaCorrenteDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2026910997120296932L;
	
	private List<PosicaoConsolidadaDTO> posicaoConsolidada = new ArrayList<PosicaoConsolidadaDTO>();

	public List<PosicaoConsolidadaDTO> getPosicaoConsolidada() {
		return posicaoConsolidada;
	}

	public void setPosicaoConsolidada(List<PosicaoConsolidadaDTO> posicaoConsolidada) {
		this.posicaoConsolidada = posicaoConsolidada;
	}

}
