package com.altec.bsbr.app.ibe.enumeration;

public enum SegundaViaComprovanteTipoTitularidadeDOC {
	CC_INDIVIDUAL("4", "DOC Outra Titularidade"),
	CC_("5", "DOC Mesma Titularidade");
	
	private String valor;
	private String descricao;
	
	private SegundaViaComprovanteTipoTitularidadeDOC(String valor, String descricao) {
		this.valor = valor;
		this.descricao = descricao;
	}
	
	public String getValor() {
		return valor;
	}

	public String getDescricao() {
		return descricao;
	}


	
}
