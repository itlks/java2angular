package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class FloaterDTO implements Serializable {

	private static final long serialVersionUID = -8387873332360213799L;

	private String textoDiv1;
	private String textoDiv2;	
	private String textoDiv3;
	private String imagem;
	private String linkURL;
	private String tpLink;
	private String tpCampanha = "";
	private String raAttribSeg = "";
 	private String boId = "";
 	private String blank;
 	private boolean desabilitarAceite = false;
 	private boolean desabilitarRejeite = false;
	private boolean habilitarFloater = false;
	private Boolean visualizouMidiaCRM = Boolean.FALSE;
	private Boolean isMidia4 = Boolean.FALSE;
	
	private String linkUrlClassico;
	
	private String strTopDiv1;
 	private String strLeftDiv1;
 	
 	private String strTopDiv2;
 	private String strLeftDiv2;

 	private String strTopDiv3;
 	private String strLeftDiv3;

 	private String strTextoLinkUrl;
 	private String strTopLinkUrl;
 	private String strLeftLinkUrl;

	public String getLinkURL() {
		return linkURL;
	}
	public void setLinkURL(String linkURL) {
		this.linkURL = linkURL;
	}
	public boolean getHabilitarFloater() {
		return habilitarFloater;
	}
	public void setHabilitarFloater(boolean habilitarFloater) {
		this.habilitarFloater = habilitarFloater;
	}
	public String getTextoDiv1() {
		return textoDiv1;
	}
	public void setTextoDiv1(String textoDiv1) {
		this.textoDiv1 = textoDiv1;
	}
	public String getTextoDiv2() {
		return textoDiv2;
	}
	public void setTextoDiv2(String textoDiv2) {
		this.textoDiv2 = textoDiv2;
	}
	public String getTextoDiv3() {
		return textoDiv3;
	}
	public void setTextoDiv3(String textoDiv3) {
		this.textoDiv3 = textoDiv3;
	}
	public String getImagem() {
		return imagem;
	}
	public void setImagem(String imagem) {
		this.imagem = imagem;
	}
	public String getTpCampanha() {
		return tpCampanha;
	}
	public void setTpCampanha(String tpCampanha) {
		this.tpCampanha = tpCampanha;
	}
	public String getRaAttribSeg() {
		return raAttribSeg;
	}
	public void setRaAttribSeg(String raAttribSeg) {
		this.raAttribSeg = raAttribSeg;
	}
	public String getBoId() {
		return boId;
	}
	public void setBoId(String boId) {
		this.boId = boId;
	}
	public String getTpLink() {
		return tpLink;
	}
	public void setTpLink(String tpLink) {
		this.tpLink = tpLink;
	}
	public String getBlank() {
		return blank;
	}
	public void setBlank(String blank) {
		this.blank = blank;
	}
	public boolean getDesabilitarAceite() {
		return desabilitarAceite;
	}
	public void setDesabilitarAceite(boolean desabilitarAceite) {
		this.desabilitarAceite = desabilitarAceite;
	}
	public boolean getDesabilitarRejeite() {
		return desabilitarRejeite;
	}
	public void setDesabilitarRejeite(boolean desabilitarRejeite) {
		this.desabilitarRejeite = desabilitarRejeite;
	}
	public Boolean getVisualizouMidiaCRM() {
		return visualizouMidiaCRM;
	}
	public void setVisualizouMidiaCRM(Boolean visualizouMidiaCRM) {
		this.visualizouMidiaCRM = visualizouMidiaCRM;
	}
	public String getStrTopDiv2() {
		return strTopDiv2;
	}
	public void setStrTopDiv2(String strTopDiv2) {
		this.strTopDiv2 = strTopDiv2;
	}
	public String getStrLeftDiv2() {
		return strLeftDiv2;
	}
	public void setStrLeftDiv2(String strLeftDiv2) {
		this.strLeftDiv2 = strLeftDiv2;
	}
	public String getStrTopDiv3() {
		return strTopDiv3;
	}
	public void setStrTopDiv3(String strTopDiv3) {
		this.strTopDiv3 = strTopDiv3;
	}
	public String getStrLeftDiv3() {
		return strLeftDiv3;
	}
	public void setStrLeftDiv3(String strLeftDiv3) {
		this.strLeftDiv3 = strLeftDiv3;
	}
	public String getStrTextoLinkUrl() {
		return strTextoLinkUrl;
	}
	public void setStrTextoLinkUrl(String strTextoLinkUrl) {
		this.strTextoLinkUrl = strTextoLinkUrl;
	}
	public String getStrTopLinkUrl() {
		return strTopLinkUrl;
	}
	public void setStrTopLinkUrl(String strTopLinkUrl) {
		this.strTopLinkUrl = strTopLinkUrl;
	}
	public String getStrLeftLinkUrl() {
		return strLeftLinkUrl;
	}
	public void setStrLeftLinkUrl(String strLeftLinkUrl) {
		this.strLeftLinkUrl = strLeftLinkUrl;
	}
	public String getStrTopDiv1() {
		return strTopDiv1;
	}
	public void setStrTopDiv1(String strTopDiv1) {
		this.strTopDiv1 = strTopDiv1;
	}
	public String getStrLeftDiv1() {
		return strLeftDiv1;
	}
	public void setStrLeftDiv1(String strLeftDiv1) {
		this.strLeftDiv1 = strLeftDiv1;
	}
	public Boolean getIsMidia4() {
		return isMidia4;
	}
	public void setIsMidia4(Boolean isMidia4) {
		this.isMidia4 = isMidia4;
	}
	public String getLinkUrlClassico() {
		return linkUrlClassico;
	}
	public void setLinkUrlClassico(String linkUrlClassico) {
		this.linkUrlClassico = linkUrlClassico;
	}
	
}
