package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.List;

public class DDAPainelResumoDTO extends GenericDTO implements Serializable {

	private static final long serialVersionUID = 8340856092080385758L;

	private String tipoPessoa;
	private String tipoPessoaDetalhe;
	private String pagadorEletronico;
	private String numDocumento;
	private String banco;
	private String agencia;
	private String conta;
	private String referOper;
	private String codigoDoCanal;
	private List<DDAEventoDTO> listaEventosPosicaoDia;
	private List<DDAEventoDTO> listaEventosPosicaoDiaAnterior;

	public String getTipoPessoa() {
		return tipoPessoa;
	}

	public void setTipoPessoa(String tipoPessoa) {
		this.tipoPessoa = tipoPessoa;
	}

	public String getPagadorEletronico() {
		return pagadorEletronico;
	}

	public void setPagadorEletronico(String pagadorEletronico) {
		this.pagadorEletronico = pagadorEletronico;
	}

	public String getNumDocumento() {
		return numDocumento;
	}

	public void setNumDocumento(String numDocumento) {
		this.numDocumento = numDocumento;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getConta() {
		return conta;
	}

	public void setConta(String conta) {
		this.conta = conta;
	}

	public String getReferOper() {
		return referOper;
	}

	public void setReferOper(String referOper) {
		this.referOper = referOper;
	}

	public String getCodigoDoCanal() {
		return codigoDoCanal;
	}

	public void setCodigoDoCanal(String codigoCanal) {
		this.codigoDoCanal = codigoCanal;
	}

	public String getTipoPessoaDetalhe() {
		return tipoPessoaDetalhe;
	}

	public void setTipoPessoaDetalhe(String tipoPessoaDetalhe) {
		this.tipoPessoaDetalhe = tipoPessoaDetalhe;
	}

	public List<DDAEventoDTO> getListaEventosPosicaoDia() {
		return listaEventosPosicaoDia;
	}

	public void setListaEventosPosicaoDia(List<DDAEventoDTO> listaEventosPosicaoDia) {
		this.listaEventosPosicaoDia = listaEventosPosicaoDia;
	}

	public List<DDAEventoDTO> getListaEventosPosicaoDiaAnterior() {
		return listaEventosPosicaoDiaAnterior;
	}

	public void setListaEventosPosicaoDiaAnterior(List<DDAEventoDTO> listaEventosPosicaoDiaAnterior) {
		this.listaEventosPosicaoDiaAnterior = listaEventosPosicaoDiaAnterior;
	}
}