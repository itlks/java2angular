package com.altec.bsbr.app.ibe.enumeration;

public enum TipoCotaEnum {
	ABERTURA(1, "abertura"), FECHAMENTO(0, "fechamento");

	private Integer id;
	private String desc;

	private TipoCotaEnum(Integer id, String desc) {
		this.id = id;
		this.desc = desc;
	}

	public int getId() {
		return id;
	}

	public String getDesc() {
		return desc;
	}

	public static TipoCotaEnum findById(Integer id) {
		TipoCotaEnum retorno = null;
		if (id == null || id == 0)
			retorno = null;

		for (TipoCotaEnum tipoCota : TipoCotaEnum.values()) {
			if (tipoCota.getId() == id) {
				retorno = tipoCota;
				break;
			}
		}
		return retorno;
	}

}