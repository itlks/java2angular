
/*
 * Cheque Ades�o Empresa Protegido (Rest Implementation para controle de fluxo)
 *
 */
package com.altec.bsbr.app.ibe.rest.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.altec.bsbr.app.ibe.dto.SeguroPrestamistaChequeEempresaResponseDTO;
import com.altec.bsbr.app.ibe.dto.SeguroPrestamistaChequeEmpresaRequestDTO;
import com.altec.bsbr.app.ibe.enumeration.EstatisticaEnum;
import com.altec.bsbr.app.ibe.enumeration.ProdutoEnum;
import com.altec.bsbr.app.ibe.enumeration.ServicoEnum;
import com.altec.bsbr.app.ibe.enumeration.SituacaoDaTransacaoEnum;
import com.altec.bsbr.app.ibe.rest.hub.HubRest;
import com.altec.bsbr.app.ibe.rest.hub.dto.HubRestResourceDTO;
import com.altec.bsbr.app.ibe.rest.service.SeguroPrestamistaChequeEmpresaRestService;
import com.altec.bsbr.app.ibe.service.LogsDelegateService;
import com.altec.bsbr.app.ibe.service.impl.IBEBasicDelegate;
import com.altec.bsbr.app.ibe.util.UtilFunction;
import com.altec.bsbr.app.ibe.web.jsf.attributes.AtributosDaSessao;
import com.altec.bsbr.fw.BusinessException;

@Service
public class SeguroPrestamistaChequeEmpresaRestServiceImpl extends IBEBasicDelegate
		implements SeguroPrestamistaChequeEmpresaRestService {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3140665692230859710L;

	public static final Logger LOGGER = LoggerFactory.getLogger(SeguroPrestamistaChequeEmpresaRestServiceImpl.class);

	
	private static final int NUMERO_DOZE = 12;
	private static final int NUMERO_QUATRO = 4;
	private static final int NUMERO_DUZENTOS = 200;

	@Autowired
	private transient HubRest hubRest;

	@Autowired
	@Qualifier("chequesEspecialProtegicoAdesao_BGSP")
	private transient HubRestResourceDTO resource;

	@Autowired
	private LogsDelegateService logService;

	@Override
	public void confirmarAdesao(final AtributosDaSessao session) throws BusinessException {
		SeguroPrestamistaChequeEempresaResponseDTO seguroPrestamistaChequeEspecialResponseDTO = new SeguroPrestamistaChequeEempresaResponseDTO();

		try {
			ResponseEntity<SeguroPrestamistaChequeEempresaResponseDTO> response = hubRest.postForEntity(
					resource.getUrl(), montarRequest(session), SeguroPrestamistaChequeEempresaResponseDTO.class);
			if (response != null && response.getStatusCode().value() == NUMERO_DUZENTOS) {
				seguroPrestamistaChequeEspecialResponseDTO = response.getBody();
				LOGGER.debug("INVESTIMENTO HubRest Consultado com SUCESSO !!!!");
				String codigoRetorno = seguroPrestamistaChequeEspecialResponseDTO.getOutputLendersInsurances().get(0)
						.getOutput().get(0).getReturnCode();
				if (!"00".equals(codigoRetorno)) {
					throw new BusinessException(codigoRetorno);
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception [SeguroPrestamistaChequeEspecialRestServiceImpl] consultarInvestimentos : [{}]", e);
		} finally {
			logService.gerarLogTransacionalOuInformacional(
					getDadosBasicosLog(ProdutoEnum.PRODUTOCONTACORRENTE, ServicoEnum.SERVCONTRATACAOCHQEMPPROT, session,
							EstatisticaEnum.FLAGTRANSACAOVALIDAPARAESTATISTICA.getEstatistica(),
							SituacaoDaTransacaoEnum.FLAGIMPERATIVACONFIRMACAO.getSituacao(),
							session.getNomeTitularConta() + "|" + session.getCnpj(), ""));
		}

	}

	public SeguroPrestamistaChequeEmpresaRequestDTO montarRequest(final AtributosDaSessao session) {
		final SeguroPrestamistaChequeEmpresaRequestDTO seguroPrestamistaChequeEspecialRequestDTO = new SeguroPrestamistaChequeEmpresaRequestDTO();
		seguroPrestamistaChequeEspecialRequestDTO
				.setBank(UtilFunction.preencherZeroEsquerda(session.getBanco(), NUMERO_QUATRO));
		seguroPrestamistaChequeEspecialRequestDTO.setAgency(session.getAgencia());
		seguroPrestamistaChequeEspecialRequestDTO
				.setAccount(UtilFunction.preencherZeroEsquerda(session.getConta(), NUMERO_DOZE));

		return seguroPrestamistaChequeEspecialRequestDTO;
	}

}