package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class FiltroMenuDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String idUsuarioConta;
	private String destino;
	private String nomePagina;
	

	public String getDestino() {
		return destino;
	}
	public void setDestino(String destino) {
		this.destino = destino;
	}
	public String getNomePagina() {
		return nomePagina;
	}
	public void setNomePagina(String nomePagina) {
		this.nomePagina = nomePagina;
	}
	public String getIdUsuarioConta() {
		return idUsuarioConta;
	}
	public void setIdUsuarioConta(String idUsuarioConta) {
		this.idUsuarioConta = idUsuarioConta;
	}
	@Override
	public String toString() {
		return "FiltroMenuDTO [idUsuarioConta=" + idUsuarioConta + ", destino=" + destino + ", nomePagina=" + nomePagina
				+ "]";
	}
		
}
