package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class ListaComprovanteDTO implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6738364475877181575L;
	private String tipoLinha;
	private Integer numVias;
	private boolean pulaLinha;
	private String dadosLinha;
	private String dadosLinha2;
	/**
	 * @return the tipoLinha
	 */
	public String getTipoLinha() {
		return tipoLinha;
	}
	/**
	 * @param tipoLinha the tipoLinha to set
	 */
	public void setTipoLinha(String tipoLinha) {
		this.tipoLinha = tipoLinha;
	}
	/**
	 * @return the numVias
	 */
	public Integer getNumVias() {
		return numVias;
	}
	/**
	 * @param numVias the numVias to set
	 */
	public void setNumVias(Integer numVias) {
		this.numVias = numVias;
	}
	/**
	 * @return the pulaLinha
	 */
	public boolean isPulaLinha() {
		return pulaLinha;
	}
	/**
	 * @param pulaLinha the pulaLinha to set
	 */
	public void setPulaLinha(boolean pulaLinha) {
		this.pulaLinha = pulaLinha;
	}
	/**
	 * @return the dadosLinha
	 */
	public String getDadosLinha() {
		return dadosLinha;
	}
	/**
	 * @param dadosLinha the dadosLinha to set
	 */
	public void setDadosLinha(String dadosLinha) {
		this.dadosLinha = dadosLinha;
	}
	/**
	 * @return the dadosLinha2
	 */
	public String getDadosLinha2() {
		return dadosLinha2;
	}
	/**
	 * @param dadosLinha2 the dadosLinha2 to set
	 */
	public void setDadosLinha2(String dadosLinha2) {
		this.dadosLinha2 = dadosLinha2;
	}
	
	

}
