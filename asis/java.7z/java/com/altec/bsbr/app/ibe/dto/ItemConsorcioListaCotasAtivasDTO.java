package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class ItemConsorcioListaCotasAtivasDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4011003372496563761L;
	
	private String grupo;
	private String cota;
	private String bem;
	private String codBem;
	
	/**
	 * @return the grupo
	 */
	public String getGrupo() {
		return grupo;
	}
	/**
	 * @param grupo the grupo to set
	 */
	public void setGrupo(String grupo) {
		this.grupo = grupo;
	}
	/**
	 * @return the cota
	 */
	public String getCota() {
		return cota;
	}
	/**
	 * @param cota the cota to set
	 */
	public void setCota(String cota) {
		this.cota = cota;
	}
	/**
	 * @return the bem
	 */
	public String getBem() {
		return bem;
	}
	/**
	 * @param bem the bem to set
	 */
	public void setBem(String bem) {
		this.bem = bem;
	}
	/**
	 * @return the codBem
	 */
	public String getCodBem() {
		return codBem;
	}
	/**
	 * @param codBem the codBem to set
	 */
	public void setCodBem(String codBem) {
		this.codBem = codBem;
	}
	
	
	
}
