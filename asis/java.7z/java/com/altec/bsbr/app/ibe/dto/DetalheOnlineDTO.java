package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class DetalheOnlineDTO implements Serializable {

	
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	
	private List<DadosDetalheOnline> dadosDetalheOnilne;
	
	
	
	/**
	 * DetalheOnlineDTO
	 */
	public DetalheOnlineDTO() {
		setDadosDetalheOnilne(new ArrayList<DadosDetalheOnline>());
	}
	
	
	
	/**
	 * @return the dadosDetalheOnilne
	 */
	public List<DadosDetalheOnline> getDadosDetalheOnilne() {
		return dadosDetalheOnilne;
	}




	/**
	 * @param dadosDetalheOnilne the dadosDetalheOnilne to set
	 */
	public void setDadosDetalheOnilne(List<DadosDetalheOnline> dadosdetalheOnilne) {
		this.dadosDetalheOnilne = dadosdetalheOnilne;
	}


}