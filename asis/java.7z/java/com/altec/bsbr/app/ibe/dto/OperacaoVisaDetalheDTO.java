package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class OperacaoVisaDetalheDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3211918186137110919L;
	private String nomeCredenciadora;
	private String nomeBandeira;
	private Date dtOperacao;
	private BigDecimal vlOperacao;

	public Date getDtOperacao() {
		return dtOperacao;
	}

	public void setDtOperacao(Date dtOperacao) {
		this.dtOperacao = dtOperacao;
	}

	public BigDecimal getVlOperacao() {
		return vlOperacao;
	}

	public void setVlOperacao(BigDecimal vlOperacao) {
		this.vlOperacao = vlOperacao;
	}

	public String getNomeCredenciadora() {
		return nomeCredenciadora;
	}

	public void setNomeCredenciadora(String nomeCredenciadora) {
		this.nomeCredenciadora = nomeCredenciadora;
	}

	public String getNomeBandeira() {
		return nomeBandeira;
	}

	public void setNomeBandeira(String nomeBandeira) {
		this.nomeBandeira = nomeBandeira;
	}

}
