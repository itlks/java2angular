package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class UsuarioMasterDTO implements Serializable{

	private static final long serialVersionUID = -8470819640279024236L;

	private String agencia;       
	private String conta;
	private String usuario;
	private String senha;
	private String senhaNova;
	private String senhaConfirmacao;
	private String banco;
	private String msgErroJavaStript;
	private String idUsuario;
	private String nomeCompleto;
	private String cdSituacaoUsua;
	private String cpf;
	private String email;
	private String telefoneDdd;
	private String telefoneNumero;
	private String telefoneRamal;
	private String perguntaAcesso;
	private String respostaAcesso;
	private String qtdAssinatura;
	private String inStatusUsuario;
	private String nomeAcesso;
	private String senhaAcessoInternetBankingEmpresarial; 
	private String confirmeSenhaAcessoInternetBankingEmpresarial;
	
	public UsuarioMasterDTO(){}	
	

	public UsuarioMasterDTO(String idUsuario, String nomeCompleto, String cdSituacaoUsua, String cpf,
			String telefoneDdd, String telefoneNumero, String telefoneRamal, String inStatusUsuario) {
		super();
		this.idUsuario = idUsuario;
		this.nomeCompleto = nomeCompleto;
		this.cdSituacaoUsua = cdSituacaoUsua;
		this.cpf = cpf;
		this.telefoneDdd = telefoneDdd;
		this.telefoneNumero = telefoneNumero;
		this.telefoneRamal = telefoneRamal;
		this.inStatusUsuario = inStatusUsuario;
	}
	
	public String getNomeCompleto() {
		return nomeCompleto;
	}

	public void setNomeCompleto(String nomeCompleto) {
		this.nomeCompleto = nomeCompleto;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTelefoneDdd() {
		return telefoneDdd;
	}

	public void setTelefoneDdd(String telefoneDdd) {
		this.telefoneDdd = telefoneDdd;
	}

	public String getTelefoneNumero() {
		return telefoneNumero;
	}

	public void setTelefoneNumero(String telefoneNumero) {
		this.telefoneNumero = telefoneNumero;
	}

	public String getTelefoneRamal() {
		return telefoneRamal;
	}

	public void setTelefoneRamal(String telefoneRamal) {
		this.telefoneRamal = telefoneRamal;
	}

	public String getPerguntaAcesso() {
		return perguntaAcesso;
	}

	public void setPerguntaAcesso(String perguntaAcesso) {
		this.perguntaAcesso = perguntaAcesso;
	}

	public String getRespostaAcesso() {
		return respostaAcesso;
	}

	public void setRespostaAcesso(String respostaAcesso) {
		this.respostaAcesso = respostaAcesso;
	}

	public String getQtdAssinatura() {
		return qtdAssinatura;
	}

	public void setQtdAssinatura(String qtdAssinatura) {
		this.qtdAssinatura = qtdAssinatura;
	}

	public String getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(String idUsuario) {
		this.idUsuario = idUsuario;
	}

	public String getCdSituacaoUsua() {
		return cdSituacaoUsua;
	}

	public void setCdSituacaoUsua(String cdSituacaoUsua) {
		this.cdSituacaoUsua = cdSituacaoUsua;
	}


	public String getNomeAcesso() {
		return nomeAcesso;
	}


	public void setNomeAcesso(String nomeAcesso) {
		this.nomeAcesso = nomeAcesso;
	}
	
	public String getInStatusUsuario() {
		return inStatusUsuario;
	}


	public void setInStatusUsuario(String inStatusUsuario) {
		this.inStatusUsuario = inStatusUsuario;
	}


	public String getSenhaAcessoInternetBankingEmpresarial() {
		return senhaAcessoInternetBankingEmpresarial;
	}


	public void setSenhaAcessoInternetBankingEmpresarial(String senhaAcessoInternetBankingEmpresarial) {
		this.senhaAcessoInternetBankingEmpresarial = senhaAcessoInternetBankingEmpresarial;
	}


	public String getConfirmeSenhaAcessoInternetBankingEmpresarial() {
		return confirmeSenhaAcessoInternetBankingEmpresarial;
	}


	public void setConfirmeSenhaAcessoInternetBankingEmpresarial(String confirmeSenhaAcessoInternetBankingEmpresarial) {
		this.confirmeSenhaAcessoInternetBankingEmpresarial = confirmeSenhaAcessoInternetBankingEmpresarial;
	}


	public String getAgencia() {
		return agencia;
	}


	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}


	public String getConta() {
		return conta;
	}


	public void setConta(String conta) {
		this.conta = conta;
	}


	public String getUsuario() {
		return usuario;
	}


	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}


	public String getSenha() {
		return senha;
	}


	public void setSenha(String senha) {
		this.senha = senha;
	}


	public String getSenhaNova() {
		return senhaNova;
	}


	public void setSenhaNova(String senhaNova) {
		this.senhaNova = senhaNova;
	}


	public String getSenhaConfirmacao() {
		return senhaConfirmacao;
	}


	public void setSenhaConfirmacao(String senhaConfirmacao) {
		this.senhaConfirmacao = senhaConfirmacao;
	}


	public String getBanco() {
		return banco;
	}


	public void setBanco(String banco) {
		this.banco = banco;
	}


	public String getMsgErroJavaStript() {
		return msgErroJavaStript;
	}


	public void setMsgErroJavaStript(String msgErroJavaStript) {
		this.msgErroJavaStript = msgErroJavaStript;
	}
	
}
