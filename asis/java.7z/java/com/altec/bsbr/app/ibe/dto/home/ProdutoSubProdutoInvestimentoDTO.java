package com.altec.bsbr.app.ibe.dto.home;

public class ProdutoSubProdutoInvestimentoDTO {
	String produto;
	String subproduto;
	
	public ProdutoSubProdutoInvestimentoDTO(String produto, String subproduto) {
		super();
		this.produto = produto;
		this.subproduto = subproduto;
	}
	
	public String getProduto() {
		return produto;
	}
	public String getSubproduto() {
		return subproduto;
	}
	public void setProduto(String produto) {
		this.produto = produto;
	}
	public void setSubproduto(String subproduto) {
		this.subproduto = subproduto;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProdutoSubProdutoInvestimentoDTO other = (ProdutoSubProdutoInvestimentoDTO) obj;
		
		if (produto == null) {
			if (other.produto != null)
				return false;
		} else if (!produto.equals(other.produto))
			return false;
		if (subproduto == null) {
			if (other.subproduto != null)
				return false;
		} else if (!subproduto.equals(other.subproduto))
			return false;
		return true;
	}
	
	
	
}
