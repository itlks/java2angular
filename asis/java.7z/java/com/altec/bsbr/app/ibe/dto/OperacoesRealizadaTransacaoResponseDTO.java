package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class OperacoesRealizadaTransacaoResponseDTO implements Serializable {

	private static final long serialVersionUID = -8018967744861180121L;

	private String dataTransacao;	
	private String horaTransacao;	
	private String valor;	
	private String nomeTransacao;	
	private String idTransacao;	
	private String compHis;	
	private String conta;	
	private String usuario;	
	private String numeroAutenticacao;	
	private String nomePagina;	
	private String nomeServico;	
	private String nomeProduto;	
	private String clienteDestino;	
	private String bancoDestino;
	private String agenciaDestino;	
	private String contaDestino;	
	private String codigoBanco;	
	private String codigoAgencia;
	
	// Variaveis das HISTS
		private String nomeEmpresa;
		private String custoEfetivoTotal;
		private String valorPrimeiraParcela;
		private String valorDemaisParcelas;
		private String cabecalho;
		private String valorParcelado;
		private String valorEntrada;
		private String favorecido;
		private String bancoDestinoIspb;
		private String bancoDestinoFormated;
		private String agencia;
//		private String conta;
		private String tipoTed;
		private String finalidade;
		private String historico;
		private String tipoAdesao;
		private String valorTarifa;
//		private String valor;
		private String informacoesAdicionais;
		private String contaOrigem;
		private String contaInvestimentoDebito;
		private String tipoContaDestino;
		private String banco;
		private String opcoesDebito;
		private String cpf;
		private String nome;
		private String acao;
		private String apelido;
		private String identificacao;
		private String cpfCnpj;
		private String tipoOperacao;
		private String perfilRisco;
		private String nomeFundo;
		private String contaFundo;
		private String diaProgramado;
		private String periodicidade;
		private String dataInicial;
		private String dataFinal;
		private String dataPrimeiraProgramacao;
		private String agenciaConta;
		private String cpfDespachanteRepresentante;
		private String cpfCnpjAutorizacao;
		private String labelDataAutorizacaoOutroPagador;
		private String dataAutorizacaoOutroPagador;
		private String cpfCnpjPagador;
		private String ordemTitulo;
		private String produto;
		private String numeroCertificado;
		private String numeroProcessoSusep;
		private String registroSusep;
		private String numeroCartao;
		private String segurado;
		private String cnpjSegurado;
		private String nomeBeneficiario;
		private String agenciaContaCentralizadora;
		private String codigoBeneficiario;
		private String nomePagador;
		private String valorTitulo;
		private String dataVencimento;
		private String nossoNumero;
		private String codigoOperacao;
		private String informacoesAdicionaisValor;
		private String informacoesAdicionaisData;
		private String numeroOperacao;
		private String exclusaoParticipanteAte;
		private String formaPagamento;
		private String valorAntecipado;
		private String razaoSocial;
		private String contaDebitoCredito;
		private String contaCorrente;
		private String numeroCheque;
		private String dataCompensacao;
		private String valorCheque;
		private String valorAmortizado;
		private String dataSolicitacao;
		private String bancoVinculado;
		private String agenciaVinculada;
		private String contratoVinculado;
		private String valorLiberado;
		private String empresa;
		private String identificador;
		private String empresaConveniada;
		private String limiteDebito;
		private String valorLimite;
		private String dataCadastramento;
		private String dataUltimoLancamento;
		private String motivoExclusao;
		private String emissaoAviso;
		private String inicioSuspensao;
		private String terminoSuspensao;
		private String prazo;
		private String valorAplicado;
		private String tipo;
		private String cpfSegurado;
		private String taxaCdi;
		private String numeroFundos;
		private String situacaoContrato;
		private String periodo;
		private String atualizadaPara;
		private String numeroRemessa;
		private String mesReferencia;
		private String convenio;
		private String quantidadeRegistros;
		private String dataCredito;
		private String codigoBarras;
		private String beneficiario;
		private String pagador;
		private String clientePagador;
		private String dadosDisponiveisSegundaVia;
		private String chave;
		private String placaVeiculo;
		private String renavam;
		private String numeroContribuinte;
		private String nsuProdam;
		private String parcela;
		private String numeroPoupanca;
		private String valorPoupanca;
		private String livre;
		private String integrada;
//		private String bancoDestino;
		private String tipoDoc;
		private String agenciaContaCadastro;
		private String municipio;
		private String documento;
		private String proprietario;
		private String quantidadeMultasPagas;
		private String valorTotalPago;
		private String cartaoCredito;
		private String clienteConsumidor;
		private String vencimento;
		private String codigo;
		private String premioLiquido;
		private String premioBruto;
		private String iof;
		private String telefone;
		private String ramal;
		private String fax;
		private String percentual;
		private String referencia;
		private String prefeitura;
		private String codigoArea;
		private String tipoContaOrigem;
		private String tipoApelido;
		private String tipoCartao;		
		private String contrato;
		private String valorTransfBanespa;
		private String numeroDaRemessa;
		private String diaVencimento;
		private String cpfOuCnpj;
		private String agContaCadastro;
		private String dataDaSolicitacao;
		private String codigoBarra;
		private String IOF;
		private String nomeRazaoSocial;
		private String contaCredito;
		private String livreVerificarNecessidade;
		private String integradaVerificarNecessidade;
		private String saldoDisponivel;
		private String limiteMaximoDiario;
		private String dia;
		private String dias;
		private String cpfSolicitante;
		private String metodoHabilitacao;
		private String nomeAparelho;
		private String numeroCompromisso;
		private String contaDebito;
		private String dataPagto;
		private String valorJuros;
		private String abatDesc;
		private String quantidadeParcelas;
		private String tipoTaxa;
		private String taxaJurosMes;
		private String taxaJurosAno;
		private String tarifaAberturaCredito;
		private String cetMes;
		private String cetAno;
		private String valorTotalFinanciado;
		private String valorEmprestimoEncargos;
		private String valorParcela;
		private String primeiroVencimento;
		private String ultimoVencimento;
		private String encargosInadimplencia;
		private String multaHora;
		private String razaoSocialBeneficiarioOriginal;
		private String razaoSocialPagadorEfetivo;
		private String nomeRazaoSocialPagadorEfetivo;
		private String valorTotalCobrar;
		private String dataVencimento2;
		private String horaEnvio;
		private String agenciaCredito;
		private String data;
		private String valorCompromisso;
		private String favorecidoCpfCnpj;
		private String numeroAgrupamento;
		private String inicio;
		private String numeroMes;
		private String fim;
		private String plano;
		private String dtIniVig;
		private String saldoReserva;
		private String valorAporte;
		private String cnpj;
		private String contaColetiva;
		private String tipoRelatorio;
		private String nomeAparelhoAutorizado;
		private String usuarioSolicitante;
		private String nomeCompletoAutorizado;
		private String cpfAutorizado;
		private String numeroCelular;
		private String valorEmprestimo;
		private String premioSeguro;
		private String repasseEncargosOperacoesCredito;
		private String diaDebito;
		private String valorSaqueParcelado;
		private String numeroParcelas;
		private String limiteCompromisso;
		private String travaValorFolha;
		private String bancoAgenciaContaDestino;
		private String nomeDestinatario;
		private String valorTransacao;
		private String operacaoAnterior;
		private String novaOperacao;
		private String nomeCompleto;
		private String nomeDispositivo;
		private String tipoTransacao;
		private String tipoAlegacao;
		private String dataAlegacao;
		private String arquivo;
		private String situacao;
		private String sequencia;
		private String registros;
		private String tamanhoBytes;
		private String dataHoraTransferencia;
		private String numeroControle;
		private String historicoComplementar;
		private String valorResgatado;
		private String taxa;
		private String vinculo;
		private String dataPrimeiraParcela;
		private String taxaJuros;
		private String contratoRenegociado;
		private String totalDivida;
		private String valorTotal;
		private String valorDesconto;		
		private boolean labelFrasesSeguro; 
		private boolean labelPropostaCancelada;
		private String dataOperacao;		
		private String tituloEletronicoDDA;
		private String reconhecimentoApresentacao;
		private String percentualLance;
		private String valorLance;
		private String diaVencimentoParcela;
		private String percentualCET;
		private String qtdContratoRenegociados;
		private String codigoConvenio;
		private String contaDebitoTarifa;
		private String geradorArquivos;
		private String tarifaEnvioHolerite;
		private String consolidarDebitoExtrato;
		private String formaAutorizacao;
		private String informacoesAdicionaisDias;
		private String mesExtrato;
		private String opcaoEntrega;
		private String numeroInicial;
		private String numeroFinal;
		private String quantidadeTaloes;
		private String emailEnvioFatura;
		private String codigoBandeira;
		private String descBandeiraCartao;
		private String urlImagem;
		private String saldoDevedor;
		private String operadora;
		private String telefoneDDD;
		private String anoCalendario;
		private String email;
		private String dataNascimento;
		private String floatCompHistParts;
		
		
	public String getHistoricoComplementar() {
			return historicoComplementar;
		}

		public void setHistoricoComplementar(String historicoComplementar) {
			this.historicoComplementar = historicoComplementar;
		}

	public String getFavorecidoCpfCnpj() {
			return favorecidoCpfCnpj;
		}

		public void setFavorecidoCpfCnpj(String favorecidoCpfCnpj) {
			this.favorecidoCpfCnpj = favorecidoCpfCnpj;
		}

	public String getNomeServico() {
		return nomeServico;
	}

	public void setNomeServico(String nomeServico) {
		this.nomeServico = nomeServico;
	}

	public String getNomeProduto() {
		return nomeProduto;
	}

	public void setNomeProduto(String nomeProduto) {
		this.nomeProduto = nomeProduto;
	}

	public String getNumeroAutenticacao() {
		return numeroAutenticacao;
	}

	public void setNumeroAutenticacao(String numeroAutenticacao) {
		this.numeroAutenticacao = numeroAutenticacao;
	}

	public String getConta() {
		return conta;
	}

	public void setConta(String conta) {
		this.conta = conta;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getDataTransacao() {
		return dataTransacao;
	}

	public void setDataTransacao(String dataTransacao) {
		this.dataTransacao = dataTransacao;
	}

	public String getHoraTransacao() {
		return horaTransacao;
	}

	public void setHoraTransacao(String horaTransacao) {
		this.horaTransacao = horaTransacao;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	public String getNomeTransacao() {
		return nomeTransacao;
	}

	public void setNomeTransacao(String nomeTransacao) {
		this.nomeTransacao = nomeTransacao;
	}

	public String getIdTransacao() {
		return idTransacao;
	}

	public void setIdTransacao(String idTransacao) {
		this.idTransacao = idTransacao;
	}

	public String getCompHis() {
		return compHis;
	}

	public void setCompHis(String compHis) {
		this.compHis = compHis;
	}

	public String getNomePagina() {
		return nomePagina;
	}

	public void setNomePagina(String nomePagina) {
		this.nomePagina = nomePagina;
	}

	public String getClienteDestino() {
		return clienteDestino;
	}

	public void setClienteDestino(String clienteDestino) {
		this.clienteDestino = clienteDestino;
	}

	public String getBancoDestino() {
		return bancoDestino;
	}

	public void setBancoDestino(String bancoDestino) {
		this.bancoDestino = bancoDestino;
	}

	public String getAgenciaDestino() {
		return agenciaDestino;
	}

	public void setAgenciaDestino(String agenciaDestino) {
		this.agenciaDestino = agenciaDestino;
	}

	public String getContaDestino() {
		return contaDestino;
	}

	public void setContaDestino(String contaDestino) {
		this.contaDestino = contaDestino;
	}

	public String getCodigoBanco() {
		return codigoBanco;
	}

	public void setCodigoBanco(String codigoBanco) {
		this.codigoBanco = codigoBanco;
	}

	public String getCodigoAgencia() {
		return codigoAgencia;
	}

	public void setCodigoAgencia(String codigoAgencia) {
		this.codigoAgencia = codigoAgencia;
	}

	public String getFavorecido() {
		return favorecido;
	}

	public void setFavorecido(String favorecido) {
		this.favorecido = favorecido;
	}

	public String getBancoDestinoIspb() {
		return bancoDestinoIspb;
	}

	public void setBancoDestinoIspb(String bancoDestinoIspb) {
		this.bancoDestinoIspb = bancoDestinoIspb;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getTipoTed() {
		return tipoTed;
	}

	public void setTipoTed(String tipoTed) {
		this.tipoTed = tipoTed;
	}

	public String getFinalidade() {
		return finalidade;
	}

	public void setFinalidade(String finalidade) {
		this.finalidade = finalidade;
	}

	public String getHistorico() {
		return historico;
	}

	public void setHistorico(String historico) {
		this.historico = historico;
	}

	public String getTipoAdesao() {
		return tipoAdesao;
	}

	public void setTipoAdesao(String tipoAdesao) {
		this.tipoAdesao = tipoAdesao;
	}

	public String getValorTarifa() {
		return valorTarifa;
	}

	public void setValorTarifa(String valorTarifa) {
		this.valorTarifa = valorTarifa;
	}

	public String getInformacoesAdicionais() {
		return informacoesAdicionais;
	}

	public void setInformacoesAdicionais(String informacoesAdicionais) {
		this.informacoesAdicionais = informacoesAdicionais;
	}

	public String getContaOrigem() {
		return contaOrigem;
	}

	public void setContaOrigem(String contaOrigem) {
		this.contaOrigem = contaOrigem;
	}

	public String getContaInvestimentoDebito() {
		return contaInvestimentoDebito;
	}

	public void setContaInvestimentoDebito(String contaInvestimentoDebito) {
		this.contaInvestimentoDebito = contaInvestimentoDebito;
	}

	public String getTipoContaDestino() {
		return tipoContaDestino;
	}

	public void setTipoContaDestino(String tipoContaDestino) {
		this.tipoContaDestino = tipoContaDestino;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getOpcoesDebito() {
		return opcoesDebito;
	}

	public void setOpcoesDebito(String opcoesDebito) {
		this.opcoesDebito = opcoesDebito;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getAcao() {
		return acao;
	}

	public void setAcao(String acao) {
		this.acao = acao;
	}

	public String getApelido() {
		return apelido;
	}

	public void setApelido(String apelido) {
		this.apelido = apelido;
	}

	public String getIdentificacao() {
		return identificacao;
	}

	public void setIdentificacao(String identificacao) {
		this.identificacao = identificacao;
	}

	public String getCpfCnpj() {
		return cpfCnpj;
	}

	public void setCpfCnpj(String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}

	public String getTipoOperacao() {
		return tipoOperacao;
	}

	public void setTipoOperacao(String tipoOperacao) {
		this.tipoOperacao = tipoOperacao;
	}

	public String getPerfilRisco() {
		return perfilRisco;
	}

	public void setPerfilRisco(String perfilRisco) {
		this.perfilRisco = perfilRisco;
	}

	public String getNomeFundo() {
		return nomeFundo;
	}

	public void setNomeFundo(String nomeFundo) {
		this.nomeFundo = nomeFundo;
	}

	public String getContaFundo() {
		return contaFundo;
	}

	public void setContaFundo(String contaFundo) {
		this.contaFundo = contaFundo;
	}

	public String getDiaProgramado() {
		return diaProgramado;
	}

	public void setDiaProgramado(String diaProgramado) {
		this.diaProgramado = diaProgramado;
	}

	public String getPeriodicidade() {
		return periodicidade;
	}

	public void setPeriodicidade(String periodicidade) {
		this.periodicidade = periodicidade;
	}

	public String getDataInicial() {
		return dataInicial;
	}

	public void setDataInicial(String dataInicial) {
		this.dataInicial = dataInicial;
	}

	public String getDataFinal() {
		return dataFinal;
	}

	public void setDataFinal(String dataFinal) {
		this.dataFinal = dataFinal;
	}

	public String getDataPrimeiraProgramacao() {
		return dataPrimeiraProgramacao;
	}

	public void setDataPrimeiraProgramacao(String dataPrimeiraProgramacao) {
		this.dataPrimeiraProgramacao = dataPrimeiraProgramacao;
	}

	public String getAgenciaConta() {
		return agenciaConta;
	}

	public void setAgenciaConta(String agenciaConta) {
		this.agenciaConta = agenciaConta;
	}

	public String getCpfDespachanteRepresentante() {
		return cpfDespachanteRepresentante;
	}

	public void setCpfDespachanteRepresentante(String cpfDespachanteRepresentante) {
		this.cpfDespachanteRepresentante = cpfDespachanteRepresentante;
	}

	public String getCpfCnpjAutorizacao() {
		return cpfCnpjAutorizacao;
	}

	public void setCpfCnpjAutorizacao(String cpfCnpjAutorizacao) {
		this.cpfCnpjAutorizacao = cpfCnpjAutorizacao;
	}

	public String getLabelDataAutorizacaoOutroPagador() {
		return labelDataAutorizacaoOutroPagador;
	}

	public void setLabelDataAutorizacaoOutroPagador(String labelDataAutorizacaoOutroPagador) {
		this.labelDataAutorizacaoOutroPagador = labelDataAutorizacaoOutroPagador;
	}

	public String getDataAutorizacaoOutroPagador() {
		return dataAutorizacaoOutroPagador;
	}

	public void setDataAutorizacaoOutroPagador(String dataAutorizacaoOutroPagador) {
		this.dataAutorizacaoOutroPagador = dataAutorizacaoOutroPagador;
	}

	public String getCpfCnpjPagador() {
		return cpfCnpjPagador;
	}

	public void setCpfCnpjPagador(String cpfCnpjPagador) {
		this.cpfCnpjPagador = cpfCnpjPagador;
	}

	public String getOrdemTitulo() {
		return ordemTitulo;
	}

	public void setOrdemTitulo(String ordemTitulo) {
		this.ordemTitulo = ordemTitulo;
	}

	public String getProduto() {
		return produto;
	}

	public void setProduto(String produto) {
		this.produto = produto;
	}

	public String getNumeroCertificado() {
		return numeroCertificado;
	}

	public void setNumeroCertificado(String numeroCertificado) {
		this.numeroCertificado = numeroCertificado;
	}

	public String getNumeroProcessoSusep() {
		return numeroProcessoSusep;
	}

	public void setNumeroProcessoSusep(String numeroProcessoSusep) {
		this.numeroProcessoSusep = numeroProcessoSusep;
	}

	public String getRegistroSusep() {
		return registroSusep;
	}

	public void setRegistroSusep(String registroSusep) {
		this.registroSusep = registroSusep;
	}

	public String getNumeroCartao() {
		return numeroCartao;
	}

	public void setNumeroCartao(String numeroCartao) {
		this.numeroCartao = numeroCartao;
	}

	public String getSegurado() {
		return segurado;
	}

	public void setSegurado(String segurado) {
		this.segurado = segurado;
	}

	public String getCnpjSegurado() {
		return cnpjSegurado;
	}

	public void setCnpjSegurado(String cnpjSegurado) {
		this.cnpjSegurado = cnpjSegurado;
	}

	public String getNomeBeneficiario() {
		return nomeBeneficiario;
	}

	public void setNomeBeneficiario(String nomeBeneficiario) {
		this.nomeBeneficiario = nomeBeneficiario;
	}

	public String getAgenciaContaCentralizadora() {
		return agenciaContaCentralizadora;
	}

	public void setAgenciaContaCentralizadora(String agenciaContaCentralizadora) {
		this.agenciaContaCentralizadora = agenciaContaCentralizadora;
	}

	public String getCodigoBeneficiario() {
		return codigoBeneficiario;
	}

	public void setCodigoBeneficiario(String codigoBeneficiario) {
		this.codigoBeneficiario = codigoBeneficiario;
	}

	public String getNomePagador() {
		return nomePagador;
	}

	public void setNomePagador(String nomePagador) {
		this.nomePagador = nomePagador;
	}

	public String getValorTitulo() {
		return valorTitulo;
	}

	public void setValorTitulo(String valorTitulo) {
		this.valorTitulo = valorTitulo;
	}

	public String getDataVencimento() {
		return dataVencimento;
	}

	public void setDataVencimento(String dataVencimento) {
		this.dataVencimento = dataVencimento;
	}

	public String getNossoNumero() {
		return nossoNumero;
	}

	public void setNossoNumero(String nossoNumero) {
		this.nossoNumero = nossoNumero;
	}

	public String getCodigoOperacao() {
		return codigoOperacao;
	}

	public void setCodigoOperacao(String codigoOperacao) {
		this.codigoOperacao = codigoOperacao;
	}

	public String getInformacoesAdicionaisValor() {
		return informacoesAdicionaisValor;
	}

	public void setInformacoesAdicionaisValor(String informacoesAdicionaisValor) {
		this.informacoesAdicionaisValor = informacoesAdicionaisValor;
	}

	public String getInformacoesAdicionaisData() {
		return informacoesAdicionaisData;
	}

	public void setInformacoesAdicionaisData(String informacoesAdicionaisData) {
		this.informacoesAdicionaisData = informacoesAdicionaisData;
	}

	public String getNumeroOperacao() {
		return numeroOperacao;
	}

	public void setNumeroOperacao(String numeroOperacao) {
		this.numeroOperacao = numeroOperacao;
	}

	public String getExclusaoParticipanteAte() {
		return exclusaoParticipanteAte;
	}

	public void setExclusaoParticipanteAte(String exclusaoParticipanteAte) {
		this.exclusaoParticipanteAte = exclusaoParticipanteAte;
	}

	public String getFormaPagamento() {
		return formaPagamento;
	}

	public void setFormaPagamento(String formaPagamento) {
		this.formaPagamento = formaPagamento;
	}

	public String getValorAntecipado() {
		return valorAntecipado;
	}

	public void setValorAntecipado(String valorAntecipado) {
		this.valorAntecipado = valorAntecipado;
	}

	public String getRazaoSocial() {
		return razaoSocial;
	}

	public void setRazaoSocial(String razaoSocial) {
		this.razaoSocial = razaoSocial;
	}

	public String getContaDebitoCredito() {
		return contaDebitoCredito;
	}

	public void setContaDebitoCredito(String contaDebitoCredito) {
		this.contaDebitoCredito = contaDebitoCredito;
	}

	public String getContaCorrente() {
		return contaCorrente;
	}

	public void setContaCorrente(String contaCorrente) {
		this.contaCorrente = contaCorrente;
	}

	public String getNumeroCheque() {
		return numeroCheque;
	}

	public void setNumeroCheque(String numeroCheque) {
		this.numeroCheque = numeroCheque;
	}

	public String getDataCompensacao() {
		return dataCompensacao;
	}

	public void setDataCompensacao(String dataCompensacao) {
		this.dataCompensacao = dataCompensacao;
	}

	public String getValorCheque() {
		return valorCheque;
	}

	public void setValorCheque(String valorCheque) {
		this.valorCheque = valorCheque;
	}

	public String getValorAmortizado() {
		return valorAmortizado;
	}

	public void setValorAmortizado(String valorAmortizado) {
		this.valorAmortizado = valorAmortizado;
	}

	public String getDataSolicitacao() {
		return dataSolicitacao;
	}

	public void setDataSolicitacao(String dataSolicitacao) {
		this.dataSolicitacao = dataSolicitacao;
	}

	public String getBancoVinculado() {
		return bancoVinculado;
	}

	public void setBancoVinculado(String bancoVinculado) {
		this.bancoVinculado = bancoVinculado;
	}

	public String getAgenciaVinculada() {
		return agenciaVinculada;
	}

	public void setAgenciaVinculada(String agenciaVinculada) {
		this.agenciaVinculada = agenciaVinculada;
	}

	public String getContratoVinculado() {
		return contratoVinculado;
	}

	public void setContratoVinculado(String contratoVinculado) {
		this.contratoVinculado = contratoVinculado;
	}

	public String getValorLiberado() {
		return valorLiberado;
	}

	public void setValorLiberado(String valorLiberado) {
		this.valorLiberado = valorLiberado;
	}

	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}

	public String getIdentificador() {
		return identificador;
	}

	public void setIdentificador(String identificador) {
		this.identificador = identificador;
	}

	public String getEmpresaConveniada() {
		return empresaConveniada;
	}

	public void setEmpresaConveniada(String empresaConveniada) {
		this.empresaConveniada = empresaConveniada;
	}

	public String getLimiteDebito() {
		return limiteDebito;
	}

	public void setLimiteDebito(String limiteDebito) {
		this.limiteDebito = limiteDebito;
	}

	public String getValorLimite() {
		return valorLimite;
	}

	public void setValorLimite(String valorLimite) {
		this.valorLimite = valorLimite;
	}

	public String getDataCadastramento() {
		return dataCadastramento;
	}

	public void setDataCadastramento(String dataCadastramento) {
		this.dataCadastramento = dataCadastramento;
	}

	public String getDataUltimoLancamento() {
		return dataUltimoLancamento;
	}

	public void setDataUltimoLancamento(String dataUltimoLancamento) {
		this.dataUltimoLancamento = dataUltimoLancamento;
	}

	public String getMotivoExclusao() {
		return motivoExclusao;
	}

	public void setMotivoExclusao(String motivoExclusao) {
		this.motivoExclusao = motivoExclusao;
	}

	public String getEmissaoAviso() {
		return emissaoAviso;
	}

	public void setEmissaoAviso(String emissaoAviso) {
		this.emissaoAviso = emissaoAviso;
	}

	public String getInicioSuspensao() {
		return inicioSuspensao;
	}

	public void setInicioSuspensao(String inicioSuspensao) {
		this.inicioSuspensao = inicioSuspensao;
	}

	public String getTerminoSuspensao() {
		return terminoSuspensao;
	}

	public void setTerminoSuspensao(String terminoSuspensao) {
		this.terminoSuspensao = terminoSuspensao;
	}

	public String getPrazo() {
		return prazo;
	}

	public void setPrazo(String prazo) {
		this.prazo = prazo;
	}

	public String getValorAplicado() {
		return valorAplicado;
	}

	public void setValorAplicado(String valorAplicado) {
		this.valorAplicado = valorAplicado;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getTaxaCdi() {
		return taxaCdi;
	}

	public void setTaxaCdi(String taxaCdi) {
		this.taxaCdi = taxaCdi;
	}

	public String getNumeroFundos() {
		return numeroFundos;
	}

	public void setNumeroFundos(String numeroFundos) {
		this.numeroFundos = numeroFundos;
	}

	public String getSituacaoContrato() {
		return situacaoContrato;
	}

	public void setSituacaoContrato(String situacaoContrato) {
		this.situacaoContrato = situacaoContrato;
	}

	public String getPeriodo() {
		return periodo;
	}

	public void setPeriodo(String periodo) {
		this.periodo = periodo;
	}

	public String getAtualizadaPara() {
		return atualizadaPara;
	}

	public void setAtualizadaPara(String atualizadaPara) {
		this.atualizadaPara = atualizadaPara;
	}

	public String getNumeroRemessa() {
		return numeroRemessa;
	}

	public void setNumeroRemessa(String numeroRemessa) {
		this.numeroRemessa = numeroRemessa;
	}

	public String getMesReferencia() {
		return mesReferencia;
	}

	public void setMesReferencia(String mesReferencia) {
		this.mesReferencia = mesReferencia;
	}

	public String getConvenio() {
		return convenio;
	}

	public void setConvenio(String convenio) {
		this.convenio = convenio;
	}

	public String getQuantidadeRegistros() {
		return quantidadeRegistros;
	}

	public void setQuantidadeRegistros(String quantidadeRegistros) {
		this.quantidadeRegistros = quantidadeRegistros;
	}

	public String getDataCredito() {
		return dataCredito;
	}

	public void setDataCredito(String dataCredito) {
		this.dataCredito = dataCredito;
	}

	public String getCodigoBarras() {
		return codigoBarras;
	}

	public void setCodigoBarras(String codigoBarras) {
		this.codigoBarras = codigoBarras;
	}

	public String getBeneficiario() {
		return beneficiario;
	}

	public void setBeneficiario(String beneficiario) {
		this.beneficiario = beneficiario;
	}

	public String getPagador() {
		return pagador;
	}

	public void setPagador(String pagador) {
		this.pagador = pagador;
	}

	public String getClientePagador() {
		return clientePagador;
	}

	public void setClientePagador(String clientePagador) {
		this.clientePagador = clientePagador;
	}

	public String getDadosDisponiveisSegundaVia() {
		return dadosDisponiveisSegundaVia;
	}

	public void setDadosDisponiveisSegundaVia(String dadosDisponiveisSegundaVia) {
		this.dadosDisponiveisSegundaVia = dadosDisponiveisSegundaVia;
	}

	public String getChave() {
		return chave;
	}

	public void setChave(String chave) {
		this.chave = chave;
	}

	public String getPlacaVeiculo() {
		return placaVeiculo;
	}

	public void setPlacaVeiculo(String placaVeiculo) {
		this.placaVeiculo = placaVeiculo;
	}

	public String getRenavam() {
		return renavam;
	}

	public void setRenavam(String renavam) {
		this.renavam = renavam;
	}

	public String getNumeroContribuinte() {
		return numeroContribuinte;
	}

	public void setNumeroContribuinte(String numeroContribuinte) {
		this.numeroContribuinte = numeroContribuinte;
	}

	public String getNsuProdam() {
		return nsuProdam;
	}

	public void setNsuProdam(String nsuProdam) {
		this.nsuProdam = nsuProdam;
	}

	public String getParcela() {
		return parcela;
	}

	public void setParcela(String parcela) {
		this.parcela = parcela;
	}

	public String getNumeroPoupanca() {
		return numeroPoupanca;
	}

	public void setNumeroPoupanca(String numeroPoupanca) {
		this.numeroPoupanca = numeroPoupanca;
	}	

	public String getValorPoupanca() {
		return valorPoupanca;
	}

	public void setValorPoupanca(String valorPoupanca) {
		this.valorPoupanca = valorPoupanca;
	}

	public String getLivre() {
		return livre;
	}

	public void setLivre(String livre) {
		this.livre = livre;
	}

	public String getIntegrada() {
		return integrada;
	}

	public void setIntegrada(String integrada) {
		this.integrada = integrada;
	}

	public String getTipoDoc() {
		return tipoDoc;
	}

	public void setTipoDoc(String tipoDoc) {
		this.tipoDoc = tipoDoc;
	}

	public String getAgenciaContaCadastro() {
		return agenciaContaCadastro;
	}

	public void setAgenciaContaCadastro(String agenciaContaCadastro) {
		this.agenciaContaCadastro = agenciaContaCadastro;
	}

	public String getMunicipio() {
		return municipio;
	}

	public void setMunicipio(String municipio) {
		this.municipio = municipio;
	}

	public String getDocumento() {
		return documento;
	}

	public void setDocumento(String documento) {
		this.documento = documento;
	}

	public String getProprietario() {
		return proprietario;
	}

	public void setProprietario(String proprietario) {
		this.proprietario = proprietario;
	}

	public String getQuantidadeMultasPagas() {
		return quantidadeMultasPagas;
	}

	public void setQuantidadeMultasPagas(String quantidadeMultasPagas) {
		this.quantidadeMultasPagas = quantidadeMultasPagas;
	}

	public String getValorTotalPago() {
		return valorTotalPago;
	}

	public void setValorTotalPago(String valorTotalPago) {
		this.valorTotalPago = valorTotalPago;
	}

	public String getCartaoCredito() {
		return cartaoCredito;
	}

	public void setCartaoCredito(String cartaoCredito) {
		this.cartaoCredito = cartaoCredito;
	}

	public String getClienteConsumidor() {
		return clienteConsumidor;
	}

	public void setClienteConsumidor(String clienteConsumidor) {
		this.clienteConsumidor = clienteConsumidor;
	}

	public String getVencimento() {
		return vencimento;
	}

	public void setVencimento(String vencimento) {
		this.vencimento = vencimento;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getPremioLiquido() {
		return premioLiquido;
	}

	public void setPremioLiquido(String premioLiquido) {
		this.premioLiquido = premioLiquido;
	}

	public String getIof() {
		return iof;
	}

	public void setIof(String iof) {
		this.iof = iof;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getRamal() {
		return ramal;
	}

	public void setRamal(String ramal) {
		this.ramal = ramal;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getPercentual() {
		return percentual;
	}

	public void setPercentual(String percentual) {
		this.percentual = percentual;
	}

	public String getReferencia() {
		return referencia;
	}

	public void setReferencia(String referencia) {
		this.referencia = referencia;
	}

	public String getPrefeitura() {
		return prefeitura;
	}

	public void setPrefeitura(String prefeitura) {
		this.prefeitura = prefeitura;
	}

	public String getCodigoArea() {
		return codigoArea;
	}

	public void setCodigoArea(String codigoArea) {
		this.codigoArea = codigoArea;
	}

	public String getTipoContaOrigem() {
		return tipoContaOrigem;
	}

	public void setTipoContaOrigem(String tipoContaOrigem) {
		this.tipoContaOrigem = tipoContaOrigem;
	}

	public String getTipoApelido() {
		return tipoApelido;
	}

	public void setTipoApelido(String tipoApelido) {
		this.tipoApelido = tipoApelido;
	}

	public String getTipoCartao() {
		return tipoCartao;
	}

	public void setTipoCartao(String tipoCartao) {
		this.tipoCartao = tipoCartao;
	}	

	public String getContrato() {
		return contrato;
	}

	public void setContrato(String contrato) {
		this.contrato = contrato;
	}	
	
	public String getValorTransfBanespa() {
		return valorTransfBanespa;
	}

	public void setValorTransfBanespa(String valorTransfBanespa) {
		this.valorTransfBanespa = valorTransfBanespa;
	}

	public String getNumeroDaRemessa() {
		return numeroDaRemessa;
	}

	public void setNumeroDaRemessa(String numeroDaRemessa) {
		this.numeroDaRemessa = numeroDaRemessa;
	}

	public String getDiaVencimento() {
		return diaVencimento;
	}

	public void setDiaVencimento(String diaVencimento) {
		this.diaVencimento = diaVencimento;
	}
	public String getCpfOuCnpj() {
		return cpfOuCnpj;
	}

	public void setCpfOuCnpj(String cpfOuCnpj) {
		this.cpfOuCnpj = cpfOuCnpj;
	}

	public String getAgContaCadastro() {
		return agContaCadastro;
	}

	public void setAgContaCadastro(String agContaCadastro) {
		this.agContaCadastro = agContaCadastro;
	}

	public String getDataDaSolicitacao() {
		return dataDaSolicitacao;
	}

	public void setDataDaSolicitacao(String dataDaSolicitacao) {
		this.dataDaSolicitacao = dataDaSolicitacao;
	}

	public String getCodigoBarra() {
		return codigoBarra;
	}

	public void setCodigoBarra(String codigoBarra) {
		this.codigoBarra = codigoBarra;
	}

	public String getIOF() {
		return IOF;
	}

	public void setIOF(String iOF) {
		IOF = iOF;
	}

	public String getNomeRazaoSocial() {
		return nomeRazaoSocial;
	}

	public void setNomeRazaoSocial(String nomeRazaoSocial) {
		this.nomeRazaoSocial = nomeRazaoSocial;
	}

	public String getContaCredito() {
		return contaCredito;
	}

	public void setContaCredito(String contaCredito) {
		this.contaCredito = contaCredito;
	}

	public String getLivreVerificarNecessidade() {
		return livreVerificarNecessidade;
	}

	public void setLivreVerificarNecessidade(String livreVerificarNecessidade) {
		this.livreVerificarNecessidade = livreVerificarNecessidade;
	}

	public String getIntegradaVerificarNecessidade() {
		return integradaVerificarNecessidade;
	}

	public void setIntegradaVerificarNecessidade(String integradaVerificarNecessidade) {
		this.integradaVerificarNecessidade = integradaVerificarNecessidade;
	}

	public String getSaldoDisponivel() {
		return saldoDisponivel;
	}

	public void setSaldoDisponivel(String saldoDisponivel) {
		this.saldoDisponivel = saldoDisponivel;
	}

	public String getLimiteMaximoDiario() {
		return limiteMaximoDiario;
	}

	public void setLimiteMaximoDiario(String limiteMaximoDiario) {
		this.limiteMaximoDiario = limiteMaximoDiario;
	}

	public String getDia() {
		return dia;
	}

	public void setDia(String dia) {
		this.dia = dia;
	}

	public String getDias() {
		return dias;
	}

	public void setDias(String dias) {
		this.dias = dias;
	}

	public String getBancoDestinoFormated() {
		return bancoDestinoFormated;
	}

	public void setBancoDestinoFormated(String bancoDestinoFormated) {
		this.bancoDestinoFormated = bancoDestinoFormated;
	}

	public String getCpfSolicitante() {
		return cpfSolicitante;
	}

	public void setCpfSolicitante(String cpfSolicitante) {
		this.cpfSolicitante = cpfSolicitante;
	}

	public String getMetodoHabilitacao() {
		return metodoHabilitacao;
	}

	public void setMetodoHabilitacao(String metodoHabilitacao) {
		this.metodoHabilitacao = metodoHabilitacao;
	}

	public String getNomeAparelho() {
		return nomeAparelho;
	}

	public void setNomeAparelho(String nomeAparelho) {
		this.nomeAparelho = nomeAparelho;
	}

	public String getNumeroCompromisso() {
		return numeroCompromisso;
	}

	public void setNumeroCompromisso(String numeroCompromisso) {
		this.numeroCompromisso = numeroCompromisso;
	}

	public String getContaDebito() {
		return contaDebito;
	}

	public void setContaDebito(String contaDebito) {
		this.contaDebito = contaDebito;
	}

	public String getDataPagto() {
		return dataPagto;
	}

	public void setDataPagto(String dataPagto) {
		this.dataPagto = dataPagto;
	}

	public String getValorJuros() {
		return valorJuros;
	}

	public void setValorJuros(String valorJuros) {
		this.valorJuros = valorJuros;
	}

	public String getAbatDesc() {
		return abatDesc;
	}

	public void setAbatDesc(String abatDesc) {
		this.abatDesc = abatDesc;
	}		

	public String getRazaoSocialBeneficiarioOriginal() {
		return razaoSocialBeneficiarioOriginal;
	}

	public String getRazaoSocialPagadorEfetivo() {
		return razaoSocialPagadorEfetivo;
	}

	public String getNomeRazaoSocialPagadorEfetivo() {
		return nomeRazaoSocialPagadorEfetivo;
	}

	public String getValorTotalCobrar() {
		return valorTotalCobrar;
	}

	public String getDataVencimento2() {
		return dataVencimento2;
	}

	public void setRazaoSocialBeneficiarioOriginal(String razaoSocialBeneficiarioOriginal) {
		this.razaoSocialBeneficiarioOriginal = razaoSocialBeneficiarioOriginal;
	}

	public void setRazaoSocialPagadorEfetivo(String razaoSocialPagadorEfetivo) {
		this.razaoSocialPagadorEfetivo = razaoSocialPagadorEfetivo;
	}

	public void setNomeRazaoSocialPagadorEfetivo(String nomeRazaoSocialPagadorEfetivo) {
		this.nomeRazaoSocialPagadorEfetivo = nomeRazaoSocialPagadorEfetivo;
	}

	public void setValorTotalCobrar(String valorTotalCobrar) {
		this.valorTotalCobrar = valorTotalCobrar;
	}

	public void setDataVencimento2(String dataVencimento2) {
		this.dataVencimento2 = dataVencimento2;
	}
	
	public String getQuantidadeParcelas() {
		return quantidadeParcelas;
	}

	public void setQuantidadeParcelas(String quantidadeParcelas) {
		this.quantidadeParcelas = quantidadeParcelas;
	}

	public String getTipoTaxa() {
		return tipoTaxa;
	}

	public void setTipoTaxa(String tipoTaxa) {
		this.tipoTaxa = tipoTaxa;
	}

	public String getTaxaJurosMes() {
		return taxaJurosMes;
	}

	public void setTaxaJurosMes(String taxaJurosMes) {
		this.taxaJurosMes = taxaJurosMes;
	}

	public String getTaxaJurosAno() {
		return taxaJurosAno;
	}

	public void setTaxaJurosAno(String taxaJurosAno) {
		this.taxaJurosAno = taxaJurosAno;
	}

	public String getTarifaAberturaCredito() {
		return tarifaAberturaCredito;
	}

	public void setTarifaAberturaCredito(String tarifaAberturaCredito) {
		this.tarifaAberturaCredito = tarifaAberturaCredito;
	}

	public String getCetMes() {
		return cetMes;
	}

	public void setCetMes(String cetMes) {
		this.cetMes = cetMes;
	}

	public String getCetAno() {
		return cetAno;
	}

	public void setCetAno(String cetAno) {
		this.cetAno = cetAno;
	}

	public String getValorTotalFinanciado() {
		return valorTotalFinanciado;
	}

	public void setValorTotalFinanciado(String valorTotalFinanciado) {
		this.valorTotalFinanciado = valorTotalFinanciado;
	}	

	public String getPlano() {
		return plano;
	}

	public void setPlano(String plano) {
		this.plano = plano;
	}

	public String getDtIniVig() {
		return dtIniVig;
	}

	public void setDtIniVig(String dtIniVig) {
		this.dtIniVig = dtIniVig;
	}

	public String getSaldoReserva() {
		return saldoReserva;
	}

	public void setSaldoReserva(String saldoReserva) {
		this.saldoReserva = saldoReserva;
	}

	public String getValorAporte() {
		return valorAporte;
	}

	public void setValorAporte(String valorAporte) {
		this.valorAporte = valorAporte;
	}

	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	public String getContaColetiva() {
		return contaColetiva;
	}

	public void setContaColetiva(String contaColetiva) {
		this.contaColetiva = contaColetiva;
	}

	public String getTipoRelatorio() {
		return tipoRelatorio;
	}

	public void setTipoRelatorio(String tipoRelatorio) {
		this.tipoRelatorio = tipoRelatorio;
	}

	public String getNomeAparelhoAutorizado() {
		return nomeAparelhoAutorizado;
	}

	public void setNomeAparelhoAutorizado(String nomeAparelhoAutorizado) {
		this.nomeAparelhoAutorizado = nomeAparelhoAutorizado;
	}

	public String getUsuarioSolicitante() {
		return usuarioSolicitante;
	}

	public void setUsuarioSolicitante(String usuarioSolicitante) {
		this.usuarioSolicitante = usuarioSolicitante;
	}

	public String getNomeCompletoAutorizado() {
		return nomeCompletoAutorizado;
	}

	public void setNomeCompletoAutorizado(String nomeCompletoAutorizado) {
		this.nomeCompletoAutorizado = nomeCompletoAutorizado;
	}

	public String getCpfAutorizado() {
		return cpfAutorizado;
	}

	public void setCpfAutorizado(String cpfAutorizado) {
		this.cpfAutorizado = cpfAutorizado;
	}

	public String getNumeroCelular() {
		return numeroCelular;
	}

	public void setNumeroCelular(String numeroCelular) {
		this.numeroCelular = numeroCelular;
	}	

	public String getPremioSeguro() {
		return premioSeguro;
	}

	public void setPremioSeguro(String premioSeguro) {
		this.premioSeguro = premioSeguro;
	}

	public String getRepasseEncargosOperacoesCredito() {
		return repasseEncargosOperacoesCredito;
	}

	public void setRepasseEncargosOperacoesCredito(String repasseEncargosOperacoesCredito) {
		this.repasseEncargosOperacoesCredito = repasseEncargosOperacoesCredito;
	}	

	public String getValorSaqueParcelado() {
		return valorSaqueParcelado;
	}

	public void setValorSaqueParcelado(String valorSaqueParcelado) {
		this.valorSaqueParcelado = valorSaqueParcelado;
	}

	public String getNumeroParcelas() {
		return numeroParcelas;
	}

	public void setNumeroParcelas(String numeroParcelas) {
		this.numeroParcelas = numeroParcelas;
	}

	public String getLimiteCompromisso() {
		return limiteCompromisso;
	}

	public void setLimiteCompromisso(String limiteCompromisso) {
		this.limiteCompromisso = limiteCompromisso;
	}

	public String getTravaValorFolha() {
		return travaValorFolha;
	}

	public void setTravaValorFolha(String travaValorFolha) {
		this.travaValorFolha = travaValorFolha;
	}

	public String getBancoAgenciaContaDestino() {
		return bancoAgenciaContaDestino;
	}

	public void setBancoAgenciaContaDestino(String bancoAgenciaContaDestino) {
		this.bancoAgenciaContaDestino = bancoAgenciaContaDestino;
	}

	public String getNomeDestinatario() {
		return nomeDestinatario;
	}

	public void setNomeDestinatario(String nomeDestinatario) {
		this.nomeDestinatario = nomeDestinatario;
	}

	public String getValorTransacao() {
		return valorTransacao;
	}

	public void setValorTransacao(String valorTransacao) {
		this.valorTransacao = valorTransacao;
	}
	
	public String getOperacaoAnterior() {
		return operacaoAnterior;
	}

	public void setOperacaoAnterior(String operacao) {
		this.operacaoAnterior = operacao;
	}	

	public String getNovaOperacao() {
		return novaOperacao;
	}

	public void setNovaOperacao(String novaOperacao) {
		this.novaOperacao = novaOperacao;
	}

	public String getNomeCompleto() {
		return nomeCompleto;
	}

	public void setNomeCompleto(String nomeCompleto) {
		this.nomeCompleto = nomeCompleto;
	}

	public String getNomeDispositivo() {
		return nomeDispositivo;
	}

	public void setNomeDispositivo(String nomeDispositivo) {
		this.nomeDispositivo = nomeDispositivo;
	}

	public String getTipoTransacao() {
		return tipoTransacao;
	}

	public void setTipoTransacao(String tipoTransacao) {
		this.tipoTransacao = tipoTransacao;
	}

	public String getArquivo() {
		return arquivo;
	}

	public void setArquivo(String arquivo) {
		this.arquivo = arquivo;
	}

	public String getSituacao() {
		return situacao;
	}

	public void setSituacao(String situacao) {
		this.situacao = situacao;
	}

	public String getSequencia() {
		return sequencia;
	}

	public void setSequencia(String sequencia) {
		this.sequencia = sequencia;
	}

	public String getRegistros() {
		return registros;
	}

	public void setRegistros(String registros) {
		this.registros = registros;
	}

	public String getTamanhoBytes() {
		return tamanhoBytes;
	}

	public void setTamanhoBytes(String tamanhoBytes) {
		this.tamanhoBytes = tamanhoBytes;
	}

	public String getDataHoraTransferencia() {
		return dataHoraTransferencia;
	}

	public void setDataHoraTransferencia(String dataHoraTransferencia) {
		this.dataHoraTransferencia = dataHoraTransferencia;
	}

	public String getNumeroControle() {
		return numeroControle;
	}

	public void setNumeroControle(String numeroControle) {
		this.numeroControle = numeroControle;
	}
	
	public String getValorEmprestimoEncargos() {
		return valorEmprestimoEncargos;
	}

	public void setValorEmprestimoEncargos(String valorEmprestimoEncargos) {
		this.valorEmprestimoEncargos = valorEmprestimoEncargos;
	}

	public String getValorParcela() {
		return valorParcela;
	}

	public void setValorParcela(String valorParcela) {
		this.valorParcela = valorParcela;
	}

	public String getPrimeiroVencimento() {
		return primeiroVencimento;
	}

	public void setPrimeiroVencimento(String primeiroVencimento) {
		this.primeiroVencimento = primeiroVencimento;
	}

	public String getUltimoVencimento() {
		return ultimoVencimento;
	}

	public void setUltimoVencimento(String ultimoVencimento) {
		this.ultimoVencimento = ultimoVencimento;
	}

	public String getEncargosInadimplencia() {
		return encargosInadimplencia;
	}

	public void setEncargosInadimplencia(String encargosInadimplencia) {
		this.encargosInadimplencia = encargosInadimplencia;
	}

	public String getMultaHora() {
		return multaHora;
	}

	public void setMultaHora(String multaHora) {
		this.multaHora = multaHora;
	}

	public String getPremioBruto() {
		return premioBruto;
	}

	public void setPremioBruto(String premioBruto) {
		this.premioBruto = premioBruto;
	}

	public String getHoraEnvio() {
		return horaEnvio;
	}

	public void setHoraEnvio(String horaEnvio) {
		this.horaEnvio = horaEnvio;
	}

	public String getAgenciaCredito() {
		return agenciaCredito;
	}

	public void setAgenciaCredito(String agenciaCredito) {
		this.agenciaCredito = agenciaCredito;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getValorCompromisso() {
		return valorCompromisso;
	}

	public void setValorCompromisso(String valorCompromisso) {
		this.valorCompromisso = valorCompromisso;
	}

	public String getNumeroAgrupamento() {
		return numeroAgrupamento;
	}

	public void setNumeroAgrupamento(String numeroAgrupamento) {
		this.numeroAgrupamento = numeroAgrupamento;
	}

	public String getInicio() {
		return inicio;
	}

	public void setInicio(String inicio) {
		this.inicio = inicio;
	}

	public String getNumeroMes() {
		return numeroMes;
	}

	public void setNumeroMes(String numeroMes) {
		this.numeroMes = numeroMes;
	}

	public String getFim() {
		return fim;
	}

	public void setFim(String fim) {
		this.fim = fim;
	}

	public String getDiaDebito() {
		return diaDebito;
	}

	public void setDiaDebito(String diaDebito) {
		this.diaDebito = diaDebito;
	}

	public String getValorEmprestimo() {
		return valorEmprestimo;
	}

	public void setValorEmprestimo(String valorEmprestimo) {
		this.valorEmprestimo = valorEmprestimo;
	}

	public String getValorResgatado() {
		return valorResgatado;
	}

	public void setValorResgatado(String valorResgatado) {
		this.valorResgatado = valorResgatado;
	}

	public String getTaxa() {
		return taxa;
	}

	public void setTaxa(String taxa) {
		this.taxa = taxa;
	}

	public String getVinculo() {
		return vinculo;
	}

	public void setVinculo(String vinculo) {
		this.vinculo = vinculo;
	}

	public String getDataPrimeiraParcela() {
		return dataPrimeiraParcela;
	}

	public void setDataPrimeiraParcela(String dataPrimeiraParcela) {
		this.dataPrimeiraParcela = dataPrimeiraParcela;
	}

	public String getTaxaJuros() {
		return taxaJuros;
	}

	public void setTaxaJuros(String taxaJuros) {
		this.taxaJuros = taxaJuros;
	}

	public String getContratoRenegociado() {
		return contratoRenegociado;
	}

	public void setContratoRenegociado(String contratoRenegociado) {
		this.contratoRenegociado = contratoRenegociado;
	}

	public String getTotalDivida() {
		return totalDivida;
	}

	public void setTotalDivida(String totalDivida) {
		this.totalDivida = totalDivida;
	}

	public String getValorDesconto() {
		return valorDesconto;
	}

	public void setValorDesconto(String valorDesconto) {
		this.valorDesconto = valorDesconto;
	}

	public boolean isLabelFrasesSeguro() {
		return labelFrasesSeguro;
	}

	public void setLabelFrasesSeguro(boolean labelFrasesSeguro) {
		this.labelFrasesSeguro = labelFrasesSeguro;
	}

	public boolean isLabelPropostaCancelada() {
		return labelPropostaCancelada;
	}

	public void setLabelPropostaCancelada(boolean labelPropostaCancelada) {
		this.labelPropostaCancelada = labelPropostaCancelada;
	}

	public String getDataOperacao() {
		return dataOperacao;
	}

	public void setDataOperacao(String dataOperacao) {
		this.dataOperacao = dataOperacao;
	}

	public String getTipoAlegacao() {
		return tipoAlegacao;
	}

	public void setTipoAlegacao(String tipoAlegacao) {
		this.tipoAlegacao = tipoAlegacao;
	}

	public String getDataAlegacao() {
		return dataAlegacao;
	}

	public void setDataAlegacao(String dataAlegacao) {
		this.dataAlegacao = dataAlegacao;
	}

	public String getTituloEletronicoDDA() {
		return tituloEletronicoDDA;
	}

	public void setTituloEletronicoDDA(String tituloEletronicoDDA) {
		this.tituloEletronicoDDA = tituloEletronicoDDA;
	}

	public String getReconhecimentoApresentacao() {
		return reconhecimentoApresentacao;
	}

	public void setReconhecimentoApresentacao(String reconhecimentoApresentacao) {
		this.reconhecimentoApresentacao = reconhecimentoApresentacao;
	}	

	public String getPercentualLance() {
		return percentualLance;
	}

	public void setPercentualLance(String percentualLance) {
		this.percentualLance = percentualLance;
	}	

	public String getValorLance() {
		return valorLance;
	}

	public void setValorLance(String valorLance) {
		this.valorLance = valorLance;
	}	

	public String getDiaVencimentoParcela() {
		return diaVencimentoParcela;
	}

	public void setDiaVencimentoParcela(String diaVencimentoParcela) {
		this.diaVencimentoParcela = diaVencimentoParcela;
	}	

	public String getPercentualCET() {
		return percentualCET;
	}

	public void setPercentualCET(String percentualCET) {
		this.percentualCET = percentualCET;
	}	

	public String getQtdContratoRenegociados() {
		return qtdContratoRenegociados;
	}

	public void setQtdContratoRenegociados(String qtdContratoRenegociados) {
		this.qtdContratoRenegociados = qtdContratoRenegociados;
	}	

	public String getCodigoConvenio() {
		return codigoConvenio;
	}

	public void setCodigoConvenio(String codigoConvenio) {
		this.codigoConvenio = codigoConvenio;
	}	

	public String getContaDebitoTarifa() {
		return contaDebitoTarifa;
	}

	public void setContaDebitoTarifa(String contaDebitoTarifa) {
		this.contaDebitoTarifa = contaDebitoTarifa;
	}	

	public String getGeradorArquivos() {
		return geradorArquivos;
	}

	public void setGeradorArquivos(String geradorArquivos) {
		this.geradorArquivos = geradorArquivos;
	}	

	public String getTarifaEnvioHolerite() {
		return tarifaEnvioHolerite;
	}

	public void setTarifaEnvioHolerite(String tarifaEnvioHolerite) {
		this.tarifaEnvioHolerite = tarifaEnvioHolerite;
	}	

	public String getConsolidarDebitoExtrato() {
		return consolidarDebitoExtrato;
	}

	public void setConsolidarDebitoExtrato(String consolidarDebitoExtrato) {
		this.consolidarDebitoExtrato = consolidarDebitoExtrato;
	}	

	public String getFormaAutorizacao() {
		return formaAutorizacao;
	}

	public void setFormaAutorizacao(String formaAutorizacao) {
		this.formaAutorizacao = formaAutorizacao;
	}

	public String getValorTotal() {
		return valorTotal;
	}

	public void setValorTotal(String valorTotal) {
		this.valorTotal = valorTotal;
	}
	
	public String getInformacoesAdicionaisDias() {
		return informacoesAdicionaisDias;
	}

	public void setInformacoesAdicionaisDias(String informacoesAdicionaisDias) {
		this.informacoesAdicionaisDias = informacoesAdicionaisDias;
	}

	public String getMesExtrato() {
		return mesExtrato;
	}

	public void setMesExtrato(String mesExtrato) {
		this.mesExtrato = mesExtrato;
	}

	public String getOpcaoEntrega() {
		return opcaoEntrega;
	}

	public void setOpcaoEntrega(String opcaoEntrega) {
		this.opcaoEntrega = opcaoEntrega;
	}

	public String getNumeroInicial() {
		return numeroInicial;
	}

	public String getNumeroFinal() {
		return numeroFinal;
	}

	public void setNumeroInicial(String numeroInicial) {
		this.numeroInicial = numeroInicial;
	}

	public void setNumeroFinal(String numeroFinal) {
		this.numeroFinal = numeroFinal;
	}

	public String getQuantidadeTaloes() {
		return quantidadeTaloes;
	}

	public void setQuantidadeTaloes(String quantidadeTaloes) {
		this.quantidadeTaloes = quantidadeTaloes;
	}
	
	public String getEmailEnvioFatura() {
		return emailEnvioFatura;
	}

	public void setEmailEnvioFatura(String emailEnvioFatura) {
		this.emailEnvioFatura = emailEnvioFatura;
	}

	public String getCodigoBandeira() {
		return codigoBandeira;
	}

	public void setCodigoBandeira(String codigoBandeira) {
		this.codigoBandeira = codigoBandeira;
	}

	public String getDescBandeiraCartao() {
		return descBandeiraCartao;
	}

	public void setDescBandeiraCartao(String descBandeiraCartao) {
		this.descBandeiraCartao = descBandeiraCartao;
	}

	public String getUrlImagem() {
		return urlImagem;
	}

	public void setUrlImagem(String urlImagem) {
		this.urlImagem = urlImagem;
	}

	public String getSaldoDevedor() {
		return saldoDevedor;
	}

	public void setSaldoDevedor(String saldoDevedor) {
		this.saldoDevedor = saldoDevedor;
	}
	
	public String getCpfSegurado() {
		return cpfSegurado;
	}

	public void setCpfSegurado(String cpfSegurado) {
		this.cpfSegurado = cpfSegurado;
	}

	public String getValorParcelado() {
		return valorParcelado;
	}

	public void setValorParcelado(String valorParcelado) {
		this.valorParcelado = valorParcelado;
	}

	public String getCabecalho() {
		return cabecalho;
	}

	public void setCabecalho(String cabecalho) {
		this.cabecalho = cabecalho;
	}

	public String getValorEntrada() {
		return valorEntrada;
	}

	public void setValorEntrada(String valorEntrada) {
		this.valorEntrada = valorEntrada;
	}

	public String getCustoEfetivoTotal() {
		return custoEfetivoTotal;
	}

	public void setCustoEfetivoTotal(String custoEfetivoTotal) {
		this.custoEfetivoTotal = custoEfetivoTotal;
	}

	public String getValorPrimeiraParcela() {
		return valorPrimeiraParcela;
	}

	public void setValorPrimeiraParcela(String valorPrimeiraParcela) {
		this.valorPrimeiraParcela = valorPrimeiraParcela;
	}

	public String getValorDemaisParcelas() {
		return valorDemaisParcelas;
	}
	
	public String getOperadora() {
		return operadora;
	}

	public void setOperadora(String operadora) {
		this.operadora = operadora;
	}

	public String getTelefoneDDD() {
		return telefoneDDD;
	}

	public void setTelefoneDDD(String telefoneDDD) {
		this.telefoneDDD = telefoneDDD;
	}

	public String getAnoCalendario() {
		return anoCalendario;
	}

	public void setAnoCalendario(String anoCalendario) {
		this.anoCalendario = anoCalendario;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDataNascimento() {
		return dataNascimento;
	}

	public void setDataNascimento(String dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

	public void setValorDemaisParcelas(String valorDemaisParcelas) {
		this.valorDemaisParcelas = valorDemaisParcelas;
	}

	public String getFloatCompHistParts() {
		return floatCompHistParts;
	}

	public void setFloatCompHistParts(String floatCompHistParts) {
		this.floatCompHistParts = floatCompHistParts;
	}

	public String getNomeEmpresa() {
		return nomeEmpresa;
	}

	public void setNomeEmpresa(String nomeEmpresa) {
		this.nomeEmpresa = nomeEmpresa;
	}

	
}