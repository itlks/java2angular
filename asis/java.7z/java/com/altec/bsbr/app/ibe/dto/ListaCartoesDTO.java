package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.List;

import com.altec.bsbr.app.ibe.dto.cartoes.ErrosDTO;

public class ListaCartoesDTO implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2655543059948483456L;
	
	private String saida;
	private List<ListaCartoesItemDTO> rsCartoes;
	private String lngRetCode;
	private String strErro;
	private String strErroTecnica;
	private String strErroMQS;
	private ErrosDTO erros;
	
	public String getSaida() {
		return saida;
	}
	public void setSaida(String saida) {
		this.saida = saida;
	}
	public List<ListaCartoesItemDTO> getRsCartoes() {
		return rsCartoes;
	}
	public void setRsCartoes(List<ListaCartoesItemDTO> rsCartoes) {
		this.rsCartoes = rsCartoes;
	}
	public String getLngRetCode() {
		return lngRetCode;
	}
	public void setLngRetCode(String lngRetCode) {
		this.lngRetCode = lngRetCode;
	}
	public String getStrErro() {
		return strErro;
	}
	public void setStrErro(String strErro) {
		this.strErro = strErro;
	}
	public String getStrErroTecnica() {
		return strErroTecnica;
	}
	public void setStrErroTecnica(String strErroTecnica) {
		this.strErroTecnica = strErroTecnica;
	}
	public String getStrErroMQS() {
		return strErroMQS;
	}
	public void setStrErroMQS(String strErroMQS) {
		this.strErroMQS = strErroMQS;
	}
	public ErrosDTO getErros() {
		return erros;
	}
	public void setErros(ErrosDTO erros) {
		this.erros = erros;
	}
	
	

}
