package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class FavoritoTranferenciaDTO implements Serializable {
	
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6223128381158160343L;
	private String WKCHAVEAMARRACAO;
	private String WKTIPODOCTO;
	private String WKTIPOSERVICO;
	private String WKDATACONTABIL;
	private String WKNUMEROBANCO;
	private String WKNUMEROAGENCIA;
	private String WKDIGITOAGENCIA;
	private String WKNUMEROCONTA;
	private String WKDIGITOCONTA;
	private String WKISPBATUAL;
	private String WKTIPOMOVIMENTACAO;
	private String WKNOME1TITULAR;
	private String WKNOME2TITULAR;
	private String WKTIPODOCTO1;
	private String WKDOCTO1TITULAR;
	private String WKDOCTO2TITULAR;
	private String WKTIPOCONTA;
	private String WKESPECIECONTA;
	private String WKTIPODOC;
	private String WKNUMEROBANCONOVO;
	private String WKNUMEROAGENCIANOVO;
	private String WKDIGITOAGENCIANOVO;
	private String WKNUMEROCONTANOVO;
	private String WKDIGITOCONTANOVO;
	private String WKISPBNOVO;
	private String WKDATATRANSACAO;
	private String WKHORATRANSACAO;
	public String getWKCHAVEAMARRACAO() {
		return WKCHAVEAMARRACAO;
	}
	public void setWKCHAVEAMARRACAO(String wKCHAVEAMARRACAO) {
		WKCHAVEAMARRACAO = wKCHAVEAMARRACAO;
	}
	public String getWKTIPODOCTO() {
		return WKTIPODOCTO;
	}
	public void setWKTIPODOCTO(String wKTIPODOCTO) {
		WKTIPODOCTO = wKTIPODOCTO;
	}
	public String getWKTIPOSERVICO() {
		return WKTIPOSERVICO;
	}
	public void setWKTIPOSERVICO(String wKTIPOSERVICO) {
		WKTIPOSERVICO = wKTIPOSERVICO;
	}
	public String getWKDATACONTABIL() {
		return WKDATACONTABIL;
	}
	public void setWKDATACONTABIL(String wKDATACONTABIL) {
		WKDATACONTABIL = wKDATACONTABIL;
	}
	public String getWKNUMEROBANCO() {
		return WKNUMEROBANCO;
	}
	public void setWKNUMEROBANCO(String wKNUMEROBANCO) {
		WKNUMEROBANCO = wKNUMEROBANCO;
	}
	public String getWKNUMEROAGENCIA() {
		return WKNUMEROAGENCIA;
	}
	public void setWKNUMEROAGENCIA(String wKNUMEROAGENCIA) {
		WKNUMEROAGENCIA = wKNUMEROAGENCIA;
	}
	public String getWKDIGITOAGENCIA() {
		return WKDIGITOAGENCIA;
	}
	public void setWKDIGITOAGENCIA(String wKDIGITOAGENCIA) {
		WKDIGITOAGENCIA = wKDIGITOAGENCIA;
	}
	public String getWKNUMEROCONTA() {
		return WKNUMEROCONTA;
	}
	public void setWKNUMEROCONTA(String wKNUMEROCONTA) {
		WKNUMEROCONTA = wKNUMEROCONTA;
	}
	public String getWKDIGITOCONTA() {
		return WKDIGITOCONTA;
	}
	public void setWKDIGITOCONTA(String wKDIGITOCONTA) {
		WKDIGITOCONTA = wKDIGITOCONTA;
	}
	public String getWKISPBATUAL() {
		return WKISPBATUAL;
	}
	public void setWKISPBATUAL(String wKISPBATUAL) {
		WKISPBATUAL = wKISPBATUAL;
	}
	public String getWKTIPOMOVIMENTACAO() {
		return WKTIPOMOVIMENTACAO;
	}
	public void setWKTIPOMOVIMENTACAO(String wKTIPOMOVIMENTACAO) {
		WKTIPOMOVIMENTACAO = wKTIPOMOVIMENTACAO;
	}
	public String getWKNOME1TITULAR() {
		return WKNOME1TITULAR;
	}
	public void setWKNOME1TITULAR(String wKNOME1TITULAR) {
		WKNOME1TITULAR = wKNOME1TITULAR;
	}
	public String getWKNOME2TITULAR() {
		return WKNOME2TITULAR;
	}
	public void setWKNOME2TITULAR(String wKNOME2TITULAR) {
		WKNOME2TITULAR = wKNOME2TITULAR;
	}
	public String getWKTIPODOCTO1() {
		return WKTIPODOCTO1;
	}
	public void setWKTIPODOCTO1(String wKTIPODOCTO1) {
		WKTIPODOCTO1 = wKTIPODOCTO1;
	}
	public String getWKDOCTO1TITULAR() {
		return WKDOCTO1TITULAR;
	}
	public void setWKDOCTO1TITULAR(String wKDOCTO1TITULAR) {
		WKDOCTO1TITULAR = wKDOCTO1TITULAR;
	}
	public String getWKDOCTO2TITULAR() {
		return WKDOCTO2TITULAR;
	}
	public void setWKDOCTO2TITULAR(String wKDOCTO2TITULAR) {
		WKDOCTO2TITULAR = wKDOCTO2TITULAR;
	}
	public String getWKTIPOCONTA() {
		return WKTIPOCONTA;
	}
	public void setWKTIPOCONTA(String wKTIPOCONTA) {
		WKTIPOCONTA = wKTIPOCONTA;
	}
	public String getWKESPECIECONTA() {
		return WKESPECIECONTA;
	}
	public void setWKESPECIECONTA(String wKESPECIECONTA) {
		WKESPECIECONTA = wKESPECIECONTA;
	}
	public String getWKTIPODOC() {
		return WKTIPODOC;
	}
	public void setWKTIPODOC(String wKTIPODOC) {
		WKTIPODOC = wKTIPODOC;
	}
	public String getWKNUMEROBANCONOVO() {
		return WKNUMEROBANCONOVO;
	}
	public void setWKNUMEROBANCONOVO(String wKNUMEROBANCONOVO) {
		WKNUMEROBANCONOVO = wKNUMEROBANCONOVO;
	}
	public String getWKNUMEROAGENCIANOVO() {
		return WKNUMEROAGENCIANOVO;
	}
	public void setWKNUMEROAGENCIANOVO(String wKNUMEROAGENCIANOVO) {
		WKNUMEROAGENCIANOVO = wKNUMEROAGENCIANOVO;
	}
	public String getWKDIGITOAGENCIANOVO() {
		return WKDIGITOAGENCIANOVO;
	}
	public void setWKDIGITOAGENCIANOVO(String wKDIGITOAGENCIANOVO) {
		WKDIGITOAGENCIANOVO = wKDIGITOAGENCIANOVO;
	}
	public String getWKNUMEROCONTANOVO() {
		return WKNUMEROCONTANOVO;
	}
	public void setWKNUMEROCONTANOVO(String wKNUMEROCONTANOVO) {
		WKNUMEROCONTANOVO = wKNUMEROCONTANOVO;
	}
	public String getWKDIGITOCONTANOVO() {
		return WKDIGITOCONTANOVO;
	}
	public void setWKDIGITOCONTANOVO(String wKDIGITOCONTANOVO) {
		WKDIGITOCONTANOVO = wKDIGITOCONTANOVO;
	}
	public String getWKISPBNOVO() {
		return WKISPBNOVO;
	}
	public void setWKISPBNOVO(String wKISPBNOVO) {
		WKISPBNOVO = wKISPBNOVO;
	}
	public String getWKDATATRANSACAO() {
		return WKDATATRANSACAO;
	}
	public void setWKDATATRANSACAO(String wKDATATRANSACAO) {
		WKDATATRANSACAO = wKDATATRANSACAO;
	}
	public String getWKHORATRANSACAO() {
		return WKHORATRANSACAO;
	}
	public void setWKHORATRANSACAO(String wKHORATRANSACAO) {
		WKHORATRANSACAO = wKHORATRANSACAO;
	}
	
	

}
