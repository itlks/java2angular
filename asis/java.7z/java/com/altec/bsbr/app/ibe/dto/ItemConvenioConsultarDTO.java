package com.altec.bsbr.app.ibe.dto;

import java.util.ArrayList;
import java.util.List;

public class ItemConvenioConsultarDTO {

	private String nomeDoConvenio;
	
	private List<UsuarioSecundarioConsultaConvenio> listaConvenioPerfis;
	
	public ItemConvenioConsultarDTO(){
		listaConvenioPerfis = new ArrayList<UsuarioSecundarioConsultaConvenio>();
	}

	public String getNomeDoConvenio() {
		return nomeDoConvenio;
	}

	public void setNomeDoConvenio(String nomeDoConvenio) {
		this.nomeDoConvenio = nomeDoConvenio;
	}

	public List<UsuarioSecundarioConsultaConvenio> getListaConvenioPerfis() {
		return listaConvenioPerfis;
	}

	public void setListaConvenioPerfis(List<UsuarioSecundarioConsultaConvenio> listaConvenioPerfis) {
		this.listaConvenioPerfis = listaConvenioPerfis;
	}
	
}
