package com.altec.bsbr.app.ibe.dto;

public class DebitoAutomaticoExcluirDTO {
	
	private String dataTransacao;
	private String horaTransacao;
	private String autenticacaoBancaria;
	
	public String getDataTransacao() {
		return dataTransacao;
	}
	public void setDataTransacao(String dataTransacao) {
		this.dataTransacao = dataTransacao;
	}
	public String getAutenticacaoBancaria() {
		return autenticacaoBancaria;
	}
	public void setAutenticacaoBancaria(String autenticacaoBancaria) {
		this.autenticacaoBancaria = autenticacaoBancaria;
	}
	public String getHoraTransacao() {
		return horaTransacao;
	}
	public void setHoraTransacao(String horaTransacao) {
		this.horaTransacao = horaTransacao;
	}
	
	
	

	
}
