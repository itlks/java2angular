package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

import javax.xml.datatype.XMLGregorianCalendar;

public class ConsorcioConsultaDTO implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	private String codigoGrupo;
	private String codigoCota;
	private String cnpj;
	private XMLGregorianCalendar dataEntrada; 
	private String tipoPessoa;

	
	
	
	/**
	 * @return the cnpj
	 */
	public String getCnpj() {
		return cnpj;
	}

	/**
	 * @param cnpj the cnpj to set
	 */
	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	

	/**
	 * @return the dataEntrada
	 */
	public XMLGregorianCalendar getDataEntrada() {
		return dataEntrada;
	}

	/**
	 * @param dataEntrada the dataEntrada to set
	 */
	public void setDataEntrada(XMLGregorianCalendar dataEntrada) {
		this.dataEntrada = dataEntrada;
	}

	/**
	 * @return the tipoPessoa
	 */
	public String getTipoPessoa() {
		return tipoPessoa;
	}

	/**
	 * @param tipoPessoa the tipoPessoa to set
	 */
	public void setTipoPessoa(String tipoPessoa) {
		this.tipoPessoa = tipoPessoa;
	}

	/**
	 * @return the codigoGrupo
	 */
	public String getCodigoGrupo() {
		return codigoGrupo;
	}

	/**
	 * @param codigoGrupo
	 *            the codigoGrupo to set
	 */
	public void setCodigoGrupo(String codigoGrupo) {
		this.codigoGrupo = codigoGrupo;
	}

	/**
	 * @return the codigoCota
	 */
	public String getCodigoCota() {
		return codigoCota;
	}

	/**
	 * @param codigoCota
	 *            the codigoCota to set
	 */
	public void setCodigoCota(String codigoCota) {
		this.codigoCota = codigoCota;
	}

}
