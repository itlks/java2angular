package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

import javax.xml.datatype.XMLGregorianCalendar;

import com.altec.bsbr.app.ibe.enumeration.TipoEnderecoEnum;

public class ListarDomicilioDTO implements Serializable {

	private static final long serialVersionUID = -1255301220889691947L;
	
	private Integer seqEnder;
    private String categEnder;
    private String tipoEnder;
    private String indCorresp;
    private String descLograd;
    private String numImovel;
    private String descComplem;
    private String descBairro;
    private String codMunic;
    private String descMunic;
    private String codUf;
    private String descUf;
    private String codCep;
	@SuppressWarnings("unused")
	private String codCepMasc;
	private String indCorrespDev;
    private String motCorrespDev;
    private String tipoResid;
    private String residDesde;
    
    private XMLGregorianCalendar timeStamp;
    
	public ListarDomicilioDTO() {}
	
	public String getDescricaoSituacao(){
		return TipoEnderecoEnum.findDescricaoByCodigo(this.tipoEnder);
	}
	
	
    /**
	 * @return the seqEnder
	 */
	public Integer getSeqEnder() {
		return seqEnder;
	}

	/**
	 * @param seqEnder the seqEnder to set
	 */
	public void setSeqEnder(Integer seqEnder) {
		this.seqEnder = seqEnder;
	}

	/**
	 * @return the categEnder
	 */
	public String getCategEnder() {
		return categEnder;
	}

	/**
	 * @param categEnder the categEnder to set
	 */
	public void setCategEnder(String categEnder) {
		this.categEnder = categEnder;
	}

	/**
	 * @return the tipoEnder
	 */
	public String getTipoEnder() {
		return tipoEnder;
	}

	/**
	 * @param tipoEnder the tipoEnder to set
	 */
	public void setTipoEnder(String tipoEnder) {
		this.tipoEnder = tipoEnder;
	}

	/**
	 * @return the indCorresp
	 */
	public String getIndCorresp() {
		return indCorresp;
	}

	/**
	 * @param indCorresp the indCorresp to set
	 */
	public void setIndCorresp(String indCorresp) {
		this.indCorresp = indCorresp;
	}

	/**
	 * @return the descLograd
	 */
	public String getDescLograd() {
		return descLograd;
	}

	/**
	 * @param descLograd the descLograd to set
	 */
	public void setDescLograd(String descLograd) {
		this.descLograd = descLograd.trim();
	}

	/**
	 * @return the numImovel
	 */
	public String getNumImovel() {
		return numImovel;
	}

	/**
	 * @param numImovel the numImovel to set
	 */
	public void setNumImovel(String numImovel) {
		this.numImovel = numImovel;
	}

	/**
	 * @return the descComplem
	 */
	public String getDescComplem() {
		return descComplem;
	}

	/**
	 * @param descComplem the descComplem to set
	 */
	public void setDescComplem(String descComplem) {
		this.descComplem = descComplem;
	}

	/**
	 * @return the descBairro
	 */
	public String getDescBairro() {
		return descBairro;
	}

	/**
	 * @param descBairro the descBairro to set
	 */
	public void setDescBairro(String descBairro) {
		this.descBairro = descBairro;
	}

	/**
	 * @return the codMunic
	 */
	public String getCodMunic() {
		return codMunic;
	}

	/**
	 * @param codMunic the codMunic to set
	 */
	public void setCodMunic(String codMunic) {
		this.codMunic = codMunic;
	}

	/**
	 * @return the descMunic
	 */
	public String getDescMunic() {
		return descMunic;
	}

	/**
	 * @param descMunic the descMunic to set
	 */
	public void setDescMunic(String descMunic) {
		this.descMunic = descMunic;
	}

	/**
	 * @return the codUf
	 */
	public String getCodUf() {
		return codUf;
	}

	/**
	 * @param codUf the codUf to set
	 */
	public void setCodUf(String codUf) {
		this.codUf = codUf;
	}

	/**
	 * @return the descUf
	 */
	public String getDescUf() {
		return descUf;
	}

	/**
	 * @param descUf the descUf to set
	 */
	public void setDescUf(String descUf) {
		this.descUf = descUf;
	}

	/**
	 * @return the codCep
	 */
	public String getCodCep() {
		return codCep;
	}

	/**
	 * @param codCep the codCep to set
	 */
	public void setCodCep(String codCep) {
		this.codCep = codCep;
	}

	/**
	 * @return the codCepMasc
	 */
	public String getCodCepMasc() {
		String mascara = this.getCodCep();
		if(this.getCodCep() != null && mascara.length() == 8){
			mascara = this.getCodCep().substring(0, 5)+"-"+this.getCodCep().substring(5, 8);
		}
		return mascara;
	}

	public String getIndCorrespDev() {
		return indCorrespDev;
	}

	public void setIndCorrespDev(String indCorrespDev) {
		this.indCorrespDev = indCorrespDev;
	}

	public String getMotCorrespDev() {
		return motCorrespDev;
	}

	public void setMotCorrespDev(String motCorrespDev) {
		this.motCorrespDev = motCorrespDev;
	}

	public String getTipoResid() {
		return tipoResid;
	}

	public void setTipoResid(String tipoResid) {
		this.tipoResid = tipoResid;
	}

	public String getResidDesde() {
		return residDesde;
	}

	public void setResidDesde(String residDesde) {
		this.residDesde = residDesde;
	}

	public XMLGregorianCalendar getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(XMLGregorianCalendar timeStamp) {
		this.timeStamp = timeStamp;
	}
	
}
