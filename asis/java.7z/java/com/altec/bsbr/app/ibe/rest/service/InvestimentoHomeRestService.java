package com.altec.bsbr.app.ibe.rest.service;

import com.altec.bsbr.app.ibe.dto.investimento.home.InvestimentoHomeRequestDTO;
import com.altec.bsbr.app.ibe.dto.investimento.home.InvestimentoHomeResponseDTO;
import com.altec.bsbr.app.ibe.rest.portfolio.dto.PortfolioResponseDTO;

public interface InvestimentoHomeRestService {
	
	public PortfolioResponseDTO consultarInvestimentos (InvestimentoHomeRequestDTO investimentoHomeRequestDTO);
	
}