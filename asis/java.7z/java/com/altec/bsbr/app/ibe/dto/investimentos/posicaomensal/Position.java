
package com.altec.bsbr.app.ibe.dto.investimentos.posicaomensal;

import java.io.Serializable;

public class Position implements Serializable {

	private String movimentDate;
	private String movimentType;
	private String aplicationDate;
	private String contract;
	private String sequenceNumber;
	private String sequenceNumberRenewal;
	private String movimentValue;
	private String grossValueMoviment;
	private String netValueMoviment;
	private String taxValueMoviment;
	private String iofValue;
	private String movimentNumber;
	private String URcode;
	private final static long serialVersionUID = 580413292558691519L;

	/**
	 * No args constructor for use in serialization
	 * 
	 */
	public Position() {}

	public Position(String movimentDate, String movimentType, String aplicationDate, String contract,
			String sequenceNumber, String sequenceNumberRenewal, String movimentValue, String grossValueMoviment,
			String netValueMoviment, String taxValueMoviment, String iofValue, String movimentNumber, String uRcode) {
		super();
		this.movimentDate = movimentDate;
		this.movimentType = movimentType;
		this.aplicationDate = aplicationDate;
		this.contract = contract;
		this.sequenceNumber = sequenceNumber;
		this.sequenceNumberRenewal = sequenceNumberRenewal;
		this.movimentValue = movimentValue;
		this.grossValueMoviment = grossValueMoviment;
		this.netValueMoviment = netValueMoviment;
		this.taxValueMoviment = taxValueMoviment;
		this.iofValue = iofValue;
		this.movimentNumber = movimentNumber;
		URcode = uRcode;
	}

	public String getMovimentDate() {
		return movimentDate;
	}

	public void setMovimentDate(String movimentDate) {
		this.movimentDate = movimentDate;
	}

	public String getMovimentType() {
		return movimentType;
	}

	public void setMovimentType(String movimentType) {
		this.movimentType = movimentType;
	}

	public String getAplicationDate() {
		return aplicationDate;
	}

	public void setAplicationDate(String aplicationDate) {
		this.aplicationDate = aplicationDate;
	}

	public String getContract() {
		return contract;
	}

	public void setContract(String contract) {
		this.contract = contract;
	}

	public String getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(String sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public String getSequenceNumberRenewal() {
		return sequenceNumberRenewal;
	}

	public void setSequenceNumberRenewal(String sequenceNumberRenewal) {
		this.sequenceNumberRenewal = sequenceNumberRenewal;
	}

	public String getMovimentValue() {
		return movimentValue;
	}

	public void setMovimentValue(String movimentValue) {
		this.movimentValue = movimentValue;
	}

	public String getGrossValueMoviment() {
		return grossValueMoviment;
	}

	public void setGrossValueMoviment(String grossValueMoviment) {
		this.grossValueMoviment = grossValueMoviment;
	}

	public String getNetValueMoviment() {
		return netValueMoviment;
	}

	public void setNetValueMoviment(String netValueMoviment) {
		this.netValueMoviment = netValueMoviment;
	}

	public String getTaxValueMoviment() {
		return taxValueMoviment;
	}

	public void setTaxValueMoviment(String taxValueMoviment) {
		this.taxValueMoviment = taxValueMoviment;
	}

	public String getIofValue() {
		return iofValue;
	}

	public void setIofValue(String iofValue) {
		this.iofValue = iofValue;
	}

	public String getMovimentNumber() {
		return movimentNumber;
	}

	public void setMovimentNumber(String movimentNumber) {
		this.movimentNumber = movimentNumber;
	}

	public String getURcode() {
		return URcode;
	}

	public void setURcode(String uRcode) {
		URcode = uRcode;
	}

}
