package com.altec.bsbr.app.ibe.dto.agendamentos;

import java.io.Serializable;

public class PagueDiretoDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 636202894080230076L;

	private String fornecedor;
	private String notaFiscal;
	private String pos;

	public String getFornecedor() {
		return fornecedor;
	}

	public void setFornecedor(String fornecedor) {
		this.fornecedor = fornecedor;
	}

	public String getNotaFiscal() {
		return notaFiscal;
	}

	public void setNotaFiscal(String notaFiscal) {
		this.notaFiscal = notaFiscal;
	}

	public String getPos() {
		return pos;
	}

	public void setPos(String pos) {
		this.pos = pos;
	}

}
