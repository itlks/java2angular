package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class Output implements Serializable
{

    private String bank;
    private String agency;
    private String account;
    private String returnCode;
    private final static long serialVersionUID = 6281564540812410618L;

    /**
     * No args constructor for use in serialization
     * 
     */
    public Output() {
    }

    /**
     * 
     * @param returnCode
     * @param account
     * @param agency
     * @param bank
     */
    public Output(String bank, String agency, String account, String returnCode) {
        super();
        this.bank = bank;
        this.agency = agency;
        this.account = account;
        this.returnCode = returnCode;
    }

    public String getBank() {
        return bank;
    }

    public void setBank(String bank) {
        this.bank = bank;
    }

    public Output withBank(String bank) {
        this.bank = bank;
        return this;
    }

    public String getAgency() {
        return agency;
    }

    public void setAgency(String agency) {
        this.agency = agency;
    }

    public Output withAgency(String agency) {
        this.agency = agency;
        return this;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public Output withAccount(String account) {
        this.account = account;
        return this;
    }

    public String getReturnCode() {
        return returnCode;
    }

    public void setReturnCode(String returnCode) {
        this.returnCode = returnCode;
    }

    public Output withReturnCode(String returnCode) {
        this.returnCode = returnCode;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(bank).append(agency).append(account).append(returnCode).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Output) == false) {
            return false;
        }
        Output rhs = ((Output) other);
        return new EqualsBuilder().append(bank, rhs.bank).append(agency, rhs.agency).append(account, rhs.account).append(returnCode, rhs.returnCode).isEquals();
    }

}
