package com.altec.bsbr.app.ibe.dto;

public class TaxasDetranSpDadosComprovanteDTO {

    private String label;
    private String valor;
    private String tipo;
    private String pulaLinha;
    
	public String getLabel() {
		return label;
	}
	
	public void setLabel(String label) {
		this.label = label;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getPulaLinha() {
		return pulaLinha;
	}

	public void setPulaLinha(String pulaLinha) {
		this.pulaLinha = pulaLinha;
	}
}
