package com.altec.bsbr.app.ibe.helper;

import java.math.BigDecimal;

public class ItemConsultaHelper {
	
	private String TSOESYCODBANDCRED;
	private String TSOESYCODREG;
	private String TSOESYNOMBANDCRED;
	private BigDecimal valorMediaFaturamento;
	private BigDecimal valorTotal;
	private BigDecimal valorAnterior;
	private BigDecimal valorGarantia;
	private BigDecimal valorDisponivel;
	
	
	
	public ItemConsultaHelper(String TSOESYCODBANDCRED,String TSOESYCODREG, String TSOESYNOMBANDCRED, String TSOESYVLRMEDFAT
			, String TSOESYVLRTOT, String TSOESYVLRANT, String TSOESYVLRGAR, String TSOESYVLRDISP){
		
		this.TSOESYCODBANDCRED = TSOESYCODBANDCRED;
		this.TSOESYCODREG = TSOESYCODREG;
		this.TSOESYNOMBANDCRED = TSOESYNOMBANDCRED;
		this.valorMediaFaturamento = new BigDecimal(TSOESYVLRMEDFAT);
		this.valorTotal = new BigDecimal(TSOESYVLRTOT);
		this.valorAnterior = new BigDecimal(TSOESYVLRANT);
		this.valorGarantia = new BigDecimal(TSOESYVLRGAR);
		this.valorDisponivel = new BigDecimal(TSOESYVLRDISP);
		
	}
	
	
	
	public BigDecimal getValorMediaFaturamento() {
		return valorMediaFaturamento;
	}

	public BigDecimal getValorTotal() {
		return valorTotal;
	}

	public BigDecimal getValorAnterior() {
		return valorAnterior;
	}

	public BigDecimal getValorGarantia() {
		return valorGarantia;
	}

	public BigDecimal getValorDisponivel() {
		return valorDisponivel;
	}

	public String getTSOESYNOMBANDCRED() {
		return TSOESYNOMBANDCRED;
	}

	public String getTSOESYCODREG() {
		return TSOESYCODREG;
	}

	public String getTSOESYCODBANDCRED() {
		return TSOESYCODBANDCRED;
	}


}
