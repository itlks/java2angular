package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

public class ListaPLSelecaoFluxosCartoesSubTotalDTO  implements Serializable {

	private static final long serialVersionUID = -4915355449795109792L;

	private List<ListaPLSelecaoFluxosCartoesDTO> listaPLSelecaoFluxosCartoesDTO;
	private BigDecimal subTotal;

	public List<ListaPLSelecaoFluxosCartoesDTO> getListaPLSelecaoFluxosCartoesDTO() {
		return listaPLSelecaoFluxosCartoesDTO;
	}
	public void setListaPLSelecaoFluxosCartoesDTO(List<ListaPLSelecaoFluxosCartoesDTO> listaPLSelecaoFluxosCartoesDTO) {
		this.listaPLSelecaoFluxosCartoesDTO = listaPLSelecaoFluxosCartoesDTO;
	}
	public BigDecimal getSubTotal() {
		return subTotal;
	}
	public void setSubTotal(BigDecimal subTotal) {
		this.subTotal = subTotal;
	}
}
