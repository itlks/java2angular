package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;



public class DetalheUsuarioAlteracaoDTO implements Serializable {
	
private static final long serialVersionUID = 1L;
	
	private List<DetalheUsuarioAlteracaoListaDTO> detalhesUsuarioAlteracao = new ArrayList<DetalheUsuarioAlteracaoListaDTO>();

	private int RetCode;
	
	public DetalheUsuarioAlteracaoDTO() {}
	
	/**
	 * @return the detalhesUsuarioAlteracao
	 */
	public List<DetalheUsuarioAlteracaoListaDTO> getDetalhesUsuarioAlteracao() {
		return detalhesUsuarioAlteracao;
	}

	/**
	 * @param detalhesUsuarioAlteracao the detalhesUsuarioAlteracao to set
	 */
	public void setDetalhesUsuarioAlteracao(List<DetalheUsuarioAlteracaoListaDTO> detalhesUsuarioAlteracao) {
		this.detalhesUsuarioAlteracao = detalhesUsuarioAlteracao;
	}

	/**
	 * @return the retCode
	 */
	public int getRetCode() {
		return RetCode;
	}

	/**
	 * @param retCode the retCode to set
	 */
	public void setRetCode(int retCode) {
		RetCode = retCode;
	}
			

}