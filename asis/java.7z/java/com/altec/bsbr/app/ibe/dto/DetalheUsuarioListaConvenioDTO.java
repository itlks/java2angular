package com.altec.bsbr.app.ibe.dto;

public class DetalheUsuarioListaConvenioDTO {

	private String nomeUsuarioInclusao;
	private Integer codigoUsuario;
	private String codigoConvenio;
	private String nomeTipoConvenio;
	private String flagPermiteAcesso;
	private String nomePerfilAutorizacao;
	
	

	/**
	 * @return the nomeUsuarioInclusao
	 */
	public String getNomeUsuarioInclusao() {
		return nomeUsuarioInclusao;
	}


	
	
	/**
	 * @param nomeUsuarioInclusao the nomeUsuarioInclusao to set
	 */
	public void setNomeUsuarioInclusao(String nomeUsuarioInclusao) {
		this.nomeUsuarioInclusao = nomeUsuarioInclusao;
	}


	/**
	 * @return the codigoUsuario
	 */
	public Integer getCodigoUsuario() {
		return codigoUsuario;
	}


	/**
	 * @param codigoUsuario the codigoUsuario to set
	 */
	public void setCodigoUsuario(Integer codigoUsuario) {
		this.codigoUsuario = codigoUsuario;
	}


	/**
	 * @return the codigoConvenio
	 */
	public String getCodigoConvenio() {
		return codigoConvenio;
	}


	/**
	 * @param codigoConvenio the codigoConvenio to set
	 */
	public void setCodigoConvenio(String codigoConvenio) {
		this.codigoConvenio = codigoConvenio;
	}


	/**
	 * @return the nomeTipoConvenio
	 */
	public String getNomeTipoConvenio() {
		return nomeTipoConvenio;
	}


	/**
	 * @param nomeTipoConvenio the nomeTipoConvenio to set
	 */
	public void setNomeTipoConvenio(String nomeTipoConvenio) {
		this.nomeTipoConvenio = nomeTipoConvenio;
	}


	/**
	 * @return the flagPermiteAcesso
	 */
	public String getFlagPermiteAcesso() {
		return flagPermiteAcesso;
	}


	/**
	 * @param flagPermiteAcesso the flagPermiteAcesso to set
	 */
	public void setFlagPermiteAcesso(String flagPermiteAcesso) {
		this.flagPermiteAcesso = flagPermiteAcesso;
	}


	public String getNomePerfilAutorizacao() {
		return nomePerfilAutorizacao;
	}


	public void setNomePerfilAutorizacao(String nomePerfilAutorizacao) {
		this.nomePerfilAutorizacao = nomePerfilAutorizacao;
	}
	
}
