package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class DebitoAutomaticoCadastroGenericoDTO implements Serializable {

	private static final long serialVersionUID = 3073364332914722120L;
	
	private String dataHoraTransacao; // formato 14/08/2012 - 15:06:45
	
	private List<EmpresaConveniadaDTO> empresasConveniadas;

	public DebitoAutomaticoCadastroGenericoDTO(){
		this.empresasConveniadas = new ArrayList<EmpresaConveniadaDTO>();
	}

	public List<EmpresaConveniadaDTO> getEmpresasConveniadas() {
		
		if(empresasConveniadas == null)
		{
			empresasConveniadas = new ArrayList<EmpresaConveniadaDTO>();
		}
		
		return empresasConveniadas;
	}

	public void setEmpresasConveniadas(List<EmpresaConveniadaDTO> empresasConveniadas) {
		this.empresasConveniadas = empresasConveniadas;
	}

	public String getDataHoraTransacao() {
		return dataHoraTransacao;
	}

	public void setDataHoraTransacao(String dataHoraTransacao) {
		this.dataHoraTransacao = dataHoraTransacao;
	}
	
}
