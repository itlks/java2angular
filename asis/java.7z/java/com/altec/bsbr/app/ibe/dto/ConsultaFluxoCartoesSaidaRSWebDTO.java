package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

import com.altec.bsbr.app.ibe.util.UtilFunction;

/**
 * @since 2017-01-17
 * @author x187169 - Julio Leme
 *
 */
public class ConsultaFluxoCartoesSaidaRSWebDTO implements Serializable{

	private static final long serialVersionUID = 1L;
	private String nomeBandeira;
	private String nomeOperacao;
	private String codBandeira;
	private String codOperadora;
	private String valorFluxoOriginal;
	private String valorFluxo;
	private String valorFluxoWeb;
	
	private String dataFluxo;
	private String dataFluxoWeb;
	private String valorFluxoOperacaoSel;
	private String valorSolicitadoSel;
	
	private String preg;
	private String dataTitulo;
	private String valorTitulo;
	private String valorTituloOriginal;
	private String valorTituloOriginalSelec;
	
	

	/**
	 * encapsulamento
	 * @return
	 */
	public String getValorTituloOriginalSelec() {
		return valorTituloOriginalSelec;
	}
	
	public void setValorTituloOriginalSelec(String valorSolicitadoSel) {
		this.valorTituloOriginalSelec = valorSolicitadoSel;
	}	
	
	public String getDataTitulo() {
		return dataTitulo;
	}
	
	public void setDataTitulo(String valorSolicitadoSel) {
		this.dataTitulo = valorSolicitadoSel;
	}
	
	public String getValorTitulo() {
		return valorTitulo;
	}
	
	public void setValorTitulo(String valorSolicitadoSel) {
		this.valorTitulo = valorSolicitadoSel;
	}
	
	public String getValorTituloOriginal() {
		return valorTituloOriginal;
	}
	
	public void setValorTituloOriginal(String valorSolicitadoSel) {
		this.valorTituloOriginal = valorSolicitadoSel;
	}

	public String getNomeBandeira() {
		return nomeBandeira;
	}

	public void setNomeBandeira(String nomeBandeira) {
		this.nomeBandeira = nomeBandeira;
	}

	public String getNomeOperacao() {
		return nomeOperacao;
	}

	public void setNomeOperacao(String nomeOperacao) {
		this.nomeOperacao = nomeOperacao;
	}

	public String getValorFluxoOriginal() {
		return valorFluxoOriginal;
	}

	public void setValorFluxoOriginal(String valorDisponivelOperacaoTotal) {
		this.valorFluxoOriginal = valorDisponivelOperacaoTotal;
	}

	public String getValorFluxo() {
		return valorFluxo;
	}

	public void setValorFluxo(String valorDisponivelOperacaoSel) {
		this.valorFluxo = valorDisponivelOperacaoSel;
	}

	public String getDataFluxo() {
		return dataFluxo;
	}

	public void setDataFluxo(String dataOperacaoSel) {
		this.dataFluxo = dataOperacaoSel;
	}

	public String getValorFluxoOperacaoSel() {
		return valorFluxoOperacaoSel;
	}

	public void setValorFluxoOperacaoSel(String valorFluxoOperacaoSel) {
		this.valorFluxoOperacaoSel = valorFluxoOperacaoSel;
	}

	
	public String getValorSolicitadoSel() {
		return valorSolicitadoSel;
	}

	public void setValorSolicitadoSel(String valorSolicitadoSel) {
		this.valorSolicitadoSel = valorSolicitadoSel;
	}
	
	public String getCodBandeira() {
		return codBandeira;
	}
	
	public void setCodBandeira(String valorSolicitadoSel) {
		this.codBandeira = valorSolicitadoSel;
	}
	
	public String getCodOperadora() {
		return codOperadora;
	}

	public void setCodOperadora(String valorSolicitadoSel) {
		this.codOperadora = valorSolicitadoSel;
	}
	
	public void setPreg(String valorSolicitadoSel) {
		this.preg = valorSolicitadoSel;
	}
	
	public String getPreg() {
		return preg;
	}

	public String getValorFluxoWeb() {
		valorFluxoWeb = UtilFunction.convertStringToStringFormatoBR(valorFluxo);
		return valorFluxoWeb;
	}

	public void setValorFluxoWeb(String valorFluxoWeb) {
		this.valorFluxoWeb = valorFluxoWeb;
	}

	public String getDataFluxoWeb() {
		String[] arr = new String[3];
		arr = dataFluxo.split("-");
		String ano = arr[0], mes = arr[1], dia = arr[2]; 
		StringBuilder sb = new StringBuilder();
		sb.append(dia).append("/").append(mes).append("/").append(ano);
		dataFluxoWeb = sb.toString();
		return dataFluxoWeb;
	}

	public void setDataFluxoWeb(String dataTituloWeb) {
		this.dataFluxoWeb = dataTituloWeb;
	}	

}
