package com.altec.bsbr.app.ibe.dto.agendamentos;

import java.io.Serializable;

public class AplicacaoDTO implements Serializable {

	private static final long serialVersionUID = -592065517336144091L;
	private String contaFundo;
	private String origemRecurso;
	private String numeroContratoCDB;
	private String valorTaxa;
	private String prazoMax;

	public String getContaFundo() {
		return contaFundo;
	}

	public void setContaFundo(String contaFundo) {
		this.contaFundo = contaFundo;
	}

	public String getOrigemRecurso() {
		return origemRecurso;
	}

	public void setOrigemRecurso(String origemRecurso) {
		this.origemRecurso = origemRecurso;
	}

	public String getNumeroContratoCDB() {
		return numeroContratoCDB;
	}

	public void setNumeroContratoCDB(String numeroContratoCDB) {
		this.numeroContratoCDB = numeroContratoCDB;
	}

	public String getValorTaxa() {
		return valorTaxa;
	}

	public void setValorTaxa(String valorTaxa) {
		this.valorTaxa = valorTaxa;
	}

	public String getPrazoMax() {
		return prazoMax;
	}

	public void setPrazoMax(String prazoMax) {
		this.prazoMax = prazoMax;
	}

}
