package com.altec.bsbr.app.ibe.dto.agendamentos;

import java.io.Serializable;
import java.util.Date;

public class TituloDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4861433404172216990L;

	private String codigoBarras;
	private Date dataVencimento;

	public String getCodigoBarras() {
		return codigoBarras;
	}

	public void setCodigoBarras(String codigoBarras) {
		this.codigoBarras = codigoBarras;
	}

	public Date getDataVencimento() {
		return dataVencimento;
	}

	public void setDataVencimento(Date dataDeVencimento) {
		this.dataVencimento = dataDeVencimento;
	}

}
