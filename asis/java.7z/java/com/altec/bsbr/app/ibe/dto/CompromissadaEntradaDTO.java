package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.Date;

public class CompromissadaEntradaDTO implements Serializable {
	
	private static final long serialVersionUID = 6660773043346049593L;
	
	protected String strBanco;
    protected String strAgencia;
    protected String strConta;
    protected String strPenumper;
    protected String lngIDConexao;
    protected String lngCodUsuario;
    protected String strFisicaJuridica;
    protected String strIPAddrCliente;
    protected String strIPAddrServer;
    protected String intIdCanal;
    protected String lngRetCode;
    protected String strErro;
    protected String strErroTecnica;
    protected String strErroMQS;
    protected String strTipo;
    protected String strDataVigencia;

	public CompromissadaEntradaDTO(){
		
	}

	/**
	 * @return the lngRetCode
	 */
	public String getLngRetCode() {
		return lngRetCode;
	}

	/**
	 * @param lngRetCode the lngRetCode to set
	 */
	public void setLngRetCode(String lngRetCode) {
		this.lngRetCode = lngRetCode;
	}

	/**
	 * @return the strErro
	 */
	public String getStrErro() {
		return strErro;
	}

	/**
	 * @param strErro the strErro to set
	 */
	public void setStrErro(String strErro) {
		this.strErro = strErro;
	}

	/**
	 * @return the strErroTecnica
	 */
	public String getStrErroTecnica() {
		return strErroTecnica;
	}

	/**
	 * @param strErroTecnica the strErroTecnica to set
	 */
	public void setStrErroTecnica(String strErroTecnica) {
		this.strErroTecnica = strErroTecnica;
	}

	/**
	 * @return the strErroMQS
	 */
	public String getStrErroMQS() {
		return strErroMQS;
	}

	/**
	 * @param strErroMQS the strErroMQS to set
	 */
	public void setStrErroMQS(String strErroMQS) {
		this.strErroMQS = strErroMQS;
	}

	/**
	 * @return the strTipo
	 */
	public String getStrTipo() {
		return strTipo;
	}

	/**
	 * @param strTipo the strTipo to set
	 */
	public void setStrTipo(String strTipo) {
		this.strTipo = strTipo;
	}

	/**
	 * @return the strDataVigencia
	 */
	public String getStrDataVigencia() {
		return strDataVigencia;
	}

	/**
	 * @param strDataVigencia the strDataVigencia to set
	 */
	public void setStrDataVigencia(String strDataVigencia) {
		this.strDataVigencia = strDataVigencia;
	}

	/**
	 * @return the strBanco
	 */
	public String getStrBanco() {
		return strBanco;
	}

	/**
	 * @param strBanco the strBanco to set
	 */
	public void setStrBanco(String strBanco) {
		this.strBanco = strBanco;
	}

	/**
	 * @return the strAgencia
	 */
	public String getStrAgencia() {
		return strAgencia;
	}

	/**
	 * @param strAgencia the strAgencia to set
	 */
	public void setStrAgencia(String strAgencia) {
		this.strAgencia = strAgencia;
	}

	/**
	 * @return the strConta
	 */
	public String getStrConta() {
		return strConta;
	}

	/**
	 * @param strConta the strConta to set
	 */
	public void setStrConta(String strConta) {
		this.strConta = strConta;
	}

	/**
	 * @return the strPenumper
	 */
	public String getStrPenumper() {
		return strPenumper;
	}

	/**
	 * @param strPenumper the strPenumper to set
	 */
	public void setStrPenumper(String strPenumper) {
		this.strPenumper = strPenumper;
	}

	/**
	 * @return the lngIDConexao
	 */
	public String getLngIDConexao() {
		return lngIDConexao;
	}

	/**
	 * @param lngIDConexao the lngIDConexao to set
	 */
	public void setLngIDConexao(String lngIDConexao) {
		this.lngIDConexao = lngIDConexao;
	}

	/**
	 * @return the lngCodUsuario
	 */
	public String getLngCodUsuario() {
		return lngCodUsuario;
	}

	/**
	 * @param lngCodUsuario the lngCodUsuario to set
	 */
	public void setLngCodUsuario(String lngCodUsuario) {
		this.lngCodUsuario = lngCodUsuario;
	}

	/**
	 * @return the strFisicaJuridica
	 */
	public String getStrFisicaJuridica() {
		return strFisicaJuridica;
	}

	/**
	 * @param strFisicaJuridica the strFisicaJuridica to set
	 */
	public void setStrFisicaJuridica(String strFisicaJuridica) {
		this.strFisicaJuridica = strFisicaJuridica;
	}

	/**
	 * @return the strIPAddrCliente
	 */
	public String getStrIPAddrCliente() {
		return strIPAddrCliente;
	}

	/**
	 * @param strIPAddrCliente the strIPAddrCliente to set
	 */
	public void setStrIPAddrCliente(String strIPAddrCliente) {
		this.strIPAddrCliente = strIPAddrCliente;
	}

	/**
	 * @return the strIPAddrServer
	 */
	public String getStrIPAddrServer() {
		return strIPAddrServer;
	}

	/**
	 * @param strIPAddrServer the strIPAddrServer to set
	 */
	public void setStrIPAddrServer(String strIPAddrServer) {
		this.strIPAddrServer = strIPAddrServer;
	}

	/**
	 * @return the intIdCanal
	 */
	public String getIntIdCanal() {
		return intIdCanal;
	}

	/**
	 * @param intIdCanal the intIdCanal to set
	 */
	public void setIntIdCanal(String intIdCanal) {
		this.intIdCanal = intIdCanal;
	}
	
}
