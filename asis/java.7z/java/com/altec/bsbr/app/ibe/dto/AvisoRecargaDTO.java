package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class AvisoRecargaDTO implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3385718623628699183L;
	private String codTransacao;
	private String descTransacao;
	/**
	 * @return the codTransacao
	 */
	public String getCodTransacao() {
		return codTransacao;
	}
	/**
	 * @param codTransacao the codTransacao to set
	 */
	public void setCodTransacao(String codTransacao) {
		this.codTransacao = codTransacao;
	}
	/**
	 * @return the descTransacao
	 */
	public String getDescTransacao() {
		return descTransacao;
	}
	/**
	 * @param descTransacao the descTransacao to set
	 */
	public void setDescTransacao(String descTransacao) {
		this.descTransacao = descTransacao;
	}
	
	

}
