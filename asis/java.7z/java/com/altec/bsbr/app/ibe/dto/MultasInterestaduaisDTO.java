package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

public class MultasInterestaduaisDTO extends GenericDTO  implements Serializable {
	private static final long serialVersionUID = 8150343169429694821L;
	
	private String codigoServico;
	private String renavam;
	private String codigoMunicipio;
	private String proprietario;
	private String cpfCnpj;
	private String numDoc;
	private String placaVeiculo;
	private String uf;
	private String descricaoConvenio;
	private List<GuiaDTO> listaGuiaDTO;
	private String codigoRetorno;
	private String mensagemRetornoProduto;
	private String mensagemRetornoCliente;
	private String numeroMultas;
	private String banco;
	private String agencia;
	private String conta;
	private String referOper;
	private String codigoDoCanal;
	private String autBancaria;
	private String dataPagamento;
	private String dataContabil;
	private BigDecimal valorTotal;
	private boolean geraPendencia;
		
	public MultasInterestaduaisDTO(){
		
	}	

	public MultasInterestaduaisDTO(String codigoServico, String renavam, String codigoMunicipio, String proprietario, String cpfCnpj,
			String placaVeiculo, String uf, String descricaoConvenio, List<GuiaDTO> listaGuiaDTO) {
		super();
		this.codigoServico = codigoServico;
		this.renavam = renavam;
		this.codigoMunicipio = codigoMunicipio;
		this.proprietario = proprietario;
		this.cpfCnpj = cpfCnpj;
		this.placaVeiculo = placaVeiculo;
		this.uf = uf;
		this.descricaoConvenio = descricaoConvenio;
		this.listaGuiaDTO = listaGuiaDTO;
	}

	public String getRenavam() {
		return renavam;
	}

	public void setRenavam(String renavam) {
		this.renavam = renavam;
	}

	public String getCodigoMunicipio() {
		return codigoMunicipio;
	}

	public void setCodigoMunicipio(String codigoMunicipio) {
		this.codigoMunicipio = codigoMunicipio;
	}

	public String getProprietario() {
		return proprietario;
	}

	public void setProprietario(String proprietario) {
		this.proprietario = proprietario;
	}

	public String getCpfCnpj() {
		return cpfCnpj;
	}

	public void setCpfCnpj(String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}
	
	public String getNumDoc() {
		return numDoc;
	}

	public void setNumDoc(String numDoc) {
		this.numDoc = numDoc;
	}

	public String getPlacaVeiculo() {
		return placaVeiculo;
	}

	public void setPlacaVeiculo(String placaVeiculo) {
		this.placaVeiculo = placaVeiculo;
	}

	public List<GuiaDTO> getListaGuiaDTO() {
		return listaGuiaDTO;
	}

	public void setListaGuiaDTO(List<GuiaDTO> listaGuiaDTO) {
		this.listaGuiaDTO = listaGuiaDTO;
	}

	public String getCodigoRetorno() {
		return codigoRetorno;
	}

	public void setCodigoRetorno(String codigoRetorno) {
		this.codigoRetorno = codigoRetorno;
	}

	public String getMensagemRetornoProduto() {
		return mensagemRetornoProduto;
	}

	public void setMensagemRetornoProduto(String mensagemRetornoProduto) {
		this.mensagemRetornoProduto = mensagemRetornoProduto;
	}

	public String getMensagemRetornoCliente() {
		return mensagemRetornoCliente;
	}

	public void setMensagemRetornoCliente(String mensagemRetornoCliente) {
		this.mensagemRetornoCliente = mensagemRetornoCliente;
	}

	public String getNumeroMultas() {
		return numeroMultas;
	}

	public void setNumeroMultas(String numeroMultas) {
		this.numeroMultas = numeroMultas;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getConta() {
		return conta;
	}

	public void setConta(String conta) {
		this.conta = conta;
	}

	public String getReferOper() {
		return referOper;
	}

	public void setReferOper(String referOper) {
		this.referOper = referOper;
	}

	public String getCodigoDoCanal() {
		return codigoDoCanal;
	}

	public void setCodigoDoCanal(String codigoDoCanal) {
		this.codigoDoCanal = codigoDoCanal;
	}

	public String getAutBancaria() {
		return autBancaria;
	}

	public void setAutBancaria(String autBancaria) {
		this.autBancaria = autBancaria;
	}

	public String getDataPagamento() {
		return dataPagamento;
	}

	public void setDataPagamento(String dataPagamento) {
		this.dataPagamento = dataPagamento;
	}

	public String getDataContabil() {
		return dataContabil;
	}

	public void setDataContabil(String dataContabil) {
		this.dataContabil = dataContabil;
	}

	public BigDecimal getValorTotal() {
		return valorTotal;
	}

	public void setValorTotal(BigDecimal valorTotal) {
		this.valorTotal = valorTotal;
	}

	public boolean getGeraPendencia() {
		return geraPendencia;
	}

	public void setGeraPendencia(boolean geraPendencia) {
		this.geraPendencia = geraPendencia;
	}

	public String getCodigoServico() {
		return codigoServico;
	}

	public void setCodigoServico(String codigoServico) {
		this.codigoServico = codigoServico;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public String getDescricaoConvenio() {
		return descricaoConvenio;
	}

	public void setDescricaoConvenio(String descricaoConvenio) {
		this.descricaoConvenio = descricaoConvenio;
	}

	

}
