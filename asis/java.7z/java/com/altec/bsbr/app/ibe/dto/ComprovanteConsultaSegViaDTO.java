package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.Date;

import com.altec.bsbr.app.ibe.enumeration.ListarTributosEnum;

public class ComprovanteConsultaSegViaDTO implements Serializable {

	
	
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -820552695464341374L;
	private String cdCanal;
	private Date dtInicio;
	private Date dtFim;
	private ListarTributosEnum cdServico;
	private String refOper;
	
	private String tipoSelecionado;
	private String periodoEspecificoSelecionado;
	private String pagamentoSelecionado;
	private String cartaoSelecionado;
	private String contaSelecionada;
	private String tributoSelecionado;
	private String formaPagamentoSelecionada;
	private String strDisponibilidade;
	private String strTitulo;
	private Date dataInicial;
	private Date dataFinal;
	private Date dataInicialEspecifica;
	private Date dataFinalEspecifica;
	private Date periodoInicial;
	private Date periodoFinal;
	private String periodoInicialFormat;
	private String periodoFinalFormat;

	
	
	public String getCdCanal() {
		return cdCanal;
	}
	public void setCdCanal(String cdCanal) {
		this.cdCanal = cdCanal;
	}
	public Date getDtInicio() {
		return dtInicio;
	}
	public void setDtInicio(Date dtInicio) {
		this.dtInicio = dtInicio;
	}
	public Date getDtFim() {
		return dtFim;
	}
	public void setDtFim(Date dtFim) {
		this.dtFim = dtFim;
	}
	

	public ListarTributosEnum getCdServico() {
		return cdServico;
	}
	public void setCdServico(ListarTributosEnum cdServico) {
		this.cdServico = cdServico;
	}
	public String getRefOper() {
		return refOper;
	}
	public void setRefOper(String refOper) {
		this.refOper = refOper;
	}
	public String getPeriodoEspecificoSelecionado() {
		return periodoEspecificoSelecionado;
	}
	public void setPeriodoEspecificoSelecionado(String periodoEspecificoSelecionado) {
		this.periodoEspecificoSelecionado = periodoEspecificoSelecionado;
	}
	public String getPagamentoSelecionado() {
		return pagamentoSelecionado;
	}
	public void setPagamentoSelecionado(String pagamentoSelecionado) {
		this.pagamentoSelecionado = pagamentoSelecionado;
	}
	public String getCartaoSelecionado() {
		return cartaoSelecionado;
	}
	public void setCartaoSelecionado(String cartaoSelecionado) {
		this.cartaoSelecionado = cartaoSelecionado;
	}
	public String getContaSelecionada() {
		return contaSelecionada;
	}
	public void setContaSelecionada(String contaSelecionada) {
		this.contaSelecionada = contaSelecionada;
	}
	public String getTributoSelecionado() {
		return tributoSelecionado;
	}
	public void setTributoSelecionado(String tributoSelecionado) {
		this.tributoSelecionado = tributoSelecionado;
	}
	public String getFormaPagamentoSelecionada() {
		return formaPagamentoSelecionada;
	}
	public void setFormaPagamentoSelecionada(String formaPagamentoSelecionada) {
		this.formaPagamentoSelecionada = formaPagamentoSelecionada;
	}
	public String getStrDisponibilidade() {
		return strDisponibilidade;
	}
	public void setStrDisponibilidade(String strDisponibilidade) {
		this.strDisponibilidade = strDisponibilidade;
	}
	public String getStrTitulo() {
		return strTitulo;
	}
	public void setStrTitulo(String strTitulo) {
		this.strTitulo = strTitulo;
	}
	public Date getDataInicial() {
		return dataInicial;
	}
	public void setDataInicial(Date dataInicial) {
		this.dataInicial = dataInicial;
	}
	public Date getDataFinal() {
		return dataFinal;
	}
	public void setDataFinal(Date dataFinal) {
		this.dataFinal = dataFinal;
	}
	public Date getDataInicialEspecifica() {
		return dataInicialEspecifica;
	}
	public void setDataInicialEspecifica(Date dataInicialEspecifica) {
		this.dataInicialEspecifica = dataInicialEspecifica;
	}
	public Date getDataFinalEspecifica() {
		return dataFinalEspecifica;
	}
	public void setDataFinalEspecifica(Date dataFinalEspecifica) {
		this.dataFinalEspecifica = dataFinalEspecifica;
	}
	public Date getPeriodoInicial() {
		return periodoInicial;
	}
	public void setPeriodoInicial(Date periodoInicial) {
		this.periodoInicial = periodoInicial;
	}
	public Date getPeriodoFinal() {
		return periodoFinal;
	}
	public void setPeriodoFinal(Date periodoFinal) {
		this.periodoFinal = periodoFinal;
	}
	public String getPeriodoInicialFormat() {
		return periodoInicialFormat;
	}
	public void setPeriodoInicialFormat(String periodoInicialFormat) {
		this.periodoInicialFormat = periodoInicialFormat;
	}
	public String getPeriodoFinalFormat() {
		return periodoFinalFormat;
	}
	public void setPeriodoFinalFormat(String periodoFinalFormat) {
		this.periodoFinalFormat = periodoFinalFormat;
	}
	public String getTipoSelecionado() {
		return tipoSelecionado;
	}
	public void setTipoSelecionado(String tipoSelecionado) {
		this.tipoSelecionado = tipoSelecionado;
	}
	
	
	
	
	
}
