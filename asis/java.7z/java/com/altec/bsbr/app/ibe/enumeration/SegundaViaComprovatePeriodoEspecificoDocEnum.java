package com.altec.bsbr.app.ibe.enumeration;

public enum SegundaViaComprovatePeriodoEspecificoDocEnum {

	SELECIONE(0, "Selecione"),
	ULTIMOS_TRES(3, "�ltimos 3 dias"),
	ULTIMOS_CINCO(5, "�ltimos 5 dias"),
	ULTIMOS_SETE(7, "�ltimos 7 dias"),
	ULTIMOS_TRINTA(30, "�ltimos 30 dias"),
	ULTIMOS_SESSENTA(60, "�ltimos 60 dias"),
	ULTIMOS_NOVENTA(90, "�ltimos 90 dias");
	
	
	private int valor;
	private String descricao;
	
	private SegundaViaComprovatePeriodoEspecificoDocEnum(int valor, String descricao) {
		this.valor = valor;
		this.descricao = descricao;
	}
	
	public int getValor() {
		return valor;
	}

	public String getDescricao() {
		return descricao;
	}

}