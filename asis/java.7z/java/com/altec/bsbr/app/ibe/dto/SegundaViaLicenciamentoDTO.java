package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

import com.altec.bsbr.app.ibe.enumeration.RenavamEstadoPesquisaEnum;
import com.altec.bsbr.app.ibe.enumeration.RenavamSituacaoEnum;

public class SegundaViaLicenciamentoDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6660773043346049593L;



	private String numero;

	private String placa;
	private RenavamEstadoPesquisaEnum estado;
	private RenavamSituacaoEnum situacao;
	private String proprietario;
	private String codMunicipio;
	private String numCpfCnpj;
	private int anoLicenciamento;
	private float taxaLicenciamento;
	private float taxaPost;
	private String chaveNSU;
	private String referOper;
	private int qntMultaPendentes; 
	private float valorTotalMultas;
	private int qntIpvaPendentes; 
	private float valorTotalIpva;
	private int qntDpvatPendentes; 
	private float valorTotalDpvat;
	private float valorTotal;
	private String autenticacaoDigital;
	private String dataPagamento;
	private String dataContabil;
	
	
	public SegundaViaLicenciamentoDTO() {
	}


	

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}
	
	
	public RenavamEstadoPesquisaEnum getEstado() {
		return estado;
	}
	
	public void setEstado(RenavamEstadoPesquisaEnum estado) {
		this.estado = estado;
	}
	
	public String getPlaca() {
		return placa;
	}
	
	public void setPlaca(String placa) {
		this.placa = placa;
	}

	public RenavamSituacaoEnum getSituacao() {
		return situacao;
	}

	public void setSituacao(RenavamSituacaoEnum situacao) {
		this.situacao = situacao;
	}

	public String getProprietario() {
		return proprietario;
	}

	public void setProprietario(String proprietario) {
		this.proprietario = proprietario;
	}

	public String getCodMunicipio() {
		return codMunicipio;
	}

	public void setCodMunicipio(String codMunicipio) {
		this.codMunicipio = codMunicipio;
	}

	public String getNumCpfCnpj() {
		return numCpfCnpj;
	}

	public void setNumCpfCnpj(String numCpfCnpj) {
		this.numCpfCnpj = numCpfCnpj;
	}

	public int getAnoLicenciamento() {
		return anoLicenciamento;
	}

	public void setAnoLicenciamento(int anoLicenciamento) {
		this.anoLicenciamento = anoLicenciamento;
	}

	public float getTaxaLicenciamento() {
		return taxaLicenciamento;
	}

	public void setTaxaLicenciamento(float taxaLicenciamento) {
		this.taxaLicenciamento = taxaLicenciamento;
	}

	public float getTaxaPost() {
		return taxaPost;
	}

	public void setTaxaPost(float taxaPost) {
		this.taxaPost = taxaPost;
	}




	public String getChaveNSU() {
		return chaveNSU;
	}




	public void setChaveNSU(String chaveNSU) {
		this.chaveNSU = chaveNSU;
	}




	public String getReferOper() {
		return referOper;
	}




	public int getQntMultaPendentes() {
		return qntMultaPendentes;
	}




	public void setQntMultaPendentes(int qntMultaPendentes) {
		this.qntMultaPendentes = qntMultaPendentes;
	}




	public float getValorTotalMultas() {
		return valorTotalMultas;
	}




	public void setValorTotalMultas(float valorTotalMultas) {
		this.valorTotalMultas = valorTotalMultas;
	}




	public int getQntIpvaPendentes() {
		return qntIpvaPendentes;
	}




	public float getValorTotal() {
		return valorTotal;
	}




	public void setValorTotal(float valorTotal) {
		this.valorTotal = valorTotal;
	}




	public void setQntIpvaPendentes(int qntIpvaPendentes) {
		this.qntIpvaPendentes = qntIpvaPendentes;
	}




	public float getValorTotalIpva() {
		return valorTotalIpva;
	}




	public void setValorTotalIpva(float valorTotalIpva) {
		this.valorTotalIpva = valorTotalIpva;
	}




	public int getQntDpvatPendentes() {
		return qntDpvatPendentes;
	}




	public void setQntDpvatPendentes(int qntDpvatPendentes) {
		this.qntDpvatPendentes = qntDpvatPendentes;
	}




	public float getValorTotalDpvat() {
		return valorTotalDpvat;
	}




	public void setValorTotalDpvat(float valorTotalDpvat) {
		this.valorTotalDpvat = valorTotalDpvat;
	}




	public void setReferOper(String referOper) {
		this.referOper = referOper;
	}



	public String getDataPagamento() {
		return dataPagamento;
	}




	public void setDataPagamento(String dataPagamento) {
		this.dataPagamento = dataPagamento;
	}




	public String getDataContabil() {
		return dataContabil;
	}




	public void setDataContabil(String dataContabil) {
		this.dataContabil = dataContabil;
	}




	public String getAutenticacaoDigital() {
		return autenticacaoDigital;
	}




	public void setAutenticacaoDigital(String autenticacaoDigital) {
		this.autenticacaoDigital = autenticacaoDigital;
	}




	


	
	

}
