package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class ItemConsorcioConsultarAssembleiaCalendarioListaResponseDTO implements Serializable {
	
	private static final long serialVersionUID = -1869279213857769916L;
	
	private String numeroAssembleia;
	private String dtAssembleia;
	private String dtSorteio;
	private String dtVencimento;
	private String hrAssembleia;

	public ItemConsorcioConsultarAssembleiaCalendarioListaResponseDTO() {
		super();
	}
	
	public ItemConsorcioConsultarAssembleiaCalendarioListaResponseDTO(String numeroAssembleia, String dtAssembleia,
			String dtSorteio, String dtVencimento, String hrAssembleia) {
		super();
		this.numeroAssembleia = numeroAssembleia;
		this.dtAssembleia = dtAssembleia;
		this.dtSorteio = dtSorteio;
		this.dtVencimento = dtVencimento;
		this.hrAssembleia = hrAssembleia;
	}

	public String getNumeroAssembleia() {
		return numeroAssembleia;
	}

	public void setNumeroAssembleia(String numeroAssembleia) {
		this.numeroAssembleia = numeroAssembleia;
	}

	public String getDtAssembleia() {
		return dtAssembleia;
	}

	public void setDtAssembleia(String dtAssembleia) {
		this.dtAssembleia = dtAssembleia;
	}

	public String getDtSorteio() {
		return dtSorteio;
	}

	public void setDtSorteio(String dtSorteio) {
		this.dtSorteio = dtSorteio;
	}

	public String getDtVencimento() {
		return dtVencimento;
	}

	public void setDtVencimento(String dtVencimento) {
		this.dtVencimento = dtVencimento;
	}

	public String getHrAssembleia() {
		return hrAssembleia;
	}

	public void setHrAssembleia(String hrAssembleia) {
		this.hrAssembleia = hrAssembleia;
	}
	
	
}
