package com.altec.bsbr.app.ibe.dto.agendamentos;

import java.io.Serializable;

public class CartaoCreditoDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2884424157109205103L;
	
	private String numeroCartaoCredito;

	public String getNumeroCartaoCredito() {
		return numeroCartaoCredito;
	}

	public void setNumeroCartaoCredito(String numeroCartaoCredito) {
		this.numeroCartaoCredito = numeroCartaoCredito;
	}

}
