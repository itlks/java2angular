package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ConsultarTransacaoTipoOperacoesDTO implements Serializable{
	
	private static final long serialVersionUID = 1059352468225156350L;

	private List<ItemConsultarTransacaoTipoOperacoesDTO> listaConsultarTipoOperacoes;

	private List<ItemConsultarTransacaoTipoOperacoesDTO> listaConsultarTipoOperacoesSelecionado;
	
	public ConsultarTransacaoTipoOperacoesDTO(){
		
		listaConsultarTipoOperacoes = new ArrayList<ItemConsultarTransacaoTipoOperacoesDTO>();
		
		listaConsultarTipoOperacoesSelecionado = new ArrayList<ItemConsultarTransacaoTipoOperacoesDTO>();
		
	}


	/**
	 * @return the listaOperacoes
	 */
	public List<ItemConsultarTransacaoTipoOperacoesDTO> getListaConsultarTipoOperacoes() {
		return listaConsultarTipoOperacoes;
	}


	/**
	 * @param listaOperacoes the listaOperacoes to set
	 */
	public void setListaOperacoes(List<ItemConsultarTransacaoTipoOperacoesDTO> listaConsultarTipoOperacoes) {
		this.listaConsultarTipoOperacoes = listaConsultarTipoOperacoes;
	}


	public List<ItemConsultarTransacaoTipoOperacoesDTO> getListaConsultarTipoOperacoesSelecionado() {
		return listaConsultarTipoOperacoesSelecionado;
	}


	public void setListaConsultarTipoOperacoesSelecionado(List<ItemConsultarTransacaoTipoOperacoesDTO> listaConsultarTipoOperacoesSelecionado) {
		this.listaConsultarTipoOperacoesSelecionado = listaConsultarTipoOperacoesSelecionado;
	}

	
	
}
