package com.altec.bsbr.app.ibe.dto.home;

import java.io.Serializable;
import java.util.HashMap;

public class PainelInvestimentosHomeDTO implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -6582962841432732841L;

	private Double total;
	
	private HashMap<String, Double> valores ;
	
	public Double getTotal() {
		return total;
	}
	public void setTotal(Double total) {
		this.total = total;
	}
	public HashMap<String, Double> getValores() {
		return valores;
	}
	public void setValores(HashMap<String, Double> valores) {
		this.valores = valores;
	} 
	
}
