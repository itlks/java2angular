package com.altec.bsbr.app.ibe.exception;

import com.altec.bsbr.fw.BusinessException;

public class DispositivoSegurancaException extends BusinessException {
	private static final long serialVersionUID = -1350374034132101850L;
	private String aliasPaginaErro;
	private String mensagemErro;
	
	public DispositivoSegurancaException(String message, String aliasPaginaErro, String mensagemErro) {
		super(message);
		this.aliasPaginaErro = aliasPaginaErro;
		this.mensagemErro = mensagemErro;
	}

	public DispositivoSegurancaException(String message, String aliasPaginaErro, Exception e, String mensagemErro) {
		super(message, e);
		this.aliasPaginaErro = aliasPaginaErro;
		this.mensagemErro = mensagemErro;
	}

	public String getAlias() {
		return aliasPaginaErro;
	}

	public String getMensagemErro() {
		return mensagemErro;
	}
	
}
