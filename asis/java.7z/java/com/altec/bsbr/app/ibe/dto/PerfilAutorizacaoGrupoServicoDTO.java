package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class PerfilAutorizacaoGrupoServicoDTO implements Serializable {

	private static final long serialVersionUID = 9141698492479062472L;

	private Integer nrGrupo;
	private String nomeServico;
	private List<PerfilAutorizacaoTransacaoDTO> transacoes = new ArrayList<PerfilAutorizacaoTransacaoDTO>();

	private Integer quantidadeTransacao;
	private boolean renderPanel = false;
	private boolean checkPrincipal = false;
	private Integer tpTransacao;
	private String nomeTransacao;
	private BigDecimal valorAlcada; 
	private BigDecimal valorDiario;

	private String imagem = "/images/u34.png";

	public Integer getNrGrupo() {
		return nrGrupo;
	}
	public void setNrGrupo(Integer nrGrupo) {
		this.nrGrupo = nrGrupo;
	}
	public String getNomeServico() {
		return nomeServico;
	}
	public void setNomeServico(String nomeServico) {
		this.nomeServico = nomeServico;
	}
	public List<PerfilAutorizacaoTransacaoDTO> getTransacoes() {
		return transacoes;
	}
	public void setTransacoes(List<PerfilAutorizacaoTransacaoDTO> transacoes) {
		this.transacoes = transacoes;
	}
	public boolean isRenderPanel() {
		return renderPanel;
	}
	public void setRenderPanel(boolean renderPanel) {
		this.renderPanel = renderPanel;
	}
	public boolean isCheckPrincipal() {
		return checkPrincipal;
	}
	public void setCheckPrincipal(boolean checkPrincipal) {
		this.checkPrincipal = checkPrincipal;
	}
	public String getImagem() {
		return imagem;
	}
	public void setImagem(String imagem) {
		this.imagem = imagem;
	}
	public Integer getQuantidadeTransacao() {
		return quantidadeTransacao;
	}
	public void setQuantidadeTransacao(Integer quantidadeTransacao) {
		this.quantidadeTransacao = quantidadeTransacao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((nrGrupo == null) ? 0 : nrGrupo.hashCode());
		result = prime * result + ((nomeServico == null) ? 0 : nomeServico.hashCode());
		result = prime * result + ((transacoes == null) ? 0 : transacoes.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PerfilAutorizacaoGrupoServicoDTO other = (PerfilAutorizacaoGrupoServicoDTO) obj;
		if (nrGrupo == null) {
			if (other.nrGrupo != null)
				return false;
		} else if (!nrGrupo.equals(other.nrGrupo))
			return false;
		if (nomeServico == null) {
			if (other.nomeServico != null)
				return false;
		} else if (!nomeServico.equals(other.nomeServico))
			return false;
		if (transacoes == null) {
			if (other.transacoes != null)
				return false;
		} else if (!transacoes.equals(other.transacoes))
			return false;
		return true;
	}
	public Integer getTpTransacao() {
		return tpTransacao;
	}
	public void setTpTransacao(Integer tpTransacao) {
		this.tpTransacao = tpTransacao;
	}
	public String getNomeTransacao() {
		return nomeTransacao;
	}
	public void setNomeTransacao(String nomeTransacao) {
		this.nomeTransacao = nomeTransacao;
	}
	public boolean isRenderizaInputValorDiario() {
		return this.tpTransacao==1;
	}
	
	public boolean isRenderizaInputValorAlcada() {
		return (this.tpTransacao==1 || this.tpTransacao==2);
	}
	public BigDecimal getValorAlcada() {
		return valorAlcada;
	}
	public void setValorAlcada(BigDecimal valorAlcada) {
		this.valorAlcada = valorAlcada;
	}
	public BigDecimal getValorDiario() {
		return valorDiario;
	}
	public void setValorDiario(BigDecimal valorDiario) {
		this.valorDiario = valorDiario;
	}
	
}
