package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ListaPosicaoConsolidadaRendaFixaDTO implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -2348330531323519409L;

	private List<PosicaoConsolidadaDTO> posicaoConsolidada = new ArrayList<PosicaoConsolidadaDTO>();

	public List<PosicaoConsolidadaDTO> getPosicaoConsolidada() {
		return posicaoConsolidada;
	}

	public void setPosicaoConsolidada(List<PosicaoConsolidadaDTO> posicaoConsolidada) {
		this.posicaoConsolidada = posicaoConsolidada;
	}
	
}
