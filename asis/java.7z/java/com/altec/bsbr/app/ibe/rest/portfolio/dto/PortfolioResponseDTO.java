package com.altec.bsbr.app.ibe.rest.portfolio.dto;

import java.io.Serializable;
import java.util.List;

public class PortfolioResponseDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Warning warning;
	
	private List<SavingPortifolio> savingsPortifolio;
	
	private String statusCode;
	private String faultCode;
	private String faultDetails;
	private String faultActor;
	private String message;
	
	public Warning getWarning() {
		return warning;
	}
	public void setWarning(Warning warning) {
		this.warning = warning;
	}
	public List<SavingPortifolio> getSavingsPortifolio() {
		return savingsPortifolio;
	}
	public void setSavingsPortifolio(List<SavingPortifolio> savingsPortifolio) {
		this.savingsPortifolio = savingsPortifolio;
	}
	@Override
	public String toString() {
		return "PortfolioResponseDTO [warning=" + warning + ", savingsPortifolio=" + savingsPortifolio + "]";
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getFaultCode() {
		return faultCode;
	}
	public void setFaultCode(String faultCode) {
		this.faultCode = faultCode;
	}
	public String getFaultDetails() {
		return faultDetails;
	}
	public void setFaultDetails(String faultDetails) {
		this.faultDetails = faultDetails;
	}
	public String getFaultActor() {
		return faultActor;
	}
	public void setFaultActor(String faultActor) {
		this.faultActor = faultActor;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

}
