package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.text.SimpleDateFormat;

import javax.xml.datatype.XMLGregorianCalendar;

import com.altec.bsbr.app.ibe.enumeration.ChequesSituacaoTalaoEnum;
import com.altec.bsbr.app.ibe.util.WSFormat;
import com.altec.bsbr.app.ibe.util.WSFormat.Position;

public class ConsultaChequeDesbloquearTaloesDTO implements Serializable,  Comparable<ConsultaChequeDesbloquearTaloesDTO> {

	private static final long serialVersionUID = 715980357501077266L;
	
	private String header;
    private Integer pricheq;
    private Integer ultcheq;
    private String moeda;
    private String classe;
    private String serie;
    private String numeche;
    private String sectala;
    private String numchef;
    private String estcheq;
    private String petaut;
    private XMLGregorianCalendar dtentre;
    private XMLGregorianCalendar dtpripg;
    private XMLGregorianCalendar dtultpg;
    private XMLGregorianCalendar dtinctl;
    private XMLGregorianCalendar dtexctl;
    private String esttalo;
    private String estante;
    private String motbloq;
    private String modpeti;
    private String pedotro;
    private String folbloq;
    private String entcto;
    private String entsucu;
    private String deliver;
    private String domicil;
    private String centrop;
    private String codreme;
    private String codimpr;
    private String codtran;
    private String indauto;
    private String abemass;
    private String depara;
    private String qtddisp;
    
    
    private String descPricheq;
    private String descUltcheq;
    
    private boolean chkChequeSust;
    
	public String getHeader() {
		return header;
	}
	public void setHeader(String header) {
		this.header = header;
	}
	public Integer getPricheq() {
		return pricheq;
	}
	public void setPricheq(Integer pricheq) {
		this.pricheq = pricheq;
		this.descPricheq = WSFormat.getFormatString(String.valueOf(pricheq), 6, "0", Position.RIGHT);
	}
	public Integer getUltcheq() {
		return ultcheq;
	}
	public void setUltcheq(Integer ultcheq) {
		this.ultcheq = ultcheq;
		this.descUltcheq = WSFormat.getFormatString(String.valueOf(ultcheq), 6, "0", Position.RIGHT);
	}
	public String getMoeda() {
		return moeda;
	}
	public void setMoeda(String moeda) {
		this.moeda = moeda;
	}
	public String getClasse() {
		return classe;
	}
	public void setClasse(String classe) {
		this.classe = classe;
	}
	public String getSerie() {
		return serie;
	}
	public void setSerie(String serie) {
		this.serie = serie;
	}
	public String getNumeche() {
		return numeche;
	}
	public void setNumeche(String numeche) {
		this.numeche = numeche;
	}
	public String getSectala() {
		return sectala;
	}
	public void setSectala(String sectala) {
		this.sectala = sectala;
	}
	public String getNumchef() {
		return numchef;
	}
	public void setNumchef(String numchef) {
		this.numchef = numchef;
	}
	public String getEstcheq() {
		return estcheq;
	}
	public void setEstcheq(String estcheq) {
		this.estcheq = estcheq;
	}
	public String getPetaut() {
		return petaut;
	}
	public void setPetaut(String petaut) {
		this.petaut = petaut;
	}
	public XMLGregorianCalendar getDtentre() {
		return dtentre;
	}
	public void setDtentre(XMLGregorianCalendar dtentre) {
		this.dtentre = dtentre;
	}
	public XMLGregorianCalendar getDtpripg() {
		return dtpripg;
	}
	public void setDtpripg(XMLGregorianCalendar dtpripg) {
		this.dtpripg = dtpripg;
	}
	public XMLGregorianCalendar getDtultpg() {
		return dtultpg;
	}
	public void setDtultpg(XMLGregorianCalendar dtultpg) {
		this.dtultpg = dtultpg;
	}
	public XMLGregorianCalendar getDtinctl() {
		return dtinctl;
	}
	public void setDtinctl(XMLGregorianCalendar dtinctl) {
		this.dtinctl = dtinctl;
	}
	public XMLGregorianCalendar getDtexctl() {
		return dtexctl;
	}
	public void setDtexctl(XMLGregorianCalendar dtexctl) {
		this.dtexctl = dtexctl;
	}
	public String getEsttalo() {
		return esttalo;
	}
	public void setEsttalo(String esttalo) {
		this.esttalo = esttalo;
	}
	public String getEstante() {
		return estante;
	}
	public void setEstante(String estante) {
		this.estante = estante;
	}
	public String getMotbloq() {
		return motbloq;
	}
	public void setMotbloq(String motbloq) {
		this.motbloq = motbloq;
	}
	public String getModpeti() {
		return modpeti;
	}
	public void setModpeti(String modpeti) {
		this.modpeti = modpeti;
	}
	public String getPedotro() {
		return pedotro;
	}
	public void setPedotro(String pedotro) {
		this.pedotro = pedotro;
	}
	public String getFolbloq() {
		return folbloq;
	}
	public void setFolbloq(String folbloq) {
		this.folbloq = folbloq;
	}
	public String getEntcto() {
		return entcto;
	}
	public void setEntcto(String entcto) {
		this.entcto = entcto;
	}
	public String getEntsucu() {
		return entsucu;
	}
	public void setEntsucu(String entsucu) {
		this.entsucu = entsucu;
	}
	public String getDeliver() {
		return deliver;
	}
	public void setDeliver(String deliver) {
		this.deliver = deliver;
	}
	public String getDomicil() {
		return domicil;
	}
	public void setDomicil(String domicil) {
		this.domicil = domicil;
	}
	public String getCentrop() {
		return centrop;
	}
	public void setCentrop(String centrop) {
		this.centrop = centrop;
	}
	public String getCodreme() {
		return codreme;
	}
	public void setCodreme(String codreme) {
		this.codreme = codreme;
	}
	public String getCodimpr() {
		return codimpr;
	}
	public void setCodimpr(String codimpr) {
		this.codimpr = codimpr;
	}
	public String getCodtran() {
		return codtran;
	}
	public void setCodtran(String codtran) {
		this.codtran = codtran;
	}
	public String getIndauto() {
		return indauto;
	}
	public void setIndauto(String indauto) {
		this.indauto = indauto;
	}
	public String getAbemass() {
		return abemass;
	}
	public void setAbemass(String abemass) {
		this.abemass = abemass;
	}
	public String getDepara() {
		return depara;
	}
	public void setDepara(String depara) {
		this.depara = depara;
	}
	public String getQtddisp() {
		return qtddisp;
	}
	public void setQtddisp(String qtddisp) {
		this.qtddisp = qtddisp;
	}
	public boolean isChkChequeSust() {
		return chkChequeSust;
	}
	public void setChkChequeSust(boolean chkChequeSust) {
		this.chkChequeSust = chkChequeSust;
	}
	public String getDescPricheq() {
		return descPricheq;
	}
	public void setDescPricheq(String descPricheq) {
		this.descPricheq = descPricheq;
	}
	public String getDescUltcheq() {
		return descUltcheq;
	}
	public void setDescUltcheq(String descUltcheq) {
		this.descUltcheq = descUltcheq;
	}
	 
	
	@Override
	public int compareTo(ConsultaChequeDesbloquearTaloesDTO o) {		 
		return -this.pricheq.compareTo(o.pricheq);
	}
    
	public String getDataFormatadaDDMMYYYYY(){
		String dataFormatada = "";
		
		if(dtinctl != null){
			
			SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
			String data = format.format(this.dtinctl.toGregorianCalendar().getTime());
			dataFormatada = data.equalsIgnoreCase("01/01/0001") ? "" : data;
			
		}		
		return dataFormatada;
	}
	
	public String getDescricaoSituacao(){
		return ChequesSituacaoTalaoEnum.findSituacaoByValue(this.esttalo);
	}
	
	public String getDescricaoObservacao(){
		return ChequesSituacaoTalaoEnum.findObservacaoByValue(this.esttalo);
	}

}
