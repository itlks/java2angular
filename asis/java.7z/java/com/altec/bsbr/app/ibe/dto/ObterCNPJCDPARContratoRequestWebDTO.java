package com.altec.bsbr.app.ibe.dto;

public class ObterCNPJCDPARContratoRequestWebDTO {
	private long nr_sequ_usua; 
	private double nr_sequ_cntr; 
	private int retcode; 


	public long getNr_sequ_usua(){
		return this.nr_sequ_usua;
	} 
	public double getNr_sequ_cntr(){
		return this.nr_sequ_cntr;
	} 
	public int getRetcode(){
		return this.retcode;
	} 

	public void setNr_sequ_usua(long nr_sequ_usua){
		this.nr_sequ_usua = nr_sequ_usua;
	} 
	public void setNr_sequ_cntr(double nr_sequ_cntr){
		this.nr_sequ_cntr = nr_sequ_cntr;
	} 
	public void setRetcode(int retcode){
		this.retcode = retcode;
	} 
}
