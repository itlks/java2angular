package com.altec.bsbr.app.ibe.dto;

public class TransacaoLimiteDiarioDTO {
	private boolean checked;
	private String nomeTransacao;
	private String quantidade;
	private Double valor;
	private String novaQuantidade;
	private String novoValor;

	public TransacaoLimiteDiarioDTO(String nomeTransacao, String quantidade, Double valor) {
		this.nomeTransacao = nomeTransacao;
		this.quantidade = quantidade;
		this.valor = valor;
	}

	public boolean isChecked() {
		return checked;
	}

	public void setChecked(boolean checked) {
		this.checked = checked;
	}

	public String getNomeTransacao() {
		return nomeTransacao;
	}

	public void setNomeTransacao(String nomeTransacao) {
		this.nomeTransacao = nomeTransacao;
	}

	public String getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(String quantidade) {
		this.quantidade = quantidade;
	}

	public Double getValor() {
		return valor;
	}

	public void setValor(Double valor) {
		this.valor = valor;
	}

	public String getNovaQuantidade() {
		return novaQuantidade;
	}

	public void setNovaQuantidade(String novaQuantidade) {
		this.novaQuantidade = novaQuantidade;
	}

	public String getNovoValor() {
		return novoValor;
	}

	public void setNovoValor(String novoValor) {
		this.novoValor = novoValor;
	}
	
}
