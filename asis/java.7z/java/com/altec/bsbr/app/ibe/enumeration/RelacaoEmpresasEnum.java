	package com.altec.bsbr.app.ibe.enumeration;

	public enum RelacaoEmpresasEnum {

		CONCESSIONARIA_AGUA("1001","CONTAS DE AGUA"),
		CONCESSIONARIA_LUZ("1002","CONTAS DE LUZ"),
		CONCESSIONARIA_GAS("1003","CONTAS DE GAS"),
		CONCESSIONARIA_TELEFONE("1004","CONTAS DE TELEFONE"),
		CONTAS_DEMAIS_DOCUMENTOS("1005","CONTAS - DEMAIS DOCUMENTOS"),
		DARF("2001","DARF"),
		GPS("2002","GPS"),
		FGTS("2003","FGTS"),
		SIMPLES_NACIONAL("2004","SIMPLES NACIONAL"),
		GARE_ICMS_IMPORTACAO_SP("3001","GARE ICMS IMPORTACAOO SP"),
		GNRE("3002","GNRE"),
		DARE_DAE_TRIBUTOS_ESTADUAIS("3003","DARE / DAE / TRIBUTOS ESTADUAIS"),
		IPTU_PMSP("4001","IPTU PMSP"),
		TRIBUTOS_E_TAXAS_MUNICIPAIS("4002","TRIBUTOS E TAXAS MUNICIPAIS"),
		TRIBUTO_PMSP("4003","TRIBUTO PMSP"),
		IPVA_SP("5001","IPVA SP"),
		DPVAT_SP("5002","DPVAT SP"),
		VEICULOS_SP_INSPECAO_VEICULAR("5003","Veiculos Sao Paulo Inspecao Veicular"),
		IPVA_MG("5101","IPVA MG"),
		DPVAT_MG("5102","DPVAT MG"),
		MULTAS_DE_TRANSITO("5103","MULTAS DE TRANSITO"),
		DPVAT_DE_OUTROS_ESTADOS("6001","DPVAT DE OUTROS ESTADOS"),
		;
		private String strMenu;
		private String Nome;

		private RelacaoEmpresasEnum(String strMenu,String Nome) {
			this.strMenu = strMenu;
			this.Nome = Nome;
		}

		public String getStrMenu() {
			return strMenu;
		}

		public String getNome() {
			return Nome;
		}
	}
