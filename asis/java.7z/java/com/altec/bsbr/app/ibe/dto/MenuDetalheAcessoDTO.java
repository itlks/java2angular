package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.List;

public class MenuDetalheAcessoDTO implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	
	private String idMenu;
	private String descricao;
	private List<MenuDetalheAcessoDTO> subMenu;
	
	
	/**
	 * MenuDetalheAcessoDTO
	 */
	public MenuDetalheAcessoDTO() {}
	
	/**
	 * MenuDetalheAcessoDTO
	 * @param idMenu
	 * @param descricao
	 * @param subMenu
	 */
	public MenuDetalheAcessoDTO(String idMenu, String descricao, List<MenuDetalheAcessoDTO> subMenu) {
		super();
		this.idMenu = idMenu;
		this.descricao = descricao;
		this.subMenu = subMenu;
	}

	/**
	 * @return the idMenu
	 */
	public String getIdMenu() {
		return idMenu;
	}

	/**
	 * @param idMenu the idMenu to set
	 */
	public void setIdMenu(String idMenu) {
		this.idMenu = idMenu;
	}

	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}

	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	/**
	 * @return the subMenu
	 */
	public List<MenuDetalheAcessoDTO> getSubMenu() {
		return subMenu;
	}

	/**
	 * @param subMenu the subMenu to set
	 */
	public void setSubMenu(List<MenuDetalheAcessoDTO> subMenu) {
		this.subMenu = subMenu;
	}

}