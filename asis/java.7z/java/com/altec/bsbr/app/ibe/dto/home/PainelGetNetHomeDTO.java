package com.altec.bsbr.app.ibe.dto.home;

public class PainelGetNetHomeDTO {
	private Double total;
	private Double totalVisa;
	private Double totalMaster;
	public Double getTotal() {
		return total;
	}
	public void setTotal(Double total) {
		this.total = total;
	}
	public Double getTotalVisa() {
		return totalVisa;
	}
	public void setTotalVisa(Double totalVisa) {
		this.totalVisa = totalVisa;
	}
	public Double getTotalMaster() {
		return totalMaster;
	}
	public void setTotalMaster(Double totalMaster) {
		this.totalMaster = totalMaster;
	}
	
}
