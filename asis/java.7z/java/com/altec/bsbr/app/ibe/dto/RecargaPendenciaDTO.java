package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class RecargaPendenciaDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3940929734873822589L;
	private BigDecimal valorRecarga;
	private String codigoArea;
	private String numeroCelular;
	private String digitoVerificador;
	private Date dataAgendamento;
	private Date dataFimAgendamento;
	private String periodicidade;
	private String indSmsAgendamento;
	private String indAgendamento;
	private BancoDTO contratoOperadora;

	public BigDecimal getValorRecarga() {
		return valorRecarga;
	}

	public void setValorRecarga(BigDecimal valorRecarga) {
		this.valorRecarga = valorRecarga;
	}

	public String getCodigoArea() {
		return codigoArea;
	}

	public void setCodigoArea(String codigoArea) {
		this.codigoArea = codigoArea;
	}

	public String getNumeroCelular() {
		return numeroCelular;
	}

	public void setNumeroCelular(String numeroCelular) {
		this.numeroCelular = numeroCelular;
	}

	public String getDigitoVerificador() {
		return digitoVerificador;
	}

	public void setDigitoVerificador(String digitoVerificador) {
		this.digitoVerificador = digitoVerificador;
	}

	public Date getDataAgendamento() {
		return dataAgendamento;
	}

	public void setDataAgendamento(Date dataAgendamento) {
		this.dataAgendamento = dataAgendamento;
	}

	public Date getDataFimAgendamento() {
		return dataFimAgendamento;
	}

	public void setDataFimAgendamento(Date dataFimAgendamento) {
		this.dataFimAgendamento = dataFimAgendamento;
	}

	public String getPeriodicidade() {
		return periodicidade;
	}

	public void setPeriodicidade(String periodicidade) {
		this.periodicidade = periodicidade;
	}

	public String getIndSmsAgendamento() {
		return indSmsAgendamento;
	}

	public void setIndSmsAgendamento(String indSmsAgendamento) {
		this.indSmsAgendamento = indSmsAgendamento;
	}

	public String getIndAgendamento() {
		return indAgendamento;
	}

	public void setIndAgendamento(String indAgendamento) {
		this.indAgendamento = indAgendamento;
	}

	public BancoDTO getContratoOperadora() {
		return contratoOperadora;
	}

	public void setContratoOperadora(BancoDTO contratoOperadora) {
		this.contratoOperadora = contratoOperadora;
	}

}
