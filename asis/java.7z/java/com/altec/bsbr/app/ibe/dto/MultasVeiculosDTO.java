package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

public class MultasVeiculosDTO extends GenericDTO  implements Serializable {
	private static final long serialVersionUID = 8150343169429694821L;
	
	private String identificacao;
	private String renavam;
	private String codigoMunicipio;
	private String proprietario;
	private String cpfCnpj;
	private String placaVeiculo;
	private List<GuiaDTO> listaGuiaDTO;
	private String codigoRetorno;
	private String mensagemRetornoProduto;
	private String mensagemRetornoCliente;
	private String numeroMultas;
	private String banco;
	private String agencia;
	private String conta;
	private String referOper;
	private String codigoDoCanal;
	private String autBancaria;
	private String dataPagamento;
	private String dataContabil;
	private BigDecimal valorTotal;
	private boolean geraPendencia;
	private String numDoc;
	
	public MultasVeiculosDTO(){
		
	}	

	public MultasVeiculosDTO(String identificacao, String renavam, String codigoMunicipio, String proprietario, String cpfCnpj,
			String placaVeiculo, List<GuiaDTO> listaGuiaDTO) {
		super();
		this.identificacao = identificacao;
		this.renavam = renavam;
		this.codigoMunicipio = codigoMunicipio;
		this.proprietario = proprietario;
		this.cpfCnpj = cpfCnpj;
		this.placaVeiculo = placaVeiculo;
		this.listaGuiaDTO = listaGuiaDTO;
	}

	public String getIdentificacao() {
		return identificacao;
	}

	public void setIdentificacao(String identificacao) {
		this.identificacao = identificacao;
	}

	public String getRenavam() {
		return renavam;
	}

	public void setRenavam(String renavam) {
		this.renavam = renavam;
	}

	public String getCodigoMunicipio() {
		return codigoMunicipio;
	}

	public void setCodigoMunicipio(String codigoMunicipio) {
		this.codigoMunicipio = codigoMunicipio;
	}

	public String getProprietario() {
		return proprietario;
	}

	public void setProprietario(String proprietario) {
		this.proprietario = proprietario;
	}

	public String getCpfCnpj() {
		return cpfCnpj;
	}

	public void setCpfCnpj(String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}

	public String getPlacaVeiculo() {
		return placaVeiculo;
	}

	public void setPlacaVeiculo(String placaVeiculo) {
		this.placaVeiculo = placaVeiculo;
	}

	public List<GuiaDTO> getListaGuiaDTO() {
		return listaGuiaDTO;
	}

	public void setListaGuiaDTO(List<GuiaDTO> listaGuiaDTO) {
		this.listaGuiaDTO = listaGuiaDTO;
	}

	public String getCodigoRetorno() {
		return codigoRetorno;
	}

	public void setCodigoRetorno(String codigoRetorno) {
		this.codigoRetorno = codigoRetorno;
	}

	public String getMensagemRetornoProduto() {
		return mensagemRetornoProduto;
	}

	public void setMensagemRetornoProduto(String mensagemRetornoProduto) {
		this.mensagemRetornoProduto = mensagemRetornoProduto;
	}

	public String getMensagemRetornoCliente() {
		return mensagemRetornoCliente;
	}

	public void setMensagemRetornoCliente(String mensagemRetornoCliente) {
		this.mensagemRetornoCliente = mensagemRetornoCliente;
	}

	public String getNumeroMultas() {
		return numeroMultas;
	}

	public void setNumeroMultas(String numeroMultas) {
		this.numeroMultas = numeroMultas;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getConta() {
		return conta;
	}

	public void setConta(String conta) {
		this.conta = conta;
	}

	public String getReferOper() {
		return referOper;
	}

	public void setReferOper(String referOper) {
		this.referOper = referOper;
	}

	public String getCodigoDoCanal() {
		return codigoDoCanal;
	}

	public void setCodigoDoCanal(String codigoDoCanal) {
		this.codigoDoCanal = codigoDoCanal;
	}

	public String getAutBancaria() {
		return autBancaria;
	}

	public void setAutBancaria(String autBancaria) {
		this.autBancaria = autBancaria;
	}

	public String getDataPagamento() {
		return dataPagamento;
	}

	public void setDataPagamento(String dataPagamento) {
		this.dataPagamento = dataPagamento;
	}

	public String getDataContabil() {
		return dataContabil;
	}

	public void setDataContabil(String dataContabil) {
		this.dataContabil = dataContabil;
	}

	public BigDecimal getValorTotal() {
		return valorTotal;
	}

	public void setValorTotal(BigDecimal valorTotal) {
		this.valorTotal = valorTotal;
	}

	public boolean getGeraPendencia() {
		return geraPendencia;
	}

	public void setGeraPendencia(boolean geraPendencia) {
		this.geraPendencia = geraPendencia;
	}

	public String getNumDoc() {
		return numDoc;
	}

	public void setNumDoc(String numDoc) {
		this.numDoc = numDoc;
	}

}
