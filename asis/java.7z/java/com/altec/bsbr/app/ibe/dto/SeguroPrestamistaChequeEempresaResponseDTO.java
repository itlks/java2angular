/*
 * Cheque Ades�o Empresa Protegido (Rest Implementation para controle de fluxo)
 *
 */
package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class SeguroPrestamistaChequeEempresaResponseDTO implements Serializable
{

    private List<OutputLendersInsurance> outputLendersInsurances = new ArrayList<OutputLendersInsurance>();
    private final static long serialVersionUID = -2884143994469232645L;

    /**
     * No args constructor for use in serialization
     * 
     */
    public SeguroPrestamistaChequeEempresaResponseDTO() {
    	throw new UnsupportedOperationException();
    }

    /**
     * 
     * @param outputLendersInsurances
     */
    public SeguroPrestamistaChequeEempresaResponseDTO(List<OutputLendersInsurance> outputLendersInsurances) {
        super();
        this.outputLendersInsurances = outputLendersInsurances;
    }

    public List<OutputLendersInsurance> getOutputLendersInsurances() {
        return outputLendersInsurances;
    }

    public void setOutputLendersInsurances(List<OutputLendersInsurance> outputLendersInsurances) {
        this.outputLendersInsurances = outputLendersInsurances;
    }

    public SeguroPrestamistaChequeEempresaResponseDTO withOutputLendersInsurances(List<OutputLendersInsurance> outputLendersInsurances) {
        this.outputLendersInsurances = outputLendersInsurances;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(outputLendersInsurances).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof SeguroPrestamistaChequeEempresaResponseDTO) == false) {
            return false;
        }
        SeguroPrestamistaChequeEempresaResponseDTO rhs = (SeguroPrestamistaChequeEempresaResponseDTO) other;
        return new EqualsBuilder().append(outputLendersInsurances, rhs.outputLendersInsurances).isEquals();
    }

}