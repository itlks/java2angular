package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class ApelidoBoletoBancarioDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1085363951682620650L;
	private String tipoApelido;
	private String apelido;
	private String nomeCedente;
	private String nomeFavorecido;

	public String getTipoApelido() {
		return tipoApelido;
	}

	public void setTipoApelido(String tipoApelido) {
		this.tipoApelido = tipoApelido;
	}

	public String getApelido() {
		return apelido;
	}

	public void setApelido(String apelido) {
		this.apelido = apelido;
	}

	public String getNomeCedente() {
		return nomeCedente;
	}

	public void setNomeCedente(String nomeCedente) {
		this.nomeCedente = nomeCedente;
	}

	public String getNomeFavorecido() {
		return nomeFavorecido;
	}

	public void setNomeFavorecido(String nomeFavorecido) {
		this.nomeFavorecido = nomeFavorecido;
	}

}
