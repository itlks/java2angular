package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class DebitosPendentesVeiculosRenavamDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String codigoMensajeOk;
	private Integer codServ;
	private String renavam;
	private String documen;
	private String palca;
	private Integer muniest;
	private Integer munifed;
	private String nomePro;
	private String unidFed;
	private Integer ocoIPVA;
	private Integer ocoMult;
	private String autentDigital;
	private Integer anoExer;
	private Integer idenTex;
	private Integer categDP;
	private BigDecimal valDPV1;
	private Integer anoExer2;
	private Integer idenTex2;
	private Integer categDP2;
	private BigDecimal valDPV2;
	private String dadIPV1;
	private BigDecimal valIPV1;
	private String dadIPV2;
	private BigDecimal valIPV2;
	private String dadIPV3;
	private BigDecimal valIPV3;
	private String dadIPV4;
	private BigDecimal valIPV4;
	private String dadIPV5;
	private BigDecimal valIPV5;
	private String dadIPV6;
	private BigDecimal valIPV6;
	private BigDecimal totIPVA;
	private BigDecimal totDPVA;
	private BigDecimal totMult;
	private BigDecimal totDebi;
	private String codigoalfanum2;
	private String codigoalfanum4;
	private String desConv;
	private String autoInfracao1;
	private Integer numGuia1;
	private Integer codSegmento1;
	private Date dataInfracao1;
	private Date dataVcto1;
	private BigDecimal valorMuta1;
	private String dadosMulta1;
	private String autoInfracao2;
	private Integer numGuia2;
	private Integer codSegmento2;
	private Date dataInfracao2;
	private Date dataVcto2;
	private BigDecimal valorMuta2;
	private String dadosMulta2;
	private String autoInfracao3;
	private Integer numGuia3;
	private Integer codSegmento3;
	private Date dataInfracao3;
	private Date dataVcto3;
	private BigDecimal valorMuta3;
	private String dadosMulta3;
	private String autoInfracao4;
	private Integer numGuia4;
	private Integer codSegmento4;
	private Date dataInfracao4;
	private Date dataVcto4;
	private BigDecimal valorMuta4;
	private String dadosMulta4;
	private String autoInfracao5;
	private Integer numGuia5;
	private Integer codSegmento5;
	private Date dataInfracao5;
	private Date dataVcto5;
	private BigDecimal valorMuta5;
	private String dadosMulta5;
	private String autoInfracao6;
	private Integer numGuia6;
	private Integer codSegmento6;
	private Date dataInfracao6;
	private Date dataVcto6;
	private BigDecimal valorMuta6;
	private String dadosMulta6;
	private String autoInfracao7;
	private Integer numGuia7;
	private Integer codSegmento7;
	private Date dataInfracao7;
	private Date dataVcto7;
	private BigDecimal valorMuta7;
	private String dadosMulta7;
	private String autoInfracao8;
	private Integer numGuia8;
	private Integer codSegmento8;
	private Date dataInfracao8;
	private Date dataVcto8;
	private BigDecimal valorMuta8;
	private String dadosMulta8;
	private String autoInfracao9;
	private Integer numGuia9;
	private Integer codSegmento9;
	private Date dataInfracao9;
	private Date dataVcto9;
	private BigDecimal valorMuta9;
	private String dadosMulta9;
	private String autoInfracao10;
	private Integer numGuia10;
	private Integer codSegmento10;
	private Date dataInfracao10;
	private Date dataVcto10;
	private BigDecimal valorMuta10;
	private String dadosMulta10;
	private String autoInfracao11;
	private Integer numGuia11;
	private Integer codSegmento11;
	private Date dataInfracao11;
	private Date dataVcto11;
	private BigDecimal valorMuta11;
	private String dadosMulta11;
	private String autoInfracao12;
	private Integer numGuia12;
	private Integer codSegmento12;
	private Date dataInfracao12;
	private Date dataVcto12;
	private BigDecimal valorMuta12;
	private String dadosMulta12;
	private String autoInfracao13;
	private Integer numGuia13;
	private Integer codSegmento13;
	private Date dataInfracao13;
	private Date dataVcto13;
	private BigDecimal valorMuta13;
	private String dadosMulta13;
	private String autoInfracao14;
	private Integer numGuia14;
	private Integer codSegmento14;
	private Date dataInfracao14;
	private Date dataVcto14;
	private BigDecimal valorMuta14;
	private String dadosMulta14;
	private String autoInfracao15;
	private Integer numGuia15;
	private Integer codSegmento15;
	private Date dataInfracao15;
	private Date dataVcto15;
	private BigDecimal valorMuta15;
	private String dadosMulta15;
	private String descErro;

	public DebitosPendentesVeiculosRenavamDTO() {
	}

	public String getCodigoMensajeOk() {
		return codigoMensajeOk;
	}

	public void setCodigoMensajeOk(String codigoMensajeOk) {
		this.codigoMensajeOk = codigoMensajeOk;
	}

	public Integer getCodServ() {
		return codServ;
	}

	public void setCodServ(Integer codServ) {
		this.codServ = codServ;
	}

	public String getRenavam() {
		return renavam;
	}

	public void setRenavam(String renavam) {
		this.renavam = renavam;
	}

	public String getDocumen() {
		return documen;
	}

	public void setDocumen(String documen) {
		this.documen = documen;
	}

	public String getPalca() {
		return palca;
	}

	public void setPalca(String palca) {
		this.palca = palca;
	}

	public Integer getMuniest() {
		return muniest;
	}

	public void setMuniest(Integer muniest) {
		this.muniest = muniest;
	}

	public Integer getMunifed() {
		return munifed;
	}

	public void setMunifed(Integer munifed) {
		this.munifed = munifed;
	}

	public String getNomePro() {
		return nomePro;
	}

	public void setNomePro(String nomePro) {
		this.nomePro = nomePro;
	}

	public String getUnidFed() {
		return unidFed;
	}

	public void setUnidFed(String unidFed) {
		this.unidFed = unidFed;
	}

	public Integer getOcoIPVA() {
		return ocoIPVA;
	}

	public void setOcoIPVA(Integer ocoIPVA) {
		this.ocoIPVA = ocoIPVA;
	}

	public Integer getOcoMult() {
		return ocoMult;
	}

	public void setOcoMult(Integer ocoMult) {
		this.ocoMult = ocoMult;
	}

	public String getAutentDigital() {
		return autentDigital;
	}

	public void setAutentDigital(String autentDigital) {
		this.autentDigital = autentDigital;
	}

	public Integer getAnoExer() {
		return anoExer;
	}

	public void setAnoExer(Integer anoExer) {
		this.anoExer = anoExer;
	}

	public Integer getIdenTex() {
		return idenTex;
	}

	public void setIdenTex(Integer idenTex) {
		this.idenTex = idenTex;
	}

	public Integer getCategDP() {
		return categDP;
	}

	public void setCategDP(Integer categDP) {
		this.categDP = categDP;
	}

	public BigDecimal getValDPV1() {
		return valDPV1;
	}

	public void setValDPV1(BigDecimal valDPV1) {
		this.valDPV1 = valDPV1;
	}

	public Integer getAnoExer2() {
		return anoExer2;
	}

	public void setAnoExer2(Integer anoExer2) {
		this.anoExer2 = anoExer2;
	}

	public Integer getIdenTex2() {
		return idenTex2;
	}

	public void setIdenTex2(Integer idenTex2) {
		this.idenTex2 = idenTex2;
	}

	public Integer getCategDP2() {
		return categDP2;
	}

	public void setCategDP2(Integer categDP2) {
		this.categDP2 = categDP2;
	}

	public BigDecimal getValDPV2() {
		return valDPV2;
	}

	public void setValDPV2(BigDecimal valDPV2) {
		this.valDPV2 = valDPV2;
	}

	public String getDadIPV1() {
		return dadIPV1;
	}

	public void setDadIPV1(String dadIPV1) {
		this.dadIPV1 = dadIPV1;
	}

	public BigDecimal getValIPV1() {
		return valIPV1;
	}

	public void setValIPV1(BigDecimal valIPV1) {
		this.valIPV1 = valIPV1;
	}

	public String getDadIPV2() {
		return dadIPV2;
	}

	public void setDadIPV2(String dadIPV2) {
		this.dadIPV2 = dadIPV2;
	}

	public BigDecimal getValIPV2() {
		return valIPV2;
	}

	public void setValIPV2(BigDecimal valIPV2) {
		this.valIPV2 = valIPV2;
	}

	public String getDadIPV3() {
		return dadIPV3;
	}

	public void setDadIPV3(String dadIPV3) {
		this.dadIPV3 = dadIPV3;
	}

	public BigDecimal getValIPV3() {
		return valIPV3;
	}

	public void setValIPV3(BigDecimal valIPV3) {
		this.valIPV3 = valIPV3;
	}

	public String getDadIPV4() {
		return dadIPV4;
	}

	public void setDadIPV4(String dadIPV4) {
		this.dadIPV4 = dadIPV4;
	}

	public BigDecimal getValIPV4() {
		return valIPV4;
	}

	public void setValIPV4(BigDecimal valIPV4) {
		this.valIPV4 = valIPV4;
	}

	public String getDadIPV5() {
		return dadIPV5;
	}

	public void setDadIPV5(String dadIPV5) {
		this.dadIPV5 = dadIPV5;
	}

	public BigDecimal getValIPV5() {
		return valIPV5;
	}

	public void setValIPV5(BigDecimal valIPV5) {
		this.valIPV5 = valIPV5;
	}

	public String getDadIPV6() {
		return dadIPV6;
	}

	public void setDadIPV6(String dadIPV6) {
		this.dadIPV6 = dadIPV6;
	}

	public BigDecimal getValIPV6() {
		return valIPV6;
	}

	public void setValIPV6(BigDecimal valIPV6) {
		this.valIPV6 = valIPV6;
	}

	public BigDecimal getTotIPVA() {
		return totIPVA;
	}

	public void setTotIPVA(BigDecimal totIPVA) {
		this.totIPVA = totIPVA;
	}

	public BigDecimal getTotDPVA() {
		return totDPVA;
	}

	public void setTotDPVA(BigDecimal totDPVA) {
		this.totDPVA = totDPVA;
	}

	public BigDecimal getTotMult() {
		return totMult;
	}

	public void setTotMult(BigDecimal totMult) {
		this.totMult = totMult;
	}

	public BigDecimal getTotDebi() {
		return totDebi;
	}

	public void setTotDebi(BigDecimal totDebi) {
		this.totDebi = totDebi;
	}

	public String getCodigoalfanum2() {
		return codigoalfanum2;
	}

	public void setCodigoalfanum2(String codigoalfanum2) {
		this.codigoalfanum2 = codigoalfanum2;
	}

	public String getCodigoalfanum4() {
		return codigoalfanum4;
	}

	public void setCodigoalfanum4(String codigoalfanum4) {
		this.codigoalfanum4 = codigoalfanum4;
	}

	public String getDesConv() {
		return desConv;
	}

	public void setDesConv(String desConv) {
		this.desConv = desConv;
	}

	public String getAutoInfracao1() {
		return autoInfracao1;
	}

	public void setAutoInfracao1(String autoInfracao1) {
		this.autoInfracao1 = autoInfracao1;
	}

	public Integer getNumGuia1() {
		return numGuia1;
	}

	public void setNumGuia1(Integer numGuia1) {
		this.numGuia1 = numGuia1;
	}

	public Integer getCodSegmento1() {
		return codSegmento1;
	}

	public void setCodSegmento1(Integer codSegmento1) {
		this.codSegmento1 = codSegmento1;
	}

	public Date getDataInfracao1() {
		return dataInfracao1;
	}

	public void setDataInfracao1(Date dataInfracao1) {
		this.dataInfracao1 = dataInfracao1;
	}

	public Date getDataVcto1() {
		return dataVcto1;
	}

	public void setDataVcto1(Date dataVcto1) {
		this.dataVcto1 = dataVcto1;
	}

	public BigDecimal getValorMuta1() {
		return valorMuta1;
	}

	public void setValorMuta1(BigDecimal valorMuta1) {
		this.valorMuta1 = valorMuta1;
	}

	public String getDadosMulta1() {
		return dadosMulta1;
	}

	public void setDadosMulta1(String dadosMulta1) {
		this.dadosMulta1 = dadosMulta1;
	}

	public String getAutoInfracao2() {
		return autoInfracao2;
	}

	public void setAutoInfracao2(String autoInfracao2) {
		this.autoInfracao2 = autoInfracao2;
	}

	public Integer getNumGuia2() {
		return numGuia2;
	}

	public void setNumGuia2(Integer numGuia2) {
		this.numGuia2 = numGuia2;
	}

	public Integer getCodSegmento2() {
		return codSegmento2;
	}

	public void setCodSegmento2(Integer codSegmento2) {
		this.codSegmento2 = codSegmento2;
	}

	public Date getDataInfracao2() {
		return dataInfracao2;
	}

	public void setDataInfracao2(Date dataInfracao2) {
		this.dataInfracao2 = dataInfracao2;
	}

	public Date getDataVcto2() {
		return dataVcto2;
	}

	public void setDataVcto2(Date dataVcto2) {
		this.dataVcto2 = dataVcto2;
	}

	public BigDecimal getValorMuta2() {
		return valorMuta2;
	}

	public void setValorMuta2(BigDecimal valorMuta2) {
		this.valorMuta2 = valorMuta2;
	}

	public String getDadosMulta2() {
		return dadosMulta2;
	}

	public void setDadosMulta2(String dadosMulta2) {
		this.dadosMulta2 = dadosMulta2;
	}

	public String getAutoInfracao3() {
		return autoInfracao3;
	}

	public void setAutoInfracao3(String autoInfracao3) {
		this.autoInfracao3 = autoInfracao3;
	}

	public Integer getNumGuia3() {
		return numGuia3;
	}

	public void setNumGuia3(Integer numGuia3) {
		this.numGuia3 = numGuia3;
	}

	public Integer getCodSegmento3() {
		return codSegmento3;
	}

	public void setCodSegmento3(Integer codSegmento3) {
		this.codSegmento3 = codSegmento3;
	}

	public Date getDataInfracao3() {
		return dataInfracao3;
	}

	public void setDataInfracao3(Date dataInfracao3) {
		this.dataInfracao3 = dataInfracao3;
	}

	public Date getDataVcto3() {
		return dataVcto3;
	}

	public void setDataVcto3(Date dataVcto3) {
		this.dataVcto3 = dataVcto3;
	}

	public BigDecimal getValorMuta3() {
		return valorMuta3;
	}

	public void setValorMuta3(BigDecimal valorMuta3) {
		this.valorMuta3 = valorMuta3;
	}

	public String getDadosMulta3() {
		return dadosMulta3;
	}

	public void setDadosMulta3(String dadosMulta3) {
		this.dadosMulta3 = dadosMulta3;
	}

	public String getAutoInfracao4() {
		return autoInfracao4;
	}

	public void setAutoInfracao4(String autoInfracao4) {
		this.autoInfracao4 = autoInfracao4;
	}

	public Integer getNumGuia4() {
		return numGuia4;
	}

	public void setNumGuia4(Integer numGuia4) {
		this.numGuia4 = numGuia4;
	}

	public Integer getCodSegmento4() {
		return codSegmento4;
	}

	public void setCodSegmento4(Integer codSegmento4) {
		this.codSegmento4 = codSegmento4;
	}

	public Date getDataInfracao4() {
		return dataInfracao4;
	}

	public void setDataInfracao4(Date dataInfracao4) {
		this.dataInfracao4 = dataInfracao4;
	}

	public Date getDataVcto4() {
		return dataVcto4;
	}

	public void setDataVcto4(Date dataVcto4) {
		this.dataVcto4 = dataVcto4;
	}

	public BigDecimal getValorMuta4() {
		return valorMuta4;
	}

	public void setValorMuta4(BigDecimal valorMuta4) {
		this.valorMuta4 = valorMuta4;
	}

	public String getDadosMulta4() {
		return dadosMulta4;
	}

	public void setDadosMulta4(String dadosMulta4) {
		this.dadosMulta4 = dadosMulta4;
	}

	public String getAutoInfracao5() {
		return autoInfracao5;
	}

	public void setAutoInfracao5(String autoInfracao5) {
		this.autoInfracao5 = autoInfracao5;
	}

	public Integer getNumGuia5() {
		return numGuia5;
	}

	public void setNumGuia5(Integer numGuia5) {
		this.numGuia5 = numGuia5;
	}

	public Integer getCodSegmento5() {
		return codSegmento5;
	}

	public void setCodSegmento5(Integer codSegmento5) {
		this.codSegmento5 = codSegmento5;
	}

	public Date getDataInfracao5() {
		return dataInfracao5;
	}

	public void setDataInfracao5(Date dataInfracao5) {
		this.dataInfracao5 = dataInfracao5;
	}

	public Date getDataVcto5() {
		return dataVcto5;
	}

	public void setDataVcto5(Date dataVcto5) {
		this.dataVcto5 = dataVcto5;
	}

	public BigDecimal getValorMuta5() {
		return valorMuta5;
	}

	public void setValorMuta5(BigDecimal valorMuta5) {
		this.valorMuta5 = valorMuta5;
	}

	public String getDadosMulta5() {
		return dadosMulta5;
	}

	public void setDadosMulta5(String dadosMulta5) {
		this.dadosMulta5 = dadosMulta5;
	}

	public String getAutoInfracao6() {
		return autoInfracao6;
	}

	public void setAutoInfracao6(String autoInfracao6) {
		this.autoInfracao6 = autoInfracao6;
	}

	public Integer getNumGuia6() {
		return numGuia6;
	}

	public void setNumGuia6(Integer numGuia6) {
		this.numGuia6 = numGuia6;
	}

	public Integer getCodSegmento6() {
		return codSegmento6;
	}

	public void setCodSegmento6(Integer codSegmento6) {
		this.codSegmento6 = codSegmento6;
	}

	public Date getDataInfracao6() {
		return dataInfracao6;
	}

	public void setDataInfracao6(Date dataInfracao6) {
		this.dataInfracao6 = dataInfracao6;
	}

	public Date getDataVcto6() {
		return dataVcto6;
	}

	public void setDataVcto6(Date dataVcto6) {
		this.dataVcto6 = dataVcto6;
	}

	public BigDecimal getValorMuta6() {
		return valorMuta6;
	}

	public void setValorMuta6(BigDecimal valorMuta6) {
		this.valorMuta6 = valorMuta6;
	}

	public String getDadosMulta6() {
		return dadosMulta6;
	}

	public void setDadosMulta6(String dadosMulta6) {
		this.dadosMulta6 = dadosMulta6;
	}

	public String getAutoInfracao7() {
		return autoInfracao7;
	}

	public void setAutoInfracao7(String autoInfracao7) {
		this.autoInfracao7 = autoInfracao7;
	}

	public Integer getNumGuia7() {
		return numGuia7;
	}

	public void setNumGuia7(Integer numGuia7) {
		this.numGuia7 = numGuia7;
	}

	public Integer getCodSegmento7() {
		return codSegmento7;
	}

	public void setCodSegmento7(Integer codSegmento7) {
		this.codSegmento7 = codSegmento7;
	}

	public Date getDataInfracao7() {
		return dataInfracao7;
	}

	public void setDataInfracao7(Date dataInfracao7) {
		this.dataInfracao7 = dataInfracao7;
	}

	public Date getDataVcto7() {
		return dataVcto7;
	}

	public void setDataVcto7(Date dataVcto7) {
		this.dataVcto7 = dataVcto7;
	}

	public BigDecimal getValorMuta7() {
		return valorMuta7;
	}

	public void setValorMuta7(BigDecimal valorMuta7) {
		this.valorMuta7 = valorMuta7;
	}

	public String getDadosMulta7() {
		return dadosMulta7;
	}

	public void setDadosMulta7(String dadosMulta7) {
		this.dadosMulta7 = dadosMulta7;
	}

	public String getAutoInfracao8() {
		return autoInfracao8;
	}

	public void setAutoInfracao8(String autoInfracao8) {
		this.autoInfracao8 = autoInfracao8;
	}

	public Integer getNumGuia8() {
		return numGuia8;
	}

	public void setNumGuia8(Integer numGuia8) {
		this.numGuia8 = numGuia8;
	}

	public Integer getCodSegmento8() {
		return codSegmento8;
	}

	public void setCodSegmento8(Integer codSegmento8) {
		this.codSegmento8 = codSegmento8;
	}

	public Date getDataInfracao8() {
		return dataInfracao8;
	}

	public void setDataInfracao8(Date dataInfracao8) {
		this.dataInfracao8 = dataInfracao8;
	}

	public Date getDataVcto8() {
		return dataVcto8;
	}

	public void setDataVcto8(Date dataVcto8) {
		this.dataVcto8 = dataVcto8;
	}

	public BigDecimal getValorMuta8() {
		return valorMuta8;
	}

	public void setValorMuta8(BigDecimal valorMuta8) {
		this.valorMuta8 = valorMuta8;
	}

	public String getDadosMulta8() {
		return dadosMulta8;
	}

	public void setDadosMulta8(String dadosMulta8) {
		this.dadosMulta8 = dadosMulta8;
	}

	public String getAutoInfracao9() {
		return autoInfracao9;
	}

	public void setAutoInfracao9(String autoInfracao9) {
		this.autoInfracao9 = autoInfracao9;
	}

	public Integer getNumGuia9() {
		return numGuia9;
	}

	public void setNumGuia9(Integer numGuia9) {
		this.numGuia9 = numGuia9;
	}

	public Integer getCodSegmento9() {
		return codSegmento9;
	}

	public void setCodSegmento9(Integer codSegmento9) {
		this.codSegmento9 = codSegmento9;
	}

	public Date getDataInfracao9() {
		return dataInfracao9;
	}

	public void setDataInfracao9(Date dataInfracao9) {
		this.dataInfracao9 = dataInfracao9;
	}

	public Date getDataVcto9() {
		return dataVcto9;
	}

	public void setDataVcto9(Date dataVcto9) {
		this.dataVcto9 = dataVcto9;
	}

	public BigDecimal getValorMuta9() {
		return valorMuta9;
	}

	public void setValorMuta9(BigDecimal valorMuta9) {
		this.valorMuta9 = valorMuta9;
	}

	public String getDadosMulta9() {
		return dadosMulta9;
	}

	public void setDadosMulta9(String dadosMulta9) {
		this.dadosMulta9 = dadosMulta9;
	}

	public String getAutoInfracao10() {
		return autoInfracao10;
	}

	public void setAutoInfracao10(String autoInfracao10) {
		this.autoInfracao10 = autoInfracao10;
	}

	public Integer getNumGuia10() {
		return numGuia10;
	}

	public void setNumGuia10(Integer numGuia10) {
		this.numGuia10 = numGuia10;
	}

	public Integer getCodSegmento10() {
		return codSegmento10;
	}

	public void setCodSegmento10(Integer codSegmento10) {
		this.codSegmento10 = codSegmento10;
	}

	public Date getDataInfracao10() {
		return dataInfracao10;
	}

	public void setDataInfracao10(Date dataInfracao10) {
		this.dataInfracao10 = dataInfracao10;
	}

	public Date getDataVcto10() {
		return dataVcto10;
	}

	public void setDataVcto10(Date dataVcto10) {
		this.dataVcto10 = dataVcto10;
	}

	public BigDecimal getValorMuta10() {
		return valorMuta10;
	}

	public void setValorMuta10(BigDecimal valorMuta10) {
		this.valorMuta10 = valorMuta10;
	}

	public String getDadosMulta10() {
		return dadosMulta10;
	}

	public void setDadosMulta10(String dadosMulta10) {
		this.dadosMulta10 = dadosMulta10;
	}

	public String getAutoInfracao11() {
		return autoInfracao11;
	}

	public void setAutoInfracao11(String autoInfracao11) {
		this.autoInfracao11 = autoInfracao11;
	}

	public Integer getNumGuia11() {
		return numGuia11;
	}

	public void setNumGuia11(Integer numGuia11) {
		this.numGuia11 = numGuia11;
	}

	public Integer getCodSegmento11() {
		return codSegmento11;
	}

	public void setCodSegmento11(Integer codSegmento11) {
		this.codSegmento11 = codSegmento11;
	}

	public Date getDataInfracao11() {
		return dataInfracao11;
	}

	public void setDataInfracao11(Date dataInfracao11) {
		this.dataInfracao11 = dataInfracao11;
	}

	public Date getDataVcto11() {
		return dataVcto11;
	}

	public void setDataVcto11(Date dataVcto11) {
		this.dataVcto11 = dataVcto11;
	}

	public BigDecimal getValorMuta11() {
		return valorMuta11;
	}

	public void setValorMuta11(BigDecimal valorMuta11) {
		this.valorMuta11 = valorMuta11;
	}

	public String getDadosMulta11() {
		return dadosMulta11;
	}

	public void setDadosMulta11(String dadosMulta11) {
		this.dadosMulta11 = dadosMulta11;
	}

	public String getAutoInfracao12() {
		return autoInfracao12;
	}

	public void setAutoInfracao12(String autoInfracao12) {
		this.autoInfracao12 = autoInfracao12;
	}

	public Integer getNumGuia12() {
		return numGuia12;
	}

	public void setNumGuia12(Integer numGuia12) {
		this.numGuia12 = numGuia12;
	}

	public Integer getCodSegmento12() {
		return codSegmento12;
	}

	public void setCodSegmento12(Integer codSegmento12) {
		this.codSegmento12 = codSegmento12;
	}

	public Date getDataInfracao12() {
		return dataInfracao12;
	}

	public void setDataInfracao12(Date dataInfracao12) {
		this.dataInfracao12 = dataInfracao12;
	}

	public Date getDataVcto12() {
		return dataVcto12;
	}

	public void setDataVcto12(Date dataVcto12) {
		this.dataVcto12 = dataVcto12;
	}

	public BigDecimal getValorMuta12() {
		return valorMuta12;
	}

	public void setValorMuta12(BigDecimal valorMuta12) {
		this.valorMuta12 = valorMuta12;
	}

	public String getDadosMulta12() {
		return dadosMulta12;
	}

	public void setDadosMulta12(String dadosMulta12) {
		this.dadosMulta12 = dadosMulta12;
	}

	public String getAutoInfracao13() {
		return autoInfracao13;
	}

	public void setAutoInfracao13(String autoInfracao13) {
		this.autoInfracao13 = autoInfracao13;
	}

	public Integer getNumGuia13() {
		return numGuia13;
	}

	public void setNumGuia13(Integer numGuia13) {
		this.numGuia13 = numGuia13;
	}

	public Integer getCodSegmento13() {
		return codSegmento13;
	}

	public void setCodSegmento13(Integer codSegmento13) {
		this.codSegmento13 = codSegmento13;
	}

	public Date getDataInfracao13() {
		return dataInfracao13;
	}

	public void setDataInfracao13(Date dataInfracao13) {
		this.dataInfracao13 = dataInfracao13;
	}

	public Date getDataVcto13() {
		return dataVcto13;
	}

	public void setDataVcto13(Date dataVcto13) {
		this.dataVcto13 = dataVcto13;
	}

	public BigDecimal getValorMuta13() {
		return valorMuta13;
	}

	public void setValorMuta13(BigDecimal valorMuta13) {
		this.valorMuta13 = valorMuta13;
	}

	public String getDadosMulta13() {
		return dadosMulta13;
	}

	public void setDadosMulta13(String dadosMulta13) {
		this.dadosMulta13 = dadosMulta13;
	}

	public String getAutoInfracao14() {
		return autoInfracao14;
	}

	public void setAutoInfracao14(String autoInfracao14) {
		this.autoInfracao14 = autoInfracao14;
	}

	public Integer getNumGuia14() {
		return numGuia14;
	}

	public void setNumGuia14(Integer numGuia14) {
		this.numGuia14 = numGuia14;
	}

	public Integer getCodSegmento14() {
		return codSegmento14;
	}

	public void setCodSegmento14(Integer codSegmento14) {
		this.codSegmento14 = codSegmento14;
	}

	public Date getDataInfracao14() {
		return dataInfracao14;
	}

	public void setDataInfracao14(Date dataInfracao14) {
		this.dataInfracao14 = dataInfracao14;
	}

	public Date getDataVcto14() {
		return dataVcto14;
	}

	public void setDataVcto14(Date dataVcto14) {
		this.dataVcto14 = dataVcto14;
	}

	public BigDecimal getValorMuta14() {
		return valorMuta14;
	}

	public void setValorMuta14(BigDecimal valorMuta14) {
		this.valorMuta14 = valorMuta14;
	}

	public String getDadosMulta14() {
		return dadosMulta14;
	}

	public void setDadosMulta14(String dadosMulta14) {
		this.dadosMulta14 = dadosMulta14;
	}

	public String getAutoInfracao15() {
		return autoInfracao15;
	}

	public void setAutoInfracao15(String autoInfracao15) {
		this.autoInfracao15 = autoInfracao15;
	}

	public Integer getNumGuia15() {
		return numGuia15;
	}

	public void setNumGuia15(Integer numGuia15) {
		this.numGuia15 = numGuia15;
	}

	public Integer getCodSegmento15() {
		return codSegmento15;
	}

	public void setCodSegmento15(Integer codSegmento15) {
		this.codSegmento15 = codSegmento15;
	}

	public Date getDataInfracao15() {
		return dataInfracao15;
	}

	public void setDataInfracao15(Date dataInfracao15) {
		this.dataInfracao15 = dataInfracao15;
	}

	public Date getDataVcto15() {
		return dataVcto15;
	}

	public void setDataVcto15(Date dataVcto15) {
		this.dataVcto15 = dataVcto15;
	}

	public BigDecimal getValorMuta15() {
		return valorMuta15;
	}

	public void setValorMuta15(BigDecimal valorMuta15) {
		this.valorMuta15 = valorMuta15;
	}

	public String getDadosMulta15() {
		return dadosMulta15;
	}

	public void setDadosMulta15(String dadosMulta15) {
		this.dadosMulta15 = dadosMulta15;
	}

	public String getDescErro() {
		return descErro;
	}

	public void setDescErro(String descErro) {
		this.descErro = descErro;
	}
}
