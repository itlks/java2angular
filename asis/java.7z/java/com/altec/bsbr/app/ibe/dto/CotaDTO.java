package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

import com.altec.bsbr.app.ibe.enumeration.TipoPagamentoCotaEnum;

public class CotaDTO implements Serializable {
	private static final long serialVersionUID = 375005512539592204L;

	private String id;
	private Integer index;
	private String dataVencimento;
	private Double valor;
	private Integer parcela;
	private ExercicioDTO exercicioDTO;
	private String anoExercio;
	private String descricao;
	
	public CotaDTO() {
	}

	public CotaDTO(String dataVencimento, Double valor, Integer parcela) {
		this.dataVencimento = dataVencimento;
		this.valor = valor;
		this.parcela = parcela;	
	}
	
	public CotaDTO(Integer index, Double valor, Integer parcela, String descricao){
		this.index = index;
		this.valor = valor;
		this.parcela = parcela;
		this.descricao = descricao;
	}
	
	public CotaDTO(Integer index, Double valor){
		this.index = index;
		this.valor = valor;
	}
	
	public CotaDTO(String dataVencimento, Double valor, Integer parcela, String anoExercio) {
		this.dataVencimento = dataVencimento;
		this.valor = valor;
		this.parcela = parcela;
		this.anoExercio = anoExercio;
	}
	
	public CotaDTO(String id, String dataVencimento, Double valor, Integer parcela, String anoExercio) {
		this.id = id;
		this.dataVencimento = dataVencimento;
		this.valor = valor;
		this.parcela = parcela;
		this.anoExercio = anoExercio;
	}
	
	public CotaDTO(Integer index, String id, String dataVencimento, Double valor, Integer parcela, String anoExercio) {
		this.index = index;
		this.id = id;
		this.dataVencimento = dataVencimento;
		this.valor = valor;
		this.parcela = parcela;
		this.anoExercio = anoExercio;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDataVencimento() {
		return dataVencimento;
	}

	public void setDataVencimento(String dataVencimento) {
		this.dataVencimento = dataVencimento;
	}

	public Double getValor() {
		return valor;
	}

	public void setValor(Double valor) {
		this.valor = valor;
	}

	public Integer getParcela() {
		return parcela;
	}

	public void setParcela(Integer parcela) {
		this.parcela = parcela;
	}
	
	public String getDescricaoCota(String icoTuni) {
		if (this.parcela==0) {
			TipoPagamentoCotaEnum enumCota = TipoPagamentoCotaEnum.buscarPorIndicador(icoTuni);
			return (enumCota == null ? "" : enumCota.getDescricao());			
		}	
		else {
			return " " + parcela + "� Parcela";
		}		
	}	 

	public ExercicioDTO getExercicioDTO() {
		return exercicioDTO;
	}

	public void setExercicioDTO(ExercicioDTO exercicioDTO) {
		this.exercicioDTO = exercicioDTO;
	}

	public String getAnoExercio() {
		return anoExercio;
	}

	public void setAnoExercio(String anoExercio) {
		this.anoExercio = anoExercio;
	}

	public Integer getIndex() {
		return index;
	}

	public void setIndex(Integer index) {
		this.index = index;
	}

	public String getDescricao() {
		if(descricao==null) {
			return descricao;
		}
		return descricao.replace("a. p", "� p");
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dataVencimento == null) ? 0 : dataVencimento.hashCode());
		result = prime * result + ((parcela == null) ? 0 : parcela.hashCode());
		result = prime * result + ((valor == null) ? 0 : valor.hashCode());		
		result = prime * result + ((anoExercio == null) ? 0 : anoExercio.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		
		if (obj == null) {
			return false;
		}
		
		if (!(obj instanceof CotaDTO)) {
			return this.isEqualsExercicioDTO(obj);
		}
		
		CotaDTO other = (CotaDTO) obj;
		if (dataVencimento == null) {
			if (other.dataVencimento != null) {
				return false;
			}
		} else if (!dataVencimento.equals(other.dataVencimento)) {
			return false;
		}
		
		if (parcela == null) {
			if (other.parcela != null) {
				return false;
			}
		} else if (!parcela.equals(other.parcela)) {
			return false;
		}
		
		if (valor == null) {
			if (other.valor != null) {
				return false;
			}
		} else if (!valor.equals(other.valor)) {
			return false;
		}
		
		if (anoExercio == null) {
			if (other.anoExercio != null) {
				return false;
			}
		} else if (!anoExercio.equals(other.anoExercio)) {
			return false;
		}
				
		return true;
	}
	
	/*
	 * Metodo utilizado para verificacao de igualdade nos itens do <p:selectOneRadio>
	 * na pagina veiculosIpvaConsultaOnline.xhtml, pois o primeiro item da lista e do
	 * tipo ExercicioDTO e o objeto gerado pelo CotaDTOIpvaRadioConverter.java e do tipo
	 * CotaDTO.
	 */
	private boolean isEqualsExercicioDTO(Object obj) {
		if (obj instanceof ExercicioDTO) {
			ExercicioDTO other = (ExercicioDTO) obj;
			if (dataVencimento == null) {
				if (other.getVencimento() != null) {
					return false;
				}
			} else if (!dataVencimento.equals(other.getVencimento())) {
				return false;
			}
			
			if (parcela == null) {
				return false;
			} else if (parcela != 0) {
				return false;
			}
			
			if (valor == null) {
				if (other.getValorTotal() != null) {
					return false;
				}
			} else if (!valor.equals(other.getValorTotal())) {
				return false;
			}					
			
			return true;
			
		} else {
			return false;
		}
	}
}