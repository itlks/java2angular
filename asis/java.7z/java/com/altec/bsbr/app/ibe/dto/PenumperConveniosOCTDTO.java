package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.List;

public class PenumperConveniosOCTDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private List<ItemPenumperConveniosOCTDTO> listaItemPenumperOCT;

	public List<ItemPenumperConveniosOCTDTO> getListaItemPenumper() {
		return listaItemPenumperOCT;
	}

	public void setListaItemPenumper(List<ItemPenumperConveniosOCTDTO> listaItemPenumperOCT) {
		this.listaItemPenumperOCT = listaItemPenumperOCT;
	}

}
