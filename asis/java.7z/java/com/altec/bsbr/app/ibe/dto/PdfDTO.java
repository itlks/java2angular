package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class PdfDTO implements Serializable {
	
	private static final long serialVersionUID = 1730975894443471999L;
	
	private byte[] file;
	
	public PdfDTO(byte[] file){
		setFile(file);
	}
	
	public byte[] getFile() {
		return file;
	}
	public void setFile(byte[] file) {
		this.file = file;
	}

}
