package com.altec.bsbr.app.ibe.enumeration;

import org.apache.commons.lang3.StringUtils;

public enum HistoricoCompromossoComplCashEnum {
	
	DIVIDENDOS 			("0013", "Dividendos"),
	LIQVENCIMENTOS 		("0021", "L�quido de Vencimentos"),
	SINISTRO 			("0091", "Pagamento de Sinistro"),
	DESPESAS 			("0109", "Pagamento de Despesas"),
	AUTORIZADOS 		("0137", "Pagamento a Repres/Vend Autorizados"),
	INSS 				("0149", "Pagamento de Benef�cios do INSS"),
	FORNECEDORES 		("0183", "Pagamento a Fornecedores"),
	EMPCONVENIADAS 		("0295", "Pagamento Credenc Empr Conveniadas Visado"),
	DEVLANCAMENTOS 		("0197", "Devolu��o de Lan�amentos"),
	DEVCIPTITU 			("0471", "Devolu��o TED CIP Mesma Titularidade"),
	DEVTEDCIP 			("0475", "Devolu��o TED CIP"),
	DEVTEDSTR 			("0479", "Devolu��o TED STR"),
	DEVSTRTITU 			("0483", "Devolu��o STR Mesma Titularidade"),
	DEVTITUBANCO 		("2023", "Devolu��o T�tulo Outro Banco"),
	DEVTITUSANTANDER 	("2024", "Devolu��o T�tulo do Santander"),
	DEVDOCD 			("2021", "Devolu��o DOC D"),
	DEVDOCE			 	("2022", "Devolu��o DOC E");
		
	private String codigo;
	private String descricao;

	private HistoricoCompromossoComplCashEnum(String codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}
	
	public static String findDescricaoByCodigo(String codigo) {
		String descricao = " ";
		if (StringUtils.isNotBlank(codigo) ) {
			for (HistoricoCompromossoComplCashEnum item : values()) {
				if (item.codigo.equals(codigo)) {
					return item.descricao;
				}
			}
		}
		return descricao;
	}
}