package com.altec.bsbr.app.ibe.dto;

import java.math.BigDecimal;

public class DadosPosicaoConsolidadaGrupoDTO {
	private String nomeDoProduto; 
	private String tipoOOuC; 
	private BigDecimal vltotalPendente; 
	private Integer qttotalPendente; 
	private BigDecimal vltotalAutorizada; 
	private Integer qttotalAutorizada; 
	private BigDecimal vltotalCancelada; 
	private Integer qttotalCancelada;
	
	public String getNomeDoProduto() {
		return nomeDoProduto;
	}
	public void setNomeDoProduto(String nomeDoProduto) {
		this.nomeDoProduto = nomeDoProduto;
	}
	public String getTipoOOuC() {
		return tipoOOuC;
	}
	public void setTipoOOuC(String tipoOOuC) {
		this.tipoOOuC = tipoOOuC;
	}
	public BigDecimal getVltotalPendente() {
		return vltotalPendente;
	}
	public Integer getQttotalPendente() {
		return qttotalPendente;
	}
	public void setQttotalPendente(Integer qttotalPendente) {
		this.qttotalPendente = qttotalPendente;
	}
	public BigDecimal getVltotalAutorizada() {
		return vltotalAutorizada;
	}
	public void setVltotalAutorizada(BigDecimal vltotalAutorizada) {
		this.vltotalAutorizada = vltotalAutorizada;
	}
	public Integer getQttotalAutorizada() {
		return qttotalAutorizada;
	}
	public void setQttotalAutorizada(Integer qttotalAutorizada) {
		this.qttotalAutorizada = qttotalAutorizada;
	}
	public BigDecimal getVltotalCancelada() {
		return vltotalCancelada;
	}
	public void setVltotalCancelada(BigDecimal vltotalCancelada) {
		this.vltotalCancelada = vltotalCancelada;
	}
	public Integer getQttotalCancelada() {
		return qttotalCancelada;
	}
	public void setQttotalCancelada(Integer qttotalCancelada) {
		this.qttotalCancelada = qttotalCancelada;
	}
	public void setVltotalPendente(BigDecimal vltotalPendente) {
		this.vltotalPendente = vltotalPendente;
	}
	
	
	
}
