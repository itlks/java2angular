package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.Date;

public class ManutencaoUsuarioMasterDTO implements Serializable {


	private static final long serialVersionUID = -9004915114244947356L;
	
	private String nomeAcesso;
	private String nomeCompleto;
	private String cpf;
	private String email;
	private String telefoneDdd;
	private String telefoneNumero;
	private String telefoneRamal;
	private String inStatusUsuario;
	private Date dtInclusaoUsuario;
	private Date dtUltimoAcessoUsuario;
	private Date dtUltimaAlteracaoSenha;
	private String pergutaResposta;
	private String situacaoAcessoUsuario;
	private String statusSenhaAcesso;
	private String statusAssinaturaEletronica;
	private String statusMobileToken;
	private boolean excluir;
	private boolean novoUsuarioMaster;
	
	/**
	 * @return the nomeAcesso
	 */
	public String getNomeAcesso() {
		return nomeAcesso;
	}
	/**
	 * @param nomeAcesso the nomeAcesso to set
	 */
	public void setNomeAcesso(String nomeAcesso) {
		this.nomeAcesso = nomeAcesso;
	}
	/**
	 * @return the nomeCompleto
	 */
	public String getNomeCompleto() {
		return nomeCompleto;
	}
	/**
	 * @param nomeCompleto the nomeCompleto to set
	 */
	public void setNomeCompleto(String nomeCompleto) {
		this.nomeCompleto = nomeCompleto;
	}
	/**
	 * @return the cpf
	 */
	public String getCpf() {
		return cpf;
	}
	/**
	 * @param cpf the cpf to set
	 */
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return the telefoneDdd
	 */
	public String getTelefoneDdd() {
		return telefoneDdd;
	}
	/**
	 * @param telefoneDdd the telefoneDdd to set
	 */
	public void setTelefoneDdd(String telefoneDdd) {
		this.telefoneDdd = telefoneDdd;
	}
	/**
	 * @return the telefoneNumero
	 */
	public String getTelefoneNumero() {
		return telefoneNumero;
	}
	/**
	 * @param telefoneNumero the telefoneNumero to set
	 */
	public void setTelefoneNumero(String telefoneNumero) {
		this.telefoneNumero = telefoneNumero;
	}
	/**
	 * @return the telefoneRamal
	 */
	public String getTelefoneRamal() {
		return telefoneRamal;
	}
	/**
	 * @param telefoneRamal the telefoneRamal to set
	 */
	public void setTelefoneRamal(String telefoneRamal) {
		this.telefoneRamal = telefoneRamal;
	}
	/**
	 * @return the inStatusUsuario
	 */
	public String getInStatusUsuario() {
		return inStatusUsuario;
	}
	/**
	 * @param inStatusUsuario the inStatusUsuario to set
	 */
	public void setInStatusUsuario(String inStatusUsuario) {
		this.inStatusUsuario = inStatusUsuario;
	}
	/**
	 * @return the dtInclusaoUsuario
	 */
	public Date getDtInclusaoUsuario() {
		return dtInclusaoUsuario;
	}
	/**
	 * @param dtInclusaoUsuario the dtInclusaoUsuario to set
	 */
	public void setDtInclusaoUsuario(Date dtInclusaoUsuario) {
		this.dtInclusaoUsuario = dtInclusaoUsuario;
	}
	/**
	 * @return the dtUltimoAcessoUsuario
	 */
	public Date getDtUltimoAcessoUsuario() {
		return dtUltimoAcessoUsuario;
	}
	/**
	 * @param dtUltimoAcessoUsuario the dtUltimoAcessoUsuario to set
	 */
	public void setDtUltimoAcessoUsuario(Date dtUltimoAcessoUsuario) {
		this.dtUltimoAcessoUsuario = dtUltimoAcessoUsuario;
	}
	/**
	 * @return the dtUltimaAlteracaoSenha
	 */
	public Date getDtUltimaAlteracaoSenha() {
		return dtUltimaAlteracaoSenha;
	}
	/**
	 * @param dtUltimaAlteracaoSenha the dtUltimaAlteracaoSenha to set
	 */
	public void setDtUltimaAlteracaoSenha(Date dtUltimaAlteracaoSenha) {
		this.dtUltimaAlteracaoSenha = dtUltimaAlteracaoSenha;
	}
	/**
	 * @return the pergutaResposta
	 */
	public String getPergutaResposta() {
		return pergutaResposta;
	}
	/**
	 * @param pergutaResposta the pergutaResposta to set
	 */
	public void setPergutaResposta(String pergutaResposta) {
		this.pergutaResposta = pergutaResposta;
	}
	/**
	 * @return the situacaoAcessoUsuario
	 */
	public String getSituacaoAcessoUsuario() {
		return situacaoAcessoUsuario;
	}
	/**
	 * @param situacaoAcessoUsuario the situacaoAcessoUsuario to set
	 */
	public void setSituacaoAcessoUsuario(String situacaoAcessoUsuario) {
		this.situacaoAcessoUsuario = situacaoAcessoUsuario;
	}
	/**
	 * @return the statusSenhaAcesso
	 */
	public String getStatusSenhaAcesso() {
		return statusSenhaAcesso;
	}
	/**
	 * @param statusSenhaAcesso the statusSenhaAcesso to set
	 */
	public void setStatusSenhaAcesso(String statusSenhaAcesso) {
		this.statusSenhaAcesso = statusSenhaAcesso;
	}
	/**
	 * @return the statusAssinaturaEletronica
	 */
	public String getStatusAssinaturaEletronica() {
		return statusAssinaturaEletronica;
	}
	/**
	 * @param statusAssinaturaEletronica the statusAssinaturaEletronica to set
	 */
	public void setStatusAssinaturaEletronica(String statusAssinaturaEletronica) {
		this.statusAssinaturaEletronica = statusAssinaturaEletronica;
	}
	/**
	 * @return the statusMobileToken
	 */
	public String getStatusMobileToken() {
		return statusMobileToken;
	}
	/**
	 * @param statusMobileToken the statusMobileToken to set
	 */
	public void setStatusMobileToken(String statusMobileToken) {
		this.statusMobileToken = statusMobileToken;
	}
	/**
	 * @return the excluir
	 */
	public boolean getExcluir() {
		return excluir;
	}
	/**
	 * @param excluir the excluir to set
	 */
	public void setExcluir(boolean excluir) {
		this.excluir = excluir;
	}
	public boolean getNovoUsuarioMaster() {
		return novoUsuarioMaster;
	}
	public void setNovoUsuarioMaster(boolean novoUsuarioMaster) {
		this.novoUsuarioMaster = novoUsuarioMaster;
	}
	
	

}
