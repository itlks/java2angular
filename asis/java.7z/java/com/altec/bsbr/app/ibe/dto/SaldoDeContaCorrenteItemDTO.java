package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.List;

public class SaldoDeContaCorrenteItemDTO implements Serializable {

	private static final long serialVersionUID = 726630466141688175L;
	
	private static final String IMG_PLUS = "../../../images/u34.png";
	private static final String IMG_MINUS = "../../../images/u36.png";
	private static final String IMG_INFO = "../../../images/icon-i.png";

	private String descricao;
	private String valor;
	private String aviso;
	private List<SaldoDeContaCorrenteItemDTO> detalhes;
	private boolean exibeDetalhes;

	public SaldoDeContaCorrenteItemDTO() {
		//empty
	}

	public SaldoDeContaCorrenteItemDTO(String descricao, String valor) {
		this(descricao, valor, "", null);
	}

	public SaldoDeContaCorrenteItemDTO(String descricao, String valor, String aviso) {
		this(descricao, valor, aviso, null);
	}

	public SaldoDeContaCorrenteItemDTO(String descricao, String valor, List<SaldoDeContaCorrenteItemDTO> detalhes) {
		this(descricao, valor, "", detalhes);
	}
	
	public SaldoDeContaCorrenteItemDTO(String descricao, String valor, String aviso, List<SaldoDeContaCorrenteItemDTO> detalhes) {
		this.descricao = descricao;
		this.valor = valor;
		this.aviso = aviso;
		this.detalhes = detalhes;
		this.exibeDetalhes = true;
	}

	public void toggleExibeDetalhes() {
		this.exibeDetalhes = !this.exibeDetalhes;
	}

	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}

	/**
	 * @param descricao
	 *            the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	/**
	 * @return the valor
	 */
	public String getValor() {
		return valor;
	}

	/**
	 * @param valor
	 *            the valor to set
	 */
	public void setValor(String valor) {
		this.valor = valor;
	}

	/**
	 * @return the aviso
	 */
	public String getAviso() {
		return aviso;
	}

	/**
	 * @param aviso
	 *            the aviso to set
	 */
	public void setAviso(String aviso) {
		this.aviso = aviso;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/**
	 * @return the detalhes
	 */
	public List<SaldoDeContaCorrenteItemDTO> getDetalhes() {
		return detalhes;
	}

	/**
	 * @param detalhes
	 *            the detalhes to set
	 */
	public void setDetalhes(List<SaldoDeContaCorrenteItemDTO> detalhes) {
		this.detalhes = detalhes;
	}

	/**
	 * @return the exibeDetalhes
	 */
	public boolean isExibeDetalhes() {
		return exibeDetalhes;
	}

	/**
	 * @param exibeDetalhes
	 *            the exibeDetalhes to set
	 */
	public void setExibeDetalhes(boolean exibeDetalhes) {
		this.exibeDetalhes = exibeDetalhes;
	}
	
	public String getImagemExpandCollapse(Boolean condicao) {
		return condicao ? IMG_MINUS : IMG_PLUS;
	}
	
	public String getImagemInfoIcon() {
		return IMG_INFO;
	}

}
