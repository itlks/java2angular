package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;

import com.altec.bsbr.app.ibe.dto.clsfinancashvisa.ListaResumoOperRSDTO;

public class ListaResumoOperDTO implements Serializable {
	
	private static final long serialVersionUID = -413125757091150271L;
	/**
	 * Atributos
	 */
	private ListaResumoOperRSDTO listaResumoOperRSDTO;
	/* Foram adicionados apenas os getter e setters dos atributos utilizados. Caso necess�rio adicionar restante */
	private String dtVencTitu;
	private String codBandeira;
	private BigDecimal vlrTituloAtual;
	private String nrEstabelecimento;
	private String valorTituloAtual;

	/**
	 * Getters e Setters respectivos
	 */
	
	public ListaResumoOperRSDTO getListaResumoOperRSDTO() {
		return listaResumoOperRSDTO;
	}
	public void setListaResumoOperRSDTO(ListaResumoOperRSDTO listaResumoOperRSDTO) {
		this.listaResumoOperRSDTO = listaResumoOperRSDTO;
	}
	public String getDtVencTitu() {
		return dtVencTitu;
	}
	public void setDtVencTitu(String dtVencTitu) {
		this.dtVencTitu = dtVencTitu;
	}
	public String getCodBandeira() {
		return codBandeira;
	}
	public void setCodBandeira(String codBandeira) {
		this.codBandeira = codBandeira;
	}
	public BigDecimal getVlrTituloAtual() {
		return vlrTituloAtual;
	}
	public void setVlrTituloAtual(BigDecimal vlrTituloAtual) {
		this.vlrTituloAtual = vlrTituloAtual;
	}
	public String getNrEstabelecimento() {
		return nrEstabelecimento;
	}
	public void setNrEstabelecimento(String nrEstabelecimento) {
		this.nrEstabelecimento = nrEstabelecimento;
	}
	/**
	 * @return the valorTituloAtual
	 */
	public String getValorTituloAtual() {
		return valorTituloAtual;
	}
	/**
	 * @param valorTituloAtual the valorTituloAtual to set
	 */
	public void setValorTituloAtual(String valorTituloAtual) {
		this.valorTituloAtual = valorTituloAtual;
	}
	
	
}
