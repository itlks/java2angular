package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class OperacoesRealizadasDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7821629846781139979L;

	private String banco;
	
	private String agencia;
	
	private String conta;

	private String agenciade;

	private String contade;

	private String usuario;

	private Integer tipocna;

	private String tipoescolha;

	private String datainicio;
	
	private String datafim;
	
	// detalhe transacao
	private OperacoesRealizadaTransacaoDTO detalheOperacaoRealizadaDTO;
	
	private OperacoesRealizadaTransacaoResponseDTO detalheOperacaoRealizadaResponseDTO;
	
	private ItemConsultarTransacaoTipoOperacoesDTO itemOperacoesRealizadaDTO;
	
	
	/**
	 * @return the itemOperacoesRealizadaDTO
	 */
	public ItemConsultarTransacaoTipoOperacoesDTO getItemOperacoesRealizadaDTO() {
		return itemOperacoesRealizadaDTO;
	}



	/**
	 * @param itemOperacoesRealizadaDTO the itemOperacoesRealizadaDTO to set
	 */
	public void setItemOperacoesRealizadaDTO(ItemConsultarTransacaoTipoOperacoesDTO itemOperacoesRealizadaDTO) {
		this.itemOperacoesRealizadaDTO = itemOperacoesRealizadaDTO;
	}



	/**
	 * @return the detalheOperacaoRealizadaDTO
	 */
	public OperacoesRealizadaTransacaoDTO getDetalheOperacaoRealizadaDTO() {
		return detalheOperacaoRealizadaDTO;
	}



	/**
	 * @param detalheOperacaoRealizadaDTO the detalheOperacaoRealizadaDTO to set
	 */
	public void setDetalheOperacaoRealizadaDTO(OperacoesRealizadaTransacaoDTO detalheOperacaoRealizadaDTO) {
		this.detalheOperacaoRealizadaDTO = detalheOperacaoRealizadaDTO;
	}



	/**
	 * @return the detalheOperacaoRealizadaResponseDTO
	 */
	public OperacoesRealizadaTransacaoResponseDTO getDetalheOperacaoRealizadaResponseDTO() {
		return detalheOperacaoRealizadaResponseDTO;
	}



	/**
	 * @param detalheOperacaoRealizadaResponseDTO the detalheOperacaoRealizadaResponseDTO to set
	 */
	public void setDetalheOperacaoRealizadaResponseDTO(
			OperacoesRealizadaTransacaoResponseDTO detalheOperacaoRealizadaResponseDTO) {
		this.detalheOperacaoRealizadaResponseDTO = detalheOperacaoRealizadaResponseDTO;
	}



	/**
	 * @return the banco
	 */
	public String getBanco() {
		return banco;
	}



	/**
	 * @param banco the banco to set
	 */
	public void setBanco(String banco) {
		this.banco = banco;
	}



	/**
	 * @return the agencia
	 */
	public String getAgencia() {
		return agencia;
	}



	/**
	 * @param agencia the agencia to set
	 */
	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}



	/**
	 * @return the conta
	 */
	public String getConta() {
		return conta;
	}



	/**
	 * @param conta the conta to set
	 */
	public void setConta(String conta) {
		this.conta = conta;
	}



	/**
	 * @return the agenciade
	 */
	public String getAgenciade() {
		return agenciade;
	}



	/**
	 * @param agenciade the agenciade to set
	 */
	public void setAgenciade(String agenciade) {
		this.agenciade = agenciade;
	}



	/**
	 * @return the contade
	 */
	public String getContade() {
		return contade;
	}



	/**
	 * @param contade the contade to set
	 */
	public void setContade(String contade) {
		this.contade = contade;
	}



	/**
	 * @return the usuario
	 */
	public String getUsuario() {
		return usuario;
	}



	/**
	 * @param usuario the usuario to set
	 */
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}



	/**
	 * @return the tipocna
	 */
	public Integer getTipocna() {
		return tipocna;
	}



	/**
	 * @param tipocna the tipocna to set
	 */
	public void setTipocna(Integer tipocna) {
		this.tipocna = tipocna;
	}



	/**
	 * @return the tipoescolha
	 */
	public String getTipoescolha() {
		return tipoescolha;
	}



	/**
	 * @param tipoescolha the tipoescolha to set
	 */
	public void setTipoescolha(String tipoescolha) {
		this.tipoescolha = tipoescolha;
	}



	/**
	 * @return the datainicio
	 */
	public String getDatainicio() {
		return datainicio;
	}



	/**
	 * @param datainicio the datainicio to set
	 */
	public void setDatainicio(String datainicio) {
		this.datainicio = datainicio;
	}



	/**
	 * @return the datafim
	 */
	public String getDatafim() {
		return datafim;
	}



	/**
	 * @param datafim the datafim to set
	 */
	public void setDatafim(String datafim) {
		this.datafim = datafim;
	}



	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}



	public OperacoesRealizadasDTO() {
	
	}

	

}
