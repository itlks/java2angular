package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import com.altec.bsbr.app.ibe.util.UtilFunction;

public class DetalheRecebimentoDTO implements Serializable {


	private static final long serialVersionUID = 1L;
	private String TSOEIWDTTITULO;
	private List<ListarDetalheRecebimentoDiaDTO> listaDetalhe;
	private BigDecimal subTotal;
	private String subTotalFormatado;
	
	public String getSubTotalFormatado() {
		subTotalFormatado = UtilFunction.convertBigDecimalToStringFormatoBR(subTotal);
		return subTotalFormatado;
	}
	public void setSubTotalFormatado(String subTotalFormatado) {
		this.subTotalFormatado = subTotalFormatado;
	}
	public String getTSOEIWDTTITULO() {
		return TSOEIWDTTITULO;
	}
	public void setTSOEIWDTTITULO(String tSOEIWDTTITULO) {
		TSOEIWDTTITULO = tSOEIWDTTITULO;
	}
	public List<ListarDetalheRecebimentoDiaDTO> getListaDetalhe() {
		return listaDetalhe;
	}
	public void setListaDetalhe(List<ListarDetalheRecebimentoDiaDTO> listaDetalhe) {
		this.listaDetalhe = listaDetalhe;
	}
	
	public BigDecimal getSubTotal() {
		return subTotal;
	}
	public void setSubTotal(BigDecimal subTotal) {
		this.subTotal = subTotal;
	}

	
}
