package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class AutorizacoesHistoricoBancoDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String contaDebitoValor;
	private String contaDebitoLabel;


	public String getContaDebitoValor() {
		return contaDebitoValor;
	}

	public void setContaDebitoValor(String contaDebitoValor) {
		this.contaDebitoValor = contaDebitoValor;
	}

	public String getContaDebitoLabel() {
		return contaDebitoLabel;
	}

	public void setContaDebitoLabel(String contaDebitoLabel) {
		this.contaDebitoLabel = contaDebitoLabel;
	}

}
