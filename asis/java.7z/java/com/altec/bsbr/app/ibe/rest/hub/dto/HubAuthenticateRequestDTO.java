package com.altec.bsbr.app.ibe.rest.hub.dto;

import java.io.Serializable;

public class HubAuthenticateRequestDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String ticket;
	private String siglaSistema;
	
	public String getTicket() {
		return ticket;
	}
	public void setTicket(String ticket) {
		this.ticket = ticket;
	}
	public String getSiglaSistema() {
		return siglaSistema;
	}
	public void setSiglaSistema(String siglaSistema) {
		this.siglaSistema = siglaSistema;
	}

}
