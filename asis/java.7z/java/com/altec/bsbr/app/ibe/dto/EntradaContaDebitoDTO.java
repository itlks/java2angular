package com.altec.bsbr.app.ibe.dto;

import java.util.ArrayList;

public class EntradaContaDebitoDTO {
	
	private ArrayList<ItemEntradaContaDebitoDTO> listaContaDeb = new ArrayList<ItemEntradaContaDebitoDTO>(50);

	/**
	 * @return the listaContaDeb
	 */
	public ArrayList<ItemEntradaContaDebitoDTO> getListaContaDeb() {
		return listaContaDeb;
	}

	/**
	 * @param listaContaDeb the listaContaDeb to set
	 */
	public void setListaContaDeb(ArrayList<ItemEntradaContaDebitoDTO> listaContaDeb) {
		this.listaContaDeb = listaContaDeb;
	}
}
