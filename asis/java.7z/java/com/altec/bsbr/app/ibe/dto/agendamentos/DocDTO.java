package com.altec.bsbr.app.ibe.dto.agendamentos;

import java.io.Serializable;

public class DocDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3051383405372629467L;
	
	private String tipoDoc;
	private String tipoRecorrente;
	private String numeroBanco;
	private String agencia;
	private String conta;
	private String favorecido;
	private String finalidade;
	private String historico;

	public String getTipoDoc() {
		return tipoDoc;
	}

	public void setTipoDoc(String tipoDoc) {
		this.tipoDoc = tipoDoc;
	}

	public String getNumeroBanco() {
		return numeroBanco;
	}

	public void setNumeroBanco(String numeroBanco) {
		this.numeroBanco = numeroBanco;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getFavorecido() {
		return favorecido;
	}

	public void setFavorecido(String favorecido) {
		this.favorecido = favorecido;
	}

	public String getFinalidade() {
		return finalidade;
	}

	public void setFinalidade(String finalidade) {
		this.finalidade = finalidade;
	}

	public String getHistorico() {
		return historico;
	}

	public void setHistorico(String historico) {
		this.historico = historico;
	}

	public String getTipoRecorrente() {
		return tipoRecorrente;
	}

	public void setTipoRecorrente(String tipoRecorrente) {
		this.tipoRecorrente = tipoRecorrente;
	}

	public String getConta() {
		return conta;
	}

	public void setConta(String conta) {
		this.conta = conta;
	}

}
