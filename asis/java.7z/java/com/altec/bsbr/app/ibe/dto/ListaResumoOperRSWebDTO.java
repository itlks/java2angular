package com.altec.bsbr.app.ibe.dto;

/**
 * @since 2017-01-17
 * @author x187169 - Julio Leme
 *
 */
public class ListaResumoOperRSWebDTO {

	private String nomeCliente;

	/**
	 * encapsulamento
	 * 
	 * @return
	 */
	public String getNomeCliente() {
		return nomeCliente;
	}

	public void setNomeCliente(String nomeCliente) {
		this.nomeCliente = nomeCliente;
	}
	
	

}
