package com.altec.bsbr.app.ibe.dto;

import java.math.BigDecimal;
import java.util.Date;

public class AutorizacoesCanceladasDadoGrupoDTO {

	private String grupo;
	private long codGrupo;
	private int qtdTransAssinadas;
	private BigDecimal valorTotalAssinado;
	private String favorecido;
	private BigDecimal valor;
	private Date dataInclusao;
	private Date dataAssinatura;
	private String nomeTransacao;
	private Date dataCancelamento;
	private String codConvenio;
	private String codContaDebito;
	
	public int getQtdTransAssinadas() {
		return qtdTransAssinadas;
	}
	public void setQtdTransAssinadas(int qtdTransAssinadas) {
		this.qtdTransAssinadas = qtdTransAssinadas;
	}
	public BigDecimal getValorTotalAssinado() {
		return valorTotalAssinado;
	}
	public void setValorTotalAssinado(BigDecimal valorTotalAssinado) {
		this.valorTotalAssinado = valorTotalAssinado;
	}
	public String getFavorecido() {
		return favorecido;
	}
	public void setFavorecido(String favorecido) {
		this.favorecido = favorecido;
	}
	public BigDecimal getValor() {
		return valor;
	}
	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}
	public Date getDataInclusao() {
		return dataInclusao;
	}
	public void setDataInclusao(Date dataInclusao) {
		this.dataInclusao = dataInclusao;
	}
	public Date getDataAssinatura() {
		return dataAssinatura;
	}
	public void setDataAssinatura(Date dataAssinatura) {
		this.dataAssinatura = dataAssinatura;
	}
	public String getNomeTransacao() {
		return nomeTransacao;
	}
	public void setNomeTransacao(String nomeTransacao) {
		this.nomeTransacao = nomeTransacao;
	}
	
	public long getCodGrupo() {
		return codGrupo;
	}
	public void setCodGrupo(long codGrupo) {
		this.codGrupo = codGrupo;
	}
	public Date getDataCancelamento() {
		return dataCancelamento;
	}
	public void setDataCancelamento(Date dataCancelamento) {
		this.dataCancelamento = dataCancelamento;
	}
	public String getGrupo() {
		return grupo;
	}
	public void setGrupo(String grupo) {
		this.grupo = grupo;
	}
	public String getCodConvenio() {
		return codConvenio;
	}
	public void setCodConvenio(String codConvenio) {
		this.codConvenio = codConvenio;
	}
	public String getCodContaDebito() {
		return codContaDebito;
	}
	public void setCodContaDebito(String codContaDebito) {
		this.codContaDebito = codContaDebito;
	}
	
	
	
	
}
