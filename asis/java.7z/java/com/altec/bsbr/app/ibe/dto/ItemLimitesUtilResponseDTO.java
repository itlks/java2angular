package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;

import com.altec.bsbr.app.ibe.util.StringUtil;
import com.altec.bsbr.app.ibe.util.UtilFunction;

public class ItemLimitesUtilResponseDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String idUsuario;

	private String nomeUsuario;

	private String nomeAcesso;

	private String cpfUsuario;

	private String area;

	private String numeroBanco;

	private String agencia;

	private String numeroConta;

	private String idPerfilAutorizacao;

	private String nomePerfilAutorizacao;

	private String descPerfilAutorizacao;

	private String idProduto;

	private String nomeProduto;

	private String tipoTransacao;

	private String convenio;

	private String contaDebito;

	private String idTransacao;

	private String nomeTransacao;

	private String qtdAssinaturas;

	private String valorAlcada;

	private String limiteDiario;

	public ItemLimitesUtilResponseDTO() {

	}

	public String getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(String idUsuario) {
		this.idUsuario = idUsuario;
	}

	public String getNomeUsuario() {
		return nomeUsuario;
	}

	public void setNomeUsuario(String nomeUsuario) {
		this.nomeUsuario = nomeUsuario;
	}

	public String getNomeAcesso() {
		return nomeAcesso;
	}

	public void setNomeAcesso(String nomeAcesso) {
		this.nomeAcesso = nomeAcesso;
	}

	public String getCpfUsuario() {
		return cpfUsuario;
	}

	public void setCpfUsuario(String cpfUsuario) {
		this.cpfUsuario = cpfUsuario;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getNumeroBanco() {
		return numeroBanco;
	}

	public void setNumeroBanco(String numeroBanco) {
		this.numeroBanco = numeroBanco;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getNumeroConta() {
		return numeroConta;
	}

	public void setNumeroConta(String numeroConta) {
		this.numeroConta = numeroConta;
	}

	public String getIdPerfilAutorizacao() {
		return idPerfilAutorizacao;
	}

	public void setIdPerfilAutorizacao(String idPerfilAutorizacao) {
		this.idPerfilAutorizacao = idPerfilAutorizacao;
	}

	public String getNomePerfilAutorizacao() {
		return nomePerfilAutorizacao;
	}

	public void setNomePerfilAutorizacao(String nomePerfilAutorizacao) {
		this.nomePerfilAutorizacao = nomePerfilAutorizacao;
	}

	public String getDescPerfilAutorizacao() {
		return descPerfilAutorizacao;
	}

	public void setDescPerfilAutorizacao(String descPerfilAutorizacao) {
		this.descPerfilAutorizacao = descPerfilAutorizacao;
	}

	public String getIdProduto() {
		return idProduto;
	}

	public void setIdProduto(String idProduto) {
		this.idProduto = idProduto;
	}

	public String getNomeProduto() {
		return nomeProduto;
	}

	public void setNomeProduto(String nomeProduto) {
		this.nomeProduto = nomeProduto;
	}

	public String getTipoTransacao() {
		return tipoTransacao;
	}

	public void setTipoTransacao(String tipoTransacao) {
		this.tipoTransacao = tipoTransacao;
	}

	public String getConvenio() {
		return convenio;
	}

	public void setConvenio(String convenio) {
		this.convenio = convenio;
	}

	public String getContaDebito() {
		return contaDebito;
	}

	public void setContaDebito(String contaDebito) {
		this.contaDebito = contaDebito;
	}

	public String getIdTransacao() {
		return idTransacao;
	}

	public void setIdTransacao(String idTransacao) {
		this.idTransacao = idTransacao;
	}

	public String getNomeTransacao() {
		return nomeTransacao;
	}

	public void setNomeTransacao(String nomeTransacao) {
		this.nomeTransacao = nomeTransacao;
	}

	public String getQtdAssinaturas() {
		return qtdAssinaturas;
	}

	public void setQtdAssinaturas(String qtdAssinaturas) {
		this.qtdAssinaturas = qtdAssinaturas;
	}

	public String getValorAlcada() {
		return valorAlcada;
	}

	public void setValorAlcada(String valorAlcada) {
		this.valorAlcada = valorAlcada;
	}

	public String getLimiteDiario() {
		return limiteDiario;
	}

	public void setLimiteDiario(String limiteDiario) {
		this.limiteDiario = limiteDiario;
	}

	public String getCpfFormatado() {
		if (getCpfUsuario() != null && !getCpfUsuario().isEmpty()) {
			return UtilFunction.formatarCpfComTraco(getCpfUsuario());
		} else {
			return null;
		}
	}

	public String getAgenciaContaFormatada() {
		if (getAgencia() != null && !getAgencia().isEmpty() && getContaDebito() != null
				&& !getContaDebito().isEmpty()) {
			StringBuilder retorno = new StringBuilder();
			retorno.append(getAgencia());
			retorno.append(" ");
			retorno.append(StringUtil.formatContaCorrenteComPonto(getContaDebito()));
			return retorno.toString();
		} else {
			return null;
		}
	}

	public String getValorAlcadaFormatado() {
		if (getValorAlcada() != null && !getValorAlcada().isEmpty()) {
			BigDecimal convertValorAlcada = UtilFunction.converterStringToBigDecimal(getValorAlcada(), ",", ".");
			return UtilFunction.convertBigDecimalToStringFormatoBR(convertValorAlcada);
		} else {
			return null;
		}
	}

	public String getLimiteDiarioFormatado() {
		if (getLimiteDiario() != null && !getLimiteDiario().isEmpty()) {
			BigDecimal convertLimiteDiario = UtilFunction.converterStringToBigDecimal(getLimiteDiario(), ",", ".");
			return UtilFunction.convertBigDecimalToStringFormatoBR(convertLimiteDiario);
		} else {
			return null;
		}
	}

}
