package com.altec.bsbr.app.ibe.dto;

public class DetalhePreencheModalDTO {
	
	private String idUsuarioLogin;
	private String nomeFavorecidoPendencia;
	private String codUsuarioUltimaAtu;
	private String descricaoOperacao;	
	private String codigoProduto;
	private String descricaoProduto;
	private String imgTransacao;
	private String data; 
	private String codigoTransacao;
	private String codigoTransacaoDetalhe;
	private String timeStamp;
	private String contratoUsuarioLogado;
	private String valorUsuarioPendencia;
	
	


	/**
	 * @return the nomeFavorecidoPendencia
	 */
	public String getNomeFavorecidoPendencia() {
		return nomeFavorecidoPendencia;
	}


	/**
	 * @param nomeFavorecidoPendencia the nomeFavorecidoPendencia to set
	 */
	public void setNomeFavorecidoPendencia(String nomeFavorecidoPendencia) {
		this.nomeFavorecidoPendencia = nomeFavorecidoPendencia;
	}


	/**
	 * @return the codUsuarioUltimaAtu
	 */
	public String getCodUsuarioUltimaAtu() {
		return codUsuarioUltimaAtu;
	}


	/**
	 * @param codUsuarioUltimaAtu the codUsuarioUltimaAtu to set
	 */
	public void setCodUsuarioUltimaAtu(String codUsuarioUltimaAtu) {
		this.codUsuarioUltimaAtu = codUsuarioUltimaAtu;
	}


	/**
	 * @return the descricaoOperacao
	 */
	public String getDescricaoOperacao() {
		return descricaoOperacao;
	}


	/**
	 * @param descricaoOperacao the descricaoOperacao to set
	 */
	public void setDescricaoOperacao(String descricaoOperacao) {
		this.descricaoOperacao = descricaoOperacao;
	}


	/**
	 * @return the codigoProduto
	 */
	public String getCodigoProduto() {
		return codigoProduto;
	}


	/**
	 * @param codigoProduto the codigoProduto to set
	 */
	public void setCodigoProduto(String codigoProduto) {
		this.codigoProduto = codigoProduto;
	}


	/**
	 * @return the descricaoProduto
	 */
	public String getDescricaoProduto() {
		return descricaoProduto;
	}


	/**
	 * @param descricaoProduto the descricaoProduto to set
	 */
	public void setDescricaoProduto(String descricaoProduto) {
		this.descricaoProduto = descricaoProduto;
	}


	/**
	 * @return the imgTransacao
	 */
	public String getImgTransacao() {
		return imgTransacao;
	}


	/**
	 * @param imgTransacao the imgTransacao to set
	 */
	public void setImgTransacao(String imgTransacao) {
		this.imgTransacao = imgTransacao;
	}


	/**
	 * @return the data
	 */
	public String getData() {
		return data;
	}


	/**
	 * @param data the data to set
	 */
	public void setData(String data) {
		this.data = data;
	}


	/**
	 * @return the codigoTransacao
	 */
	public String getCodigoTransacao() {
		return codigoTransacao;
	}


	/**
	 * @param codigoTransacao the codigoTransacao to set
	 */
	public void setCodigoTransacao(String codigoTransacao) {
		this.codigoTransacao = codigoTransacao;
	}


	/**
	 * @return the codigoTransacaoDetalhe
	 */
	public String getCodigoTransacaoDetalhe() {
		return codigoTransacaoDetalhe;
	}


	/**
	 * @param codigoTransacaoDetalhe the codigoTransacaoDetalhe to set
	 */
	public void setCodigoTransacaoDetalhe(String codigoTransacaoDetalhe) {
		this.codigoTransacaoDetalhe = codigoTransacaoDetalhe;
	}


	/**
	 * @return the timeStamp
	 */
	public String getTimeStamp() {
		return timeStamp;
	}


	/**
	 * @param timeStamp the timeStamp to set
	 */
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}


	/**
	 * @return the contratoUsuarioLogado
	 */
	public String getContratoUsuarioLogado() {
		return contratoUsuarioLogado;
	}


	/**
	 * @param contratoUsuarioLogado the contratoUsuarioLogado to set
	 */
	public void setContratoUsuarioLogado(String contratoUsuarioLogado) {
		this.contratoUsuarioLogado = contratoUsuarioLogado;
	}


	/**
	 * @return the valorUsuarioPendencia
	 */
	public String getValorUsuarioPendencia() {
		return valorUsuarioPendencia;
	}


	/**
	 * @param valorUsuarioPendencia the valorUsuarioPendencia to set
	 */
	public void setValorUsuarioPendencia(String valorUsuarioPendencia) {
		this.valorUsuarioPendencia = valorUsuarioPendencia;
	}


	/**
	 * @return the idUsuarioLogin
	 */
	public String getIdUsuarioLogin() {
		return idUsuarioLogin;
	}


	/**
	 * @param idUsuarioLogin the idUsuarioLogin to set
	 */
	public void setIdUsuarioLogin(String idUsuarioLogin) {
		this.idUsuarioLogin = idUsuarioLogin;
	}

}