package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class DetalheCashDTO implements Serializable {

	
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	
	private List<DadosDetalheCash> dadosDetalheCash;
	
	public DetalheCashDTO() {
		dadosDetalheCash = new ArrayList<DadosDetalheCash>();
	}

	public List<DadosDetalheCash> getDadosDetalheCash() {
		return dadosDetalheCash;
	}

	public void setDadosDetalheCash(List<DadosDetalheCash> dadosDetalheCash) {
		this.dadosDetalheCash = dadosDetalheCash;
	}
	
	
	
	

}