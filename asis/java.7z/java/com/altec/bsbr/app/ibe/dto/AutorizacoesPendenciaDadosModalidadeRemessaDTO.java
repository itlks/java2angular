package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class AutorizacoesPendenciaDadosModalidadeRemessaDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5657172171867078297L;

	private String dataPagamento;
	private List<AutorizacoesPendenciaDadosModalidadeDTO> listaModalidadeSegundoNivel;
	private List<AutorizacoesPendenciaDadosAnaliticaDTO> listaModalidade;
	private Integer quantidade;
	private BigDecimal valor;
	private boolean selecionado;
	private boolean flgAutorizarModalidade;

	public AutorizacoesPendenciaDadosModalidadeRemessaDTO(String dataPagamento) {
		this.dataPagamento = dataPagamento;
		this.listaModalidadeSegundoNivel = new ArrayList<AutorizacoesPendenciaDadosModalidadeDTO>();
		this.listaModalidade = new ArrayList<AutorizacoesPendenciaDadosAnaliticaDTO>();

	}

	public List<AutorizacoesPendenciaDadosAnaliticaDTO> getListaModalidade() {
		return listaModalidade;
	}

	public void setListaModalidade(List<AutorizacoesPendenciaDadosAnaliticaDTO> listaModalidade) {
		this.listaModalidade = listaModalidade;
	}

	public String getDataPagamento() {
		return dataPagamento;
	}

	public void setDataPagamento(String dataPagamento) {
		this.dataPagamento = dataPagamento;
	}

	public Integer getQuantidade() {
		// quantidade = calculaQuantidadeTotal();
		return quantidade;
	}
	// private int calculaQuantidadeTotal() {
	// int resultado = 0;
	// for (int i = 0; i < listaModalidade.size(); i++) {
	// resultado++;
	// }
	// return resultado;
	// }

	public void setQuantidade(Integer quantidade) {
		this.quantidade = quantidade;
	}

	public BigDecimal getValor() {
		// if (UtilFunction.isNotBlankOrNull(listaModalidade)) {
		// return
		// UtilFunction.convertBigDecimalToStringFormatoBR(calculaValorTotal());
		// }
		// return UtilFunction.convertBigDecimalToStringFormatoBR(valor);
		return valor;
	}

	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}

	// private BigDecimal calculaValorTotal() {
	// BigDecimal retorno = BigDecimal.ZERO;
	// for (AutorizacoesPendenciaDadosAnaliticaDTO analitica : listaModalidade)
	// {
	// BigDecimal valorConvertido =analitica.getValorUsuarioPendencia();
	// retorno = retorno.add(valorConvertido);
	// }
	// return retorno;
	// }
	public boolean isSelecionado() {
		return selecionado;
	}

	/**
	 * @param selecionado
	 *            the selecionado to set
	 */
	public void setSelecionado(boolean selecionado) {
		this.selecionado = selecionado;
	}

	public void adicionaAnalitica(AutorizacoesPendenciaDadosAnaliticaDTO analitica) {
		if (!listaModalidade.contains(analitica)) {
			this.listaModalidade.add(analitica);
		}
	}

	public boolean isFlgAutorizarModalidade() {
		return flgAutorizarModalidade;
	}

	public void setFlgAutorizarModalidade(boolean flgAutorizarModalidade) {
		this.flgAutorizarModalidade = flgAutorizarModalidade;
	}

	public List<AutorizacoesPendenciaDadosModalidadeDTO> getListaModalidadeSegundoNivel() {
		return listaModalidadeSegundoNivel;
	}

	public void setListaModalidadeSegundoNivel(
			List<AutorizacoesPendenciaDadosModalidadeDTO> listaModalidadeSegundoNivel) {
		this.listaModalidadeSegundoNivel = listaModalidadeSegundoNivel;
	}

}
