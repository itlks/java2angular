
package com.altec.bsbr.app.ibe.dto.contaMaxEmpresas;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class ConsultarParametrosContaMaxResponseDTO implements Serializable
{

    private String dateUsefulPrevious;
    private String minimumValueCurrentAccount;
    private String minimumProductValue;
    private List<YearMonth> yearMonth;
    private final static long serialVersionUID = -9067947919098143509L;

    /**
     * No args constructor for use in serialization
     * 
     */
    public ConsultarParametrosContaMaxResponseDTO() {
    }

    /**
     * 
     * @param minimumProductValue
     * @param yearMonth
     * @param minimumValueCurrentAccount
     * @param dateUsefulPrevious
     */
    public ConsultarParametrosContaMaxResponseDTO(String dateUsefulPrevious, String minimumValueCurrentAccount, String minimumProductValue, List<YearMonth> yearMonth) {
        super();
        this.dateUsefulPrevious = dateUsefulPrevious;
        this.minimumValueCurrentAccount = minimumValueCurrentAccount;
        this.minimumProductValue = minimumProductValue;
        this.yearMonth = yearMonth;
    }

    public String getDateUsefulPrevious() {
        return dateUsefulPrevious;
    }

    public void setDateUsefulPrevious(String dateUsefulPrevious) {
        this.dateUsefulPrevious = dateUsefulPrevious;
    }

    public ConsultarParametrosContaMaxResponseDTO withDateUsefulPrevious(String dateUsefulPrevious) {
        this.dateUsefulPrevious = dateUsefulPrevious;
        return this;
    }

    public String getMinimumValueCurrentAccount() {
        return minimumValueCurrentAccount;
    }

    public void setMinimumValueCurrentAccount(String minimumValueCurrentAccount) {
        this.minimumValueCurrentAccount = minimumValueCurrentAccount;
    }

    public ConsultarParametrosContaMaxResponseDTO withMinimumValueCurrentAccount(String minimumValueCurrentAccount) {
        this.minimumValueCurrentAccount = minimumValueCurrentAccount;
        return this;
    }

    public String getMinimumProductValue() {
        return minimumProductValue;
    }

    public void setMinimumProductValue(String minimumProductValue) {
        this.minimumProductValue = minimumProductValue;
    }

    public ConsultarParametrosContaMaxResponseDTO withMinimumProductValue(String minimumProductValue) {
        this.minimumProductValue = minimumProductValue;
        return this;
    }

    
    public List<YearMonth> getYearMonth() {
		return yearMonth;
	}

	public void setYearMonth(List<YearMonth> yearMonth) {
		this.yearMonth = yearMonth;
	}

	public ConsultarParametrosContaMaxResponseDTO withYearMonthReference(List<YearMonth> yearMonth) {
        this.yearMonth = yearMonth;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(dateUsefulPrevious).append(minimumValueCurrentAccount).append(minimumProductValue).append(yearMonth).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ConsultarParametrosContaMaxResponseDTO) == false) {
            return false;
        }
        ConsultarParametrosContaMaxResponseDTO rhs = ((ConsultarParametrosContaMaxResponseDTO) other);
        return new EqualsBuilder().append(dateUsefulPrevious, rhs.dateUsefulPrevious).append(minimumValueCurrentAccount, rhs.minimumValueCurrentAccount).append(minimumProductValue, rhs.minimumProductValue).append(yearMonth, rhs.yearMonth).isEquals();
    }

}
