package com.altec.bsbr.app.ibe.dto;

import java.util.List;

public class ItemPosicaoConsolidadaConsultarDTO {

	private String nomeDoGrupo; 
	private List<DadosPosicaoConsolidadaGrupoDTO> dadosPosicaoConsolidada;
	
	public String getNomeDoGrupo() {
		return nomeDoGrupo;
	}
	public void setNomeDoGrupo(String nomeDoGrupo) {
		this.nomeDoGrupo = nomeDoGrupo;
	}
	public List<DadosPosicaoConsolidadaGrupoDTO> getDadosPosicaoConsolidada() {
		return dadosPosicaoConsolidada;
	}
	public void setDadosPosicaoConsolidada(List<DadosPosicaoConsolidadaGrupoDTO> dadosPosicaoConsolidada) {
		this.dadosPosicaoConsolidada = dadosPosicaoConsolidada;
	}
	
	
	
	
}
