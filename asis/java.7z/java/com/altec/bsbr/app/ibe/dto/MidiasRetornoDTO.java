package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class MidiasRetornoDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Integer nrMidia;
	private Integer tpLote;
	private Integer tpPagina;
	private String tpCampanha;
	private Integer campanhaCRM;
	private String txtCampanha;
	private String tpMidia;
	private String txtImagem;
	private String tpLink;
	private Integer cdLink;
	private String linkUrlPJ;
	private String linkUrlClassico;
	private String linkUrl;
	private String linkPJ; 
	private String cdItemMenu; 
	private String coCamiPagina;
	private String raAttribSeg;
 	private String boId;
 	private String width;
	private String height;
	
	/**
	 * @return the nrMidia
	 */
	public Integer getNrMidia() {
		return nrMidia;
	}
	/**
	 * @param nrMidia the nrMidia to set
	 */
	public void setNrMidia(Integer nrMidia) {
		this.nrMidia = nrMidia;
	}
	/**
	 * @return the tpLote
	 */
	public Integer getTpLote() {
		return tpLote;
	}
	/**
	 * @param tpLote the tpLote to set
	 */
	public void setTpLote(Integer tpLote) {
		this.tpLote = tpLote;
	}
	/**
	 * @return the tpPagina
	 */
	public Integer getTpPagina() {
		return tpPagina;
	}
	/**
	 * @param tpPagina the tpPagina to set
	 */
	public void setTpPagina(Integer tpPagina) {
		this.tpPagina = tpPagina;
	}
	/**
	 * @return the tpCampanha
	 */
	public String getTpCampanha() {
		return tpCampanha;
	}
	/**
	 * @param tpCampanha the tpCampanha to set
	 */
	public void setTpCampanha(String tpCampanha) {
		this.tpCampanha = tpCampanha;
	}
	/**
	 * @return the campanhaCRM
	 */
	public Integer getCampanhaCRM() {
		return campanhaCRM;
	}
	/**
	 * @param campanhaCRM the campanhaCRM to set
	 */
	public void setCampanhaCRM(Integer campanhaCRM) {
		this.campanhaCRM = campanhaCRM;
	}
	/**
	 * @return the txtCampanha
	 */
	public String getTxtCampanha() {
		return txtCampanha;
	}
	/**
	 * @param txtCampanha the txtCampanha to set
	 */
	public void setTxtCampanha(String txtCampanha) {
		this.txtCampanha = txtCampanha;
	}
	/**
	 * @return the tpMidia
	 */
	public String getTpMidia() {
		return tpMidia;
	}
	/**
	 * @param tpMidia the tpMidia to set
	 */
	public void setTpMidia(String tpMidia) {
		this.tpMidia = tpMidia;
	}
	/**
	 * @return the txtImagem
	 */
	public String getTxtImagem() {
		return txtImagem;
	}
	/**
	 * @param txtImagem the txtImagem to set
	 */
	public void setTxtImagem(String txtImagem) {
		this.txtImagem = txtImagem;
	}
	/**
	 * @return the tpLink
	 */
	public String getTpLink() {
		return tpLink;
	}
	/**
	 * @param tpLink the tpLink to set
	 */
	public void setTpLink(String tpLink) {
		this.tpLink = tpLink;
	}
	/**
	 * @return the cdLink
	 */
	public Integer getCdLink() {
		return cdLink;
	}
	/**
	 * @param cdLink the cdLink to set
	 */
	public void setCdLink(Integer cdLink) {
		this.cdLink = cdLink;
	}
	/**
	 * @return the linkUrl
	 */
	public String getLinkUrl() {
		return linkUrl;
	}
	/**
	 * @param linkUrl the linkUrl to set
	 */
	public void setLinkUrl(String linkUrl) {
		this.linkUrl = linkUrl;
	}
	/**
	 * @return the linkPJ
	 */
	public String getLinkPJ() {
		return linkPJ;
	}
	/**
	 * @param linkPJ the linkPJ to set
	 */
	public void setLinkPJ(String linkPJ) {
		this.linkPJ = linkPJ;
	}
	/**
	 * @return the cdItemMenu
	 */
	public String getCdItemMenu() {
		return cdItemMenu;
	}
	/**
	 * @param cdItemMenu the cdItemMenu to set
	 */
	public void setCdItemMenu(String cdItemMenu) {
		this.cdItemMenu = cdItemMenu;
	}
	/**
	 * @return the coCamiPagina
	 */
	public String getCoCamiPagina() {
		return coCamiPagina;
	}
	/**
	 * @param coCamiPagina the coCamiPagina to set
	 */
	public void setCoCamiPagina(String coCamiPagina) {
		this.coCamiPagina = coCamiPagina;
	}
	public String getLinkUrlPJ() {
		return linkUrlPJ;
	}
	public void setLinkUrlPJ(String linkUrlPJ) {
		this.linkUrlPJ = linkUrlPJ;
	}
	public String getRaAttribSeg() {
		return raAttribSeg;
	}
	public void setRaAttribSeg(String raAttribSeg) {
		this.raAttribSeg = raAttribSeg;
	}
	public String getBoId() {
		return boId;
	}
	public void setBoId(String boId) {
		this.boId = boId;
	}
	public String getLinkUrlClassico() {
		return linkUrlClassico;
	}
	public void setLinkUrlClassico(String linkUrlClassico) {
		this.linkUrlClassico = linkUrlClassico;
	}
	public String getWidth() {
		return width;
	}
	public void setWidth(String width) {
		this.width = width;
	}
	public String getHeight() {
		return height;
	}
	public void setHeight(String height) {
		this.height = height;
	}
	
}
