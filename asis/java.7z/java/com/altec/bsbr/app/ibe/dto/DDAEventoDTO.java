package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;

public class DDAEventoDTO extends GenericDTO implements Serializable {

	private static final long serialVersionUID = 5820517167421870658L;

	private Integer tipo;
	private String descricao;
	private String dataInicio;
	private String dataFim;
	private Integer quantidade;
	private BigDecimal valorTotal;
	private String mensagemToolTip;

	public DDAEventoDTO() {
	}

	public DDAEventoDTO(Integer tipo, String descricao, String dataInicio, String dataFim, Integer quantidade,
			BigDecimal valorTotal, String toolTip) {
		this.tipo = tipo;
		this.descricao = descricao;
		this.dataInicio = dataInicio;
		this.dataFim = dataFim;
		this.quantidade = quantidade;
		this.valorTotal = valorTotal;
		this.mensagemToolTip = toolTip;
	}

	public Integer getTipo() {
		return tipo;
	}

	public void setTipo(Integer tipo) {
		this.tipo = tipo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public String getDataInicio() {
		return dataInicio;
	}

	public void setDataInicio(String dataInicio) {
		this.dataInicio = dataInicio;
	}

	public String getDataFim() {
		return dataFim;
	}

	public void setDataFim(String dataFim) {
		this.dataFim = dataFim;
	}

	public Integer getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(Integer quantidade) {
		this.quantidade = quantidade;
	}

	public BigDecimal getValorTotal() {
		return valorTotal;
	}

	public void setValorTotal(BigDecimal valorTotal) {
		this.valorTotal = valorTotal;
	}

	public String getMensagemToolTip() {
		return mensagemToolTip;
	}

	public void setMensagemToolTip(String mensagemToolTip) {
		this.mensagemToolTip = mensagemToolTip;
	}
	
	
}