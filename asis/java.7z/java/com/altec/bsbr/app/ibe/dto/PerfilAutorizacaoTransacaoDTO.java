package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;

import com.altec.bsbr.app.ibe.anotation.Hash;
import com.altec.bsbr.app.ibe.hash.converter.BigDecimalConverter;

public class PerfilAutorizacaoTransacaoDTO implements Serializable {

	private static final long serialVersionUID = 394310760130100476L;
	
	private String nomeTransacao;
	private Integer idGrupoServico;
	private Integer numeroDaTransacao; 
	
	@Hash(position=1)
	private Integer qtdAssinaturas; 
	@Hash(position=2, converter=BigDecimalConverter.class)
	private BigDecimal valorAlcada;
	@Hash(position=3, converter=BigDecimalConverter.class)
	private BigDecimal valorDiario;
	
	private boolean checked;
	private boolean enableInput = true;

	public String getNomeTransacao() {
		return nomeTransacao;
	}

	public void setNomeTransacao(String nomeTransacao) {
		this.nomeTransacao = nomeTransacao;
	}

	public Integer getNumeroDaTransacao() {
		return numeroDaTransacao;
	}

	public void setNumeroDaTransacao(Integer numeroDaTransacao) {
		this.numeroDaTransacao = numeroDaTransacao;
	}

	public Integer getQtdAssinaturas() {
		return qtdAssinaturas;
	}

	public void setQtdAssinaturas(Integer qtdAssinaturas) {
		this.qtdAssinaturas = qtdAssinaturas;
	}

	public BigDecimal getValorAlcada() {
		return valorAlcada;
	}

	public void setValorAlcada(BigDecimal valorAlcada) {
		this.valorAlcada = valorAlcada;
	}

	public BigDecimal getValorDiario() {
		return valorDiario;
	}

	public void setValorDiario(BigDecimal valorDiario) {
		this.valorDiario = valorDiario;
	}

	public boolean isChecked() {
		return checked;
	}

	public void setChecked(boolean checked) {
		this.checked = checked;
	}

	public boolean isEnableInput() {
		return enableInput;
	}

	public void setEnableInput(boolean enableInput) {
		this.enableInput = enableInput;
	}

	public Integer getIdGrupoServico() {
		return idGrupoServico;
	}

	public void setIdGrupoServico(Integer idGrupoServico) {
		this.idGrupoServico = idGrupoServico;
	}

}
