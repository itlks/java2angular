package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.altec.bsbr.app.ibe.anotation.Hash;
import com.altec.bsbr.app.ibe.mocks.Apelido;

public class TributoGpsDTO implements Serializable {

  private static final long serialVersionUID = 7760945557698374706L;

  private String nomeRazaoSocial;

  private Date dataPagamento;

  private String codigoPagamento;
  private String competencia;

  @Hash(position = 1)
  private String identificador;
  private BigDecimal valorInss;
  private BigDecimal valorOutrasEntidades;
  private BigDecimal valorMultasJuros;
  private BigDecimal valorPrincipal;

  private Double total;

  private boolean cadastrarApelido;
  private boolean agendarPagamento;
  private List<Apelido> apelidos;
  private String nomeApelido;
  private String autenticacao;
  private String dataHoraTransacao;
  private boolean pendencias;
  private boolean gravaApelido;
  private Date dataAgendamento;
  private String datAgend;
  private String chaveNSU;
  private boolean agendar;
  private String agendarTog;
  private String banco;
  private String agencia;
  private String conta;
  private String dataVencimento;

  private String codigoDaReceita;

  private String tipoDocumento;
  private String numeroDoDocumento;
  private String nomeDoContribuinte;
  private String codigoDaArea;
  private String telefoneDoContribuinte;
  private String enderecoDoContribuinte;
  private String codigoDoMunicipio;
  private String tipoIdentificador;
  private String dataContabil;
  private String multaMora;
  private BigDecimal valorReceita;
  private BigDecimal valorTotal;
  private String tipoTerminal;
  private String numeroTerminal;
  private String versaoDoCanal;
  private String siglaDoUsuario;
  private String infoComplementar;

  private String tipoApelido;
  private String nomeFavorecido;

  private boolean usarApelido;

  public TributoGpsDTO() {
    // Constructor
  }

  public TributoGpsDTO(String nome, String codigoPagamento, String identificador) {
    this.nomeRazaoSocial = nome;
    this.codigoPagamento = codigoPagamento;
    this.identificador = identificador;
  }

  public String getNomeRazaoSocial() {
    return nomeRazaoSocial;
  }

  public void setNomeRazaoSocial(String nomeRazaoSocial) {
    this.nomeRazaoSocial = nomeRazaoSocial;
  }

  public Date getDataPagamento() {
    return dataPagamento;
  }

  public void setDataPagamento(Date dataPagamento) {
    this.dataPagamento = dataPagamento;
  }

  public String getCodigoPagamento() {
    return codigoPagamento;
  }

  public void setCodigoPagamento(String codigoPagamento) {
    this.codigoPagamento = codigoPagamento;
  }

  public String getCompetencia() {
    return competencia;
  }

  public void setCompetencia(String competencia) {
    this.competencia = competencia;
  }

  public String getIdentificador() {
    return identificador;
  }

  public void setIdentificador(String identificador) {
    this.identificador = identificador;
  }

  public BigDecimal getValorInss() {
    return valorInss;
  }

  public void setValorInss(BigDecimal valorInss) {
    this.valorInss = valorInss;
  }

  public BigDecimal getValorOutrasEntidades() {
    return valorOutrasEntidades;
  }

  public void setValorOutrasEntidades(BigDecimal valorOutrasEntidades) {
    this.valorOutrasEntidades = valorOutrasEntidades;
  }

  public BigDecimal getValorMultasJuros() {
    return valorMultasJuros;
  }

  public void setValorMultasJuros(BigDecimal valorMultasJuros) {
    this.valorMultasJuros = valorMultasJuros;
  }

  public BigDecimal getValorPrincipal() {
    return valorPrincipal;
  }

  public void setValorPrincipal(BigDecimal valorPrincipal) {
    this.valorPrincipal = valorPrincipal;
  }

  public Double getTotal() {
    return total;
  }

  public void setTotal(Double total) {
    this.total = total;
  }

  public boolean isCadastrarApelido() {
    return cadastrarApelido;
  }

  public void setCadastrarApelido(boolean cadastrarApelido) {
    this.cadastrarApelido = cadastrarApelido;
  }

  public boolean isAgendarPagamento() {
    return agendarPagamento;
  }

  public void setAgendarPagamento(boolean agendarPagamento) {
    this.agendarPagamento = agendarPagamento;
  }

  public List<Apelido> getApelidos() {
    return apelidos;
  }

  public void setApelidos(List<Apelido> apelidos) {
    this.apelidos = apelidos;
  }

  public String getNomeApelido() {
    return nomeApelido;
  }

  public void setNomeApelido(String nomeApelido) {
    this.nomeApelido = nomeApelido;
  }

  public String getAutenticacao() {
    return autenticacao;
  }

  public void setAutenticacao(String autenticacao) {
    this.autenticacao = autenticacao;
  }

  public String getDataHoraTransacao() {
    return dataHoraTransacao;
  }

  public void setDataHoraTransacao(String dataHoraTransacao) {
    this.dataHoraTransacao = dataHoraTransacao;
  }

  public boolean isPendencias() {
    return pendencias;
  }

  public void setPendencias(boolean pendencias) {
    this.pendencias = pendencias;
  }

  public boolean isGravaApelido() {
    return gravaApelido;
  }

  public void setGravaApelido(boolean gravaApelido) {
    this.gravaApelido = gravaApelido;
  }

  public Date getDataAgendamento() {
    return dataAgendamento;
  }

  public void setDataAgendamento(Date dataAgendamento) {
    this.dataAgendamento = dataAgendamento;
  }

  public String getDatAgend() {
    return datAgend;
  }

  public void setDatAgend(String datAgend) {
    this.datAgend = datAgend;
  }

  public String getChaveNSU() {
    return chaveNSU;
  }

  public void setChaveNSU(String chaveNSU) {
    this.chaveNSU = chaveNSU;
  }

  public boolean isAgendar() {
    return agendar;
  }

  public void setAgendar(boolean agendar) {
    this.agendar = agendar;
  }

  public String getAgendarTog() {
    return agendarTog;
  }

  public void setAgendarTog(String agendarTog) {
    this.agendarTog = agendarTog;
  }

  public String getBanco() {
    return banco;
  }

  public void setBanco(String banco) {
    this.banco = banco;
  }

  public String getAgencia() {
    return agencia;
  }

  public void setAgencia(String agencia) {
    this.agencia = agencia;
  }

  public String getConta() {
    return conta;
  }

  public void setConta(String conta) {
    this.conta = conta;
  }

  public String getDataVencimento() {
    return dataVencimento;
  }

  public void setDataVencimento(String dataVencimento) {
    this.dataVencimento = dataVencimento;
  }

  public String getCodigoDaReceita() {
    return codigoDaReceita;
  }

  public void setCodigoDaReceita(String codigoDaReceita) {
    this.codigoDaReceita = codigoDaReceita;
  }

  public String getTipoDocumento() {
    return tipoDocumento;
  }

  public void setTipoDocumento(String tipoDocumento) {
    this.tipoDocumento = tipoDocumento;
  }

  public String getNumeroDoDocumento() {
    return numeroDoDocumento;
  }

  public void setNumeroDoDocumento(String numeroDoDocumento) {
    this.numeroDoDocumento = numeroDoDocumento;
  }

  public String getNomeDoContribuinte() {
    return nomeDoContribuinte;
  }

  public void setNomeDoContribuinte(String nomeDoContribuinte) {
    this.nomeDoContribuinte = nomeDoContribuinte;
  }

  public String getCodigoDaArea() {
    return codigoDaArea;
  }

  public void setCodigoDaArea(String codigoDaArea) {
    this.codigoDaArea = codigoDaArea;
  }

  public String getTelefoneDoContribuinte() {
    return telefoneDoContribuinte;
  }

  public void setTelefoneDoContribuinte(String telefoneDoContribuinte) {
    this.telefoneDoContribuinte = telefoneDoContribuinte;
  }

  public String getEnderecoDoContribuinte() {
    return enderecoDoContribuinte;
  }

  public void setEnderecoDoContribuinte(String enderecoDoContribuinte) {
    this.enderecoDoContribuinte = enderecoDoContribuinte;
  }

  public String getCodigoDoMunicipio() {
    return codigoDoMunicipio;
  }

  public void setCodigoDoMunicipio(String codigoDoMunicipio) {
    this.codigoDoMunicipio = codigoDoMunicipio;
  }

  public String getTipoIdentificador() {
    return tipoIdentificador;
  }

  public void setTipoIdentificador(String tipoIdentificador) {
    this.tipoIdentificador = tipoIdentificador;
  }

  public String getDataContabil() {
    return dataContabil;
  }

  public void setDataContabil(String dataContabil) {
    this.dataContabil = dataContabil;
  }

  public String getMultaMora() {
    return multaMora;
  }

  public void setMultaMora(String multaMora) {
    this.multaMora = multaMora;
  }

  public BigDecimal getValorReceita() {
    return valorReceita;
  }

  public void setValorReceita(BigDecimal valorReceita) {
    this.valorReceita = valorReceita;
  }

  public BigDecimal getValorTotal() {
    return valorTotal;
  }

  public void setValorTotal(BigDecimal valorTotal) {
    this.valorTotal = valorTotal;
  }

  public String getTipoTerminal() {
    return tipoTerminal;
  }

  public void setTipoTerminal(String tipoTerminal) {
    this.tipoTerminal = tipoTerminal;
  }

  public String getNumeroTerminal() {
    return numeroTerminal;
  }

  public void setNumeroTerminal(String numeroTerminal) {
    this.numeroTerminal = numeroTerminal;
  }

  public String getVersaoDoCanal() {
    return versaoDoCanal;
  }

  public void setVersaoDoCanal(String versaoDoCanal) {
    this.versaoDoCanal = versaoDoCanal;
  }

  public String getSiglaDoUsuario() {
    return siglaDoUsuario;
  }

  public void setSiglaDoUsuario(String siglaDoUsuario) {
    this.siglaDoUsuario = siglaDoUsuario;
  }

  public String getInfoComplementar() {
    return infoComplementar;
  }

  public void setInfoComplementar(String infoComplementar) {
    this.infoComplementar = infoComplementar;
  }

  public String getTipoApelido() {
    return tipoApelido;
  }

  public void setTipoApelido(String tipoApelido) {
    this.tipoApelido = tipoApelido;
  }

  public String getNomeFavorecido() {
    return nomeFavorecido;
  }

  public void setNomeFavorecido(String nomeFavorecido) {
    this.nomeFavorecido = nomeFavorecido;
  }

  public boolean isUsarApelido() {
    return usarApelido;
  }

  public void setUsarApelido(boolean usarApelido) {
    this.usarApelido = usarApelido;
  }

}
