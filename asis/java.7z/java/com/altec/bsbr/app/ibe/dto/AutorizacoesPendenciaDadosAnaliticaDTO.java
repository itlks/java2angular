package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;

import org.apache.commons.lang3.StringUtils;

import com.altec.bsbr.app.ibe.util.UtilFunction;
import com.altec.bsbr.app.ibe.web.util.StringUtilsEncode;

public class AutorizacoesPendenciaDadosAnaliticaDTO implements Serializable{

	private static final long serialVersionUID = -4830777175996983705L;
	private String dataHoraInclusao; 
	private String codigoTransacao;
	private String codigoTransacaoDetalhe;
	private String dataPagamento;		
	private int codigoProduto;		
	private String contaConvenio;	
	private String contaDebito;		
	private int qtAssNecessario;	
	private int qtAssPendente;		
	private BigDecimal valorUsuarioPendencia; 
	private String flagPermiteAutorizar;  
	private String nomeFavorecidoPendencia; 
	private String codUsuarioUltimaAtu; 	
	private String imgTransacao;			
	private boolean itemSelecionado;
	private String timeStamp;
	private String descricaoOperacao;
	private String descricaoProduto;
	
	private String contaConvenioAutoriza; // conta convenio concatenado sem fonrmata��o para autorizacao;
	
	private String msgErro;//Erro autorizacao
	private String msgErroTecnico;//Codigo Erro autorizacao
		
	public String getDataHoraInclusao() {
		return dataHoraInclusao;
	}
	
	private String convertidoAlta(){
		String retorno = "";
		if (UtilFunction.isNotBlankOrNull(msgErroTecnico)){
			String fromUtils = StringUtilsEncode.unescapeHtml3(msgErroTecnico);		
			String normalizeSpace = StringUtils.normalizeSpace(msgErroTecnico);
			
			retorno.concat("Utils: ").concat(fromUtils).concat("\n").concat("Normalize: ").concat(normalizeSpace);
		}
		return retorno;
	}

	/**
	 * @param dataHoraInclusao the dataHoraInclusao to set
	 */
	public void setDataHoraInclusao(String dataHoraInclusao) {
		this.dataHoraInclusao = dataHoraInclusao;
	}

	/**
	 * @return the codigoTransacao
	 */
	public String getCodigoTransacao() {
		return codigoTransacao;
	}

	/**
	 * @param codigoTransacao the codigoTransacao to set
	 */
	public void setCodigoTransacao(String codigoTransacao) {
		this.codigoTransacao = codigoTransacao;
	}

	/**
	 * @return the dataPagamento
	 */
	public String getDataPagamento() {
		return dataPagamento;
	}

	/**
	 * @param dataPagamento the dataPagamento to set
	 */
	public void setDataPagamento(String dataPagamento) {
		this.dataPagamento = dataPagamento;
	}

	/**
	 * @return the codigoProduto
	 */
	public int getCodigoProduto() {
		return codigoProduto;
	}

	/**
	 * @param codigoProduto the codigoProduto to set
	 */
	public void setCodigoProduto(int codigoProduto) {
		this.codigoProduto = codigoProduto;
	}

	/**
	 * @return the contaConvenio
	 */
	public String getContaConvenio() {
		return contaConvenio;
	}

	/**
	 * @param contaConvenio the contaConvenio to set
	 */
	public void setContaConvenio(String contaConvenio) {
		this.contaConvenio = contaConvenio;
	}

	/**
	 * @return the contaDebito
	 */
	public String getContaDebito() {
		return contaDebito;
	}

	/**
	 * @param contaDebito the contaDebito to set
	 */
	public void setContaDebito(String contaDebito) {
		this.contaDebito = contaDebito;
	}

	/**
	 * @return the qtAssNecessario
	 */
	public int getQtAssNecessario() {
		return qtAssNecessario;
	}

	/**
	 * @param qtAssNecessario the qtAssNecessario to set
	 */
	public void setQtAssNecessario(int qtAssNecessario) {
		this.qtAssNecessario = qtAssNecessario;
	}

	/**
	 * @return the qtAssPendente
	 */
	public int getQtAssPendente() {
		return qtAssPendente;
	}

	/**
	 * @param qtAssPendente the qtAssPendente to set
	 */
	public void setQtAssPendente(int qtAssPendente) {
		this.qtAssPendente = qtAssPendente;
	}

	/**
	 * @return the valorUsuarioPendencia
	 */
	public BigDecimal getValorUsuarioPendencia() {
		return valorUsuarioPendencia;
	}

	/**
	 * @param valorUsuarioPendencia the valorUsuarioPendencia to set
	 */
	public void setValorUsuarioPendencia(BigDecimal valorUsuarioPendencia) {
		this.valorUsuarioPendencia = valorUsuarioPendencia;
	}

	/**
	 * @return the flagPermiteAutorizar
	 */
	public String getFlagPermiteAutorizar() {
		return flagPermiteAutorizar;
	}

	/**
	 * @param flagPermiteAutorizar the flagPermiteAutorizar to set
	 */
	public void setFlagPermiteAutorizar(String flagPermiteAutorizar) {
		this.flagPermiteAutorizar = flagPermiteAutorizar;
	}

	/**
	 * @return the nomeFavorecidoPendencia
	 */
	public String getNomeFavorecidoPendencia() {
		return nomeFavorecidoPendencia;
	}

	/**
	 * @param nomeFavorecidoPendencia the nomeFavorecidoPendencia to set
	 */
	public void setNomeFavorecidoPendencia(String nomeFavorecidoPendencia) {
		this.nomeFavorecidoPendencia = nomeFavorecidoPendencia;
	}

	/**
	 * @return the codUsuarioUltimaAtu
	 */
	public String getCodUsuarioUltimaAtu() {
		return codUsuarioUltimaAtu;
	}

	/**
	 * @param codUsuarioUltimaAtu the codUsuarioUltimaAtu to set
	 */
	public void setCodUsuarioUltimaAtu(String codUsuarioUltimaAtu) {
		this.codUsuarioUltimaAtu = codUsuarioUltimaAtu;
	}

	/**
	 * @return the imgTransacao
	 */
	public String getImgTransacao() {
		return imgTransacao;
	}

	/**
	 * @param imgTransacao the imgTransacao to set
	 */
	public void setImgTransacao(String imgTransacao) {
		this.imgTransacao = imgTransacao;
	}

	/**
	 * @return the itemSelecionado
	 */
	public boolean isItemSelecionado() {
		return itemSelecionado;
	}

	/**
	 * @param itemSelecionado the itemSelecionado to set
	 */
	public void setItemSelecionado(boolean itemSelecionado) {
		this.itemSelecionado = itemSelecionado;
	}

	/**
	 * @return the timeStamp
	 */
	public String getTimeStamp() {
		return timeStamp;
	}

	/**
	 * @param timeStamp the timeStamp to set
	 */
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	/**
	 * @return the codigoTransacaoDetalhe
	 */
	public String getCodigoTransacaoDetalhe() {
		return codigoTransacaoDetalhe;
	}

	/**
	 * @param codigoTransacaoDetalhe the codigoTransacaoDetalhe to set
	 */
	public void setCodigoTransacaoDetalhe(String codigoTransacaoDetalhe) {
		this.codigoTransacaoDetalhe = codigoTransacaoDetalhe;
	}

	public String getDescricaoOperacao() {
		return descricaoOperacao;
	}

	public void setDescricaoOperacao(String descricaoOperacao) {
		this.descricaoOperacao = descricaoOperacao;
	}
	

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codUsuarioUltimaAtu == null) ? 0 : codUsuarioUltimaAtu.hashCode());
		result = prime * result + codigoProduto;
		result = prime * result + ((codigoTransacao == null) ? 0 : codigoTransacao.hashCode());
		result = prime * result + ((codigoTransacaoDetalhe == null) ? 0 : codigoTransacaoDetalhe.hashCode());
		result = prime * result + ((contaConvenio == null) ? 0 : contaConvenio.hashCode());
		result = prime * result + ((contaDebito == null) ? 0 : contaDebito.hashCode());
		result = prime * result + ((dataHoraInclusao == null) ? 0 : dataHoraInclusao.hashCode());
		result = prime * result + ((dataPagamento == null) ? 0 : dataPagamento.hashCode());
		result = prime * result + ((descricaoOperacao == null) ? 0 : descricaoOperacao.hashCode());
		result = prime * result + ((flagPermiteAutorizar == null) ? 0 : flagPermiteAutorizar.hashCode());
		result = prime * result + ((imgTransacao == null) ? 0 : imgTransacao.hashCode());
		result = prime * result + (itemSelecionado ? 1231 : 1237);
		result = prime * result + ((nomeFavorecidoPendencia == null) ? 0 : nomeFavorecidoPendencia.hashCode());
		result = prime * result + qtAssNecessario;
		result = prime * result + qtAssPendente;
		result = prime * result + ((timeStamp == null) ? 0 : timeStamp.hashCode());
		result = prime * result + ((valorUsuarioPendencia == null) ? 0 : valorUsuarioPendencia.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AutorizacoesPendenciaDadosAnaliticaDTO other = (AutorizacoesPendenciaDadosAnaliticaDTO) obj;
		if (codUsuarioUltimaAtu == null) {
			if (other.codUsuarioUltimaAtu != null)
				return false;
		} else if (!codUsuarioUltimaAtu.equals(other.codUsuarioUltimaAtu))
			return false;
		if (codigoProduto != other.codigoProduto)
			return false;
		if (codigoTransacao == null) {
			if (other.codigoTransacao != null)
				return false;
		} else if (!codigoTransacao.equals(other.codigoTransacao))
			return false;
		if (codigoTransacaoDetalhe == null) {
			if (other.codigoTransacaoDetalhe != null)
				return false;
		} else if (!codigoTransacaoDetalhe.equals(other.codigoTransacaoDetalhe))
			return false;
		if (contaConvenio == null) {
			if (other.contaConvenio != null)
				return false;
		} else if (!contaConvenio.equals(other.contaConvenio))
			return false;
		if (contaDebito == null) {
			if (other.contaDebito != null)
				return false;
		} else if (!contaDebito.equals(other.contaDebito))
			return false;
		if (dataHoraInclusao == null) {
			if (other.dataHoraInclusao != null)
				return false;
		} else if (!dataHoraInclusao.equals(other.dataHoraInclusao))
			return false;
		if (dataPagamento == null) {
			if (other.dataPagamento != null)
				return false;
		} else if (!dataPagamento.equals(other.dataPagamento))
			return false;
		if (descricaoOperacao == null) {
			if (other.descricaoOperacao != null)
				return false;
		} else if (!descricaoOperacao.equals(other.descricaoOperacao))
			return false;
		if (flagPermiteAutorizar == null) {
			if (other.flagPermiteAutorizar != null)
				return false;
		} else if (!flagPermiteAutorizar.equals(other.flagPermiteAutorizar))
			return false;
		if (imgTransacao == null) {
			if (other.imgTransacao != null)
				return false;
		} else if (!imgTransacao.equals(other.imgTransacao))
			return false;
		if (itemSelecionado != other.itemSelecionado)
			return false;
		if (nomeFavorecidoPendencia == null) {
			if (other.nomeFavorecidoPendencia != null)
				return false;
		} else if (!nomeFavorecidoPendencia.equals(other.nomeFavorecidoPendencia))
			return false;
		if (qtAssNecessario != other.qtAssNecessario)
			return false;
		if (qtAssPendente != other.qtAssPendente)
			return false;
		if (timeStamp == null) {
			if (other.timeStamp != null)
				return false;
		} else if (!timeStamp.equals(other.timeStamp))
			return false;
		if (valorUsuarioPendencia == null) {
			if (other.valorUsuarioPendencia != null)
				return false;
		} else if (!valorUsuarioPendencia.equals(other.valorUsuarioPendencia))
			return false;
		return true;
	}

	public String getMsgErro() {
		return msgErro;
	}

	public void setMsgErro(String msgErro) {
		this.msgErro = msgErro;
	}

	public String getMsgErroTecnico() {
		return msgErroTecnico;
	}

	public void setMsgErroTecnico(String msgErroTecnico) {
		this.msgErroTecnico = msgErroTecnico;
	}

	public String getContaConvenioAutoriza() {
		return contaConvenioAutoriza;
	}

	public void setContaConvenioAutoriza(String contaConvenioAutoriza) {
		this.contaConvenioAutoriza = contaConvenioAutoriza;
	}

	public String getDescricaoProduto() {
		return descricaoProduto;
	}

	public void setDescricaoProduto(String descricaoProduto) {
		this.descricaoProduto = descricaoProduto;
	}
}