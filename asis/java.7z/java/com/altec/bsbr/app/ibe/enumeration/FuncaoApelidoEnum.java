package com.altec.bsbr.app.ibe.enumeration;

public enum FuncaoApelidoEnum {
	INCLUSAO("I"), 
	EXCLUSAO("E"), 
	ALTERACAO("A"); 
	
	private String valorFuncao;

	private FuncaoApelidoEnum(String valorFuncao){
		this.valorFuncao = valorFuncao;
	}

	public String getFuncao() {
		return valorFuncao;
	}

}
