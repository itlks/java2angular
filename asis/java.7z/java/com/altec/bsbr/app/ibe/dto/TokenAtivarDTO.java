package com.altec.bsbr.app.ibe.dto;

public class TokenAtivarDTO {

	private String nomeUsuario;
	private String numeroSerie;
	private String hashNumeroSerie;
	private String senhaGerada;
	private String hashSenha;
	private String idFuncionario;
	private String msgErro;
	private String autenticacaoBancaria;
	private String dataTransacao;
	
	public String getNomeUsuario() {
		return nomeUsuario;
	}
	public void setNomeUsuario(String nomeUsuario) {
		this.nomeUsuario = nomeUsuario;
	}
	public String getNumeroSerie() {
		return numeroSerie;
	}
	public void setNumeroSerie(String numeroSerie) {
		this.numeroSerie = numeroSerie;
	}
	public String getSenhaGerada() {
		return senhaGerada;
	}
	public void setSenhaGerada(String senhaGerada) {
		this.senhaGerada = senhaGerada;
	}
	public String getIdFuncionario() {
		return idFuncionario;
	}
	public void setIdFuncionario(String idFuncionario) {
		this.idFuncionario = idFuncionario;
	}
	public String getMsgErro() {
		return msgErro;
	}
	public void setMsgErro(String msgErro) {
		this.msgErro = msgErro;
	}
	public String getAutenticacaoBancaria() {
		return autenticacaoBancaria;
	}
	public void setAutenticacaoBancaria(String autenticacaoBancaria) {
		this.autenticacaoBancaria = autenticacaoBancaria;
	}
	public String getDataTransacao() {
		return dataTransacao;
	}
	public void setDataTransacao(String dataTransacao) {
		this.dataTransacao = dataTransacao;
	}
	public String getHashNumeroSerie() {
		return hashNumeroSerie;
	}
	public void setHashNumeroSerie(String hashNumeroSerie) {
		this.hashNumeroSerie = hashNumeroSerie;
	}
	public String getHashSenha() {
		return hashSenha;
	}
	public void setHashSenha(String hashSenha) {
		this.hashSenha = hashSenha;
	}
}
