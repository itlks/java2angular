package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class ListarDetalheRecebimentoDiaSubTotalDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5357256871902148749L;

	private String TSOEIWCDBANDEIRA;
	private String TSOEIWDTTITULO;
	private String TSOEIWDSBAND;
	private String TSOEIWCDOPER;
	private String TSOEIWDSOPER;
	private String TSOEIWVLTITULO;
	private String TSOEIWCDECVENDA;

	/**
	 * @return the tSOEIWCDBANDEIRA
	 */
	public String getTSOEIWCDBANDEIRA() {
		return TSOEIWCDBANDEIRA;
	}

	/**
	 * @param tSOEIWCDBANDEIRA
	 *            the tSOEIWCDBANDEIRA to set
	 */
	public void setTSOEIWCDBANDEIRA(String tSOEIWCDBANDEIRA) {
		TSOEIWCDBANDEIRA = tSOEIWCDBANDEIRA;
	}

	/**
	 * @return the tSOEIWDTTITULO
	 */
	public String getTSOEIWDTTITULO() {
		return TSOEIWDTTITULO;
	}

	/**
	 * @param tSOEIWDTTITULO
	 *            the tSOEIWDTTITULO to set
	 */
	public void setTSOEIWDTTITULO(String tSOEIWDTTITULO) {
		TSOEIWDTTITULO = tSOEIWDTTITULO;
	}

	/**
	 * @return the tSOEIWDSBAND
	 */
	public String getTSOEIWDSBAND() {
		return TSOEIWDSBAND;
	}

	/**
	 * @param tSOEIWDSBAND
	 *            the tSOEIWDSBAND to set
	 */
	public void setTSOEIWDSBAND(String tSOEIWDSBAND) {
		TSOEIWDSBAND = tSOEIWDSBAND;
	}

	/**
	 * @return the tSOEIWCDOPER
	 */
	public String getTSOEIWCDOPER() {
		return TSOEIWCDOPER;
	}

	/**
	 * @param tSOEIWCDOPER
	 *            the tSOEIWCDOPER to set
	 */
	public void setTSOEIWCDOPER(String tSOEIWCDOPER) {
		TSOEIWCDOPER = tSOEIWCDOPER;
	}

	/**
	 * @return the tSOEIWDSOPER
	 */
	public String getTSOEIWDSOPER() {
		return TSOEIWDSOPER;
	}

	/**
	 * @param tSOEIWDSOPER
	 *            the tSOEIWDSOPER to set
	 */
	public void setTSOEIWDSOPER(String tSOEIWDSOPER) {
		TSOEIWDSOPER = tSOEIWDSOPER;
	}

	/**
	 * @return the tSOEIWVLTITULO
	 */
	public String getTSOEIWVLTITULO() {
		return TSOEIWVLTITULO;
	}

	/**
	 * @param tSOEIWVLTITULO
	 *            the tSOEIWVLTITULO to set
	 */
	public void setTSOEIWVLTITULO(String tSOEIWVLTITULO) {
		TSOEIWVLTITULO = tSOEIWVLTITULO;
	}

	/**
	 * @return the tSOEIWCDECVENDA
	 */
	public String getTSOEIWCDECVENDA() {
		return TSOEIWCDECVENDA;
	}

	/**
	 * @param tSOEIWCDECVENDA
	 *            the tSOEIWCDECVENDA to set
	 */
	public void setTSOEIWCDECVENDA(String tSOEIWCDECVENDA) {
		TSOEIWCDECVENDA = tSOEIWCDECVENDA;
	}

}
