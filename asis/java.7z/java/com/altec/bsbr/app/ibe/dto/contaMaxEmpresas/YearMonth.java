package com.altec.bsbr.app.ibe.dto.contaMaxEmpresas;

public class YearMonth {

	private String yearMonthReference;

	public String getYearMonthReference() {
		return yearMonthReference;
	}

	public void setYearMonthReference(String yearMonthReference) {
		this.yearMonthReference = yearMonthReference;
	}
	
}
