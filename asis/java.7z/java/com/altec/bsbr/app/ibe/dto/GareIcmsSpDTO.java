package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.altec.bsbr.app.ibe.anotation.Hash;
import com.altec.bsbr.app.ibe.dto.apelido.ApelidoDTO;

public class GareIcmsSpDTO implements Serializable {

	private static final long serialVersionUID = -1209860703825686316L;

	private String dataVencimento;
	private String dataVencimentoConvertida;
	private String codigoReceita;
	private String codigoReceitaFormatado;
	private String inscricaoEstadual;

	@Hash(position = 1)
	private String cnpjCpf;

	private String inscricaoDividaAtivaNumeroEtiqueta;
	private String referencia;
	private String aiimDeicmemeParcelamento;
	private String valorReceita;
	private String jurosMora;
	private String multaMoraInfracao;
	private String acrescimentoFinanceiro;
	private String honorariosAdvocaticios;
	private String valorTotal;
	private String dataPagamento;
	private String comprovanteBanco;
	private String contribuiente;
	private String endereco;
	private String cnae;
	private String observacao;
	private boolean cadastrarApelido;
	private String apelido;
	private String uf;
	private String ufFavorecida;
	private String municipio;
	private String telefone;
	private String dataHoraTransacao;

	private String autenticacaoBancaria;
	private String autenticacaoDigital;
	private String banco;

	private boolean pendencias;
	private boolean gravaApelido;
	private List<ApelidoDTO> listaApelidos = new ArrayList<ApelidoDTO>();
	
	private boolean usarApelido = false;
	
	
	public String getDataVencimento() {
		return dataVencimento;
	}
	public void setDataVencimento(String dataVencimento) {
		this.dataVencimento = dataVencimento;
	}
	public String getDataVencimentoConvertida() {
		return dataVencimentoConvertida;
	}
	public void setDataVencimentoConvertida(String dataVencimentoConvertida) {
		this.dataVencimentoConvertida = dataVencimentoConvertida;
	}
	public String getCodigoReceita() {
		return codigoReceita;
	}
	public void setCodigoReceita(String codigoReceita) {
		this.codigoReceita = codigoReceita;
	}
	public String getCodigoReceitaFormatado() {
		return codigoReceitaFormatado;
	}
	public void setCodigoReceitaFormatado(String codigoReceitaFormatado) {
		this.codigoReceitaFormatado = codigoReceitaFormatado;
	}
	public String getInscricaoEstadual() {
		return inscricaoEstadual;
	}
	public void setInscricaoEstadual(String inscricaoEstadual) {
		this.inscricaoEstadual = inscricaoEstadual;
	}
	public String getCnpjCpf() {
		return cnpjCpf;
	}
	public void setCnpjCpf(String cnpjCpf) {
		this.cnpjCpf = cnpjCpf;
	}
	public String getInscricaoDividaAtivaNumeroEtiqueta() {
		return inscricaoDividaAtivaNumeroEtiqueta;
	}
	public void setInscricaoDividaAtivaNumeroEtiqueta(String inscricaoDividaAtivaNumeroEtiqueta) {
		this.inscricaoDividaAtivaNumeroEtiqueta = inscricaoDividaAtivaNumeroEtiqueta;
	}
	public String getReferencia() {
		return referencia;
	}
	public void setReferencia(String referencia) {
		this.referencia = referencia;
	}
	public String getAiimDeicmemeParcelamento() {
		return aiimDeicmemeParcelamento;
	}
	public void setAiimDeicmemeParcelamento(String aiimDeicmemeParcelamento) {
		this.aiimDeicmemeParcelamento = aiimDeicmemeParcelamento;
	}
	public String getValorReceita() {
		return valorReceita;
	}
	public void setValorReceita(String valorReceita) {
		this.valorReceita = valorReceita;
	}
	public String getJurosMora() {
		return jurosMora;
	}
	public void setJurosMora(String jurosMora) {
		this.jurosMora = jurosMora;
	}
	public String getMultaMoraInfracao() {
		return multaMoraInfracao;
	}
	public void setMultaMoraInfracao(String multaMoraInfracao) {
		this.multaMoraInfracao = multaMoraInfracao;
	}
	public String getAcrescimentoFinanceiro() {
		return acrescimentoFinanceiro;
	}
	public void setAcrescimentoFinanceiro(String acrescimentoFinanceiro) {
		this.acrescimentoFinanceiro = acrescimentoFinanceiro;
	}
	public String getHonorariosAdvocaticios() {
		return honorariosAdvocaticios;
	}
	public void setHonorariosAdvocaticios(String honorariosAdvocaticios) {
		this.honorariosAdvocaticios = honorariosAdvocaticios;
	}
	public String getValorTotal() {
		return valorTotal;
	}
	public void setValorTotal(String valorTotal) {
		this.valorTotal = valorTotal;
	}
	public String getDataPagamento() {
		return dataPagamento;
	}
	public void setDataPagamento(String dataPagamento) {
		this.dataPagamento = dataPagamento;
	}
	public String getComprovanteBanco() {
		return comprovanteBanco;
	}
	public void setComprovanteBanco(String comprovanteBanco) {
		this.comprovanteBanco = comprovanteBanco;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public String getCnae() {
		return cnae;
	}
	public void setCnae(String cnae) {
		this.cnae = cnae;
	}
	public String getObservacao() {
		return observacao;
	}
	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}
	public boolean isCadastrarApelido() {
		return cadastrarApelido;
	}
	public void setCadastrarApelido(boolean cadastrarApelido) {
		this.cadastrarApelido = cadastrarApelido;
	}
	public String getApelido() {
		return apelido;
	}
	public void setApelido(String apelido) {
		this.apelido = apelido;
	}
	public String getUf() {
		return uf;
	}
	public void setUf(String uf) {
		this.uf = uf;
	}
	public String getUfFavorecida() {
		return ufFavorecida;
	}
	public void setUfFavorecida(String ufFavorecida) {
		this.ufFavorecida = ufFavorecida;
	}
	public String getMunicipio() {
		return municipio;
	}
	public void setMunicipio(String municipio) {
		this.municipio = municipio;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public String getDataHoraTransacao() {
		return dataHoraTransacao;
	}
	public void setDataHoraTransacao(String dataHoraTransacao) {
		this.dataHoraTransacao = dataHoraTransacao;
	}
	public String getAutenticacaoBancaria() {
		return autenticacaoBancaria;
	}
	public void setAutenticacaoBancaria(String autenticacaoBancaria) {
		this.autenticacaoBancaria = autenticacaoBancaria;
	}
	public String getAutenticacaoDigital() {
		return autenticacaoDigital;
	}
	public void setAutenticacaoDigital(String autenticacaoDigital) {
		this.autenticacaoDigital = autenticacaoDigital;
	}
	public String getBanco() {
		return banco;
	}
	public void setBanco(String banco) {
		this.banco = banco;
	}
	public boolean isPendencias() {
		return pendencias;
	}
	public void setPendencias(boolean pendencias) {
		this.pendencias = pendencias;
	}
	public boolean isGravaApelido() {
		return gravaApelido;
	}
	public void setGravaApelido(boolean gravaApelido) {
		this.gravaApelido = gravaApelido;
	}
	public List<ApelidoDTO> getListaApelidos() {
		return listaApelidos;
	}
	public void setListaApelidos(List<ApelidoDTO> listaApelidos) {
		this.listaApelidos = listaApelidos;
	}
	public boolean isUsarApelido() {
		return usarApelido;
	}
	public void setUsarApelido(boolean usarApelido) {
		this.usarApelido = usarApelido;
	}
	public String getContribuiente() {
		return contribuiente;
	}
	public void setContribuiente(String contribuiente) {
		this.contribuiente = contribuiente;
	}
}
