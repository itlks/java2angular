package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class PerfilAutorizacaoDTO implements Serializable{

	private static final long serialVersionUID = 5458833361808809709L;
	
	private String nomePerfil;
	private String descricaoPerfil;
	private int numeroSequencial;
	
	public PerfilAutorizacaoDTO(){}
	
	public PerfilAutorizacaoDTO(int numeroSequencial, String nomePerfil , String descricaoPerfil){
		super();
		this.setNumeroSequencial(numeroSequencial);
		this.setNomePerfil(nomePerfil);
		this.setDescricaoPerfil(descricaoPerfil);
	}
	
	public String getNomePerfil() {
		return nomePerfil;
	}
	public void setNomePerfil(String nomePerfil) {
		this.nomePerfil = nomePerfil;
	}
	public String getDescricaoPerfil() {
		return descricaoPerfil;
	}
	public void setDescricaoPerfil(String descricaoPerfil) {
		this.descricaoPerfil = descricaoPerfil;
	}
	public int getNumeroSequencial() {
		return numeroSequencial;
	}
	public void setNumeroSequencial(int numeroSequencial) {
		this.numeroSequencial = numeroSequencial;
	}

}
