/*
 * Cheque Ades�o Empresa Protegido (Rest Implementation para controle de fluxo)
 *
 */
package com.altec.bsbr.app.ibe.rest.service.impl;

import java.io.Serializable;

import com.altec.bsbr.app.ibe.dto.pendencia.RetornoConsultaPendencia;
import com.altec.bsbr.app.ibe.dto.pendencia.RetornoPendencia;
import com.altec.bsbr.app.ibe.web.jsf.attributes.AtributosDaAplicacao;
import com.altec.bsbr.app.ibe.web.jsf.attributes.AtributosDaSessao;
import com.altec.bsbr.fw.BusinessException;

public interface SeguroPrestamistaRequestServices extends Serializable {
	
	public RetornoConsultaPendencia consultarSeGeraPendencia(AtributosDaAplicacao aplicacao, AtributosDaSessao session) throws BusinessException;

	public RetornoPendencia gerarPendencia(RetornoConsultaPendencia retorno, AtributosDaSessao session) throws BusinessException;

}
