package com.altec.bsbr.app.ibe.dto;

import java.util.ArrayList;
import java.util.List;

public class LimiteDiarioAlterarDTO {
	
	public static final String QTDE3 = "3";
	public static final String QTDE5 = "5";
	public static final String QTDE10 = "10";
	public static final String QTDE20 = "20";
	public static final String QTDE25 = "25";
	
	private String qtdeCartaoAvulso;
	private String recomendacaoSeguranca;
	private String valorTributos;
	private String valorDocTed;
	private String valorEntreContas;
	private String valorContasConcessionarias;
	private String valotTitulos;
	private String valorCartaoAvulso;
	private String dataTransacao;
	private String termoAceite;
	private List<String> lTermoAceite = new ArrayList<String>();
	private String nrContaSelecionada;
	private LimiteDiarioEmpresaDTO empresaSelecionada;
	
	
	public String getQtdeCartaoAvulso() {
		return qtdeCartaoAvulso;
	}
	public void setQtdeCartaoAvulso(String qtdeCartaoAvulso) {
		this.qtdeCartaoAvulso = qtdeCartaoAvulso;
	}
	public String getRecomendacaoSeguranca() {
		return recomendacaoSeguranca;
	}
	public void setRecomendacaoSeguranca(String recomendacaoSeguranca) {
		this.recomendacaoSeguranca = recomendacaoSeguranca;
	}
	public String getValorTributos() {
		return valorTributos;
	}
	public void setValorTributos(String valorTributos) {
		this.valorTributos = valorTributos;
	}

	public String getValorDocTed() {
		return valorDocTed;
	}

	public void setValorDocTed(String valorDocTed) {
		this.valorDocTed = valorDocTed;
	}

	public String getValorEntreContas() {
		return valorEntreContas;
	}

	public void setValorEntreContas(String valorEntreContas) {
		this.valorEntreContas = valorEntreContas;
	}

	public String getValorContasConcessionarias() {
		return valorContasConcessionarias;
	}

	public void setValorContasConcessionarias(String valorContasConcessionarias) {
		this.valorContasConcessionarias = valorContasConcessionarias;
	}

	public String getValotTitulos() {
		return valotTitulos;
	}

	public void setValotTitulos(String valotTitulos) {
		this.valotTitulos = valotTitulos;
	}

	public String getValorCartaoAvulso() {
		return valorCartaoAvulso;
	}

	public void setValorCartaoAvulso(String valorCartaoAvulso) {
		this.valorCartaoAvulso = valorCartaoAvulso;
	}

	public String getDataTransacao() {
		return dataTransacao;
	}

	public void setDataTransacao(String dataTransacao) {
		this.dataTransacao = dataTransacao;
	}

	public String getTermoAceite() {
		return termoAceite;
	}

	public void setTermoAceite(String termoAceite) {
		this.termoAceite = termoAceite;
	}

	public List<String> getlTermoAceite() {
		return lTermoAceite;
	}

	public void setlTermoAceite(List<String> lTermoAceite) {
		this.lTermoAceite = lTermoAceite;
	}

	public LimiteDiarioEmpresaDTO getEmpresaSelecionada() {
		return empresaSelecionada;
	}

	public void setEmpresaSelecionada(LimiteDiarioEmpresaDTO empresaSelecionada) {
		this.empresaSelecionada = empresaSelecionada;
	}

	public String getNrContaSelecionada() {
		return nrContaSelecionada;
	}

	public void setNrContaSelecionada(String nrContaSelecionada) {
		this.nrContaSelecionada = nrContaSelecionada;
	}

}
