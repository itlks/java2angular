package com.altec.bsbr.app.ibe.enumeration;

import com.altec.bsbr.app.ibe.util.UtilFunction;

/**
 * @author X186801
 *
 */
public enum TipoCotaOuParcelaAgendamentoEnum {

	CODIGO_1	("1", "1� Parcela"),
	CODIGO_2	("2", "2� Parcela"),
	CODIGO_3	("3", "3� Parcela"),
	CODIGO_4	("4", "4� Parcela"),
	CODIGO_5	("5", "5� Parcela"),
	CODIGO_6	("6", "6� Parcela"),
	CODIGO_7	("7", "Cota �nica com desconto"),
	CODIGO_8	("8", "Cota �nica sem desconto");
	
	private String codigo;
	private String descricao;

	private TipoCotaOuParcelaAgendamentoEnum(String codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public static TipoCotaOuParcelaAgendamentoEnum findByCodigo(String codigo) {
		TipoCotaOuParcelaAgendamentoEnum retorno = null;

		if (UtilFunction.isNotBlankOrNull(codigo)) {
			for (TipoCotaOuParcelaAgendamentoEnum item : values()) {
				if (item.getCodigo().equals(codigo)) {
					retorno = item;
					break;
				}
			}
		}

		return retorno;
	}

	public String getCodigo() {
		return codigo;
	}

	public String getDescricao() {
		return descricao;
	}

}
