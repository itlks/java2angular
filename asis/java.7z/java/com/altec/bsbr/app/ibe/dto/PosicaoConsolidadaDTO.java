package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class PosicaoConsolidadaDTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4048765775278824430L;
	
	
	private String produto;
	private String codigo;
	private String vlBruto;
	private String vlliquido;

	
	public String getProduto() {
		return produto;
	}
	public void setProduto(String produto) {
		this.produto = produto;
	}
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	public String getVlBruto() {
		return vlBruto;
	}
	public void setVlBruto(String vlBruto) {
		this.vlBruto = vlBruto;
	}
	public String getVlliquido() {
		return vlliquido;
	}
	public void setVlliquido(String vlliquido) {
		this.vlliquido = vlliquido;
	}
	
	

}
