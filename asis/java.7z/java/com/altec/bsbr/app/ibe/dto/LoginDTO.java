package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;



public class LoginDTO implements Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
  
	private String agencia;       
	private String conta;
	private String usuario;
	private String senha;
	private String senhaNova;
	private String senhaConfirmacao;
	private String banco = "0033";
	private String msgErroJavaStript;
	private String msgErroTecladoVirtual;
	private String ticket;
	
	
	public String getAgencia() {
		return agencia;
	}
	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}
	public String getConta() {
		return conta;
	}
	public void setConta(String conta) {
		this.conta = conta;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	public String getBanco() {
		return banco;
	}
	public void setBanco(String banco) {
		this.banco = banco;
	}
	public String getSenhaNova() {
		return senhaNova;
	}
	public void setSenhaNova(String senhaNova) {
		this.senhaNova = senhaNova;
	}
	public String getSenhaConfirmacao() {
		return senhaConfirmacao;
	}
	public void setSenhaConfirmacao(String senhaConfirmacao) {
		this.senhaConfirmacao = senhaConfirmacao;
	}
	public String getMsgErroJavaStript() {
		return msgErroJavaStript;
	}
	public void setMsgErroJavaStript(String msgErroJavaStript) {
		this.msgErroJavaStript = msgErroJavaStript;
	}
	public String getMsgErroTecladoVirtual() {
		return msgErroTecladoVirtual;
	}
	public void setMsgErroTecladoVirtual(String msgErroTecladoVirtual) {
		this.msgErroTecladoVirtual = msgErroTecladoVirtual;
	}
	public String getTicket() {
		return ticket;
	}
	public void setTicket(String ticket) {
		this.ticket = ticket;
	} 

}
