package com.altec.bsbr.app.ibe.dto;

import java.util.Date;

public class MobileTokenExcluirSessaoDTO {

	private String nome;
	private Date dataInicial;
	private Date dataFinal;
	
	private String contrato;
	
	private String idTransacao;
	private String agencia;
	private String agenciaDestino;
	private String banco;
	private String bancoDestino;
	private String canal;
	private String canalWC;
	private String chaveAutenticacao;
	private String clienteDestino;
	private String codigoConexao;
	private String codigoErro;
	private Long codigoUsuario;
	private String codProduto;
	private String codServico;
	private String contaCorrente;
	private String contaCorrenteDestino;
	private String dataAgenda;
	private String estatistica;
	private String fisicaJuridica;
	private String historicoDestino;
	private String horaAgenda;
	private String ipClient;
	private String ipServer;
	private String situacaoTrans;
	private String valorOperacao;
	
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public Date getDataInicial() {
		return dataInicial;
	}
	public void setDataInicial(Date dataInicial) {
		this.dataInicial = dataInicial;
	}
	public Date getDataFinal() {
		return dataFinal;
	}
	public void setDataFinal(Date dataFinal) {
		this.dataFinal = dataFinal;
	}
	public String getContrato() {
		return contrato;
	}
	public void setContrato(String contrato) {
		this.contrato = contrato;
	}
	public String getIdTransacao() {
		return idTransacao;
	}
	public void setIdTransacao(String idTransacao) {
		this.idTransacao = idTransacao;
	}
	public String getAgencia() {
		return agencia;
	}
	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}
	public String getAgenciaDestino() {
		return agenciaDestino;
	}
	public void setAgenciaDestino(String agenciaDestino) {
		this.agenciaDestino = agenciaDestino;
	}
	public String getBanco() {
		return banco;
	}
	public void setBanco(String banco) {
		this.banco = banco;
	}
	public String getBancoDestino() {
		return bancoDestino;
	}
	public void setBancoDestino(String bancoDestino) {
		this.bancoDestino = bancoDestino;
	}
	public String getCanal() {
		return canal;
	}
	public void setCanal(String canal) {
		this.canal = canal;
	}
	public String getCanalWC() {
		return canalWC;
	}
	public void setCanalWC(String canalWC) {
		this.canalWC = canalWC;
	}
	
	public String getChaveAutenticacao() {
		return chaveAutenticacao;
	}
	public void setChaveAutenticacao(String chaveAutenticacao) {
		this.chaveAutenticacao = chaveAutenticacao;
	}
	public String getClienteDestino() {
		return clienteDestino;
	}
	public void setClienteDestino(String clienteDestino) {
		this.clienteDestino = clienteDestino;
	}
	public String getCodigoConexao() {
		return codigoConexao;
	}
	public void setCodigoConexao(String codigoConexao) {
		this.codigoConexao = codigoConexao;
	}
	public String getCodigoErro() {
		return codigoErro;
	}
	public void setCodigoErro(String codigoErro) {
		this.codigoErro = codigoErro;
	}
	public Long getCodigoUsuario() {
		return codigoUsuario;
	}
	public void setCodigoUsuario(Long codigoUsuario) {
		this.codigoUsuario = codigoUsuario;
	}
	public String getCodProduto() {
		return codProduto;
	}
	public void setCodProduto(String codProduto) {
		this.codProduto = codProduto;
	}
	public String getCodServico() {
		return codServico;
	}
	public void setCodServico(String codServico) {
		this.codServico = codServico;
	}
	public String getContaCorrente() {
		return contaCorrente;
	}
	public void setContaCorrente(String contaCorrente) {
		this.contaCorrente = contaCorrente;
	}
	public String getContaCorrenteDestino() {
		return contaCorrenteDestino;
	}
	public void setContaCorrenteDestino(String contaCorrenteDestino) {
		this.contaCorrenteDestino = contaCorrenteDestino;
	}
	public String getDataAgenda() {
		return dataAgenda;
	}
	public void setDataAgenda(String dataAgenda) {
		this.dataAgenda = dataAgenda;
	}
	public String getEstatistica() {
		return estatistica;
	}
	public void setEstatistica(String estatistica) {
		this.estatistica = estatistica;
	}
	public String getFisicaJuridica() {
		return fisicaJuridica;
	}
	public void setFisicaJuridica(String fisicaJuridica) {
		this.fisicaJuridica = fisicaJuridica;
	}
	public String getHistoricoDestino() {
		return historicoDestino;
	}
	public void setHistoricoDestino(String historicoDestino) {
		this.historicoDestino = historicoDestino;
	}
	public String getHoraAgenda() {
		return horaAgenda;
	}
	public void setHoraAgenda(String horaAgenda) {
		this.horaAgenda = horaAgenda;
	}
	public String getIpClient() {
		return ipClient;
	}
	public void setIpClient(String ipClient) {
		this.ipClient = ipClient;
	}
	public String getIpServer() {
		return ipServer;
	}
	public void setIpServer(String ipServer) {
		this.ipServer = ipServer;
	}
	public String getSituacaoTrans() {
		return situacaoTrans;
	}
	public void setSituacaoTrans(String situacaoTrans) {
		this.situacaoTrans = situacaoTrans;
	}
	public String getValorOperacao() {
		return valorOperacao;
	}
	public void setValorOperacao(String valorOperacao) {
		this.valorOperacao = valorOperacao;
	}
	
		
	
	
}
