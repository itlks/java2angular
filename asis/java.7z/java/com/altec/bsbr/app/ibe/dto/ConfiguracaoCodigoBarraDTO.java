package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class ConfiguracaoCodigoBarraDTO  implements Serializable {

	private static final long serialVersionUID = 1L;
	private String urlPageAviso;
	private boolean usarCliente;
	public ConfiguracaoCodigoBarraDTO(){

	}
	public ConfiguracaoCodigoBarraDTO(String urlPageAviso, boolean usarCliente){
		this.urlPageAviso = urlPageAviso;
		this.usarCliente = usarCliente;
	}
	public String getUrlPageAviso() {
		return urlPageAviso;
	}
	public void setUrlPageAviso(String urlPageAviso) {
		this.urlPageAviso = urlPageAviso;
	}
	public boolean isUsarCliente() {
		return usarCliente;
	}
	public void setUsarCliente(boolean usarCliente) {
		this.usarCliente = usarCliente;
	}

}
