package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;

import com.altec.bsbr.app.ibe.enumeration.TipoCartaoEnum;

public class ListaRecebimentoRSDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1423411654799420729L;
	
	private String OESYCODBAND;
	private String OESYNOMBAND;
	private String OESYVLRCRTCRE;
	private String OESYVLRCRTCRESN;
	private String OESYVLRCRTDEB;
	private String OESYVLRCRTDEBSN;
	private String OESYVLRCRTVAL;
	private String OESYVLRCRTVALSN;

	
	
	private BigDecimal OESYCODBANDFORMATADO;
	private String OESYNOMBANDFORMATADO;
	private BigDecimal OESYVLRCRTCREFORMATADO;
	private BigDecimal OESYVLRCRTCRESNFORMATADO;
	private BigDecimal OESYVLRCRTDEBFORMATADO;
	private BigDecimal OESYVLRCRTDEBSNFORMATADO;
	private BigDecimal OESYVLRCRTVALFORMATADO;
	private BigDecimal OESYVLRCRTVALSNFORMATADO;
	
	private String tipoCartaoCredito = new String();
	private String tipoCartaoDebito = new String();
	private boolean mostrarLinha = false;
	
	private TipoCartaoEnum cartaoEnum;
	private boolean mostraBotaoCre = false;
	private boolean mostraBotaoDeb = false;
	private boolean opcao;
	
	private String descricaoTotal;
	private BigDecimal valorTotal = BigDecimal.ZERO;
	private boolean mostrarLinhaVisa = false;
	
	public String getOESYCODBAND() {
		return OESYCODBAND;
	}
	public void setOESYCODBAND(String oESYCODBAND) {
		OESYCODBAND = oESYCODBAND;
	}
	public String getOESYNOMBAND() {
		return OESYNOMBAND;
	}
	public void setOESYNOMBAND(String oESYNOMBAND) {
		OESYNOMBAND = oESYNOMBAND;
	}
	public String getOESYVLRCRTCRE() {
		return OESYVLRCRTCRE;
	}
	public void setOESYVLRCRTCRE(String oESYVLRCRTCRE) {
		OESYVLRCRTCRE = oESYVLRCRTCRE;
	}
	public String getOESYVLRCRTCRESN() {
		return OESYVLRCRTCRESN;
	}
	public void setOESYVLRCRTCRESN(String oESYVLRCRTCRESN) {
		OESYVLRCRTCRESN = oESYVLRCRTCRESN;
	}
	public String getOESYVLRCRTDEB() {
		return OESYVLRCRTDEB;
	}
	public void setOESYVLRCRTDEB(String oESYVLRCRTDEB) {
		OESYVLRCRTDEB = oESYVLRCRTDEB;
	}
	public String getOESYVLRCRTDEBSN() {
		return OESYVLRCRTDEBSN;
	}
	public void setOESYVLRCRTDEBSN(String oESYVLRCRTDEBSN) {
		OESYVLRCRTDEBSN = oESYVLRCRTDEBSN;
	}
	public String getOESYVLRCRTVAL() {
		return OESYVLRCRTVAL;
	}
	public void setOESYVLRCRTVAL(String oESYVLRCRTVAL) {
		OESYVLRCRTVAL = oESYVLRCRTVAL;
	}
	public String getOESYVLRCRTVALSN() {
		return OESYVLRCRTVALSN;
	}
	public void setOESYVLRCRTVALSN(String oESYVLRCRTVALSN) {
		OESYVLRCRTVALSN = oESYVLRCRTVALSN;
	}
	public BigDecimal getOESYCODBANDFORMATADO() {
		return OESYCODBANDFORMATADO;
	}
	public void setOESYCODBANDFORMATADO(BigDecimal oESYCODBANDFORMATADO) {
		OESYCODBANDFORMATADO = oESYCODBANDFORMATADO;
	}
	public String getOESYNOMBANDFORMATADO() {
		return OESYNOMBANDFORMATADO;
	}
	public void setOESYNOMBANDFORMATADO(String oESYNOMBANDFORMATADO) {
		OESYNOMBANDFORMATADO = oESYNOMBANDFORMATADO;
	}
	public BigDecimal getOESYVLRCRTCREFORMATADO() {
		return OESYVLRCRTCREFORMATADO;
	}
	public void setOESYVLRCRTCREFORMATADO(BigDecimal oESYVLRCRTCREFORMATADO) {
		OESYVLRCRTCREFORMATADO = oESYVLRCRTCREFORMATADO;
	}
	public BigDecimal getOESYVLRCRTCRESNFORMATADO() {
		return OESYVLRCRTCRESNFORMATADO;
	}
	public void setOESYVLRCRTCRESNFORMATADO(BigDecimal oESYVLRCRTCRESNFORMATADO) {
		OESYVLRCRTCRESNFORMATADO = oESYVLRCRTCRESNFORMATADO;
	}
	public BigDecimal getOESYVLRCRTDEBFORMATADO() {
		return OESYVLRCRTDEBFORMATADO;
	}
	public void setOESYVLRCRTDEBFORMATADO(BigDecimal oESYVLRCRTDEBFORMATADO) {
		OESYVLRCRTDEBFORMATADO = oESYVLRCRTDEBFORMATADO;
	}
	public BigDecimal getOESYVLRCRTDEBSNFORMATADO() {
		return OESYVLRCRTDEBSNFORMATADO;
	}
	public void setOESYVLRCRTDEBSNFORMATADO(BigDecimal oESYVLRCRTDEBSNFORMATADO) {
		OESYVLRCRTDEBSNFORMATADO = oESYVLRCRTDEBSNFORMATADO;
	}
	public BigDecimal getOESYVLRCRTVALFORMATADO() {
		return OESYVLRCRTVALFORMATADO;
	}
	public void setOESYVLRCRTVALFORMATADO(BigDecimal oESYVLRCRTVALFORMATADO) {
		OESYVLRCRTVALFORMATADO = oESYVLRCRTVALFORMATADO;
	}
	public BigDecimal getOESYVLRCRTVALSNFORMATADO() {
		return OESYVLRCRTVALSNFORMATADO;
	}
	public void setOESYVLRCRTVALSNFORMATADO(BigDecimal oESYVLRCRTVALSNFORMATADO) {
		OESYVLRCRTVALSNFORMATADO = oESYVLRCRTVALSNFORMATADO;
	}

	public TipoCartaoEnum getCartaoEnum() {
		return cartaoEnum;
	}
	public void setCartaoEnum(TipoCartaoEnum cartaoEnum) {
		this.cartaoEnum = cartaoEnum;
	}

	public String getTipoCartaoCredito() {
		return tipoCartaoCredito;
	}
	public void setTipoCartaoCredito(String tipoCartaoCredito) {
		this.tipoCartaoCredito = tipoCartaoCredito;
	}
	public String getTipoCartaoDebito() {
		return tipoCartaoDebito;
	}
	public void setTipoCartaoDebito(String tipoCartaoDebito) {
		this.tipoCartaoDebito = tipoCartaoDebito;
	}
	public boolean isOpcao() {
		return opcao;
	}
	public void setOpcao(boolean opcao) {
		this.opcao = opcao;
	}
	public String getDescricaoTotal() {
		return descricaoTotal;
	}
	public void setDescricaoTotal(String descricaoTotal) {
		this.descricaoTotal = descricaoTotal;
	}
	public BigDecimal getValorTotal() {
		return valorTotal;
	}
	public void setValorTotal(BigDecimal valorTotal) {
		this.valorTotal = valorTotal;
	}
	public boolean isMostraBotaoCre() {
		return mostraBotaoCre;
	}
	public void setMostraBotaoCre(boolean mostraBotaoCre) {
		this.mostraBotaoCre = mostraBotaoCre;
	}
	public boolean isMostraBotaoDeb() {
		return mostraBotaoDeb;
	}
	public void setMostraBotaoDeb(boolean mostraBotaoDeb) {
		this.mostraBotaoDeb = mostraBotaoDeb;
	}
	public boolean isMostrarLinha() {
		return mostrarLinha;
	}
	public void setMostrarLinha(boolean mostrarLinha) {
		this.mostrarLinha = mostrarLinha;
	}
	public boolean isMostrarLinhaVisa() {
		return mostrarLinhaVisa;
	}
	public void setMostrarLinhaVisa(boolean mostrarLinhaVisa) {
		this.mostrarLinhaVisa = mostrarLinhaVisa;
	}

	

	
	
	
	
	
	
	
	

}
