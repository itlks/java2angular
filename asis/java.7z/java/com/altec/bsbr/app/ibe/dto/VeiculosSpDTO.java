package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class VeiculosSpDTO implements Serializable {

	private static final long serialVersionUID = -1159052692733266616L;

	private String cpf;
	private String assinatura;
	private String token;
	private String cpfMasked;
	private BigDecimal taxaRegistro;
	private String contaCorrente;
	private Integer codServ;
	private boolean contemPendencia;
	private String autentiDigital;
	private String autenticacaoBancaria;
	private String dataHoraPagamento;
	private String msgErro;
	private Date dataHoraPagamentoContabil;

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getAssinatura() {
		return assinatura;
	}

	public void setAssinatura(String assinatura) {
		this.assinatura = assinatura;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getMsgErro() {
		return msgErro;
	}

	public void setMsgErro(String msgErro) {
		this.msgErro = msgErro;
	}

	public String getContaCorrente() {
		return contaCorrente;
	}

	public void setContaCorrente(String contaCorrente) {
		this.contaCorrente = contaCorrente;
	}

	public String getCpfMasked() {
		return cpfMasked;
	}

	public void setCpfMasked(String cpfMasked) {
		this.cpfMasked = cpfMasked;
	}

	public BigDecimal getTaxaRegistro() {
		return taxaRegistro;
	}

	public void setTaxaRegistro(BigDecimal taxaRegistro) {
		this.taxaRegistro = taxaRegistro;
	}

	public Integer getCodServ() {
		return codServ;
	}

	public void setCodServ(Integer codServ) {
		this.codServ = codServ;
	}

	public boolean isContemPendencia() {
		return contemPendencia;
	}

	public void setContemPendencia(boolean contemPendencia) {
		this.contemPendencia = contemPendencia;
	}

	public String getAutentiDigital() {
		return autentiDigital;
	}

	public void setAutentiDigital(String autentiDigital) {
		this.autentiDigital = autentiDigital;
	}

	public String getAutenticacaoBancaria() {
		return autenticacaoBancaria;
	}

	public void setAutenticacaoBancaria(String autenticacaoBancaria) {
		this.autenticacaoBancaria = autenticacaoBancaria;
	}

	public String getDataHoraPagamento() {
		return dataHoraPagamento;
	}

	public void setDataHoraPagamento(String dataHoraPagamento) {
		this.dataHoraPagamento = dataHoraPagamento;
	}

	public Date getDataHoraPagamentoContabil() {
		return dataHoraPagamentoContabil;
	}

	public void setDataHoraPagamentoContabil(Date dataHoraPagamentoContabil) {
		this.dataHoraPagamentoContabil = dataHoraPagamentoContabil;
	}

}
