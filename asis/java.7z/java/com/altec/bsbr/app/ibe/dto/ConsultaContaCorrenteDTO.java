package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class ConsultaContaCorrenteDTO implements Serializable {
	
	private static final long serialVersionUID = 1679752992787881820L;
	
	private String cpfCnpj;
	private String agencia;
	private String conta;
	private String situacao;
	private boolean excluir;
	private boolean novaConta;
	
	public String getCpfCnpj() {
		return cpfCnpj;
	}
	public void setCpfCnpj(String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}
	public String getAgencia() {
		return agencia;
	}
	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}
	public String getConta() {
		return conta;
	}
	public void setConta(String conta) {
		this.conta = conta;
	}
	public String getSituacao() {
		return situacao;
	}
	public void setSituacao(String situacao) {
		this.situacao = situacao;
	}
	public boolean getExcluir() {
		return excluir;
	}
	public void setExcluir(boolean excluir) {
		this.excluir = excluir;
	}
	public boolean getNovaConta() {
		return novaConta;
	}
	public void setNovaConta(boolean novaConta) {
		this.novaConta = novaConta;
	}
	
}
