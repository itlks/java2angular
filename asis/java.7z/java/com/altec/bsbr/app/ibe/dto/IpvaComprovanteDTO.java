package com.altec.bsbr.app.ibe.dto;

import java.math.BigDecimal;

public class IpvaComprovanteDTO {

	private String exIpva;
	private BigDecimal vlIpva;

	public BigDecimal getVlIpva() {
		return vlIpva;
	}

	public void setVlIpva(BigDecimal vlIpva) {
		this.vlIpva = vlIpva;
	}

	public String getExIpva() {
		return exIpva;
	}

	public void setExIpva(String exIpva) {
		this.exIpva = exIpva;
	}

}
