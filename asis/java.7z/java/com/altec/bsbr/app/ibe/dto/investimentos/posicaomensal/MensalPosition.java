
package com.altec.bsbr.app.ibe.dto.investimentos.posicaomensal;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class MensalPosition implements Serializable
{

    private List<Position> position = new ArrayList<Position>();
    private final static long serialVersionUID = 6919140350775976296L;

    /**
     * No args constructor for use in serialization
     * 
     */
    public MensalPosition() {
    }

    /**
     * 
     * @param position
     */
    public MensalPosition(List<Position> position) {
        super();
        this.position = position;
    }

    public List<Position> getPosition() {
        return position;
    }

    public void setPosition(List<Position> position) {
        this.position = position;
    }

    public MensalPosition withPosition(List<Position> position) {
        this.position = position;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(position).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof MensalPosition) == false) {
            return false;
        }
        MensalPosition rhs = ((MensalPosition) other);
        return new EqualsBuilder().append(position, rhs.position).isEquals();
    }

}
