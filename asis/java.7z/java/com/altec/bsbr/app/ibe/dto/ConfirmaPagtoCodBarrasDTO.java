package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.List;

public class ConfirmaPagtoCodBarrasDTO  extends GenericDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String codigoMenu;
	private String formaPagamento;
	private String valorPrincipal;
	private String codLacre;
	private String dataVencimento;
	private String dataPagamento;
	private String tipoTomador;
	private String numeroCnpj;
	private String numeroCEI;
	private String NumeroIdentificacaoRecolhimento;
	private String nomeConsumidor;
	private String numeroCartaoCredito;
	private String bancoCartaoCredito;
	private String agenciaCartaoCredito;
	private String contratoCartaoCredito;
	private String indicadorLacre;
	private String chaveAmarracao;
	private String dataContabil;
	private String numeroDocumentoExtrato;
	private String nomeEmpresa;
	private String codigoBarras;
	private String dataAgendamento;
	private String horaAgendamento;
	private String ciclicidade;
	private String qtdOcorrenciaCiclicidade;
	private String dataRecibo;
	private String horaRecibo;
	private String entConvenio;
	private String cenConvenio;
	private String numConvenio;
	private String descricaoEmpresaConvenio;
	private String codRec;
	private String codIndex;
	private String cotIndex;
	private String decIndex;
	private String valIndex;
	private String valorIOF;
	private String codigoProduto;
	private String codigoSubProduto;
	private String indicadorTomador;
	private String indicadorIdentif;
	private String indicadorValorJuros;
	private String indicadorValorMulta;
	private String uf;
	private String acataDuplicidade;
	private String penumper;
	private String indicadorCliente;
	
	private String CETINDTOKEN;
	private String CETNUMTOKEN;
	private String CIDSESSAO;
	private String CDISCRIMINANTELYNX;
	private String CCODRETLYNX;
	private String CINDTOKENSESSAO;
	private String NUMDDDLIGACAO;
	private String NUMTELLIGACAO;
	private String ETSITTOKEN;
	private String ENTCONV;
	private String DESEMPCONV;
	
	private String banco;
	private String agencia;
	private String conta;		
	private String codigoUsuario;
	private String hostAddress;
	private String canal;
	
	private String canalPagamento;
	private String horaTransacao;
	private String dataTransacao;
	private String autenticacaoBancaria;
	private List<MensagenYARSDTO> mensagensYA;
	private String opcao;
			
	private boolean selecionado;
	private boolean agendamento;
	
	public ConfirmaPagtoCodBarrasDTO() {	
	}

	public String getCodigoMenu() {
		return codigoMenu;
	}

	public void setCodigoMenu(String codigoMenu) {
		this.codigoMenu = codigoMenu;
	}

	public String getFormaPagamento() {
		return formaPagamento;
	}

	public void setFormaPagamento(String formaPagamento) {
		this.formaPagamento = formaPagamento;
	}

	public String getValorPrincipal() {
		return valorPrincipal;
	}

	public void setValorPrincipal(String valorPrincipal) {
		this.valorPrincipal = valorPrincipal;
	}

	public String getCodLacre() {
		return codLacre;
	}

	public void setCodLacre(String codLacre) {
		this.codLacre = codLacre;
	}

	public String getDataVencimento() {
		return dataVencimento;
	}

	public void setDataVencimento(String dataVencimento) {
		this.dataVencimento = dataVencimento;
	}

	public String getTipoTomador() {
		return tipoTomador;
	}

	public void setTipoTomador(String tipoTomador) {
		this.tipoTomador = tipoTomador;
	}

	public String getNumeroCnpj() {
		return numeroCnpj;
	}

	public void setNumeroCnpj(String numeroCnpj) {
		this.numeroCnpj = numeroCnpj;
	}

	public String getNumeroCEI() {
		return numeroCEI;
	}

	public void setNumeroCEI(String numeroCEI) {
		this.numeroCEI = numeroCEI;
	}

	public String getNumeroIdentificacaoRecolhimento() {
		return NumeroIdentificacaoRecolhimento;
	}

	public void setNumeroIdentificacaoRecolhimento(String numeroIdentificacaoRecolhimento) {
		NumeroIdentificacaoRecolhimento = numeroIdentificacaoRecolhimento;
	}

	public String getNomeConsumidor() {
		return nomeConsumidor;
	}

	public void setNomeConsumidor(String nomeConsumidor) {
		this.nomeConsumidor = nomeConsumidor;
	}

	public String getNumeroCartaoCredito() {
		return numeroCartaoCredito;
	}

	public void setNumeroCartaoCredito(String numeroCartaoCredito) {
		this.numeroCartaoCredito = numeroCartaoCredito;
	}

	public String getBancoCartaoCredito() {
		return bancoCartaoCredito;
	}

	public void setBancoCartaoCredito(String bancoCartaoCredito) {
		this.bancoCartaoCredito = bancoCartaoCredito;
	}

	public String getAgenciaCartaoCredito() {
		return agenciaCartaoCredito;
	}

	public void setAgenciaCartaoCredito(String agenciaCartaoCredito) {
		this.agenciaCartaoCredito = agenciaCartaoCredito;
	}

	public String getContratoCartaoCredito() {
		return contratoCartaoCredito;
	}

	public void setContratoCartaoCredito(String contratoCartaoCredito) {
		this.contratoCartaoCredito = contratoCartaoCredito;
	}

	public String getIndicadorLacre() {
		return indicadorLacre;
	}

	public void setIndicadorLacre(String indicadorLacre) {
		this.indicadorLacre = indicadorLacre;
	}

	public String getChaveAmarracao() {
		return chaveAmarracao;
	}

	public void setChaveAmarracao(String chaveAmarracao) {
		this.chaveAmarracao = chaveAmarracao;
	}

	public String getDataContabil() {
		return dataContabil;
	}

	public void setDataContabil(String dataContabil) {
		this.dataContabil = dataContabil;
	}

	public String getNumeroDocumentoExtrato() {
		return numeroDocumentoExtrato;
	}

	public void setNumeroDocumentoExtrato(String numeroDocumentoExtrato) {
		this.numeroDocumentoExtrato = numeroDocumentoExtrato;
	}

	public String getNomeEmpresa() {
		return nomeEmpresa;
	}

	public void setNomeEmpresa(String nomeEmpresa) {
		this.nomeEmpresa = nomeEmpresa;
	}

	public String getCodigoBarras() {
		return codigoBarras;
	}

	public void setCodigoBarras(String codigoBarras) {
		this.codigoBarras = codigoBarras;
	}

	public String getDataAgendamento() {
		return dataAgendamento;
	}

	public void setDataAgendamento(String dataAgendamento) {
		this.dataAgendamento = dataAgendamento;
	}

	public String getHoraAgendamento() {
		return horaAgendamento;
	}

	public void setHoraAgendamento(String horaAgendamento) {
		this.horaAgendamento = horaAgendamento;
	}

	public String getCiclicidade() {
		return ciclicidade;
	}

	public void setCiclicidade(String ciclicidade) {
		this.ciclicidade = ciclicidade;
	}

	public String getQtdOcorrenciaCiclicidade() {
		return qtdOcorrenciaCiclicidade;
	}

	public void setQtdOcorrenciaCiclicidade(String qtdOcorrenciaCiclicidade) {
		this.qtdOcorrenciaCiclicidade = qtdOcorrenciaCiclicidade;
																									}

	public String getDataRecibo() {
		return dataRecibo;
	}

	public void setDataRecibo(String dataRecibo) {
		this.dataRecibo = dataRecibo;
	}

	public String getHoraRecibo() {
		return horaRecibo;
	}

	public void setHoraRecibo(String horaRecibo) {
		this.horaRecibo = horaRecibo;
	}

	public String getEntConvenio() {
		return entConvenio;
	}

	public void setEntConvenio(String entConvenio) {
		this.entConvenio = entConvenio;
	}

	public String getCenConvenio() {
		return cenConvenio;
	}

	public void setCenConvenio(String cenConvenio) {
		this.cenConvenio = cenConvenio;
	}

	public String getNumConvenio() {
		return numConvenio;
	}

	public void setNumConvenio(String numConvenio) {
		this.numConvenio = numConvenio;
	}

	public String getDescricaoEmpresaConvenio() {
		return descricaoEmpresaConvenio;
	}

	public void setDescricaoEmpresaConvenio(String descricaoEmpresaConvenio) {
		this.descricaoEmpresaConvenio = descricaoEmpresaConvenio;
	}

	public String getCodRec() {
		return codRec;
	}

	public void setCodRec(String codRec) {
		this.codRec = codRec;
	}

	public String getCodIndex() {
		return codIndex;
	}

	public void setCodIndex(String codIndex) {
		this.codIndex = codIndex;
	}

	public String getCotIndex() {
		return cotIndex;
	}

	public void setCotIndex(String cotIndex) {
		this.cotIndex = cotIndex;
	}

	public String getDecIndex() {
		return decIndex;
	}

	public void setDecIndex(String decIndex) {
		this.decIndex = decIndex;
	}

	public String getValIndex() {
		return valIndex;
	}

	public void setValIndex(String valIndex) {
		this.valIndex = valIndex;
	}

	public String getValorIOF() {
		return valorIOF;
	}

	public void setValorIOF(String valorIOF) {
		this.valorIOF = valorIOF;
	}

	public String getCodigoProduto() {
		return codigoProduto;
	}

	public void setCodigoProduto(String codigoProduto) {
		this.codigoProduto = codigoProduto;
	}

	public String getCodigoSubProduto() {
		return codigoSubProduto;
	}

	public void setCodigoSubProduto(String codigoSubProduto) {
		this.codigoSubProduto = codigoSubProduto;
	}

	public String getIndicadorTomador() {
		return indicadorTomador;
	}

	public void setIndicadorTomador(String indicadorTomador) {
		this.indicadorTomador = indicadorTomador;
	}

	public String getIndicadorIdentif() {
		return indicadorIdentif;
	}

	public void setIndicadorIdentif(String indicadorIdentif) {
		this.indicadorIdentif = indicadorIdentif;
	}

	public String getIndicadorValorJuros() {
		return indicadorValorJuros;
	}

	public void setIndicadorValorJuros(String indicadorValorJuros) {
		this.indicadorValorJuros = indicadorValorJuros;
	}

	public String getIndicadorValorMulta() {
		return indicadorValorMulta;
	}

	public void setIndicadorValorMulta(String indicadorValorMulta) {
		this.indicadorValorMulta = indicadorValorMulta;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public String getAcataDuplicidade() {
		return acataDuplicidade;
	}

	public void setAcataDuplicidade(String acataDuplicidade) {
		this.acataDuplicidade = acataDuplicidade;
	}

	public String getPenumper() {
		return penumper;
	}

	public void setPenumper(String penumper) {
		this.penumper = penumper;
	}

	public String getIndicadorCliente() {
		return indicadorCliente;
	}

	public void setIndicadorCliente(String indicadorCliente) {
		this.indicadorCliente = indicadorCliente;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getConta() {
		return conta;
	}

	public void setConta(String conta) {
		this.conta = conta;
	}

	public String getCodigoUsuario() {
		return codigoUsuario;
	}

	public void setCodigoUsuario(String codigoUsuario) {
		this.codigoUsuario = codigoUsuario;
	}

	public String getHostAddress() {
		return hostAddress;
	}

	public void setHostAddress(String hostAddress) {
		this.hostAddress = hostAddress;
	}

	public String getCanal() {
		return canal;
	}

	public void setCanal(String canal) {
		this.canal = canal;
	}

	public String getCanalPagamento() {
		return canalPagamento;
	}

	public void setCanalPagamento(String canalPagamento) {
		this.canalPagamento = canalPagamento;
	}

	public String getHoraTransacao() {
		return horaTransacao;
	}

	public void setHoraTransacao(String horaTransacao) {
		this.horaTransacao = horaTransacao;
	}

	public String getDataTransacao() {
		return dataTransacao;
	}

	public void setDataTransacao(String dataTransacao) {
		this.dataTransacao = dataTransacao;
	}

	public String getAutenticacaoBancaria() {
		return autenticacaoBancaria;
	}

	public void setAutenticacaoBancaria(String autenticacaoBancaria) {
		this.autenticacaoBancaria = autenticacaoBancaria;
	}

	public boolean isSelecionado() {
		return selecionado;
	}

	public void setSelecionado(boolean selecionado) {
		this.selecionado = selecionado;
	}

	public String getDataPagamento() {
		return dataPagamento;
	}

	public void setDataPagamento(String dataPagamento) {
		this.dataPagamento = dataPagamento;
	}

	public List<MensagenYARSDTO> getMensagensYA() {
		return mensagensYA;
	}

	public void setMensagensYA(List<MensagenYARSDTO> mensagens) {
		this.mensagensYA = mensagens;
	}

	public String getOpcao() {
		return opcao;
	}

	public void setOpcao(String opcao) {
		this.opcao = opcao;
	}

	public String getCETINDTOKEN() {
		return CETINDTOKEN;
	}

	public void setCETINDTOKEN(String cETINDTOKEN) {
		CETINDTOKEN = cETINDTOKEN;
	}

	public String getCETNUMTOKEN() {
		return CETNUMTOKEN;
	}

	public void setCETNUMTOKEN(String cETNUMTOKEN) {
		CETNUMTOKEN = cETNUMTOKEN;
	}

	public String getCIDSESSAO() {
		return CIDSESSAO;
	}

	public void setCIDSESSAO(String cIDSESSAO) {
		CIDSESSAO = cIDSESSAO;
	}

	public String getCDISCRIMINANTELYNX() {
		return CDISCRIMINANTELYNX;
	}

	public void setCDISCRIMINANTELYNX(String cDISCRIMINANTELYNX) {
		CDISCRIMINANTELYNX = cDISCRIMINANTELYNX;
	}

	public String getCCODRETLYNX() {
		return CCODRETLYNX;
	}

	public void setCCODRETLYNX(String cCODRETLYNX) {
		CCODRETLYNX = cCODRETLYNX;
	}

	public String getCINDTOKENSESSAO() {
		return CINDTOKENSESSAO;
	}

	public void setCINDTOKENSESSAO(String cINDTOKENSESSAO) {
		CINDTOKENSESSAO = cINDTOKENSESSAO;
	}

	public String getNUMDDDLIGACAO() {
		return NUMDDDLIGACAO;
	}

	public void setNUMDDDLIGACAO(String nUMDDDLIGACAO) {
		NUMDDDLIGACAO = nUMDDDLIGACAO;
	}

	public String getNUMTELLIGACAO() {
		return NUMTELLIGACAO;
	}

	public void setNUMTELLIGACAO(String nUMTELLIGACAO) {
		NUMTELLIGACAO = nUMTELLIGACAO;
	}

	public String getETSITTOKEN() {
		return ETSITTOKEN;
	}

	public void setETSITTOKEN(String eTSITTOKEN) {
		ETSITTOKEN = eTSITTOKEN;
	}

	public String getENTCONV() {
		return ENTCONV;
	}

	public void setENTCONV(String eNTCONV) {
		ENTCONV = eNTCONV;
	}

	public String getDESEMPCONV() {
		return DESEMPCONV;
	}

	public void setDESEMPCONV(String dESEMPCONV) {
		DESEMPCONV = dESEMPCONV;
	}

	public boolean isAgendamento() {
		return agendamento;
	}

	public void setAgendamento(boolean agendamento) {
		this.agendamento = agendamento;
	}
	
}
