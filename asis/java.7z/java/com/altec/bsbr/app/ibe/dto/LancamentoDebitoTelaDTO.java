package com.altec.bsbr.app.ibe.dto;

public class LancamentoDebitoTelaDTO {

	private String dataDeDebito;
	private String dataDaTransacao;
	private String historico;
	private String valor;
	private String estabelecimento;

	public String getDataDeDebito() {
		return dataDeDebito;
	}

	public void setDataDeDebito(String dataDeDebito) {
		this.dataDeDebito = dataDeDebito;
	}

	public String getDataDaTransacao() {
		return dataDaTransacao;
	}

	public void setDataDaTransacao(String dataDaTransacao) {
		this.dataDaTransacao = dataDaTransacao;
	}

	public String getHistorico() {
		return historico;
	}

	public void setHistorico(String historico) {
		this.historico = historico;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	public String getEstabelecimento() {
		return estabelecimento;
	}

	public void setEstabelecimento(String estabelecimento) {
		this.estabelecimento = estabelecimento;
	}

}