/*
 * Cheque Ades�o Empresa Protegido (Rest Implementation para controle de fluxo)
 *
 */

package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class SeguroPrestamistaChequeEmpresaRequestDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	private String bank;
	private String agency;
	private String account;

	public SeguroPrestamistaChequeEmpresaRequestDTO() {
		throw new UnsupportedOperationException();
	}

	public String getBank() {
		return bank;
	}

	public void setBank(String bank) {
		this.bank = bank;
	}

	public String getAgency() {
		return agency;
	}

	public void setAgency(String agency) {
		this.agency = agency;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

}