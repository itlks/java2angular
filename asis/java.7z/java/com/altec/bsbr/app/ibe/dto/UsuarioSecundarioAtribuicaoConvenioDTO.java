package com.altec.bsbr.app.ibe.dto;

import java.util.ArrayList;
import java.util.List;

import com.altec.bsbr.app.ibe.dto.consultarperfilautorizacaocontrato.PerfilAutorizacaoContratoResponseDTO;

public class UsuarioSecundarioAtribuicaoConvenioDTO {
	
	private String convenio;
	private String permitirAcesso;
	private boolean permitirAcessoBoolean = false;
	private String perfilAutorizacao;
	private String descricao;
	private List<PerfilAutorizacaoContratoResponseDTO> lPerfilContrato = new ArrayList<PerfilAutorizacaoContratoResponseDTO>();
	private PerfilAutorizacaoContratoResponseDTO perfilAutoSelecionado;
	
	public UsuarioSecundarioAtribuicaoConvenioDTO(){		
	}	

	public UsuarioSecundarioAtribuicaoConvenioDTO(String convenio, String permitirAcesso, String perfilAutorizacao) {
		super();
		this.convenio = convenio;
		this.permitirAcesso = permitirAcesso;
		
		this.perfilAutorizacao = perfilAutorizacao;
	}
	public UsuarioSecundarioAtribuicaoConvenioDTO(String convenio, Boolean permitirAcessoBool, String perfilAutorizacao) {
		super();
		this.convenio = convenio;
		this.permitirAcessoBoolean = permitirAcessoBool;
		
		this.perfilAutorizacao = perfilAutorizacao;
	}
	
	public UsuarioSecundarioAtribuicaoConvenioDTO(String convenio, boolean permitirAcessoBoolean,
			List<PerfilAutorizacaoContratoResponseDTO> lPerfilAutorizacao, String perfilAutorizacao) {
		super();
		this.convenio = convenio;
		this.permitirAcessoBoolean = permitirAcessoBoolean;
		this.lPerfilContrato= lPerfilAutorizacao;
		this.perfilAutorizacao = perfilAutorizacao;
	}

	public String getConvenio() {
		return convenio;
	}

	public void setConvenio(String convenio) {
		this.convenio = convenio;
	}

	public String getPermitirAcesso() {
		return permitirAcesso;
	}

	public void setPermitirAcesso(String permitirAcesso) {
		this.permitirAcesso = permitirAcesso;
	}

	public String getPerfilAutorizacao() {
		
		if (!lPerfilContrato.isEmpty()) {
			for (PerfilAutorizacaoContratoResponseDTO item : lPerfilContrato) {				
				if (String.valueOf(item.getNumSequPerfilAutorizacaoSec()).equals(perfilAutorizacao)) {
					this.setDescricao(item.getNumPerfilAcesso());
				}
			}
		}				
		
		return perfilAutorizacao;
	}

	public void setPerfilAutorizacao(String perfilAutorizacao) {
		
		if (!lPerfilContrato.isEmpty()) {
			for (PerfilAutorizacaoContratoResponseDTO item : lPerfilContrato) {				
				if (String.valueOf(item.getNumSequPerfilAutorizacaoSec()).equals(perfilAutorizacao)) {
					this.setDescricao(item.getNumPerfilAcesso());
				}
			}
		}
		
		this.perfilAutorizacao = perfilAutorizacao;
	}

	public boolean isPermitirAcessoBoolean() {
		return permitirAcessoBoolean;
	}

	public void setPermitirAcessoBoolean(boolean permitirAcessoBoolean) {
		this.permitirAcessoBoolean = permitirAcessoBoolean;
	}

/*	public List<PerfilAutorizacao> getlPerfilAutorizacao() {
		return lPerfilAutorizacao;
	}

	public void setlPerfilAutorizacao(List<PerfilAutorizacao> lPerfilAutorizacao) {
		this.lPerfilAutorizacao = lPerfilAutorizacao;
	}*/

	public List<PerfilAutorizacaoContratoResponseDTO> getlPerfilContrato() {
		return lPerfilContrato;
	}

	public void setlPerfilContrato(List<PerfilAutorizacaoContratoResponseDTO> lPerfilContrato) {
		this.lPerfilContrato = lPerfilContrato;
	}

	public PerfilAutorizacaoContratoResponseDTO getPerfilAutoSelecionado() {
		return perfilAutoSelecionado;
	}

	public void setPerfilAutoSelecionado(PerfilAutorizacaoContratoResponseDTO perfilAutoSelecionado) {
		this.perfilAutoSelecionado = perfilAutoSelecionado;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}			
		
}
