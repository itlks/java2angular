package com.altec.bsbr.app.ibe.dto.investimentos.posicaomensal.consulta;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ConsultaParametroCMResponseDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String dateUsefulPrevious;
	private String minimumValueCurrentAccount;
	private String minimumProductValue;
	private List<YearMonth> yearMonth = new ArrayList<YearMonth>();
	private String error;

	public String getDateUsefulPrevious() {
		return dateUsefulPrevious;
	}

	public void setDateUsefulPrevious(String dateUsefulPrevious) {
		this.dateUsefulPrevious = dateUsefulPrevious;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public String getMinimumValueCurrentAccount() {
		return minimumValueCurrentAccount;
	}

	public void setMinimumValueCurrentAccount(String minimumValueCurrentAccount) {
		this.minimumValueCurrentAccount = minimumValueCurrentAccount;
	}

	public String getMinimumProductValue() {
		return minimumProductValue;
	}

	public void setMinimumProductValue(String minimumProductValue) {
		this.minimumProductValue = minimumProductValue;
	}

	public List<YearMonth> getYearMonth() {
		return yearMonth;
	}

	public void setYearMonth(List<YearMonth> yearMonth) {
		this.yearMonth = yearMonth;
	}

}
