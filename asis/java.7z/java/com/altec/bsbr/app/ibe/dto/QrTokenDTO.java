/**
 * 
 */
package com.altec.bsbr.app.ibe.dto;

import java.util.List;

/**
 * @author c.de.sa.oliveira
 *
 */
public class QrTokenDTO {
	
	private String cpf;
	private String nomeAparelho;
	private String codeGerado;
	private String inputCode;
	private String metodoDeHabilitacao;
	private String metodoDeHabilitacaoEscolhido;

	private String celularEscolhido;
	private List<TelefoneDTO> listaCelular;
	private String celular;
	private String ddd;
	private String hash;
	private String dataValidadeHash;
	private String dispositivo;
	private String tipoDispositivo;
	private boolean exibirNovoCelular;		
	private String dataComprovante;
	
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getNomeAparelho() {
		return nomeAparelho;
	}
	public void setNomeAparelho(String nomeAparelho) {
		this.nomeAparelho = nomeAparelho;
	}
	public String getCodeGerado() {
		return codeGerado;
	}
	public void setCodeGerado(String codeGerado) {
		this.codeGerado = codeGerado;
	}
	public String getInputCode() {
		return inputCode;
	}
	public void setInputCode(String inputCode) {
		this.inputCode = inputCode;
	}
	public String getMetodoDeHabilitacao() {
		return metodoDeHabilitacao;
	}
	public void setMetodoDeHabilitacao(String metodoDeHabilitacao) {
		this.metodoDeHabilitacao = metodoDeHabilitacao;
	}
	public String getCelularEscolhido() {
		return celularEscolhido;
	}
	public void setCelularEscolhido(String celularEscolhido) {
		this.celularEscolhido = celularEscolhido;
	}
	
	public String getCelular() {
		return celular;
	}
	public void setCelular(String celular) {
		this.celular = celular;
	}
	public String getDdd() {
		return ddd;
	}
	public void setDdd(String ddd) {
		this.ddd = ddd;
	}
	public String getHash() {
		return hash;
	}
	public void setHash(String hash) {
		this.hash = hash;
	}
	public String getDispositivo() {
		return dispositivo;
	}
	public void setDispositivo(String dispositivo) {
		this.dispositivo = dispositivo;
	}
	public String getTipoDispositivo() {
		return tipoDispositivo;
	}
	public void setTipoDispositivo(String tipoDispositivo) {
		this.tipoDispositivo = tipoDispositivo;
	}
	public String getDataValidadeHash() {
		return dataValidadeHash;
	}
	public void setDataValidadeHash(String dataValidadeHash) {
		this.dataValidadeHash = dataValidadeHash;
	}
	
	public boolean isExibirNovoCelular() {
		return exibirNovoCelular;
	}
	public void setExibirNovoCelular(boolean exibirNovoCelular) {
		this.exibirNovoCelular = exibirNovoCelular;
	}
	public List<TelefoneDTO> getListaCelular() {
		return listaCelular;
	}
	public void setListaCelular(List<TelefoneDTO> listaCelular) {
		this.listaCelular = listaCelular;
	}
	public String getMetodoDeHabilitacaoEscolhido() {
		return metodoDeHabilitacaoEscolhido;
	}
	public void setMetodoDeHabilitacaoEscolhido(String metodoDeHabilitacaoEscolhido) {
		this.metodoDeHabilitacaoEscolhido = metodoDeHabilitacaoEscolhido;
	}
	public String getDataComprovante() {
		return dataComprovante;
	}
	public void setDataComprovante(String dataComprovante) {
		this.dataComprovante = dataComprovante;
	}

	
	
}
