package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.List;

import com.altec.bsbr.app.ibe.dto.limitesdisponiveis.ErrosDTO;

public class ListarLimitesPgDTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3708393617468574695L;
	
	private String saida;
	private List<LimitesPgDTO> rsFixed;
	private ErrosDTO erros;
	
	public String getSaida() {
		return saida;
	}
	public void setSaida(String saida) {
		this.saida = saida;
	}
	public List<LimitesPgDTO> getRsFixed() {
		return rsFixed;
	}
	public void setRsFixed(List<LimitesPgDTO> rsFixed) {
		this.rsFixed = rsFixed;
	}
	public ErrosDTO getErros() {
		return erros;
	}
	public void setErros(ErrosDTO erros) {
		this.erros = erros;
	}
	
	

}
