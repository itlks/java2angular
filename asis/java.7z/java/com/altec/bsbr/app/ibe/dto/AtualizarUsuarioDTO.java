package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;


public class AtualizarUsuarioDTO implements Serializable {

	private static final long serialVersionUID = -1L;

	
	private String cnpj;
	private String cpf;
	private String nomeAcesso;
	private String nomeAcessoConfirmacao;
	private String senhaAtual;
	private String senhaNova;
	private String senhaConfirmacao;
	private String pergunta;
	private String resposta;
	private String assinatura;
	private String assinaturaConfirmacao;
	
	private String cpfHash;
	private String cnpjHash;
	private String senhaAntigaHash;
	private String senhaNovaConfirmaHash;
	private String assinaturaConfirmaHash;
	private String perguntaHash;
	private String respostaHash;
	private String senhaNovaHash;
	private String assinaturaHash;

	
	private String cliente;
	private String agencia;
	private String contaCorrente;
	private String usuario;
	
	private Boolean tipoContrato;
	
	
	private String msgErro;
	
	
	

	public Boolean getTipoContrato() {
		return tipoContrato;
	}
	public void setTipoContrato(Boolean tipoContrato) {
		this.tipoContrato = tipoContrato;
	}
	public String getCnpj() {
		return cnpj;
	}
	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getNomeAcesso() {
		return nomeAcesso;
	}
	public void setNomeAcesso(String nomeAcesso) {
		this.nomeAcesso = nomeAcesso;
	}
	public String getNomeAcessoConfirmacao() {
		return nomeAcessoConfirmacao;
	}
	public void setNomeAcessoConfirmacao(String nomeAcessoConfirmacao) {
		this.nomeAcessoConfirmacao = nomeAcessoConfirmacao;
	}
	public String getSenhaAtual() {
		return senhaAtual;
	}
	public void setSenhaAtual(String senhaAtual) {
		this.senhaAtual = senhaAtual;
	}
	public String getSenhaNova() {
		return senhaNova;
	}
	public void setSenhaNova(String senhaNova) {
		this.senhaNova = senhaNova;
	}
	public String getSenhaConfirmacao() {
		return senhaConfirmacao;
	}
	public void setSenhaConfirmacao(String senhaConfirmacao) {
		this.senhaConfirmacao = senhaConfirmacao;
	}
	public String getPergunta() {
		return pergunta;
	}
	public void setPergunta(String pergunta) {
		this.pergunta = pergunta;
	}
	public String getResposta() {
		return resposta;
	}
	public void setResposta(String resposta) {
		this.resposta = resposta;
	}
	public String getAssinatura() {
		return assinatura;
	}
	public void setAssinatura(String assinatura) {
		this.assinatura = assinatura;
	}
	public String getAssinaturaConfirmacao() {
		return assinaturaConfirmacao;
	}
	public void setAssinaturaConfirmacao(String assinaturaConfirmacao) {
		this.assinaturaConfirmacao = assinaturaConfirmacao;
	}
	public String getCliente() {
		return cliente;
	}
	public void setCliente(String cliente) {
		this.cliente = cliente;
	}
	public String getAgencia() {
		return agencia;
	}
	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}
	public String getContaCorrente() {
		return contaCorrente;
	}
	public void setContaCorrente(String contaCorrente) {
		this.contaCorrente = contaCorrente;
	}
	public String getMsgErro() {
		return msgErro;
	}
	public void setMsgErro(String msgErro) {
		this.msgErro = msgErro;
	}
	public String getCpfHash() {
		return cpfHash;
	}
	public void setCpfHash(String cpfHash) {
		this.cpfHash = cpfHash;
	}
	public String getCnpjHash() {
		return cnpjHash;
	}
	public void setCnpjHash(String cnpjHash) {
		this.cnpjHash = cnpjHash;
	}
	public String getSenhaAntigaHash() {
		return senhaAntigaHash;
	}
	public void setSenhaAntigaHash(String senhaAntigaHash) {
		this.senhaAntigaHash = senhaAntigaHash;
	}
	public String getSenhaNovaConfirmaHash() {
		return senhaNovaConfirmaHash;
	}
	public void setSenhaNovaConfirmaHash(String senhaNovaConfirmaHash) {
		this.senhaNovaConfirmaHash = senhaNovaConfirmaHash;
	}
	public String getAssinaturaConfirmaHash() {
		return assinaturaConfirmaHash;
	}
	public void setAssinaturaConfirmaHash(String assinaturaConfirmaHash) {
		this.assinaturaConfirmaHash = assinaturaConfirmaHash;
	}
	public String getPerguntaHash() {
		return perguntaHash;
	}
	public void setPerguntaHash(String perguntaHash) {
		this.perguntaHash = perguntaHash;
	}
	public String getRespostaHash() {
		return respostaHash;
	}
	public void setRespostaHash(String respostaHash) {
		this.respostaHash = respostaHash;
	}
	public String getSenhaNovaHash() {
		return senhaNovaHash;
	}
	public void setSenhaNovaHash(String senhaNovaHash) {
		this.senhaNovaHash = senhaNovaHash;
	}
	public String getAssinaturaHash() {
		return assinaturaHash;
	}
	public void setAssinaturaHash(String assinaturaHash) {
		this.assinaturaHash = assinaturaHash;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
		
}
