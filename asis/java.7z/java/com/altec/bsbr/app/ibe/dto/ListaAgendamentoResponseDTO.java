package com.altec.bsbr.app.ibe.dto;

import java.util.ArrayList;
import java.util.List;

public class ListaAgendamentoResponseDTO {

	private List<ListaAgendamentoDTO> listaAgendamento = new ArrayList<ListaAgendamentoDTO>();
	private String codigoRetorno;
	private String msgErro;
	private int numeroPagina;
	private int sequenciaPaginacao;
	private int sequenciaPaginacaoAnterior;
	private boolean proximaPagina;

	public List<ListaAgendamentoDTO> getListaAgendamento() {
		return listaAgendamento;
	}

	public void setListaAgendamento(List<ListaAgendamentoDTO> listaAgendamento) {
		this.listaAgendamento = listaAgendamento;
	}

	public String getCodigoRetorno() {
		return codigoRetorno;
	}

	public void setCodigoRetorno(String codigoRetorno) {
		this.codigoRetorno = codigoRetorno;
	}

	public String getMsgErro() {
		return msgErro;
	}

	public void setMsgErro(String msgErro) {
		this.msgErro = msgErro;
	}

	public boolean hasProximaPagina() {
		return proximaPagina;
	}

	public void setProximaPagina(boolean proximaPagina) {
		this.proximaPagina = proximaPagina;
	}

	public int getNumeroPagina() {
		return numeroPagina;
	}

	public void setNumeroPagina(int numeroPagina) {
		this.numeroPagina = numeroPagina;
	}

	public int getSequenciaPaginacao() {
		return sequenciaPaginacao;
	}

	public void setSequenciaPaginacao(int sequenciaPaginacao) {
		this.sequenciaPaginacao = sequenciaPaginacao;
	}

	public int getSequenciaPaginacaoAnterior() {
		return sequenciaPaginacaoAnterior;
	}

	public void setSequenciaPaginacaoAnterior(int sequenciaPaginacaoAnterior) {
		this.sequenciaPaginacaoAnterior = sequenciaPaginacaoAnterior;
	}

}
