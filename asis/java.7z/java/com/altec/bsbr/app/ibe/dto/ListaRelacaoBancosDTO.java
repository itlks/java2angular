package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class ListaRelacaoBancosDTO implements Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = 4587118847327506808L;
	private String OERIFLAGATIVOISPB;
	private String OERIBANCOPESQ;
	private String OERIDESCRICAOO;
	private String OERIISPBPESQ;
	private String OERIFLAGATIVOCOMPE;
	
	
	public java.lang.String getOERIBANCOPESQ() {
		return OERIBANCOPESQ;
	}
	public void setOERIBANCOPESQ(java.lang.String oERIBANCOPESQ) {
		OERIBANCOPESQ = oERIBANCOPESQ;
	}
	public java.lang.String getOERIDESCRICAOO() {
		return OERIDESCRICAOO;
	}
	public void setOERIDESCRICAOO(java.lang.String oERIDESCRICAOO) {
		OERIDESCRICAOO = oERIDESCRICAOO;
	}
	public java.lang.String getOERIISPBPESQ() {
		return OERIISPBPESQ;
	}
	public void setOERIISPBPESQ(java.lang.String oERIISPBPESQ) {
		OERIISPBPESQ = oERIISPBPESQ;
	}
	public java.lang.String getOERIFLAGATIVOISPB() {
		return OERIFLAGATIVOISPB;
	}
	public void setOERIFLAGATIVOISPB(java.lang.String oERIFLAGATIVOISPB) {
		OERIFLAGATIVOISPB = oERIFLAGATIVOISPB;
	}
	public java.lang.String getOERIFLAGATIVOCOMPE() {
		return OERIFLAGATIVOCOMPE;
	}
	public void setOERIFLAGATIVOCOMPE(java.lang.String oERIFLAGATIVOCOMPE) {
		OERIFLAGATIVOCOMPE = oERIFLAGATIVOCOMPE;
	}

	
	
	
	
}
