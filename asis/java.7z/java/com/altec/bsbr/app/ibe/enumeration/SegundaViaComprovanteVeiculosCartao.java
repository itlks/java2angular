package com.altec.bsbr.app.ibe.enumeration;

public enum SegundaViaComprovanteVeiculosCartao {
	
	
	AMEX ("0", "AMEX"),
	CCREDITO("1", "Cart�o de Cr�dito");
	
	private String codigo;
	private String nome;
	
	private SegundaViaComprovanteVeiculosCartao (String codigo, String nome) {
		this.codigo = nome;
		this.nome = nome;
		
	}

	public String getCodigo() {
		return codigo;
	}

	

	public String getNome() {
		return nome;
	}



}
