package com.altec.bsbr.app.ibe.parser.perfil;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType
@XmlAccessorType(XmlAccessType.FIELD)
public class ItemMenu {
    @XmlAttribute(name="go")
    private String go;
    @XmlElement(name="tela")
    private List<Tela> telas;
    
	public String getGo() {
		return go;
	}
	public void setGo(String go) {
		this.go = go;
	}
	public List<Tela> getTelas() {
		return telas;
	}
	public void setTelas(List<Tela> telas) {
		this.telas = telas;
	}	
}
