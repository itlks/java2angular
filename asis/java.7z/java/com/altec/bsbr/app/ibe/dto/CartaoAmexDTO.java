package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import com.altec.bsbr.app.ibe.dto.apelido.ApelidoDTO;

public class CartaoAmexDTO implements Serializable {

	private static final long serialVersionUID = -1718320445480992452L;
	
	private LinkedHashMap<String, String> listaCartoes;
	private String cartaoSelecionado;
	private String nomeCartaoSelecionado;
	private String numeroCartaoPrimeiraParte;
	private String numeroCartaoSegundaParte;
	private String numeroCartaoTerceiraParte;
	private String valorAPagar;
	private String dataHoraTransacao;
	private String autenticacaoBancaria;
	
	private String apelido;
	private boolean gravaApelido;
	private List<ApelidoDTO> listaApelidos = new ArrayList<ApelidoDTO>();

	public String getNumeroCartaoPrimeiraParte() {
		return numeroCartaoPrimeiraParte;
	}

	public void setNumeroCartaoPrimeiraParte(String numeroCartaoPrimeiraParte) {
		this.numeroCartaoPrimeiraParte = numeroCartaoPrimeiraParte;
	}

	public String getNumeroCartaoSegundaParte() {
		return numeroCartaoSegundaParte;
	}

	public void setNumeroCartaoSegundaParte(String numeroCartaoSegundaParte) {
		this.numeroCartaoSegundaParte = numeroCartaoSegundaParte;
	}

	public String getNumeroCartaoTerceiraParte() {
		return numeroCartaoTerceiraParte;
	}

	public void setNumeroCartaoTerceiraParte(String numeroCartaoTerceiraParte) {
		this.numeroCartaoTerceiraParte = numeroCartaoTerceiraParte;
	}

	public String getValorAPagar() {
		return valorAPagar;
	}

	public void setValorAPagar(String valorAPagar) {
		this.valorAPagar = valorAPagar;
	}

	public String getApelido() {
		return apelido;
	}

	public void setApelido(String apelido) {
		this.apelido = apelido;
	}

	public boolean isGravaApelido() {
		return gravaApelido;
	}

	public void setGravaApelido(boolean gravaApelido) {
		this.gravaApelido = gravaApelido;
	}

	public String getCartaoSelecionado() {
		return cartaoSelecionado;
	}

	public void setCartaoSelecionado(String cartaoSelecionado) {
		this.cartaoSelecionado = cartaoSelecionado;
	}

	public LinkedHashMap<String, String> getListaCartoes() {
		return listaCartoes;
	}

	public void setListaCartoes(LinkedHashMap<String, String> listaCartoes) {
		this.listaCartoes = listaCartoes;
	}

	public String getNomeCartaoSelecionado() {
		return nomeCartaoSelecionado;
	}

	public void setNomeCartaoSelecionado(String nomeCartaoSelecionado) {
		this.nomeCartaoSelecionado = nomeCartaoSelecionado;
	}

	public String getDataHoraTransacao() {
		return dataHoraTransacao;
	}

	public void setDataHoraTransacao(String dataHoraTransacao) {
		this.dataHoraTransacao = dataHoraTransacao;
	}

	public String getAutenticacaoBancaria() {
		return autenticacaoBancaria;
	}

	public void setAutenticacaoBancaria(String autenticacaoBancaria) {
		this.autenticacaoBancaria = autenticacaoBancaria;
	}

	public List<ApelidoDTO> getListaApelidos() {
		return listaApelidos;
	}

	public void setListaApelidos(List<ApelidoDTO> listaApelidos) {
		this.listaApelidos = listaApelidos;
	}

}
