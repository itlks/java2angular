package com.altec.bsbr.app.ibe.dto;

import java.util.List;

public class AutorizacoesCanceladasGrupoDTO {	
	
	private String grupo;
	private List<AutorizacoesCanceladasDadoGrupoDTO> dadoAutoCancelList;	
	
	public String getGrupo() {
		return grupo;
	}

	public void setGrupo(String grupo) {
		this.grupo = grupo;
	}

	public List<AutorizacoesCanceladasDadoGrupoDTO> getDadoAutoCancelList() {
		return dadoAutoCancelList;
	}
	
	public void setDadoAutoCancelList(List<AutorizacoesCanceladasDadoGrupoDTO> dadoAutoCancelList) {
		this.dadoAutoCancelList = dadoAutoCancelList;
	}

}
