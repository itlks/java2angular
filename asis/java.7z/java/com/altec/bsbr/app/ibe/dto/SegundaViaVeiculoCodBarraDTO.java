package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;

public class SegundaViaVeiculoCodBarraDTO extends GenericDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7806017363412287179L;

	
	
	private String banco;
	private String agencia;
	private String fechaPago;
	private String nombreConvenio;
	private String descIden;
	private BigDecimal importePago;
	private String descripcionCanal;
	private BigDecimal importeTarifaComprobante;
	private String nio;
	private Integer maxSeqNio;
	private String tabela;
	private String dataMov;
	private Integer seqArre;
	private String tipoCom;
	private Boolean checado;
	private Boolean checadoTopo;
	
	
	public String getBanco() {
		return banco;
	}
	public void setBanco(String banco) {
		this.banco = banco;
	}
	public String getAgencia() {
		return agencia;
	}
	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}
	public String getFechaPago() {
		return fechaPago;
	}
	public void setFechaPago(String fechaPago) {
		this.fechaPago = fechaPago;
	}
	public String getNombreConvenio() {
		return nombreConvenio;
	}
	public void setNombreConvenio(String nombreConvenio) {
		this.nombreConvenio = nombreConvenio;
	}
	public String getDescIden() {
		return descIden;
	}
	public void setDescIden(String descIden) {
		this.descIden = descIden;
	}
	public BigDecimal getImportePago() {
		return importePago;
	}
	public void setImportePago(BigDecimal importePago) {
		this.importePago = importePago;
	}
	public String getDescripcionCanal() {
		return descripcionCanal;
	}
	public void setDescripcionCanal(String descripcionCanal) {
		this.descripcionCanal = descripcionCanal;
	}
	public BigDecimal getImporteTarifaComprobante() {
		return importeTarifaComprobante;
	}
	public void setImporteTarifaComprobante(BigDecimal importeTarifaComprobante) {
		this.importeTarifaComprobante = importeTarifaComprobante;
	}
	public String getNio() {
		return nio;
	}
	public void setNio(String nio) {
		this.nio = nio;
	}
	public Integer getMaxSeqNio() {
		return maxSeqNio;
	}
	public void setMaxSeqNio(Integer maxSeqNio) {
		this.maxSeqNio = maxSeqNio;
	}
	public String getTabela() {
		return tabela;
	}
	public void setTabela(String tabela) {
		this.tabela = tabela;
	}
	public String getDataMov() {
		return dataMov;
	}
	public void setDataMov(String dataMov) {
		this.dataMov = dataMov;
	}
	public Integer getSeqArre() {
		return seqArre;
	}
	public void setSeqArre(Integer seqArre) {
		this.seqArre = seqArre;
	}
	public String getTipoCom() {
		return tipoCom;
	}
	public void setTipoCom(String tipoCom) {
		this.tipoCom = tipoCom;
	}
	public Boolean getChecado() {
		return checado;
	}
	public void setChecado(Boolean checado) {
		this.checado = checado;
	}
	public Boolean getChecadoTopo() {
		return checadoTopo;
	}
	public void setChecadoTopo(Boolean checadoTopo) {
		this.checadoTopo = checadoTopo;
	}

	
	
}
