package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class CartaoDebitoLancamentosContratoDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5859207580314604853L;

	private String area; 
	private String produto;
	private String cartao;
	private String contaContratoCartao;
	private String cartaoComMascara;
	private String bandeira;
	private String codigoBandeira;
	private String urlImagemBandeira;
	
	/**
	 * @return the area
	 */
	public String getArea() {
		return area;
	}

	/**
	 * @param area the area to set
	 */
	public void setArea(String area) {
		this.area = area;
	}

	/**
	 * @return the produto
	 */
	public String getProduto() {
		return produto;
	}

	/**
	 * @param produto the produto to set
	 */
	public void setProduto(String produto) {
		this.produto = produto;
	}

	/**
	 * @return the cartao
	 */
	public String getCartao() {
		return cartao;
	}

	/**
	 * @param cartao the cartao to set
	 */
	public void setCartao(String cartao) {
		this.cartao = cartao;
	}

	public String getContaContratoCartao() {
		return contaContratoCartao;
	}

	public void setContaContratoCartao(String contaContratoCartao) {
		this.contaContratoCartao = contaContratoCartao;
	}

	public String getCartaoComMascara() {
		return cartaoComMascara;
	}

	public void setCartaoComMascara(String cartaoComMascara) {
		this.cartaoComMascara = cartaoComMascara;
	}

	public String getBandeira() {
		return bandeira;
	}

	public void setBandeira(String bandeira) {
		this.bandeira = bandeira;
	}

	public String getCodigoBandeira() {
		return codigoBandeira;
	}

	public void setCodigoBandeira(String codigoBandeira) {
		this.codigoBandeira = codigoBandeira;
	}

	public String getUrlImagemBandeira() {
		return urlImagemBandeira;
	}

	public void setUrlImagemBandeira(String urlImagemBandeira) {
		this.urlImagemBandeira = urlImagemBandeira;
	}


	
}
