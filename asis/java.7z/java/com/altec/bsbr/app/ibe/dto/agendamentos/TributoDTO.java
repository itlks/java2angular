package com.altec.bsbr.app.ibe.dto.agendamentos;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class TributoDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5667180032423241128L;
	private String nomeContribuinte;
	private String codigoBarras;
	private String prefeitura;
	private Integer codigoPagamento;
	private Date competencia;
	private String identificador;
	private BigDecimal valorINSS;
	private BigDecimal valorOutrasEntidades;
	private BigDecimal valorMultasJuros;
	private BigDecimal total;

	public String getCodigoBarras() {
		return codigoBarras;
	}

	public void setCodigoBarras(String codigoBarras) {
		this.codigoBarras = codigoBarras;
	}

	public String getPrefeitura() {
		return prefeitura;
	}

	public void setPrefeitura(String prefeitura) {
		this.prefeitura = prefeitura;
	}

	public String getNomeContribuinte() {
		return nomeContribuinte;
	}

	public void setNomeContribuinte(String nomeContribuinte) {
		this.nomeContribuinte = nomeContribuinte;
	}

	public Integer getCodigoPagamento() {
		return codigoPagamento;
	}

	public void setCodigoPagamento(Integer codigoPagamento) {
		this.codigoPagamento = codigoPagamento;
	}

	public Date getCompetencia() {
		return competencia;
	}

	public void setCompetencia(Date competencia) {
		this.competencia = competencia;
	}

	public String getIdentificador() {
		return identificador;
	}

	public void setIdentificador(String identificador) {
		this.identificador = identificador;
	}

	public BigDecimal getValorINSS() {
		return valorINSS;
	}

	public void setValorINSS(BigDecimal valorINSS) {
		this.valorINSS = valorINSS;
	}

	public BigDecimal getTotal() {
		return total;
	}

	public void setTotal(BigDecimal total) {
		this.total = total;
	}

	public BigDecimal getValorOutrasEntidades() {
		return valorOutrasEntidades;
	}

	public void setValorOutrasEntidades(BigDecimal valorOutrasEntidades) {
		this.valorOutrasEntidades = valorOutrasEntidades;
	}

	public BigDecimal getValorMultasJuros() {
		return valorMultasJuros;
	}

	public void setValorMultasJuros(BigDecimal valorMultasJuros) {
		this.valorMultasJuros = valorMultasJuros;
	}

}
