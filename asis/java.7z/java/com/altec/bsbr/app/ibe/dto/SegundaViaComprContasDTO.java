package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import com.altec.bsbr.app.ibe.util.UtilFunction;

public class SegundaViaComprContasDTO extends GenericDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String banco;
	private String agencia;
	private String conta;
	private String codigoUsuario;
	private String hostAddress;
	private String canal;
	private String dataVencimento;
	private String codigoRefMa;
	private String refMa;
	private String horaArr;
	private String agenOpe;
	private String dataArr;
	private String aiim;

	private String area;
	private String endeCon;
	private String cep;
	private String anoExe;
	private String autDig;
	private String ceMerca;
	private String cenMod;
	private String cmm;
	private String cnae;
	private String codArea;
	private String codDivi;
	private String mensajeErro;
	private String codigoMensajeOk;
	private String entArre;
	private String codRece;
	private String formAarr;
	private String sistOri;
	private String codServ;
	private String nAutCxa;
	private String nTerm;
	private String nAutElet;
	private String status;
	private String indReta;
	private String indErr;
	private String indInco;
	private String indPres;
	private String indConc;
	private String obs;
	private String nio;
	private Integer seqNio;
	private String indLic;
	private String indOff;
	private String indDup;
	private String codTabe;
	private BigDecimal valTota;
	private BigDecimal valPrin;
	private BigDecimal valOutr;
	private BigDecimal valMult;
	private BigDecimal valJuro;
	private BigDecimal valAcre;
	private BigDecimal valHono;
	private BigDecimal valRepa;
	private BigDecimal valIOF;
	private BigDecimal desPost;
	private BigDecimal tariFab;
	private String meiPag1;
	private BigDecimal valPag1;
	private String meiPag2;
	private BigDecimal valPag2;
	private String meiPag3;
	private BigDecimal valPag3;
	private String userID;
	private String netName;
	private String nProg;
	private String entMod;
	private String userMod;
	private String netMod;
	private String userExc;
	private String segVia;
	private Integer numRegi;
	private String pNumPab;
	private Integer numPab;
	private String valInde;
	private String tipoDoc;
	private String idDoc;
	private String nomeCon;
	private String teleCon;
	private String codMuni;
	private String munIpva;
	private String numCart;
	private String tipIdentif;
	private String identif;
	private String insEsta;
	private String insDivi;
	private String etiquet;
	private String cenArre;
	private String dataApu;
	private String dataVct;
	private String parcela;
	private String placa;
	private String numDec;
	private String numNoti;
	private String codMung;
	private String cota;
	private String fxaIpva;
	private String renavam;
	private String numDi;
	private String numDsi;
	private String numRef;
	private String perinci;
	private Integer codSerr;
	private Integer nsuProd;
	private String nsuBanc;
	private String codProc;
	private String numCont;
	private String nomCont;
	private String exercic;
	private String notific;
	private String parcel1;
	private String parcel2;
	private String sea;
	private String mmaainc;
	private String indMsgr;
	private Long numSipa;
	private String indSipa;
	private String tipDarf;
	private String referEn;
	private BigDecimal valRebR;
	private BigDecimal perRebR;
	private String cpfDesp;
	private Long protoco;
	private String numPad;
	private String compete;
	private String numCcre;
	private String numCelular;

	private String dataInicial;
	private String dataFinal;

	private String canalPagamento;

	private String empresa;
	private String convenio;
	private String codigoBarras;
	private String dataPagamento;
	private BigDecimal valorPago;
	private String horaTransacao;
	private String dataTransacao;
	private String autenticacaoBancaria;
	private String tipoConta;
	private String formaPagamento;

	private Integer MaxSeqNio;
	private String Tabela;

	private String dataMov;
	private String seqArre;
	private String numeroCartao;
	private String codigoCliente;
	private String tipoCom;
	private String nomeTelefone;
	private String periodoApuracao;
	private String cnpj;
	private String codigoReceita;
	private String receitaBruta;
	private String percentual;
	private String valorPrincipal;
	private String valorMulta;
	private String valorJuros;
	private String valorTotal;
	private String codigoNSU;
	private String valorINSS;
	private String timeStp;
	
	private List<SegundaViaComprContasDTO> segundaViaComprContasDTOs;

	private boolean selecionado;

	private String nomeContribuinte;

	private String value;

	private String label;

	private String tipoLinha;

	private Integer espacoLinha;
	
	private boolean ultimo;

	public String getNomeTelefone() {
		return nomeTelefone;
	}

	public void setNomeTelefone(String nomeTelefone) {
		this.nomeTelefone = nomeTelefone;
	}

	public String getPeriodoApuracao() {
		return periodoApuracao;
	}

	public void setPeriodoApuracao(String periodoApuracao) {
		this.periodoApuracao = periodoApuracao;
	}

	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	public String getReceitaBruta() {
		return receitaBruta;
	}

	public void setReceitaBruta(String receitaBruta) {
		this.receitaBruta = receitaBruta;
	}

	public String getPercentual() {
		return percentual;
	}

	public void setPercentual(String percentual) {
		this.percentual = percentual;
	}

	public String getValorPrincipal() {
		return valorPrincipal;
	}

	public void setValorPrincipal(String valorPrincipal) {
		this.valorPrincipal = valorPrincipal;
	}

	public String getValorMulta() {
		return valorMulta;
	}

	public void setValorMulta(String valorMulta) {
		this.valorMulta = valorMulta;
	}

	public String getValorJuros() {
		return valorJuros;
	}

	public void setValorJuros(String valorJuros) {
		this.valorJuros = valorJuros;
	}

	public String getValorTotal() {
		return valorTotal;
	}

	public void setValorTotal(String valorTotal) {
		this.valorTotal = valorTotal;
	}

	public String getCodigoNSU() {
		return codigoNSU;
	}

	public void setCodigoNSU(String codigoNSU) {
		this.codigoNSU = codigoNSU;
	}

	public String getMensajeErro() {
		return mensajeErro;
	}

	public void setMensajeErro(String mensajeErro) {
		this.mensajeErro = mensajeErro;
	}

	public String getCodigoMensajeOk() {
		return codigoMensajeOk;
	}

	public void setCodigoMensajeOk(String codigoMensajeOk) {
		this.codigoMensajeOk = codigoMensajeOk;
	}

	public String getEntArre() {
		return entArre;
	}

	public void setEntArre(String entArre) {
		this.entArre = entArre;
	}

	public String getCodRece() {
		return codRece;
	}

	public void setCodRece(String codRece) {
		this.codRece = codRece;
	}

	public String getFormAarr() {
		return formAarr;
	}

	public void setFormAarr(String formAarr) {
		this.formAarr = formAarr;
	}

	public String getSistOri() {
		return sistOri;
	}

	public void setSistOri(String sistOri) {
		this.sistOri = sistOri;
	}

	public String getCodServ() {
		return codServ;
	}

	public void setCodServ(String codServ) {
		this.codServ = codServ;
	}

	public String getnAutCxa() {
		return nAutCxa;
	}

	public void setnAutCxa(String nAutCxa) {
		this.nAutCxa = nAutCxa;
	}

	public String getnTerm() {
		return nTerm;
	}

	public void setnTerm(String nTerm) {
		this.nTerm = nTerm;
	}

	public String getnAutElet() {
		return nAutElet;
	}

	public void setnAutElet(String nAutElet) {
		this.nAutElet = nAutElet;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getIndReta() {
		return indReta;
	}

	public void setIndReta(String indReta) {
		this.indReta = indReta;
	}

	public String getIndErr() {
		return indErr;
	}

	public void setIndErr(String indErr) {
		this.indErr = indErr;
	}

	public String getIndInco() {
		return indInco;
	}

	public void setIndInco(String indInco) {
		this.indInco = indInco;
	}

	public String getIndPres() {
		return indPres;
	}

	public void setIndPres(String indPres) {
		this.indPres = indPres;
	}

	public String getIndConc() {
		return indConc;
	}

	public void setIndConc(String indConc) {
		this.indConc = indConc;
	}

	public String getObs() {
		return obs;
	}

	public void setObs(String obs) {
		this.obs = obs;
	}

	public Integer getSeqNio() {
		return seqNio;
	}

	public void setSeqNio(Integer seqNio) {
		this.seqNio = seqNio;
	}

	public String getIndLic() {
		return indLic;
	}

	public void setIndLic(String indLic) {
		this.indLic = indLic;
	}

	public String getIndOff() {
		return indOff;
	}

	public void setIndOff(String indOff) {
		this.indOff = indOff;
	}

	public String getIndDup() {
		return indDup;
	}

	public void setIndDup(String indDup) {
		this.indDup = indDup;
	}

	public String getCodTabe() {
		return codTabe;
	}

	public void setCodTabe(String codTabe) {
		this.codTabe = codTabe;
	}

	public BigDecimal getValTota() {
		return valTota;
	}

	public void setValTota(BigDecimal valTota) {
		this.valTota = valTota;
	}

	public BigDecimal getValPrin() {
		return valPrin;
	}

	public void setValPrin(BigDecimal valPrin) {
		this.valPrin = valPrin;
	}

	public BigDecimal getValOutr() {
		return valOutr;
	}

	public void setValOutr(BigDecimal valOutr) {
		this.valOutr = valOutr;
	}

	public BigDecimal getValMult() {
		return valMult;
	}

	public void setValMult(BigDecimal valMult) {
		this.valMult = valMult;
	}

	public BigDecimal getValJuro() {
		return valJuro;
	}

	public void setValJuro(BigDecimal valJuro) {
		this.valJuro = valJuro;
	}

	public BigDecimal getValAcre() {
		return valAcre;
	}

	public void setValAcre(BigDecimal valAcre) {
		this.valAcre = valAcre;
	}

	public BigDecimal getValHono() {
		return valHono;
	}

	public void setValHono(BigDecimal valHono) {
		this.valHono = valHono;
	}

	public BigDecimal getValRepa() {
		return valRepa;
	}

	public void setValRepa(BigDecimal valRepa) {
		this.valRepa = valRepa;
	}

	public BigDecimal getValIOF() {
		return valIOF;
	}

	public void setValIOF(BigDecimal valIOF) {
		this.valIOF = valIOF;
	}

	public BigDecimal getDesPost() {
		return desPost;
	}

	public void setDesPost(BigDecimal desPost) {
		this.desPost = desPost;
	}

	public BigDecimal getTariFab() {
		return tariFab;
	}

	public void setTariFab(BigDecimal tariFab) {
		this.tariFab = tariFab;
	}

	public String getMeiPag1() {
		return meiPag1;
	}

	public void setMeiPag1(String meiPag1) {
		this.meiPag1 = meiPag1;
	}

	public BigDecimal getValPag1() {
		return valPag1;
	}

	public void setValPag1(BigDecimal valPag1) {
		this.valPag1 = valPag1;
	}

	public String getMeiPag2() {
		return meiPag2;
	}

	public void setMeiPag2(String meiPag2) {
		this.meiPag2 = meiPag2;
	}

	public BigDecimal getValPag2() {
		return valPag2;
	}

	public void setValPag2(BigDecimal valPag2) {
		this.valPag2 = valPag2;
	}

	public String getMeiPag3() {
		return meiPag3;
	}

	public void setMeiPag3(String meiPag3) {
		this.meiPag3 = meiPag3;
	}

	public BigDecimal getValPag3() {
		return valPag3;
	}

	public void setValPag3(BigDecimal valPag3) {
		this.valPag3 = valPag3;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getNetName() {
		return netName;
	}

	public void setNetName(String netName) {
		this.netName = netName;
	}

	public String getnProg() {
		return nProg;
	}

	public void setnProg(String nProg) {
		this.nProg = nProg;
	}

	public String getEntMod() {
		return entMod;
	}

	public void setEntMod(String entMod) {
		this.entMod = entMod;
	}

	public String getUserMod() {
		return userMod;
	}

	public void setUserMod(String userMod) {
		this.userMod = userMod;
	}

	public String getNetMod() {
		return netMod;
	}

	public void setNetMod(String netMod) {
		this.netMod = netMod;
	}

	public String getUserExc() {
		return userExc;
	}

	public void setUserExc(String userExc) {
		this.userExc = userExc;
	}

	public String getSegVia() {
		return segVia;
	}

	public void setSegVia(String segVia) {
		this.segVia = segVia;
	}

	public Integer getNumRegi() {
		return numRegi;
	}

	public void setNumRegi(Integer numRegi) {
		this.numRegi = numRegi;
	}

	public String getpNumPab() {
		return pNumPab;
	}

	public void setpNumPab(String pNumPab) {
		this.pNumPab = pNumPab;
	}

	public Integer getNumPab() {
		return numPab;
	}

	public void setNumPab(Integer numPab) {
		this.numPab = numPab;
	}

	public String getValInde() {
		return valInde;
	}

	public void setValInde(String valInde) {
		this.valInde = valInde;
	}

	public String getTipoDoc() {
		return tipoDoc;
	}

	public void setTipoDoc(String tipoDoc) {
		this.tipoDoc = tipoDoc;
	}

	public String getIdDoc() {
		return idDoc;
	}

	public void setIdDoc(String idDoc) {
		this.idDoc = idDoc;
	}

	public String getNomeCon() {
		return nomeCon;
	}

	public void setNomeCon(String nomeCon) {
		this.nomeCon = nomeCon;
	}

	public String getTeleCon() {
		return teleCon;
	}

	public void setTeleCon(String teleCon) {
		this.teleCon = teleCon;
	}

	public String getCodMuni() {
		return codMuni;
	}

	public void setCodMuni(String codMuni) {
		this.codMuni = codMuni;
	}

	public String getMunIpva() {
		return munIpva;
	}

	public void setMunIpva(String munIpva) {
		this.munIpva = munIpva;
	}

	public String getNumCart() {
		return numCart;
	}

	public void setNumCart(String numCart) {
		this.numCart = numCart;
	}

	public String getTipIdentif() {
		return tipIdentif;
	}

	public void setTipIdentif(String tipIdentif) {
		this.tipIdentif = tipIdentif;
	}

	public String getIdentif() {
		return identif;
	}

	public void setIdentif(String identif) {
		this.identif = identif;
	}

	public String getInsEsta() {
		return insEsta;
	}

	public void setInsEsta(String insEsta) {
		this.insEsta = insEsta;
	}

	public String getInsDivi() {
		return insDivi;
	}

	public void setInsDivi(String insDivi) {
		this.insDivi = insDivi;
	}

	public String getEtiquet() {
		return etiquet;
	}

	public void setEtiquet(String etiquet) {
		this.etiquet = etiquet;
	}

	public String getParcela() {
		return parcela;
	}

	public void setParcela(String parcela) {
		this.parcela = parcela;
	}

	public String getPlaca() {
		return placa;
	}

	public void setPlaca(String placa) {
		this.placa = placa;
	}

	public String getNumDec() {
		return numDec;
	}

	public void setNumDec(String numDec) {
		this.numDec = numDec;
	}

	public String getNumNoti() {
		return numNoti;
	}

	public void setNumNoti(String numNoti) {
		this.numNoti = numNoti;
	}

	public String getCodMung() {
		return codMung;
	}

	public void setCodMung(String codMung) {
		this.codMung = codMung;
	}

	public String getCota() {
		return cota;
	}

	public void setCota(String cota) {
		this.cota = cota;
	}

	public String getFxaIpva() {
		return fxaIpva;
	}

	public void setFxaIpva(String fxaIpva) {
		this.fxaIpva = fxaIpva;
	}

	public String getRenavam() {
		return renavam;
	}

	public void setRenavam(String renavam) {
		this.renavam = renavam;
	}

	public String getNumDi() {
		return numDi;
	}

	public void setNumDi(String numDi) {
		this.numDi = numDi;
	}

	public String getNumDsi() {
		return numDsi;
	}

	public void setNumDsi(String numDsi) {
		this.numDsi = numDsi;
	}

	public String getNumRef() {
		return numRef;
	}

	public void setNumRef(String numRef) {
		this.numRef = numRef;
	}

	public String getPerinci() {
		return perinci;
	}

	public void setPerinci(String perinci) {
		this.perinci = perinci;
	}

	public Integer getCodSerr() {
		return codSerr;
	}

	public void setCodSerr(Integer codSerr) {
		this.codSerr = codSerr;
	}

	public Integer getNsuProd() {
		return nsuProd;
	}

	public void setNsuProd(Integer nsuProd) {
		this.nsuProd = nsuProd;
	}

	public String getNsuBanc() {
		return nsuBanc;
	}

	public void setNsuBanc(String nsuBanc) {
		this.nsuBanc = nsuBanc;
	}

	public String getCodProc() {
		return codProc;
	}

	public void setCodProc(String codProc) {
		this.codProc = codProc;
	}

	public String getNumCont() {
		return numCont;
	}

	public void setNumCont(String numCont) {
		this.numCont = numCont;
	}

	public String getNomCont() {
		return nomCont;
	}

	public void setNomCont(String nomCont) {
		this.nomCont = nomCont;
	}

	public String getExercic() {
		return exercic;
	}

	public void setExercic(String exercic) {
		this.exercic = exercic;
	}

	public String getNotific() {
		return notific;
	}

	public void setNotific(String notific) {
		this.notific = notific;
	}

	public String getParcel1() {
		return parcel1;
	}

	public void setParcel1(String parcel1) {
		this.parcel1 = parcel1;
	}

	public String getParcel2() {
		return parcel2;
	}

	public void setParcel2(String parcel2) {
		this.parcel2 = parcel2;
	}

	public String getSea() {
		return sea;
	}

	public void setSea(String sea) {
		this.sea = sea;
	}

	public String getMmaainc() {
		return mmaainc;
	}

	public void setMmaainc(String mmaainc) {
		this.mmaainc = mmaainc;
	}

	public String getIndMsgr() {
		return indMsgr;
	}

	public void setIndMsgr(String indMsgr) {
		this.indMsgr = indMsgr;
	}

	public Long getNumSipa() {
		return numSipa;
	}

	public void setNumSipa(Long numSipa) {
		this.numSipa = numSipa;
	}

	public String getIndSipa() {
		return indSipa;
	}

	public void setIndSipa(String indSipa) {
		this.indSipa = indSipa;
	}

	public String getTipDarf() {
		return tipDarf;
	}

	public void setTipDarf(String tipDarf) {
		this.tipDarf = tipDarf;
	}

	public String getReferEn() {
		return referEn;
	}

	public void setReferEn(String referEn) {
		this.referEn = referEn;
	}

	public BigDecimal getValRebR() {
		return valRebR;
	}

	public void setValRebR(BigDecimal valRebR) {
		this.valRebR = valRebR;
	}

	public BigDecimal getPerRebR() {
		return perRebR;
	}

	public void setPerRebR(BigDecimal perRebR) {
		this.perRebR = perRebR;
	}

	public String getCpfDesp() {
		return cpfDesp;
	}

	public void setCpfDesp(String cpfDesp) {
		this.cpfDesp = cpfDesp;
	}

	public Long getProtoco() {
		return protoco;
	}

	public void setProtoco(Long protoco) {
		this.protoco = protoco;
	}

	public String getNumPad() {
		return numPad;
	}

	public void setNumPad(String numPad) {
		this.numPad = numPad;
	}

	public String getCompete() {
		return compete;
	}

	public void setCompete(String compete) {
		this.compete = compete;
	}

	public String getNumCcre() {
		return numCcre;
	}

	public void setNumCcre(String numCcre) {
		this.numCcre = numCcre;
	}

	public String getNumCelular() {
		return numCelular;
	}

	public void setNumCelular(String numCelular) {
		this.numCelular = numCelular;
	}

	public String getValorINSS() {
		return valorINSS;
	}

	public void setValorINSS(String valorINSS) {
		this.valorINSS = valorINSS;
	}

	public String getDataVencimento() {
		return dataVencimento;
	}

	public void setDataVencimento(String dataVencimento) {
		this.dataVencimento = dataVencimento;
	}

	public String getCodigoReceita() {
		return codigoReceita;
	}

	public void setCodigoReceita(String codigoReceita) {
		this.codigoReceita = codigoReceita;
	}

	public String getCodigoRefMa() {
		return codigoRefMa;
	}

	public void setCodigoRefMa(String codigoRefMa) {
		this.codigoRefMa = codigoRefMa;
	}

	public Integer getMaxSeqNio() {
		return MaxSeqNio;
	}

	public void setMaxSeqNio(Integer maxSeqNio) {
		MaxSeqNio = maxSeqNio;
	}

	public String getTabela() {
		return Tabela;
	}

	public void setTabela(String tabela) {
		Tabela = tabela;
	}

	public SegundaViaComprContasDTO() {
		//
	}

	public String getCanal() {
		return canal;
	}

	public void setCanal(String canal) {
		this.canal = canal;
	}

	public boolean isSelecionado() {
		return selecionado;
	}

	public void setSelecionado(boolean selecionado) {
		this.selecionado = selecionado;
	}

	public String getDataInicial() {
		return dataInicial;
	}

	public void setDataInicial(String dataInicial) {
		this.dataInicial = dataInicial;
	}

	public String getDataFinal() {
		return dataFinal;
	}

	public void setDataFinal(String dataFinal) {
		this.dataFinal = dataFinal;
	}

	public BigDecimal getValorPago() {
		return valorPago;
	}

	public void setValorPago(BigDecimal valorPago) {
		this.valorPago = valorPago;
	}

	public String getDataPagamento() {
		return dataPagamento;
	}

	public void setDataPagamento(String dataPagamento) {
		this.dataPagamento = dataPagamento;
	}

	public String getDataTransacao() {
		return dataTransacao;
	}

	public void setDataTransacao(String dataTransacao) {
		this.dataTransacao = dataTransacao;
	}

	public String getAutenticacaoBancaria() {
		return autenticacaoBancaria;
	}

	public void setAutenticacaoBancaria(String autenticacaoBancaria) {
		this.autenticacaoBancaria = autenticacaoBancaria;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getConta() {
		return conta;
	}

	public void setConta(String conta) {
		this.conta = conta;
	}

	public String getCanalPagamento() {
		return canalPagamento;
	}

	public void setCanalPagamento(String canalPagamento) {
		this.canalPagamento = canalPagamento;
	}

	public String getCanalPagamentoCaseSensitive() {
		return UtilFunction.convertStringToCaseSensitive(canalPagamento);
	}

	public String getCanalPagamentoUpperCase() {
		String retorno = canalPagamento;
		if (canalPagamento != null) {
			retorno = canalPagamento.toUpperCase().trim();
		}
		return retorno;
	}

	public String getCodigoUsuario() {
		return codigoUsuario;
	}

	public void setCodigoUsuario(String codigoUsuario) {
		this.codigoUsuario = codigoUsuario;
	}

	public String getHostAddress() {
		return hostAddress;
	}

	public void setHostAddress(String hostAddress) {
		this.hostAddress = hostAddress;
	}

	public String getHoraTransacao() {
		return horaTransacao;
	}

	public void setHoraTransacao(String horaTransacao) {
		this.horaTransacao = horaTransacao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((agencia == null) ? 0 : agencia.hashCode());
		result = prime * result + ((autenticacaoBancaria == null) ? 0 : autenticacaoBancaria.hashCode());
		result = prime * result + ((banco == null) ? 0 : banco.hashCode());
		result = prime * result + ((canal == null) ? 0 : canal.hashCode());
		result = prime * result + ((canalPagamento == null) ? 0 : canalPagamento.hashCode());
		result = prime * result + ((codigoUsuario == null) ? 0 : codigoUsuario.hashCode());
		result = prime * result + ((conta == null) ? 0 : conta.hashCode());
		result = prime * result + ((dataFinal == null) ? 0 : dataFinal.hashCode());
		result = prime * result + ((dataTransacao == null) ? 0 : dataTransacao.hashCode());
		result = prime * result + ((dataInicial == null) ? 0 : dataInicial.hashCode());
		result = prime * result + ((dataPagamento == null) ? 0 : dataPagamento.hashCode());
		result = prime * result + ((horaTransacao == null) ? 0 : horaTransacao.hashCode());
		result = prime * result + ((hostAddress == null) ? 0 : hostAddress.hashCode());
		result = prime * result + (selecionado ? 1231 : 1237);
		result = prime * result + ((valorPago == null) ? 0 : valorPago.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof SegundaViaComprContasDTO)) {
			return false;
		}
		SegundaViaComprContasDTO other = (SegundaViaComprContasDTO) obj;
		if (agencia == null) {
			if (other.agencia != null) {
				return false;
			}
		} else if (!agencia.equals(other.agencia)) {
			return false;
		}
		if (autenticacaoBancaria == null) {
			if (other.autenticacaoBancaria != null) {
				return false;
			}
		} else if (!autenticacaoBancaria.equals(other.autenticacaoBancaria)) {
			return false;
		}
		if (banco == null) {
			if (other.banco != null) {
				return false;
			}
		} else if (!banco.equals(other.banco)) {
			return false;
		}
		if (canal == null) {
			if (other.canal != null) {
				return false;
			}
		} else if (!canal.equals(other.canal)) {
			return false;
		}
		if (canalPagamento == null) {
			if (other.canalPagamento != null) {
				return false;
			}
		} else if (!canalPagamento.equals(other.canalPagamento)) {
			return false;
		}
		if (codigoUsuario == null) {
			if (other.codigoUsuario != null) {
				return false;
			}
		} else if (!codigoUsuario.equals(other.codigoUsuario)) {
			return false;
		}
		if (conta == null) {
			if (other.conta != null) {
				return false;
			}
		} else if (!conta.equals(other.conta)) {
			return false;
		}
		if (dataFinal == null) {
			if (other.dataFinal != null) {
				return false;
			}
		} else if (!dataFinal.equals(other.dataFinal)) {
			return false;
		}
		if (dataTransacao == null) {
			if (other.dataTransacao != null) {
				return false;
			}
		} else if (!dataTransacao.equals(other.dataTransacao)) {
			return false;
		}
		if (dataInicial == null) {
			if (other.dataInicial != null) {
				return false;
			}
		} else if (!dataInicial.equals(other.dataInicial)) {
			return false;
		}
		if (dataPagamento == null) {
			if (other.dataPagamento != null) {
				return false;
			}
		} else if (!dataPagamento.equals(other.dataPagamento)) {
			return false;
		}
		if (horaTransacao == null) {
			if (other.horaTransacao != null) {
				return false;
			}
		} else if (!horaTransacao.equals(other.horaTransacao)) {
			return false;
		}
		if (hostAddress == null) {
			if (other.hostAddress != null) {
				return false;
			}
		} else if (!hostAddress.equals(other.hostAddress)) {
			return false;
		}
		if (selecionado != other.selecionado) {
			return false;
		}
		if (valorPago == null) {
			if (other.valorPago != null) {
				return false;
			}
		} else if (!valorPago.equals(other.valorPago)) {
			return false;
		}
		return true;
	}

	public String getDataMov() {
		return dataMov;
	}

	public void setDataMov(String dataMov) {
		this.dataMov = dataMov;
	}

	public String getSeqArre() {
		return seqArre;
	}

	public void setSeqArre(String seqArre) {
		this.seqArre = seqArre;
	}

	public String getTipoConta() {
		return tipoConta;
	}

	public void setTipoConta(String tipoConta) {
		this.tipoConta = tipoConta;
	}

	public String getFormaPagamento() {
		return formaPagamento;
	}

	public void setFormaPagamento(String formaPagamento) {
		this.formaPagamento = formaPagamento;
	}

	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}

	public String getConvenio() {
		return convenio;
	}

	public void setConvenio(String convenio) {
		this.convenio = convenio;
	}

	public String getCodigoBarras() {
		return codigoBarras;
	}

	public void setCodigoBarras(String codigoBarras) {
		this.codigoBarras = codigoBarras;
	}

	public String getNumeroCartao() {
		return numeroCartao;
	}

	public void setNumeroCartao(String numeroCartao) {
		this.numeroCartao = numeroCartao;
	}

	public String getCodigoCliente() {
		return codigoCliente;
	}

	public void setCodigoCliente(String codigoCliente) {
		this.codigoCliente = codigoCliente;
	}

	public String getTipoCom() {
		return tipoCom;
	}

	public void setTipoCom(String tipoCom) {
		this.tipoCom = tipoCom;
	}

	public String getHoraArr() {
		return horaArr;
	}

	public void setHoraArr(String horaArr) {
		this.horaArr = horaArr;
	}

	public String getNomeContribuinte() {
		return nomeContribuinte;
	}

	public void setNomeContribuinte(String nomeContribuinte) {
		this.nomeContribuinte = nomeContribuinte;
	}

	public String getAgenOpe() {
		return agenOpe;
	}

	public void setAgenOpe(String agenOpe) {
		this.agenOpe = agenOpe;
	}

	public String getAiim() {
		return aiim;
	}

	public void setAiim(String aiim) {
		this.aiim = aiim;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getEndeCon() {
		return endeCon;
	}

	public void setEndeCon(String endeCon) {
		this.endeCon = endeCon;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getAnoExe() {
		return anoExe;
	}

	public void setAnoExe(String anoExe) {
		this.anoExe = anoExe;
	}

	public String getAutDig() {
		return autDig;
	}

	public void setAutDig(String autDig) {
		this.autDig = autDig;
	}

	public String getCeMerca() {
		return ceMerca;
	}

	public void setCeMerca(String ceMerca) {
		this.ceMerca = ceMerca;
	}

	public String getCenMod() {
		return cenMod;
	}

	public void setCenMod(String cenMod) {
		this.cenMod = cenMod;
	}

	public String getCmm() {
		return cmm;
	}

	public void setCmm(String cmm) {
		this.cmm = cmm;
	}

	public String getCnae() {
		return cnae;
	}

	public void setCnae(String cnae) {
		this.cnae = cnae;
	}

	public String getCodArea() {
		return codArea;
	}

	public void setCodArea(String codArea) {
		this.codArea = codArea;
	}

	public String getCodDivi() {
		return codDivi;
	}

	public void setCodDivi(String codDivi) {
		this.codDivi = codDivi;
	}

	public String getCenArre() {
		return cenArre;
	}

	public void setCenArre(String cenArre) {
		this.cenArre = cenArre;
	}

	public String getNio() {
		return nio;
	}

	public void setNio(String nio) {
		this.nio = nio;
	}

	public String getDataArr() {
		return dataArr;
	}

	public void setDataArr(String dataArr) {
		this.dataArr = dataArr;
	}

	public String getDataVct() {
		return dataVct;
	}

	public void setDataVct(String dataVct) {
		this.dataVct = dataVct;
	}

	public String getRefMa() {
		return refMa;
	}

	public void setRefMa(String refMa) {
		this.refMa = refMa;
	}

	public String getTimeStp() {
		return timeStp;
	}

	public void setTimeStp(String timeStp) {
		this.timeStp = timeStp;
	}

	public String getDataApu() {
		return dataApu;
	}

	public void setDataApu(String dataApu) {
		this.dataApu = dataApu;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getTipoLinha() {
		return tipoLinha;
	}

	public void setTipoLinha(String tipoLinha) {
		this.tipoLinha = tipoLinha;
	}

	public Integer getEspacoLinha() {
		return espacoLinha;
	}

	public void setEspacoLinha(Integer espacoLinha) {
		this.espacoLinha = espacoLinha;
	}

	public boolean isUltimo() {
		return ultimo;
	}

	public void setUltimo(boolean ultimo) {
		this.ultimo = ultimo;
	}

	public List<SegundaViaComprContasDTO> getSegundaViaComprContasDTOs() {
		return segundaViaComprContasDTOs;
	}

	public void setSegundaViaComprContasDTOs(List<SegundaViaComprContasDTO> segundaViaComprContasDTOs) {
		this.segundaViaComprContasDTOs = segundaViaComprContasDTOs;
	}

}
