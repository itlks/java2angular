package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class ConsultarListaCnpjContratoDTO implements Serializable {
	
	private static final long serialVersionUID = 1060613932869210782L;
	
	private Integer banco;
	private Integer agencia;
	private Integer conta;
	private String titulo;
	private Integer cdPar; //PENUMPER
	private String origem;
	private String tipoAssoc;
	private String docto; //CNPJ
	private String doctoFormatado;
	private Integer tipoDocto;
	private String nomeEmpresa;
	
	public Integer getBanco() {
		return banco;
	}
	public void setBanco(Integer banco) {
		this.banco = banco;
	}
	public Integer getAgencia() {
		return agencia;
	}
	public void setAgencia(Integer agencia) {
		this.agencia = agencia;
	}
	public Integer getConta() {
		return conta;
	}
	public void setConta(Integer conta) {
		this.conta = conta;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public Integer getCdPar() {
		return cdPar;
	}
	public void setCdPar(Integer cdPar) {
		this.cdPar = cdPar;
	}
	public String getOrigem() {
		return origem;
	}
	public void setOrigem(String origem) {
		this.origem = origem;
	}
	public String getTipoAssoc() {
		return tipoAssoc;
	}
	public void setTipoAssoc(String tipoAssoc) {
		this.tipoAssoc = tipoAssoc;
	}
	public String getDocto() {
		return docto;
	}
	public void setDocto(String docto) {
		this.docto = docto;
	}
	public Integer getTipoDocto() {
		return tipoDocto;
	}
	public void setTipoDocto(Integer tipoDocto) {
		this.tipoDocto = tipoDocto;
	}
	public String getNomeEmpresa() {
		return nomeEmpresa;
	}
	public String getDoctoFormatado() {
		return doctoFormatado;
	}
	public void setDoctoFormatado(String doctoFormatado) {
		this.doctoFormatado = doctoFormatado;
	}
	public void setNomeEmpresa(String nomeEmpresa) {
		this.nomeEmpresa = nomeEmpresa;
	}


}
