package com.altec.bsbr.app.ibe.rest.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.altec.bsbr.app.ibe.dto.investimento.home.InvestimentoHomeRequestDTO;
import com.altec.bsbr.app.ibe.rest.hub.HubRest;
import com.altec.bsbr.app.ibe.rest.hub.dto.HubRestResourceDTO;
import com.altec.bsbr.app.ibe.rest.portfolio.dto.PortfolioResponseDTO;
import com.altec.bsbr.app.ibe.rest.service.InvestimentoHomeRestService;
import com.altec.bsbr.app.ibe.util.MensagensRetorno;

@Service
public class InvestimentoHomeRestServiceImpl implements InvestimentoHomeRestService {
	public static final Logger LOGGER = LoggerFactory.getLogger(InvestimentoHomeRestServiceImpl.class);
	
	@Autowired private HubRest hubRest;
	@Autowired @Qualifier("investimento") private HubRestResourceDTO resource;
	
	@Override
	public PortfolioResponseDTO consultarInvestimentos(InvestimentoHomeRequestDTO investimentoHomeRequestDTO) {
		PortfolioResponseDTO investimentoHomeResponseDTO = new PortfolioResponseDTO();
		
		try {
			
			ResponseEntity<PortfolioResponseDTO> response = hubRest.postForEntity(resource.getUrl(), investimentoHomeRequestDTO, PortfolioResponseDTO.class);
			if ( response!=null &&  response.getStatusCode().value() == 200 ){
				investimentoHomeResponseDTO = response.getBody();
				LOGGER.debug("INVESTIMENTO HubRest Consultado com SUCESSO !!!!");
			}
		} catch (Exception e) {
			investimentoHomeResponseDTO.setStatusCode(MensagensRetorno.ERRO_EXCEPTION);
			investimentoHomeResponseDTO.setMessage(e.getMessage());
			LOGGER.error("Exception [InvestimentoHomeRestServiceImpl] consultarInvestimentos : [{}]" , e);
		}
		return investimentoHomeResponseDTO;
	}

}