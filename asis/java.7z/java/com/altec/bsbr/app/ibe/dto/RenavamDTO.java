package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.text.ParseException;

import javax.swing.text.MaskFormatter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.altec.bsbr.app.ibe.enumeration.RenavamEstadoPesquisaEnum;
import com.altec.bsbr.app.ibe.enumeration.RenavamSituacaoEnum;
import com.altec.bsbr.app.ibe.util.UtilFunction;
import com.altec.bsbr.app.ibe.util.WSFormat;
import com.altec.bsbr.app.ibe.util.WSFormat.Position;

public class RenavamDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 6660773043346049593L;

	private static final String STRING_ZERO = "0";
	private static final String MASCARA_RENAVAM = "###.###.###.###";

	private String identificacao;
	private String nome;
	private String placaVeiculo;

	private String numero;
	private String apelido;
	private String placa;
	private RenavamEstadoPesquisaEnum estado;
	private RenavamSituacaoEnum situacao;
	private String estadoSelecionado;
	private String proprietario;
	private String codMunicipio;
	private String numCpfCnpj;
	private int anoLicenciamento;
	private float taxaLicenciamento;
	private float taxaPost;
	
	public static final Logger LOGGER = LoggerFactory.getLogger(RenavamDTO.class);
	
	public RenavamDTO() {
		// Construtor
	}
	
	public RenavamDTO(String identificacao, String nome, String placaVeiculo, String situacao, String numCpfCnpj, String codMunicipio, String apelido) {
		super();
		this.identificacao = identificacao;
		this.nome = nome;
		this.placaVeiculo = placaVeiculo;
		this.situacao = RenavamSituacaoEnum.findById(situacao);
	}
	
	public RenavamDTO(String numero, String placa, String apelido, String estado){
		this.numero = numero;
		this.placa = placa;
		this.apelido = apelido;
		this.estado = RenavamEstadoPesquisaEnum.findById(estado);
	}
	
	public RenavamDTO(String numero, String placa, String apelido, String estado, String situacao){
		this.numero = numero;
		this.placa = placa;
		this.apelido = apelido;
		this.estado = RenavamEstadoPesquisaEnum.findById(estado);
		this.situacao = RenavamSituacaoEnum.findById(situacao);
	}	

	public RenavamDTO(String numero, String proprietario, String codMunicipio, String numCpfCnpj, String placaVeiculo, String apelido) {
		this.numero = numero;
		this.proprietario = proprietario;
		this.codMunicipio = codMunicipio;
		this.numCpfCnpj= numCpfCnpj;
		this.placa = placaVeiculo;
		this.apelido = apelido;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}
	
	public String getApelido() {
		return apelido;
	}
	
	public void setApelido(String apelido) {
		this.apelido = apelido;
	}
	
	public RenavamEstadoPesquisaEnum getEstado() {
		return estado;
	}
	
	public void setEstado(RenavamEstadoPesquisaEnum estado) {
		this.estado = estado;
	}
	
	public String getPlaca() {
		return placa;
	}
	
	public void setPlaca(String placa) {
		this.placa = placa;
	}

	public RenavamSituacaoEnum getSituacao() {
		return situacao;
	}

	public void setSituacao(RenavamSituacaoEnum situacao) {
		this.situacao = situacao;
	}

	public String getProprietario() {
		return proprietario;
	}

	public void setProprietario(String proprietario) {
		this.proprietario = proprietario;
	}

	public String getCodMunicipio() {
		return codMunicipio;
	}

	public void setCodMunicipio(String codMunicipio) {
		this.codMunicipio = codMunicipio;
	}

	public String getNumCpfCnpj() {
		return numCpfCnpj;
	}

	public void setNumCpfCnpj(String numCpfCnpj) {
		this.numCpfCnpj = numCpfCnpj;
	}

	public int getAnoLicenciamento() {
		return anoLicenciamento;
	}

	public void setAnoLicenciamento(int anoLicenciamento) {
		this.anoLicenciamento = anoLicenciamento;
	}

	public float getTaxaLicenciamento() {
		return taxaLicenciamento;
	}

	public void setTaxaLicenciamento(float taxaLicenciamento) {
		this.taxaLicenciamento = taxaLicenciamento;
	}

	public float getTaxaPost() {
		return taxaPost;
	}

	public void setTaxaPost(float taxaPost) {
		this.taxaPost = taxaPost;
	}


	public String getIdentificacao() {
		return identificacao;
	}

	public void setIdentificacao(String identificacao) {
		this.identificacao = identificacao;
	}

	public String getPlacaVeiculo() {
		return placaVeiculo;
	}

	public void setPlacaVeiculo(String placaVeiculo) {
		this.placaVeiculo = placaVeiculo;
	}

	public String getNomeRenavamFormatado() {
		String retorno = new String();
		if (!UtilFunction.isBlankOrNull(getNome())) {
			try {
				String nome = WSFormat.getFormatString(getNome(), 12, STRING_ZERO, Position.RIGHT);
				MaskFormatter maskRenavam = new MaskFormatter(MASCARA_RENAVAM);
				maskRenavam.setValueContainsLiteralCharacters(false);
				retorno = maskRenavam.valueToString(nome).toString();
			} catch (ParseException e) {
				LOGGER.error("Exception [RENAVANDTO]", e);
			}
		}
		return retorno;
	}

	public String getEstadoSelecionado() {
		return estadoSelecionado;
	}

	public void setEstadoSelecionado(String estadoSelecionado) {
		setEstado(RenavamEstadoPesquisaEnum.findById(estadoSelecionado));
		this.estadoSelecionado = estadoSelecionado;
	}

}
