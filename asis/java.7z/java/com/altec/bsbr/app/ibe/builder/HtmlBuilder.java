package com.altec.bsbr.app.ibe.builder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.altec.bsbr.app.ibe.pdf.dto.WkHtmlToPdfDTO;

/**
 * 
 * @author Jonas Francisco Perez
 * 
 */

public class HtmlBuilder {
	private static final Logger LOGGER = LoggerFactory.getLogger(HtmlBuilder.class);
	
	private StringBuilder htm = new StringBuilder();
	
	public static HtmlBuilder htmlBuilder(){
		return new HtmlBuilder();
	}
	
	public HtmlBuilder buildPdfHtmlHeader(){
		htm.append("<!DOCTYPE html><html xmlns='http://www.w3.org/1999/xhtml' lang='pt-br'>");
		
		htm.append("<header>");
		htm.append("	<link type='text/css' rel='stylesheet' href='./css/bootstrap.min.css'/>");
		htm.append("	<link type='text/css' rel='stylesheet' href='./css/styleNovo.css'/>");
		htm.append("	<link type='text/css' rel='stylesheet' href='./css/pdf-style.css'/>");
		htm.append("	<link type='text/css' rel='stylesheet' href='./css/icones/font-awesome.css'/>");
		
		htm.append("	<style>thead, tfoot {display: table-row-group;}</style>");
		htm.append("</header>");
		return this;
	}
	
	public HtmlBuilder buildPdfHtmlBody(WkHtmlToPdfDTO wkHtmlToPdfDTO){
		htm.append("<body>");
		htm.append("<div class='col-lg-12'>");
		htm.append("	<div class='row tamanhoMinimoPDF'>");
		htm.append("		<div class='col-xs-3 img-content'>");
		htm.append("			<img src='./images/santander.PNG' />");
		htm.append("		</div>");
		htm.append("		<div class='titulo text-right col-xs-9'>");
		htm.append("			<p><span><span id='tituloSistema'>").append( wkHtmlToPdfDTO.getLabelTituloSistema() ).append("</span></span></p>");
		htm.append("		</div>");
		htm.append("	</div>");

		htm.append("	<hr class='ui-separator ui-state-default ui-corner-all separator tamanhoMinimoPDF' />");
		
		htm.append("	<div class='row tamanhoMinimoPDF'>");
		htm.append("		<div class='col-xs-6 text-left name'>").append( wkHtmlToPdfDTO.getNomeTitularConta() ).append("</div>");
		htm.append("		<div class='col-xs-6 text-right info-account'>");
		htm.append("			<div><strong><span id='agencia'>").append( wkHtmlToPdfDTO.getLabelAgencia() ).append("</span>: </strong>").append( wkHtmlToPdfDTO.getAgencia() ).append("</div>");
		htm.append("			<div><strong><span id='conta'>").append( wkHtmlToPdfDTO.getLabelConta() ).append("</span>: </strong>").append( wkHtmlToPdfDTO.getConta() ).append("</div>");
		htm.append("		</div>");
		htm.append("	</div>");

		htm.append("	<hr class='ui-separator ui-state-default ui-corner-all separator tamanhoMinimoPDF' />");

		htm.append("	<div class='row'>");
		htm.append(			wkHtmlToPdfDTO.getHtmlBody());
		htm.append("	</div>");
		htm.append("</div>");

		htm.append("</body>");
		htm.append("</html>");
		return this;
	}
	
	public HtmlBuilder buildPdfCustomHtmlBody(WkHtmlToPdfDTO wkHtmlToPdfDTO){
		htm.append("<body>");
		htm.append(     wkHtmlToPdfDTO.getHtmlBody());
		htm.append("</body>");
		htm.append("</html>");		
		return this;
	}

	public HtmlBuilder buildManyPdfsHtmlBody(String htmlBody){
		htm.append("<div id='container-fluid' class='container'>");
		htm.append(		"<div class='miolo'>");
		htm.append(			"<div class='row'>");
		htm.append(				htmlBody );
		htm.append("		</div>");
		htm.append("	</div>");
		htm.append("</div>");		
		return this;
	}
	
	public HtmlBuilder buildManyPrintHtmlBody(WkHtmlToPdfDTO wkHtmlToPdfDTO){
		if ( wkHtmlToPdfDTO.getComprovants() == 0 ) htm.append("<div class='col-lg-12 eachPdf' style='float: none!important;'>");
		else htm.append("<div class='col-lg-12 eachPdf' style='page-break-before: always; float: none!important;'>");
		htm.append("	<div class='row tamanhoMinimoPDF'>");
		htm.append("		<div class='col-xs-3 img-content'>");
		htm.append("			<img src='" + wkHtmlToPdfDTO.getPath() + "/images/santander-u29.png' />");
		htm.append("		</div>");
		htm.append("		<div class='titulo text-right col-xs-9'>");
		htm.append("			<p><span><span id='tituloSistema'>").append( wkHtmlToPdfDTO.getLabelTituloSistema() ).append("</span></span></p>");
		htm.append("		</div>");
		htm.append("	</div>");

		htm.append("	<hr class='ui-separator ui-state-default ui-corner-all separator tamanhoMinimoPDF' />");
		
		htm.append("	<div class='row tamanhoMinimoPDF'>");
		htm.append("		<div class='col-xs-6 text-left name'>").append( wkHtmlToPdfDTO.getNomeTitularConta() ).append("</div>");
		htm.append("		<div class='col-xs-6 text-right info-account'>");
		htm.append("			<div><strong><span id='agencia'>").append( wkHtmlToPdfDTO.getLabelAgencia() ).append("</span>: </strong>").append( wkHtmlToPdfDTO.getAgencia() ).append("</div>");
		htm.append("			<div><strong><span id='conta'>").append( wkHtmlToPdfDTO.getLabelConta() ).append("</span>: </strong>").append( wkHtmlToPdfDTO.getConta() ).append("</div>");
		htm.append("		</div>");
		htm.append("	</div>");

		htm.append("	<hr class='ui-separator ui-state-default ui-corner-all separator tamanhoMinimoPDF' />");

		htm.append("	<div class='row'>");
		htm.append(			wkHtmlToPdfDTO.getHtmlBody() );
		htm.append("	</div>");
		htm.append("</div>");
		return this;
	}
	
	public StringBuilder get() {
		LOGGER.debug(htm.toString());
		return htm; 
	}

}
