package com.altec.bsbr.app.ibe.dto;

import java.math.BigDecimal;

public class DpvatComprovanteDTO {

	private String exDpvt;
	private BigDecimal vlDpvt;

	public String getExDpvt() {
		return exDpvt;
	}

	public void setExDpvt(String exDpvt) {
		this.exDpvt = exDpvt;
	}

	public BigDecimal getVlDpvt() {
		return vlDpvt;
	}

	public void setVlDpvt(BigDecimal vlDpvt) {
		this.vlDpvt = vlDpvt;
	}

}
