package com.altec.bsbr.app.ibe.dto;

import java.util.Date;
import java.util.List;

import com.altec.bsbr.app.ibe.dto.consultarconveniosdebitoautomatico.ItemConsultarConveniosDebitoAutomaticoResponseDTO;
import com.altec.bsbr.app.ibe.enumeration.DebitoAutomaticoAcaoEnum;
import com.altec.bsbr.app.ibe.enumeration.DebitoAutomaticoSituacaoEnum;
import com.altec.bsbr.app.ibe.enumeration.DebitoAutomaticoTipoContaEnum;

public class DebitoAutomaticoSelecaoDTO {
	
	private DebitoAutomaticoAcaoEnum acaoEnum;
	private DebitoAutomaticoTipoContaEnum tipoConta;
	private DebitoAutomaticoSituacaoEnum situacao;
	private Date dataInicial;
	private Date dataFinal;
	private ItemConsultarConveniosDebitoAutomaticoResponseDTO empresaConveniada;
	
	public ItemConsultarConveniosDebitoAutomaticoResponseDTO getEmpresaConveniada() {
		return empresaConveniada;
	}
	public void setEmpresaConveniada(ItemConsultarConveniosDebitoAutomaticoResponseDTO empresaConveniada) {
		this.empresaConveniada = empresaConveniada;
	}
	public DebitoAutomaticoTipoContaEnum getTipoConta() {
		return tipoConta;
	}
	public void setTipoConta(DebitoAutomaticoTipoContaEnum tipoConta) {
		this.tipoConta = tipoConta;
	}
	public DebitoAutomaticoSituacaoEnum getSituacao() {
		return situacao;
	}
	public void setSituacao(DebitoAutomaticoSituacaoEnum situacao) {
		this.situacao = situacao;
	}
	public Date getDataInicial() {
		return dataInicial;
	}
	public void setDataInicial(Date dataInicial) {
		this.dataInicial = dataInicial;
	}
	public Date getDataFinal() {
		return dataFinal;
	}
	public void setDataFinal(Date dataFinal) {
		this.dataFinal = dataFinal;
	}
	
	public void setEmpresaConveniada(String numDocumento, List<ItemConsultarConveniosDebitoAutomaticoResponseDTO> listaItensConvenios){
		
		if(numDocumento != null && listaItensConvenios != null){

			for (ItemConsultarConveniosDebitoAutomaticoResponseDTO item : listaItensConvenios) {
				if(item.getBanco().getNroCuentaBr().equals(numDocumento)){
					this.empresaConveniada = item;
					break;
				}
			}
		}
		
		
	}
	
	public DebitoAutomaticoAcaoEnum getAcaoEnum() {
		return acaoEnum;
	}
	public void setAcaoEnum(DebitoAutomaticoAcaoEnum acaoEnum) {
		this.acaoEnum = acaoEnum;
	}
	
}
