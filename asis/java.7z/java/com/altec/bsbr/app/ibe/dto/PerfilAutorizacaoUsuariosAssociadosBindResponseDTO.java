package com.altec.bsbr.app.ibe.dto;

public class PerfilAutorizacaoUsuariosAssociadosBindResponseDTO {

	private String usuario;
	private String nomeAcesso;
	private String conta;
	
	public PerfilAutorizacaoUsuariosAssociadosBindResponseDTO() {}
	
	public PerfilAutorizacaoUsuariosAssociadosBindResponseDTO(String usuario, String nomeAcesso, String conta) {
		super();
		this.usuario = usuario;
		this.nomeAcesso = nomeAcesso;
		this.conta = conta;
	}
	
	public String getUsuario() {
		return usuario;
	}
	public String getNomeAcesso() {
		return nomeAcesso;
	}
	public String getConta() {
		return conta;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public void setNomeAcesso(String nomeAcesso) {
		this.nomeAcesso = nomeAcesso;
	}
	public void setConta(String conta) {
		this.conta = conta;
	}
	
	
}
