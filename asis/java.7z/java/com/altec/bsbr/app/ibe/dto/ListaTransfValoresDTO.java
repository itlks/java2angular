package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;

public class ListaTransfValoresDTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6805606417938070288L;
	private String OECHAVEAMARRACAO;
	private String OEBANCODEBITO;
	private String OEAGENCIADEBITO;
	private String OECONTADEBITO;
	private String OEBANCOCREDITO;
	private String OEAGENCIACREDITO;
	private String OECONTACREDITO;
	private String OEVALORREMESSA;
	private String OEDATAGEN;
	private String OEHORAGEN;
	private String OEINDCICL;
	private String OEQTDCICL;
	private String OECONTROLENY;
	private String OEFLAGCPMF;
	private String OENOMECLIENTEDEB;
	private String OENOMECLIENTECRED;
	private String OEDTACONTAB;
	private String OEDTATRAN;
	private String OEHORTRAN;
	private String OETIPOCONTAORIGEM;
	private String OEAGENCIAORIGEMINF;
	private String OECONTAORIGEMINF;
	private String OETIPOCONTADESTINO;
	private String OEAGENCIADESTINOINF;
	private String OECONTADESTINOINF;
	private String nomeOrigem;
	private String nomeDestino;
	private String tipoDocumento;
	private String documentoFormatado;
	private String agenciaOrigemFormatada;
	private String contaOrigemFormatada;
	private String bancoDestinoFormatado;
	private String agenciaDestinoFormatada;
	private String contaDestinoFormatada;
	private BigDecimal valorTarifa;
	
	public String getAgenciaOrigemFormatada() {
		return agenciaOrigemFormatada;
	}
	public void setAgenciaOrigemFormatada(String agenciaOrigemFormatada) {
		this.agenciaOrigemFormatada = agenciaOrigemFormatada;
	}
	public String getContaOrigemFormatada() {
		return contaOrigemFormatada;
	}
	public void setContaOrigemFormatada(String contaOrigemFormatada) {
		this.contaOrigemFormatada = contaOrigemFormatada;
	}
	public String getBancoDestinoFormatado() {
		return bancoDestinoFormatado;
	}
	public void setBancoDestinoFormatado(String bancoDestinoFormatado) {
		this.bancoDestinoFormatado = bancoDestinoFormatado;
	}
	public String getAgenciaDestinoFormatada() {
		return agenciaDestinoFormatada;
	}
	public void setAgenciaDestinoFormatada(String agenciaDestinoFormatada) {
		this.agenciaDestinoFormatada = agenciaDestinoFormatada;
	}
	public String getContaDestinoFormatada() {
		return contaDestinoFormatada;
	}
	public void setContaDestinoFormatada(String contaDestinoFormatada) {
		this.contaDestinoFormatada = contaDestinoFormatada;
	}
	public String getOECHAVEAMARRACAO() {
		return OECHAVEAMARRACAO;
	}
	public void setOECHAVEAMARRACAO(String oECHAVEAMARRACAO) {
		OECHAVEAMARRACAO = oECHAVEAMARRACAO;
	}
	public String getOEBANCODEBITO() {
		return OEBANCODEBITO;
	}
	public void setOEBANCODEBITO(String oEBANCODEBITO) {
		OEBANCODEBITO = oEBANCODEBITO;
	}
	public String getOEAGENCIADEBITO() {
		return OEAGENCIADEBITO;
	}
	public void setOEAGENCIADEBITO(String oEAGENCIADEBITO) {
		OEAGENCIADEBITO = oEAGENCIADEBITO;
	}
	public String getOECONTADEBITO() {
		return OECONTADEBITO;
	}
	public void setOECONTADEBITO(String oECONTADEBITO) {
		OECONTADEBITO = oECONTADEBITO;
	}
	public String getOEBANCOCREDITO() {
		return OEBANCOCREDITO;
	}
	public void setOEBANCOCREDITO(String oEBANCOCREDITO) {
		OEBANCOCREDITO = oEBANCOCREDITO;
	}
	public String getOEAGENCIACREDITO() {
		return OEAGENCIACREDITO;
	}
	public void setOEAGENCIACREDITO(String oEAGENCIACREDITO) {
		OEAGENCIACREDITO = oEAGENCIACREDITO;
	}
	public String getOECONTACREDITO() {
		return OECONTACREDITO;
	}
	public void setOECONTACREDITO(String oECONTACREDITO) {
		OECONTACREDITO = oECONTACREDITO;
	}
	public String getOEVALORREMESSA() {
		return OEVALORREMESSA;
	}
	public void setOEVALORREMESSA(String oEVALORREMESSA) {
		OEVALORREMESSA = oEVALORREMESSA;
	}
	public String getOEDATAGEN() {
		return OEDATAGEN;
	}
	public void setOEDATAGEN(String oEDATAGEN) {
		OEDATAGEN = oEDATAGEN;
	}
	public String getOEHORAGEN() {
		return OEHORAGEN;
	}
	public void setOEHORAGEN(String oEHORAGEN) {
		OEHORAGEN = oEHORAGEN;
	}
	public String getOEINDCICL() {
		return OEINDCICL;
	}
	public void setOEINDCICL(String oEINDCICL) {
		OEINDCICL = oEINDCICL;
	}
	public String getOEQTDCICL() {
		return OEQTDCICL;
	}
	public void setOEQTDCICL(String oEQTDCICL) {
		OEQTDCICL = oEQTDCICL;
	}
	public String getOECONTROLENY() {
		return OECONTROLENY;
	}
	public void setOECONTROLENY(String oECONTROLENY) {
		OECONTROLENY = oECONTROLENY;
	}
	public String getOEFLAGCPMF() {
		return OEFLAGCPMF;
	}
	public void setOEFLAGCPMF(String oEFLAGCPMF) {
		OEFLAGCPMF = oEFLAGCPMF;
	}
	public String getOENOMECLIENTEDEB() {
		return OENOMECLIENTEDEB;
	}
	public void setOENOMECLIENTEDEB(String oENOMECLIENTEDEB) {
		OENOMECLIENTEDEB = oENOMECLIENTEDEB;
	}
	public String getOENOMECLIENTECRED() {
		return OENOMECLIENTECRED;
	}
	public void setOENOMECLIENTECRED(String oENOMECLIENTECRED) {
		OENOMECLIENTECRED = oENOMECLIENTECRED;
	}
	public String getOEDTACONTAB() {
		return OEDTACONTAB;
	}
	public void setOEDTACONTAB(String oEDTACONTAB) {
		OEDTACONTAB = oEDTACONTAB;
	}
	public String getOEDTATRAN() {
		return OEDTATRAN;
	}
	public void setOEDTATRAN(String oEDTATRAN) {
		OEDTATRAN = oEDTATRAN;
	}
	public String getOEHORTRAN() {
		return OEHORTRAN;
	}
	public void setOEHORTRAN(String oEHORTRAN) {
		OEHORTRAN = oEHORTRAN;
	}
	public String getOETIPOCONTAORIGEM() {
		return OETIPOCONTAORIGEM;
	}
	public void setOETIPOCONTAORIGEM(String oETIPOCONTAORIGEM) {
		OETIPOCONTAORIGEM = oETIPOCONTAORIGEM;
	}
	public String getOEAGENCIAORIGEMINF() {
		return OEAGENCIAORIGEMINF;
	}
	public void setOEAGENCIAORIGEMINF(String oEAGENCIAORIGEMINF) {
		OEAGENCIAORIGEMINF = oEAGENCIAORIGEMINF;
	}
	public String getOECONTAORIGEMINF() {
		return OECONTAORIGEMINF;
	}
	public void setOECONTAORIGEMINF(String oECONTAORIGEMINF) {
		OECONTAORIGEMINF = oECONTAORIGEMINF;
	}
	public String getOETIPOCONTADESTINO() {
		return OETIPOCONTADESTINO;
	}
	public void setOETIPOCONTADESTINO(String oETIPOCONTADESTINO) {
		OETIPOCONTADESTINO = oETIPOCONTADESTINO;
	}
	public String getOEAGENCIADESTINOINF() {
		return OEAGENCIADESTINOINF;
	}
	public void setOEAGENCIADESTINOINF(String oEAGENCIADESTINOINF) {
		OEAGENCIADESTINOINF = oEAGENCIADESTINOINF;
	}
	public String getOECONTADESTINOINF() {
		return OECONTADESTINOINF;
	}
	public void setOECONTADESTINOINF(String oECONTADESTINOINF) {
		OECONTADESTINOINF = oECONTADESTINOINF;
	}
	public String getNomeOrigem() {
		return nomeOrigem;
	}
	public void setNomeOrigem(String nomeOrigem) {
		this.nomeOrigem = nomeOrigem;
	}
	public BigDecimal getValorTarifa() {
		return valorTarifa;
	}
	public void setValorTarifa(BigDecimal valorTarifa) {
		this.valorTarifa = valorTarifa;
	}
	public String getNomeDestino() {
		return nomeDestino;
	}
	public void setNomeDestino(String nomeDestino) {
		this.nomeDestino = nomeDestino;
	}
	public String getDocumentoFormatado() {
		return documentoFormatado;
	}
	public void setDocumentoFormatado(String documentoFormatado) {
		this.documentoFormatado = documentoFormatado;
	}
	public String getTipoDocumento() {
		return tipoDocumento;
	}
	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}
}
