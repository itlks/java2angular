package com.altec.bsbr.app.ibe.dto.admcontratopj;

import java.io.Serializable;

public class AdmContratoPJRequestDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7679274616280036637L;
	private int nu_contrato;

	public AdmContratoPJRequestDTO(){}

	public int getNu_contrato(){
		return this.nu_contrato;
	} 

	public void setNu_contrato(int nu_contrato){
		this.nu_contrato = nu_contrato;
	}
}