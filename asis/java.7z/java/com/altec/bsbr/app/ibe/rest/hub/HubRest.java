package com.altec.bsbr.app.ibe.rest.hub;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.altec.bsbr.app.ibe.dto.hub.HubTicketRequestDTO;
import com.altec.bsbr.app.ibe.dto.hub.HubTicketResponseDTO;
import com.altec.bsbr.app.ibe.rest.hub.dto.HubAuthenticateRequestDTO;
import com.altec.bsbr.app.ibe.rest.hub.dto.HubAuthenticateResponseDTO;
import com.altec.bsbr.app.ibe.rest.hub.dto.HubRestResourceDTO;
import com.altec.bsbr.app.ibe.rest.hub.dto.HubSessionRequestDTO;
import com.altec.bsbr.app.ibe.webservice.HubTicketWebService;

@Component
public class HubRest {

	private static final String POST = "\nPOST -> ";
	private static final String STATUS = " - Status: ";

	private static final Logger LOGGER = LoggerFactory.getLogger(HubRest.class);
	
	@Autowired private HubTicketWebService hubTicketWebService;
	@Autowired private HubSessionRequestDTO hubSessionRequestDTO;
	@Autowired @Qualifier("authenticate") private HubRestResourceDTO resource;
	
	private String authorization;
	
	public <T> ResponseEntity<T> postForEntity(String url, Object request, Class<T> responseType, Object... uriVariables){
	
		return postForEntity(0, url, request, responseType, uriVariables);	

	}
	
	private <T> ResponseEntity<T> postForEntity(int count, String url, Object request, Class<T> responseType, Object... uriVariables){
		ResponseEntity<T> responseEntity = null;
		if ( count <= 1 ) {
			RestTemplate restTemplate = getRestTemplate();
			HttpEntity<Object> entity = getAuthorizationHeader(request);
			try {
				responseEntity = restTemplate.postForEntity(url, entity, responseType);
				setAuthorization(responseEntity);
				
				if (LOGGER.isInfoEnabled()) {
					StringBuilder message = new StringBuilder();
					message.append(POST).append(url).append(STATUS).append(responseEntity.getStatusCode());
					LOGGER.info(message.toString());
				}
				
			} catch (Exception e) {
				StringBuilder message = new StringBuilder();
				message.append(POST).append(url).append(STATUS).append(e.getMessage());
				LOGGER.error(message.toString(), e);
				
				ResponseEntity<HubAuthenticateResponseDTO> responseEntityAuthenticate = null;
				if ( count < 1 ){
					responseEntityAuthenticate = authenticate();
				}
				
				if ( responseEntityAuthenticate != null && responseEntityAuthenticate.getStatusCode().value() == 200 ) {
					responseEntity = postForEntity(count + 1, url, request, responseType, uriVariables);
				}
			}
		}
		return responseEntity;
	}
	
	private ResponseEntity<HubAuthenticateResponseDTO> authenticate(){
		ResponseEntity<HubAuthenticateResponseDTO> response = null;
		try {
			HubTicketResponseDTO hubTicketResponseDTO = getTicket();
			if (hubTicketResponseDTO != null) {
				HubAuthenticateRequestDTO hubAuthenticateRequestDTO = new HubAuthenticateRequestDTO();
				hubAuthenticateRequestDTO.setTicket(hubTicketResponseDTO.getTicket());
				hubAuthenticateRequestDTO.setSiglaSistema(hubTicketResponseDTO.getSistema());

				RestTemplate restTemplate = getRestTemplate();
				response = restTemplate.postForEntity(resource.getUrl(), hubAuthenticateRequestDTO,
						HubAuthenticateResponseDTO.class);
				setAuthorization(response);

				if (LOGGER.isInfoEnabled()) {
					StringBuilder message = new StringBuilder();
					message.append(POST).append(resource.getUrl()).append(STATUS)
							.append(response.getStatusCode());
					LOGGER.info(message.toString());
				}

			}
		} catch (Exception e) {
			StringBuilder message = new StringBuilder();
			message.append(POST).append(resource.getUrl()).append(STATUS).append(e.getMessage());
			LOGGER.error(message.toString(), e);
		}
		return response;
	}
	
	private HubTicketResponseDTO getTicket(){
		HubTicketResponseDTO response = null;
		try {
			HubTicketRequestDTO hubTicketRequestDTO = new HubTicketRequestDTO();
			hubTicketRequestDTO.setDados(hubSessionRequestDTO.getFields()); 			
			response = hubTicketWebService.getTicket(hubTicketRequestDTO);
			
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}
		return response;
	}
	
	private <T> void setAuthorization(ResponseEntity<T> responseEntity){
		String x_uid = responseEntity.getHeaders().get("x-uid").get(0);
		String x_access_token = responseEntity.getHeaders().get("x-access-token").get(0);
		authorization = "Bearer " + Base64.encodeBase64String( (x_uid + ":" + x_access_token).getBytes() );
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Authorization->" + authorization);
		}
	}
	
	private HttpEntity<Object> getAuthorizationHeader(Object request){
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("Authorization", authorization);
		return new HttpEntity<Object>(request,headers);
	}
	
	private RestTemplate getRestTemplate(){
		return new RestTemplate();
	}

}
