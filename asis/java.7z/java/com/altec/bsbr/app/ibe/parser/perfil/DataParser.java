package com.altec.bsbr.app.ibe.parser.perfil;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

public class DataParser {
	private String configFile;
    private Menu menu;

    public DataParser(String configFile) throws DataParserException {
        this.configFile = configFile;
        loadFiles();
    }

    protected void loadFiles() throws DataParserException {
    	menu = parse(configFile);
    }

    protected Menu parse(String configFile) throws DataParserException {
        try {
        	InputStream inputStream = getFile(configFile);
            Unmarshaller unmarshaller = createUnmarshaller();
            return (Menu) unmarshaller.unmarshal(inputStream);
        } catch (Exception ex) {
            throw new DataParserException(ex);
        }
    }
    
    private static InputStream getFile(String path) throws IOException {
        try {
            URL url = new URL(path);
            return url.openStream();
        } catch (MalformedURLException ex) {
            return DataParser.class.getResourceAsStream(path);
        }
    }
    
    private Unmarshaller createUnmarshaller() throws JAXBException {
        return JAXBContext.newInstance(Menu.class).createUnmarshaller();
    }

	public Menu getMenu() {
		return menu;
	}
}
