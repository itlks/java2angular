package com.altec.bsbr.app.ibe.dto;

public class DetalhePerfilDTO {
	
	private int idPerfil;
	private String perfil;
	private String descricaoPerfil;
	
	public DetalhePerfilDTO() {
		
	}
	
	public DetalhePerfilDTO(int id, String per, String descricaoPerfil) {
		super();
		this.idPerfil = id;
		this.perfil = per;
		this.descricaoPerfil = descricaoPerfil;
	}
	
	public DetalhePerfilDTO(String per, String descricaoPerfil) {
		super();
		this.perfil = per;
		this.descricaoPerfil = descricaoPerfil;
	}
	
	public String getDescricaoPerfil() {
		return descricaoPerfil;
	}

	public void setDescricaoPerfil(String descricaoPerfil) {
		this.descricaoPerfil = descricaoPerfil;
	}

	public int getIdPerfil() {
		return idPerfil;
	}

	public void setIdPerfil(int idPerfil) {
		this.idPerfil = idPerfil;
	}

	
	public String getPerfil() {
		return perfil;
	}
	public void setPerfil(String perfil) {
		this.perfil = perfil;
	}
	

}
