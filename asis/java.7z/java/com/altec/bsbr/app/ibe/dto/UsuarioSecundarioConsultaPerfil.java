package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

import org.apache.commons.lang.StringUtils;

import com.altec.bsbr.app.ibe.util.WSFormat;

public class UsuarioSecundarioConsultaPerfil  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6468742230846427313L;
	
	private String banco;
	private String conta;
	private String agencia;
	private String descPerfilAcesso;
	private String descPerfilAutorizacao;
	
	
	public String getBanco() {
		return banco;
	}
	public void setBanco(String banco) {
		this.banco = banco;
	}
	public String getConta() {
		return conta;
	}
	public void setConta(String conta) {
		this.conta = conta;
	}
	public String getAgencia() {
		return agencia;
	}
	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}
	public String getDescPerfilAcesso() {
		return descPerfilAcesso;
	}
	public void setDescPerfilAcesso(String descPerfilAcesso) {
		this.descPerfilAcesso = descPerfilAcesso;
	}
	public String getDescPerfilAutorizacao() {
		return descPerfilAutorizacao;
	}
	public void setDescPerfilAutorizacao(String descPerfilAutorizacao) {
		this.descPerfilAutorizacao = descPerfilAutorizacao;
	}
	public String getAgenciaConta(){
		StringBuilder sb = new StringBuilder();

		String contaFormatada = StringUtils.leftPad(conta, 9, "0");
		
		sb.append(WSFormat.formatarRetornoAgencia(agencia));
		sb.append(" ");
		sb.append(contaFormatada.substring(0, 2));
		sb.append("");
		sb.append(contaFormatada.substring(2, contaFormatada.length() - 1));
		sb.append("");
		sb.append(contaFormatada.substring(contaFormatada.length() - 1));
		
		return sb.toString();
	}
}
