package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;

public class PaginacaoDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9208942689928633733L;
	private String numProtocoloRechamada;
	private BigDecimal valorRechamada;
	private String dataRechamada;

	public String getNumProtocoloRechamada() {
		return numProtocoloRechamada;
	}

	public void setNumProtocoloRechamada(String numProtocoloRechamada) {
		this.numProtocoloRechamada = numProtocoloRechamada;
	}

	public String getDataRechamada() {
		return dataRechamada;
	}

	public void setDataRechamada(String dataRechamada) {
		this.dataRechamada = dataRechamada;
	}

	public BigDecimal getValorRechamada() {
		return valorRechamada;
	}

	public void setValorRechamada(BigDecimal valorRechamada) {
		this.valorRechamada = valorRechamada;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dataRechamada == null) ? 0 : dataRechamada.hashCode());
		result = prime * result + ((numProtocoloRechamada == null) ? 0 : numProtocoloRechamada.hashCode());
		result = prime * result + ((valorRechamada == null) ? 0 : valorRechamada.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof PaginacaoDTO)) {
			return false;
		}
		PaginacaoDTO other = (PaginacaoDTO) obj;
		if (dataRechamada == null) {
			if (other.dataRechamada != null) {
				return false;
			}
		} else if (!dataRechamada.equals(other.dataRechamada)) {
			return false;
		}
		if (numProtocoloRechamada == null) {
			if (other.numProtocoloRechamada != null) {
				return false;
			}
		} else if (!numProtocoloRechamada.equals(other.numProtocoloRechamada)) {
			return false;
		}
		if (valorRechamada == null) {
			if (other.valorRechamada != null) {
				return false;
			}
		} else if (!valorRechamada.equals(other.valorRechamada)) {
			return false;
		}
		return true;
	}

}
