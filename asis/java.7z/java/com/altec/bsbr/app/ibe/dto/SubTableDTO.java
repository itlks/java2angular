
package com.altec.bsbr.app.ibe.dto;

import java.util.List;

public class SubTableDTO {

	private String header;
	private String footer;
	private List<UsuarioSecundarioAtribuicaoConvenioDTO> list;
	private boolean render;
	private String msg;
	private boolean mostrarToggle;	
	
	public SubTableDTO(){
		// SubTable
	}
	
	
	public SubTableDTO(String header, boolean render, String msg){
		this.header = header;
		this.msg = msg;
		this.render = render;
	}
	
	public SubTableDTO(String header, List<?> list, boolean mostrarToggle){
		this.header = header;
		this.list = (List<UsuarioSecundarioAtribuicaoConvenioDTO>) list;
		this.mostrarToggle = mostrarToggle;
	}

	public SubTableDTO(String header, String footer, List<?> list){
		this.header = header;
		this.footer = footer;
		this.list = (List<UsuarioSecundarioAtribuicaoConvenioDTO>) list;
	}	
	
	public String getHeader() {
		return header;
	}
	
	public void setHeader(String header) {
		this.header = header;
	}
	
	public String getFooter() {
		return footer;
	}
	
	public void setFooter(String footer) {
		this.footer = footer;
	}
	
	public List<UsuarioSecundarioAtribuicaoConvenioDTO> getList() {
		return list;
	}
	
	public void setList(List<UsuarioSecundarioAtribuicaoConvenioDTO> list) {
		this.list = list;
	}

	public boolean isRender() {
		return render;
	}

	public void setRender(boolean render) {
		this.render = render;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}


	public boolean isMostrarToggle() {
		return mostrarToggle;
	}

	public void setMostrarToggle(boolean mostrarToggle) {
		this.mostrarToggle = mostrarToggle;
	}		
	
	public void verificarRender(){
		if(this.render){
			this.render = false;
		}
		else{
			this.render = true;
		}

	}
	
}
