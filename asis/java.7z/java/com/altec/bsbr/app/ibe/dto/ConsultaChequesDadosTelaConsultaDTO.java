package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.Date;

import com.altec.bsbr.app.ibe.enumeration.PeriodoConsultaCopiaDeChequeEnum;

public class ConsultaChequesDadosTelaConsultaDTO implements Serializable {

	private static final long serialVersionUID = -3494025158880230921L;

	private String tarifa;
	private int tipoConsulta;
	private String numeroCheque;
	private PeriodoConsultaCopiaDeChequeEnum periodoConsulta;
	private Date dataInicial;
	private Date dataFinal;
	private byte[] imagemFrente;
	private byte[] imagemVerso;
	private boolean mostraTabela = false;

	/**
	 * @return the tarifa
	 */
	public String getTarifa() {
		return tarifa;
	}

	/**
	 * @param tarifa
	 *            the tarifa to set
	 */
	public void setTarifa(String tarifa) {
		this.tarifa = tarifa;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/**
	 * @return the tipoConsulta
	 */
	public int getTipoConsulta() {
		return tipoConsulta;
	}

	/**
	 * @param tipoConsulta
	 *            the tipoConsulta to set
	 */
	public void setTipoConsulta(int tipoConsulta) {
		this.tipoConsulta = tipoConsulta;
	}

	/**
	 * @return the numeroCheque
	 */
	public String getNumeroCheque() {
		return numeroCheque;
	}

	/**
	 * @param numeroCheque
	 *            the numeroCheque to set
	 */
	public void setNumeroCheque(String numeroCheque) {
		this.numeroCheque = numeroCheque;
	}

	/**
	 * @return the periodoConsulta
	 */
	public PeriodoConsultaCopiaDeChequeEnum getPeriodoConsulta() {
		return periodoConsulta;
	}

	/**
	 * @param periodoConsulta
	 *            the periodoConsulta to set
	 */
	public void setPeriodoConsulta(PeriodoConsultaCopiaDeChequeEnum periodoConsulta) {
		this.periodoConsulta = periodoConsulta;
	}

	/**
	 * @return the dataInicial
	 */
	public Date getDataInicial() {
		return dataInicial;
	}

	/**
	 * @param dataInicial
	 *            the dataInicial to set
	 */
	public void setDataInicial(Date dataInicial) {
		this.dataInicial = dataInicial;
	}

	/**
	 * @return the dataFinal
	 */
	public Date getDataFinal() {
		return dataFinal;
	}

	/**
	 * @param dataFinal
	 *            the dataFinal to set
	 */
	public void setDataFinal(Date dataFinal) {
		this.dataFinal = dataFinal;
	}

	/**
	 * @return the imagemFrente
	 */
	public byte[] getImagemFrente() {
		return imagemFrente;
	}

	/**
	 * @param imagemFrente
	 *            the imagemFrente to set
	 */
	public void setImagemFrente(byte[] imagemFrente) {
		this.imagemFrente = imagemFrente;
	}

	/**
	 * @return the imagemVerso
	 */
	public byte[] getImagemVerso() {
		return imagemVerso;
	}

	/**
	 * @param imagemVerso
	 *            the imagemVerso to set
	 */
	public void setImagemVerso(byte[] imagemVerso) {
		this.imagemVerso = imagemVerso;
	}

	/**
	 * @return the mostraTabela
	 */
	public boolean isMostraTabela() {
		return mostraTabela;
	}

	/**
	 * @param mostraTabela the mostraTabela to set
	 */
	public void setMostraTabela(boolean mostraTabela) {
		this.mostraTabela = mostraTabela;
	}

}
