package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class ListarRecargaProgramadaHistoricoDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private Integer qtdContas;
    private Integer situProgramacao;
    private Integer codRetorno;
    private String numProtocolo;
    private BancoDTO bancoRec;
    private List<BancoDTO> contrato;
    private Date dataInicial; 
    private Date dataFim;
	/**
	 * @return the qtdContas
	 */
	public Integer getQtdContas() {
		return qtdContas;
	}
	/**
	 * @param qtdContas the qtdContas to set
	 */
	public void setQtdContas(Integer qtdContas) {
		this.qtdContas = qtdContas;
	}
	/**
	 * @return the situProgramacao
	 */
	public Integer getSituProgramacao() {
		return situProgramacao;
	}
	/**
	 * @param situProgramacao the situProgramacao to set
	 */
	public void setSituProgramacao(Integer situProgramacao) {
		this.situProgramacao = situProgramacao;
	}
	/**
	 * @return the codRetorno
	 */
	public Integer getCodRetorno() {
		return codRetorno;
	}
	/**
	 * @param codRetorno the codRetorno to set
	 */
	public void setCodRetorno(Integer codRetorno) {
		this.codRetorno = codRetorno;
	}
	/**
	 * @return the numProtocolo
	 */
	public String getNumProtocolo() {
		return numProtocolo;
	}
	/**
	 * @param numProtocolo the numProtocolo to set
	 */
	public void setNumProtocolo(String numProtocolo) {
		this.numProtocolo = numProtocolo;
	}
	/**
	 * @return the bancoRec
	 */
	public BancoDTO getBancoRec() {
		return bancoRec;
	}
	/**
	 * @param bancoRec the bancoRec to set
	 */
	public void setBancoRec(BancoDTO bancoRec) {
		this.bancoRec = bancoRec;
	}
	/**
	 * @return the contrato
	 */
	public List<BancoDTO> getContrato() {
		return contrato;
	}
	/**
	 * @param contrato the contrato to set
	 */
	public void setContrato(List<BancoDTO> contrato) {
		this.contrato = contrato;
	}
	/**
	 * @return the dataInicial
	 */
	public Date getDataInicial() {
		return dataInicial;
	}
	/**
	 * @param dataInicial the dataInicial to set
	 */
	public void setDataInicial(Date dataInicial) {
		this.dataInicial = dataInicial;
	}
	/**
	 * @return the dataFim
	 */
	public Date getDataFim() {
		return dataFim;
	}
	/**
	 * @param dataFim the dataFim to set
	 */
	public void setDataFim(Date dataFim) {
		this.dataFim = dataFim;
	} 
    
    
    
    
}
