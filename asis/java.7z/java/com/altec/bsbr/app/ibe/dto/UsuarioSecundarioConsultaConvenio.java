package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class UsuarioSecundarioConsultaConvenio implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8883086274149391542L;

	private String nomeConvenio;
	private String perfilAcesso;
	private String perfilAutorizacao;
	
	private Boolean possuiAcesso;
	private Boolean possuiAutorizacao;
	
	public String getNomeConvenio() {
		return nomeConvenio;
	}
	public void setNomeConvenio(String nomeConvenio) {
		this.nomeConvenio = nomeConvenio;
	}
	public String getPerfilAcesso() {
		return perfilAcesso;
	}
	public void setPerfilAcesso(String perfilAcesso) {
		this.perfilAcesso = perfilAcesso;
	}
	public String getPerfilAutorizacao() {
		return perfilAutorizacao;
	}
	public void setPerfilAutorizacao(String perfilAutorizacao) {
		this.perfilAutorizacao = perfilAutorizacao;
	}
	public Boolean getPossuiAcesso() {
		return possuiAcesso;
	}
	public void setPossuiAcesso(Boolean possuiAcesso) {
		this.possuiAcesso = possuiAcesso;
	}
	public Boolean getPossuiAutorizacao() {
		return possuiAutorizacao;
	}
	public void setPossuiAutorizacao(Boolean possuiAutorizacao) {
		this.possuiAutorizacao = possuiAutorizacao;
	}
}
