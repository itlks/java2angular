package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.Date;

public class AgendamentoDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8888050354825385862L;
	private String dataInicialFormatada;
	private String dataFinalFormatada;
	private String situacao;
	private int canal;
	private Integer tipoOperacao;
	private String tipoGrupoOperacao;
	private Date dataHoraTransacao;
	private String autenticacaoBancaria;
	private String codigoNSU;
	private Integer tipoConsulta;
	private Integer sequenciaPaginacao;
	private Integer numeroPagina;

	// lista agendamento
	private ListaAgendamentoResponseDTO listaAgendamentoDTO;
	
	// agendamento selecionado
	private ListaAgendamentoDTO agendamentoSelecionado;

	// detalhe agendamento
	private DetalheAgendamentosDTO detalheAgendamentosDTO;

	public Date getDataHoraTransacao() {
		return dataHoraTransacao;
	}

	public void setDataHoraTransacao(Date dataHoraTransacao) {
		this.dataHoraTransacao = dataHoraTransacao;
	}

	public String getAutenticacaoBancaria() {
		return autenticacaoBancaria;
	}

	public void setAutenticacaoBancaria(String autenticacaoBancaria) {
		this.autenticacaoBancaria = autenticacaoBancaria;
	}

	public String getCodigoNSU() {
		return codigoNSU;
	}

	public void setCodigoNSU(String codigoNSU) {
		this.codigoNSU = codigoNSU;
	}

	public DetalheAgendamentosDTO getDetalheAgendamentosDTO() {
		return detalheAgendamentosDTO;
	}

	public void setDetalheAgendamentosDTO(DetalheAgendamentosDTO detalheAgendamentosDTO) {
		this.detalheAgendamentosDTO = detalheAgendamentosDTO;
	}

	public String getSituacao() {
		return situacao;
	}

	public void setSituacao(String situacao) {
		this.situacao = situacao;
	}

	public Integer getTipoOperacao() {
		return tipoOperacao;
	}

	public void setTipoOperacao(Integer tipoOperacao) {
		this.tipoOperacao = tipoOperacao;
	}

	public String getDataInicialFormatada() {
		return dataInicialFormatada;
	}

	public void setDataInicialFormatada(String dataInicialFormatada) {
		this.dataInicialFormatada = dataInicialFormatada;
	}

	public String getDataFinalFormatada() {
		return dataFinalFormatada;
	}

	public void setDataFinalFormatada(String dataFinalFormatada) {
		this.dataFinalFormatada = dataFinalFormatada;
	}

	public String getTipoGrupoOperacao() {
		return tipoGrupoOperacao;
	}

	public void setTipoGrupoOperacao(String tipoGrupoOperacao) {
		this.tipoGrupoOperacao = tipoGrupoOperacao;
	}

	public int getCanal() {
		return canal;
	}

	public void setCanal(int canal) {
		this.canal = canal;
	}

	public ListaAgendamentoResponseDTO getListaAgendamentoDTO() {
		return listaAgendamentoDTO;
	}

	public void setListaAgendamentoDTO(ListaAgendamentoResponseDTO listaAgendamentoDTO) {
		this.listaAgendamentoDTO = listaAgendamentoDTO;
	}

	public Integer getTipoConsulta() {
		return tipoConsulta;
	}

	public void setTipoConsulta(Integer tipoConsulta) {
		this.tipoConsulta = tipoConsulta;
	}

	public Integer getSequenciaPaginacao() {
		return sequenciaPaginacao;
	}

	public void setSequenciaPaginacao(Integer sequenciaPaginacao) {
		this.sequenciaPaginacao = sequenciaPaginacao;
	}

	public Integer getNumeroPagina() {
		return numeroPagina;
	}

	public void setNumeroPagina(Integer numeroPagina) {
		this.numeroPagina = numeroPagina;
	}

	public ListaAgendamentoDTO getAgendamentoSelecionado() {
		return agendamentoSelecionado;
	}

	public void setAgendamentoSelecionado(ListaAgendamentoDTO agendamentoSelecionado) {
		this.agendamentoSelecionado = agendamentoSelecionado;
	}

}
