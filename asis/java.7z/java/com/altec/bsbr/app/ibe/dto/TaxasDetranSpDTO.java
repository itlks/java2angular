package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.Collections;
import java.util.List;

import javax.faces.model.SelectItem;

import com.altec.bsbr.app.ibe.anotation.Hash;
import com.altec.bsbr.app.ibe.dto.consultaVeiculos.ConsultaSubServicosResponseDTO;

public class TaxasDetranSpDTO implements Serializable {

	private static final long serialVersionUID = 5334654545281972759L;

	private TaxasDetranSpSubServicosDTO subServicosDTO = new TaxasDetranSpSubServicosDTO();
	private List<DetranTipoDeSubservicoDTO> tiposSubServico = Collections.emptyList();

	private List<TaxasDetranSpDadosComprovanteDTO> listaDadosComprovante;
	private ConsultaSubServicosResponseDTO subServicoSelecionado;
	private DetranTipoDeSubservicoDTO tipoSubServicoSelecionado;
	
	private List<SelectItem> listaDeTiposDeSubServico = Collections.emptyList();
	
	@Hash(position = 1)
	private String identificador = "";
	
	private boolean tipoSubServicoVisible = false;
	private boolean tipoSubServicoValorVisible = false;
	private boolean botaoContinuarVisible = false;
	
	private String paginaPreenchimento;
	private String tipoEnvio;
	
	public String getIdentificador(){
		return identificador;
	}

	public void setIdentificador(String identificador) {
		this.identificador = identificador;
	}

	public List<DetranTipoDeSubservicoDTO> getTiposSubServico() {
		return tiposSubServico;
	}

	public void setTiposSubServico(List<DetranTipoDeSubservicoDTO> tiposSubServico) {
		this.tiposSubServico = tiposSubServico;
	}

	public DetranTipoDeSubservicoDTO getTipoSubServicoSelecionado() {
		return tipoSubServicoSelecionado;
	}

	public void setTipoSubServicoSelecionado(DetranTipoDeSubservicoDTO tipoSubServicoSelecionado) {
		this.tipoSubServicoSelecionado = tipoSubServicoSelecionado;
	}

	public TaxasDetranSpSubServicosDTO getSubServicosDTO() {
		return subServicosDTO;
	}

	public void setSubServicosDTO(TaxasDetranSpSubServicosDTO subServicosDTO) {
		this.subServicosDTO = subServicosDTO;
	}

	public List<TaxasDetranSpDadosComprovanteDTO> getListaDadosComprovante() {
		return listaDadosComprovante;
	}

	public void setListaDadosComprovante(List<TaxasDetranSpDadosComprovanteDTO> listaDadosComprovante) {
		this.listaDadosComprovante = listaDadosComprovante;
	}

	public ConsultaSubServicosResponseDTO getSubServicoSelecionado() {
		return subServicoSelecionado;
	}

	public void setSubServicoSelecionado(ConsultaSubServicosResponseDTO subServicoSelecionado) {
		this.subServicoSelecionado = subServicoSelecionado;
	}

	public Boolean getTipoSubServicoVisible() {
		return tipoSubServicoVisible;
	}

	public void setTipoSubServicoVisible(boolean tipoSubServicoVisible) {
		this.tipoSubServicoVisible = tipoSubServicoVisible;
	}

	public boolean isTipoSubServicoValorVisible() {
		return tipoSubServicoValorVisible;
	}

	public void setTipoSubServicoValorVisible(boolean tipoSubServicoValorVisible) {
		this.tipoSubServicoValorVisible = tipoSubServicoValorVisible;
	}

	public List<SelectItem> getListaDeTiposDeSubServico() {
		return listaDeTiposDeSubServico;
	}

	public void setListaDeTiposDeSubServico(List<SelectItem> listaDeTiposDeSubServico) {
		this.listaDeTiposDeSubServico = listaDeTiposDeSubServico;
	}

	public boolean isBotaoContinuarVisible() {
		return botaoContinuarVisible;
	}

	public void setBotaoContinuarVisible(boolean botaoContinuarVisible) {
		this.botaoContinuarVisible = botaoContinuarVisible;
	}

	public String getPaginaPreenchimento() {
		return paginaPreenchimento;
	}

	public void setPaginaPreenchimento(String paginaPreenchimento) {
		this.paginaPreenchimento = paginaPreenchimento;
	}

	public String getTipoEnvio() {
		return tipoEnvio;
	}

	public void setTipoEnvio(String tipoEnvio) {
		this.tipoEnvio = tipoEnvio;
	}

}
