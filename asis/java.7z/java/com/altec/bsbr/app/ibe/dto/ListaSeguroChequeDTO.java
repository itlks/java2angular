package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;


public class ListaSeguroChequeDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6864539151004438221L;


}
