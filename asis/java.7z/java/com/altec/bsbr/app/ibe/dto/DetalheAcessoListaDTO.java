package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class DetalheAcessoListaDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String codigoUsuarioInclusao;

	private String nomePerfilAcesso;
	
	private String descPerfilAcesso;
	
	private Integer ordemMenu; 
	
	private String  idItemMenu;
	
	private String idMenuItemPrincipal;
	
	private String numeroItemMenu;
	
	public DetalheAcessoListaDTO() {}
	
	/**
	 * @return the codigoUsuarioInclusao
	 */
	public String getCodigoUsuarioInclusao() {
		return codigoUsuarioInclusao;
	}

	/**
	 * @param codigoUsuarioInclusao the codigoUsuarioInclusao to set
	 */
	public void setCodigoUsuarioInclusao(String codigoUsuarioInclusao) {
		this.codigoUsuarioInclusao = codigoUsuarioInclusao;
	}

	/**
	 * @return the nomePerfilAcesso
	 */
	public String getNomePerfilAcesso() {
		return nomePerfilAcesso;
	}

	/**
	 * @param nomePerfilAcesso the nomePerfilAcesso to set
	 */
	public void setNomePerfilAcesso(String nomePerfilAcesso) {
		this.nomePerfilAcesso = nomePerfilAcesso;
	}

	/**
	 * @return the descPerfilAcesso
	 */
	public String getDescPerfilAcesso() {
		return descPerfilAcesso;
	}

	/**
	 * @param descPerfilAcesso the descPerfilAcesso to set
	 */
	public void setDescPerfilAcesso(String descPerfilAcesso) {
		this.descPerfilAcesso = descPerfilAcesso;
	}

	/**
	 * @return the ordemMenu
	 */
	public Integer getOrdemMenu() {
		return ordemMenu;
	}

	/**
	 * @param ordemMenu the ordemMenu to set
	 */
	public void setOrdemMenu(Integer ordemMenu) {
		this.ordemMenu = ordemMenu;
	}

	/**
	 * @return the idItemMenu
	 */
	public String getIdItemMenu() {
		return idItemMenu;
	}

	/**
	 * @param idItemMenu the idItemMenu to set
	 */
	public void setIdItemMenu(String idItemMenu) {
		this.idItemMenu = idItemMenu;
	}

	/**
	 * @return the idMenuItemPrincipal
	 */
	public String getIdMenuItemPrincipal() {
		return idMenuItemPrincipal;
	}

	/**
	 * @param idMenuItemPrincipal the idMenuItemPrincipal to set
	 */
	public void setIdMenuItemPrincipal(String idMenuItemPrincipal) {
		this.idMenuItemPrincipal = idMenuItemPrincipal;
	}

	/**
	 * @return the numeroItemMenu
	 */
	public String getNumeroItemMenu() {
		return numeroItemMenu;
	}

	/**
	 * @param numeroItemMenu the numeroItemMenu to set
	 */
	public void setNumeroItemMenu(String numeroItemMenu) {
		this.numeroItemMenu = numeroItemMenu;
	}
		

}
