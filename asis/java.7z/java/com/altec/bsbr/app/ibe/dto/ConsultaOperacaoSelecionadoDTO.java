package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

import com.altec.bsbr.app.ibe.dto.clsrecebiveisantec.ListaOperacoesRSDTO;

public class ConsultaOperacaoSelecionadoDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3442914600972966055L;

	private java.lang.String TSOEMBNROPER;
	private java.lang.String TSOEMBDTOPER;
	private java.lang.String TSOEMBVLOPER;


	public ConsultaOperacaoSelecionadoDTO(){
		
	}
	
	/**
     * Gets the value of the TSOEMBNROPER property.
     * 
     * @param TSOEMBNROPER
     *     allowed object is
     *     {@link java.lang.String }{@code <}{@link java.lang.String }{@code >}
     *     
     */
	public java.lang.String getTSOEMBNROPER() {
		return this.TSOEMBNROPER;
	}

	/**
     * Sets the value of the TSOEMBNROPER property.
     * 
     * @param TSOEMBNROPER
     *     allowed object is
     *     {@link java.lang.String }{@code <}{@link java.lang.String }{@code >}
     *     
     */
	public void setTSOEMBNROPER( java.lang.String TSOEMBNROPER ) {
		this.TSOEMBNROPER = TSOEMBNROPER;
	}

	/**
     * Gets the value of the TSOEMBDTOPER property.
     * 
     * @param TSOEMBDTOPER
     *     allowed object is
     *     {@link java.lang.String }{@code <}{@link java.lang.String }{@code >}
     *     
     */
	public java.lang.String getTSOEMBDTOPER() {
		return this.TSOEMBDTOPER;
	}

	/**
     * Sets the value of the TSOEMBDTOPER property.
     * 
     * @param TSOEMBDTOPER
     *     allowed object is
     *     {@link java.lang.String }{@code <}{@link java.lang.String }{@code >}
     *     
     */
	public void setTSOEMBDTOPER( java.lang.String TSOEMBDTOPER ) {
		this.TSOEMBDTOPER = TSOEMBDTOPER;
	}

	/**
     * Gets the value of the TSOEMBVLOPER property.
     * 
     * @param TSOEMBVLOPER
     *     allowed object is
     *     {@link java.lang.String }{@code <}{@link java.lang.String }{@code >}
     *     
     */
	public java.lang.String getTSOEMBVLOPER() {
		return this.TSOEMBVLOPER;
	}

	/**
     * Sets the value of the TSOEMBVLOPER property.
     * 
     * @param TSOEMBVLOPER
     *     allowed object is
     *     {@link java.lang.String }{@code <}{@link java.lang.String }{@code >}
     *     
     */
	public void setTSOEMBVLOPER( java.lang.String TSOEMBVLOPER ) {
		this.TSOEMBVLOPER = TSOEMBVLOPER;
	}


	/**
     * Fluent API
     * 
     * @param TSOEMBNROPER
     *     allowed object is
     *     {@link java.lang.String }{@code <}{@link java.lang.String }{@code >}
     *     
     */
	public ConsultaOperacaoSelecionadoDTO withTSOEMBNROPER( java.lang.String TSOEMBNROPER ) {
		this.TSOEMBNROPER = TSOEMBNROPER;
		return this;
	}

	/**
     * Fluent API
     * 
     * @param TSOEMBDTOPER
     *     allowed object is
     *     {@link java.lang.String }{@code <}{@link java.lang.String }{@code >}
     *     
     */
	public ConsultaOperacaoSelecionadoDTO withTSOEMBDTOPER( java.lang.String TSOEMBDTOPER ) {
		this.TSOEMBDTOPER = TSOEMBDTOPER;
		return this;
	}

	/**
     * Fluent API
     * 
     * @param TSOEMBVLOPER
     *     allowed object is
     *     {@link java.lang.String }{@code <}{@link java.lang.String }{@code >}
     *     
     */
	public ConsultaOperacaoSelecionadoDTO withTSOEMBVLOPER( java.lang.String TSOEMBVLOPER ) {
		this.TSOEMBVLOPER = TSOEMBVLOPER;
		return this;
	}
	
}
