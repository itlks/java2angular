package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.Date;

public class AutorizacoesHistoricoConsultaDTO implements Serializable {

  private static final long serialVersionUID = -628821440441845155L;

  private String tipo;
  private String canal;
  private String status;
  private String contrato;
  private String convenio;
  private String contaDebito;
  private String codigoGrupo;
  private String codigoProduto;
  private Date dataInicio;
  private Date dataFim;
  private Date dataPagamento;
  
  public AutorizacoesHistoricoConsultaDTO() {
    // Constructor
  }

  public String getTipo() {
    return tipo;
  }

  public void setTipo(String tipo) {
    this.tipo = tipo;
  }

  public String getCanal() {
    return canal;
  }

  public void setCanal(String canal) {
    this.canal = canal;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public String getContrato() {
    return contrato;
  }

  public void setContrato(String contrato) {
    this.contrato = contrato;
  }

  public String getConvenio() {
    return convenio;
  }

  public void setConvenio(String convenio) {
    this.convenio = convenio;
  }

  public String getContaDebito() {
    return contaDebito;
  }

  public void setContaDebito(String contaDebito) {
    this.contaDebito = contaDebito;
  }

  public Date getDataInicio() {
    return dataInicio;
  }

  public void setDataInicio(Date dataInicio) {
    this.dataInicio = dataInicio;
  }

  public Date getDataFim() {
    return dataFim;
  }

  public void setDataFim(Date dataFim) {
    this.dataFim = dataFim;
  }

  public Date getDataPagamento() {
    return dataPagamento;
  }

  public void setDataPagamento(Date dataPagamento) {
    this.dataPagamento = dataPagamento;
  }

  public String getCodigoGrupo() {
    return codigoGrupo;
  }

  public void setCodigoGrupo(String codigoGrupo) {
    this.codigoGrupo = codigoGrupo;
  }

  public String getCodigoProduto() {
    return codigoProduto;
  }

  public void setCodigoProduto(String codigoProduto) {
    this.codigoProduto = codigoProduto;
  }
}
