package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;

public class DetalheUsuarioAlteracaoListaDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String codigoUsuarioInclusao;

	private String nomePerfilAutorizacao;
	
	private String descPerfilAutorizacao;
	
	private Integer nrSeqGrupoServ;
	
	private String nomeGrupoServ;
	
	private Integer tipoTransacao;
	
	private Integer numeroSeqTransacao;
	
	private String nomeTransacao;
	
	private Integer codigoConvenio;
	
	private Integer codigoContaDebito;
	
	private Integer quantidadeAssinatura;
	
	private BigDecimal valorAlcada;
	
	private BigDecimal valroLimiteDiario;
	
	public DetalheUsuarioAlteracaoListaDTO() {}
	
	/**
	 * @return the codigoUsuarioInclusao
	 */
	public String getCodigoUsuarioInclusao() {
		return codigoUsuarioInclusao;
	}

	/**
	 * @param codigoUsuarioInclusao the codigoUsuarioInclusao to set
	 */
	public void setCodigoUsuarioInclusao(String codigoUsuarioInclusao) {
		this.codigoUsuarioInclusao = codigoUsuarioInclusao;
	}

	/**
	 * @return the nomePerfilAutorizacao
	 */
	public String getNomePerfilAutorizacao() {
		return nomePerfilAutorizacao;
	}

	/**
	 * @param nomePerfilAutorizacao the nomePerfilAutorizacao to set
	 */
	public void setNomePerfilAutorizacao(String nomePerfilAutorizacao) {
		this.nomePerfilAutorizacao = nomePerfilAutorizacao;
	}

	/**
	 * @return the descPerfilAutorizacao
	 */
	public String getDescPerfilAutorizacao() {
		return descPerfilAutorizacao;
	}

	/**
	 * @param descPerfilAutorizacao the descPerfilAutorizacao to set
	 */
	public void setDescPerfilAutorizacao(String descPerfilAutorizacao) {
		this.descPerfilAutorizacao = descPerfilAutorizacao;
	}

	/**
	 * @return the nrSeqGrupoServ
	 */
	public Integer getNrSeqGrupoServ() {
		return nrSeqGrupoServ;
	}

	/**
	 * @param nrSeqGrupoServ the nrSeqGrupoServ to set
	 */
	public void setNrSeqGrupoServ(Integer nrSeqGrupoServ) {
		this.nrSeqGrupoServ = nrSeqGrupoServ;
	}

	/**
	 * @return the nomeGrupoServ
	 */
	public String getNomeGrupoServ() {
		return nomeGrupoServ;
	}

	/**
	 * @param nomeGrupoServ the nomeGrupoServ to set
	 */
	public void setNomeGrupoServ(String nomeGrupoServ) {
		this.nomeGrupoServ = nomeGrupoServ;
	}

	/**
	 * @return the tipoTransacao
	 */
	public Integer getTipoTransacao() {
		return tipoTransacao;
	}

	/**
	 * @param tipoTransacao the tipoTransacao to set
	 */
	public void setTipoTransacao(Integer tipoTransacao) {
		this.tipoTransacao = tipoTransacao;
	}

	/**
	 * @return the numeroSeqTransacao
	 */
	public Integer getNumeroSeqTransacao() {
		return numeroSeqTransacao;
	}

	/**
	 * @param numeroSeqTransacao the numeroSeqTransacao to set
	 */
	public void setNumeroSeqTransacao(Integer numeroSeqTransacao) {
		this.numeroSeqTransacao = numeroSeqTransacao;
	}

	/**
	 * @return the nomeTransacao
	 */
	public String getNomeTransacao() {
		return nomeTransacao;
	}

	/**
	 * @param nomeTransacao the nomeTransacao to set
	 */
	public void setNomeTransacao(String nomeTransacao) {
		this.nomeTransacao = nomeTransacao;
	}

	/**
	 * @return the codigoConvenio
	 */
	public Integer getCodigoConvenio() {
		return codigoConvenio;
	}

	/**
	 * @param codigoConvenio the codigoConvenio to set
	 */
	public void setCodigoConvenio(Integer codigoConvenio) {
		this.codigoConvenio = codigoConvenio;
	}

	/**
	 * @return the codigoContaDebito
	 */
	public Integer getCodigoContaDebito() {
		return codigoContaDebito;
	}

	/**
	 * @param codigoContaDebito the codigoContaDebito to set
	 */
	public void setCodigoContaDebito(Integer codigoContaDebito) {
		this.codigoContaDebito = codigoContaDebito;
	}

	/**
	 * @return the quantidadeAssinatura
	 */
	public Integer getQuantidadeAssinatura() {
		return quantidadeAssinatura;
	}

	/**
	 * @param quantidadeAssinatura the quantidadeAssinatura to set
	 */
	public void setQuantidadeAssinatura(Integer quantidadeAssinatura) {
		this.quantidadeAssinatura = quantidadeAssinatura;
	}

	/**
	 * @return the valorAlcada
	 */
	public BigDecimal getValorAlcada() {
		return valorAlcada;
	}

	/**
	 * @param valorAlcada the valorAlcada to set
	 */
	public void setValorAlcada(BigDecimal valorAlcada) {
		this.valorAlcada = valorAlcada;
	}

	/**
	 * @return the valroLimiteDiario
	 */
	public BigDecimal getValroLimiteDiario() {
		return valroLimiteDiario;
	}

	/**
	 * @param valroLimiteDiario the valroLimiteDiario to set
	 */
	public void setValroLimiteDiario(BigDecimal valroLimiteDiario) {
		this.valroLimiteDiario = valroLimiteDiario;
	}
			

}
