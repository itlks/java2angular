package com.altec.bsbr.app.ibe.parser.perfil;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="root")
@XmlAccessorType(XmlAccessType.FIELD)
public class Menu {
    @XmlElement(name="itemMenu")
    private List<ItemMenu> itensMenu;

	public List<ItemMenu> getItensMenu() {
		return itensMenu;
	}

	public void setItensMenu(List<ItemMenu> itensMenu) {
		this.itensMenu = itensMenu;
	}
}
