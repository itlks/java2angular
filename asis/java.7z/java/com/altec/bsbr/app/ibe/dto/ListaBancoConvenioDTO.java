package com.altec.bsbr.app.ibe.dto;

import java.util.ArrayList;

public class ListaBancoConvenioDTO {

	private ArrayList<ItemListaBancoConvenioDTO> listaBancoConv = new ArrayList<ItemListaBancoConvenioDTO>();

	/**
	 * @return the listaBancoConv
	 */
	public ArrayList<ItemListaBancoConvenioDTO> getListaBancoConv() {
		return listaBancoConv;
	}

	/**
	 * @param listaBancoConv the listaBancoConv to set
	 */
	public void setListaBancoConv(ArrayList<ItemListaBancoConvenioDTO> listaBancoConv) {
		this.listaBancoConv = listaBancoConv;
	}
}
