package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.altec.bsbr.app.ibe.enumeration.CanalAgendamentoEnum;
import com.altec.bsbr.app.ibe.enumeration.ConcessionariaAgendamentoEnum;
import com.altec.bsbr.app.ibe.enumeration.FinalidadesAgendamentoEnum;
import com.altec.bsbr.app.ibe.enumeration.FinalidadesDocAgendamentoEnum;
import com.altec.bsbr.app.ibe.enumeration.SituacaoAgendamentoEnum;
import com.altec.bsbr.app.ibe.enumeration.TipoContaAgendamentoEnum;
import com.altec.bsbr.app.ibe.enumeration.TipoCotaOuParcelaMGAgendamentoEnum;
import com.altec.bsbr.app.ibe.enumeration.TipoOperacaoAgendamentoEnum;

public class DetalheAgendamentosDTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 634349972763054289L;
	private String nomePagina;
	private String titulo;
	private String transacao;
	private SituacaoAgendamentoEnum situacaoAgendamento;
	private CanalAgendamentoEnum canalAgendamento;
	private Date dataSolicitacao;
	private String protocolo;
	private String tipoPessoa;
	private TipoOperacaoAgendamentoEnum tipoOperacaoAgendamento;
	private Date dataAgendamento;
	private BigDecimal valorAgendamento;
	private Integer tipoAgendamento;
	private Date dataExecucao;
	private Date dataVencimentoTitulo;
	private String tipoDOC;
	private String tipoTED;
	private String numeroContratoCDB;
	private BigDecimal valorTaxaCDB;
	private Integer prazoCDB;
	private String nomeDistribuidor;
	private String numeroNotaFiscal;
	private String codigoGetNet;
	private String contaCorrenteDebito;
	private String contaCorrenteCredito;
	private String contaPoupancaDebito;
	private String contaPoupancaCredito;
	private String contaFundo;
	private String tipoContaDebito;
	private String tipoContaCredito;
	private String usrPrvAgendamento;
	private Integer codigoGruFco;
	private Integer codigoBcoOri;
	private String contaCorrenteSolicitada;
	private String tipoUor;
	private String codigoUor;
	private String codigoUsrCcm;
	private String codigoRtn;
	private String msgRtn;
	private String fgCbnCpm;
	private String dcmEmiExt;
	private String hstLncExt;
	private String chaveDh;
	private String codigoRetorno;
	private String contaCorrenteAnt;
	private String dataDepara;
	private String codigoProdutoAlt;
	private ConcessionariaAgendamentoEnum concessionaria;
	private FinalidadesAgendamentoEnum finalidadeDOC;
	private FinalidadesDocAgendamentoEnum finalidadeTED;
	private TipoContaAgendamentoEnum tipoConta;
	private TipoCotaOuParcelaMGAgendamentoEnum cotaParcela;
	private String numeroDocumento;
	private String contaCorrenteDev;
	private String nomeProprietario;
	private String cotaIPVA;
	private String tipoCcsn;
	private String codigoCcsn;
	private String codigoBarra;
	private String renavam;
	private String tipoCapCdbr;
	private String numCartaoCredito;
	private String situacaoContrato;
	private String vinculo;
	private String tipo;
	private String bancoDestino;
	private String agenciaDestino;
	private String contaDestino;
	private String favorecido;
	private String prefeitura;
	private String nomeContribuinteGPS;
	private String codigoPagamentoGPS;
	private String competenciaGPS;
	private String identificadorGPS;
	private String fornecedor;
	private String pos;
	private String nomeOperadora;
	private String numeroTelefone;
	private String anoExercicioIPVA;
	private String codigoMunicipio;
	private String placaVeiculo;
	private String nossoNumero;
	private String instituicaoFinanceira;
	private String codigoISPB;
	private String nomeBeneficiarioOriginal;
	private String documentoBeneficiarioOriginal;
	private Long numeroDocumentoBeneficiarioOriginal;
	private Long numeroDocumentoPagadorOriginal;
	private Long numeroDocumentoPagadorEfetivo;
	private Long numeroDocumentoSacadorAvalista;
	private String tipoPessoaBeneficiarioOriginal;
	private String nomePagadorOriginal;
	private String documentoPagadorOriginal;
	private String tipoPessoaPagadorOriginal;
	private String nomePagadorEfetivo;
	private String documentoPagadorEfetivo;
	private String tipoPessoaPagadorEfetivo;
	private String nomeSacadorAvalista;
	private String documentoSacadorAvalista;
	private String tipoPessoaSacadorAvalista;
	private BigDecimal valorNominal;
	private BigDecimal valorEncargos;
	private BigDecimal valorDesconto;
	private BigDecimal valorPago;
	private BigDecimal valorINSSGPS;
	private BigDecimal valorOutrasEntidadesGPS;
	private BigDecimal valorMultasJurosGPS;
	private BigDecimal valorTotalGPS;
	private String historico;
	private Integer quantidadeCampos;
	private String retCode;
	private String erro;
	private String erroTecnica;
	private String erroMqs;
	private boolean exibeMsgBoletoBancario;
	
	public Date getDataSolicitacao() {
		return dataSolicitacao;
	}
	public void setDataSolicitacao(Date dataSolicitacao) {
		this.dataSolicitacao = dataSolicitacao;
	}
	public String getProtocolo() {
		return protocolo;
	}
	public void setProtocolo(String protocolo) {
		this.protocolo = protocolo;
	}
	public Date getDataAgendamento() {
		return dataAgendamento;
	}
	public void setDataAgendamento(Date dataAgendamento) {
		this.dataAgendamento = dataAgendamento;
	}
	public BigDecimal getValorAgendamento() {
		return valorAgendamento;
	}
	public void setValorAgendamento(BigDecimal valorAgendamento) {
		this.valorAgendamento = valorAgendamento;
	}
	public Integer getTipoAgendamento() {
		return tipoAgendamento;
	}
	public void setTipoAgendamento(Integer tipoAgendamento) {
		this.tipoAgendamento = tipoAgendamento;
	}
	public Date getDataExecucao() {
		return dataExecucao;
	}
	public void setDataExecucao(Date dataExecucao) {
		this.dataExecucao = dataExecucao;
	}
	public String getTipoDOC() {
		return tipoDOC;
	}
	public void setTipoDOC(String tipoDOC) {
		this.tipoDOC = tipoDOC;
	}
	public BigDecimal getValorTaxaCDB() {
		return valorTaxaCDB;
	}
	public void setValorTaxaCDB(BigDecimal valorTaxaCDB) {
		this.valorTaxaCDB = valorTaxaCDB;
	}
	public String getNomeDistribuidor() {
		return nomeDistribuidor;
	}
	public void setNomeDistribuidor(String nomeDistribuidor) {
		this.nomeDistribuidor = nomeDistribuidor;
	}
	public String getNumeroNotaFiscal() {
		return numeroNotaFiscal;
	}
	public void setNumeroNotaFiscal(String numeroNotaFiscal) {
		this.numeroNotaFiscal = numeroNotaFiscal;
	}
	public String getCodigoGetNet() {
		return codigoGetNet;
	}
	public void setCodigoGetNet(String codigoGetNet) {
		this.codigoGetNet = codigoGetNet;
	}
	public String getContaCorrenteDebito() {
		return contaCorrenteDebito;
	}
	public void setContaCorrenteDebito(String contaCorrenteDebito) {
		this.contaCorrenteDebito = contaCorrenteDebito;
	}
	public String getContaCorrenteCredito() {
		return contaCorrenteCredito;
	}
	public void setContaCorrenteCredito(String contaCorrenteCredito) {
		this.contaCorrenteCredito = contaCorrenteCredito;
	}
	public String getTipoContaDebito() {
		return tipoContaDebito;
	}
	public void setTipoContaDebito(String tipoContaDebito) {
		this.tipoContaDebito = tipoContaDebito;
	}
	public String getTipoContaCredito() {
		return tipoContaCredito;
	}
	public void setTipoContaCredito(String tipoContaCredito) {
		this.tipoContaCredito = tipoContaCredito;
	}
	public String getUsrPrvAgendamento() {
		return usrPrvAgendamento;
	}
	public void setUsrPrvAgendamento(String usrPrvAgendamento) {
		this.usrPrvAgendamento = usrPrvAgendamento;
	}
	public Integer getCodigoGruFco() {
		return codigoGruFco;
	}
	public void setCodigoGruFco(Integer codigoGruFco) {
		this.codigoGruFco = codigoGruFco;
	}
	public Integer getCodigoBcoOri() {
		return codigoBcoOri;
	}
	public void setCodigoBcoOri(Integer codigoBcoOri) {
		this.codigoBcoOri = codigoBcoOri;
	}
	public String getContaCorrenteSolicitada() {
		return contaCorrenteSolicitada;
	}
	public void setContaCorrenteSolicitada(String contaCorrenteSolicitada) {
		this.contaCorrenteSolicitada = contaCorrenteSolicitada;
	}
	public String getTipoUor() {
		return tipoUor;
	}
	public void setTipoUor(String tipoUor) {
		this.tipoUor = tipoUor;
	}
	public String getCodigoUor() {
		return codigoUor;
	}
	public void setCodigoUor(String codigoUor) {
		this.codigoUor = codigoUor;
	}
	public String getCodigoUsrCcm() {
		return codigoUsrCcm;
	}
	public void setCodigoUsrCcm(String codigoUsrCcm) {
		this.codigoUsrCcm = codigoUsrCcm;
	}
	public String getCodigoRtn() {
		return codigoRtn;
	}
	public void setCodigoRtn(String codigoRtn) {
		this.codigoRtn = codigoRtn;
	}
	public String getMsgRtn() {
		return msgRtn;
	}
	public void setMsgRtn(String msgRtn) {
		this.msgRtn = msgRtn;
	}
	public String getFgCbnCpm() {
		return fgCbnCpm;
	}
	public void setFgCbnCpm(String fgCbnCpm) {
		this.fgCbnCpm = fgCbnCpm;
	}
	public String getDcmEmiExt() {
		return dcmEmiExt;
	}
	public void setDcmEmiExt(String dcmEmiExt) {
		this.dcmEmiExt = dcmEmiExt;
	}
	public String getHstLncExt() {
		return hstLncExt;
	}
	public void setHstLncExt(String hstLncExt) {
		this.hstLncExt = hstLncExt;
	}
	public String getChaveDh() {
		return chaveDh;
	}
	public void setChaveDh(String chaveDh) {
		this.chaveDh = chaveDh;
	}
	public String getCodigoRetorno() {
		return codigoRetorno;
	}
	public void setCodigoRetorno(String codigoRetorno) {
		this.codigoRetorno = codigoRetorno;
	}
	public String getContaCorrenteAnt() {
		return contaCorrenteAnt;
	}
	public void setContaCorrenteAnt(String contaCorrenteAnt) {
		this.contaCorrenteAnt = contaCorrenteAnt;
	}
	public String getDataDepara() {
		return dataDepara;
	}
	public void setDataDepara(String dataDepara) {
		this.dataDepara = dataDepara;
	}
	public String getCodigoProdutoAlt() {
		return codigoProdutoAlt;
	}
	public void setCodigoProdutoAlt(String codigoProdutoAlt) {
		this.codigoProdutoAlt = codigoProdutoAlt;
	}
	public String getContaCorrenteDev() {
		return contaCorrenteDev;
	}
	public void setContaCorrenteDev(String contaCorrenteDev) {
		this.contaCorrenteDev = contaCorrenteDev;
	}
	public String getTipoCcsn() {
		return tipoCcsn;
	}
	public void setTipoCcsn(String tipoCcsn) {
		this.tipoCcsn = tipoCcsn;
	}
	public String getCodigoCcsn() {
		return codigoCcsn;
	}
	public void setCodigoCcsn(String codigoCcsn) {
		this.codigoCcsn = codigoCcsn;
	}
	public String getCodigoBarra() {
		return codigoBarra;
	}
	public void setCodigoBarra(String codigoBarra) {
		this.codigoBarra = codigoBarra;
	}
	public String getTipoCapCdbr() {
		return tipoCapCdbr;
	}
	public void setTipoCapCdbr(String tipoCapCdbr) {
		this.tipoCapCdbr = tipoCapCdbr;
	}
	public Integer getQuantidadeCampos() {
		return quantidadeCampos;
	}
	public void setQuantidadeCampos(Integer quantidadeCampos) {
		this.quantidadeCampos = quantidadeCampos;
	}
	public String getRetCode() {
		return retCode;
	}
	public void setRetCode(String retCode) {
		this.retCode = retCode;
	}
	public String getErro() {
		return erro;
	}
	public void setErro(String erro) {
		this.erro = erro;
	}
	public String getErroTecnica() {
		return erroTecnica;
	}
	public void setErroTecnica(String erroTecnica) {
		this.erroTecnica = erroTecnica;
	}
	public String getErroMqs() {
		return erroMqs;
	}
	public void setErroMqs(String erroMqs) {
		this.erroMqs = erroMqs;
	}
	public String getNomePagina() {
		return nomePagina;
	}
	public void setNomePagina(String nomePagina) {
		this.nomePagina = nomePagina;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public SituacaoAgendamentoEnum getSituacaoAgendamento() {
		return situacaoAgendamento;
	}
	public void setSituacaoAgendamento(SituacaoAgendamentoEnum situacaoAgendamento) {
		this.situacaoAgendamento = situacaoAgendamento;
	}
	public CanalAgendamentoEnum getCanalAgendamento() {
		return canalAgendamento;
	}
	public void setCanalAgendamento(CanalAgendamentoEnum canalAgendamento) {
		this.canalAgendamento = canalAgendamento;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public String getContaPoupancaDebito() {
		return contaPoupancaDebito;
	}
	public void setContaPoupancaDebito(String contaPoupancaDebito) {
		this.contaPoupancaDebito = contaPoupancaDebito;
	}
	public String getContaPoupancaCredito() {
		return contaPoupancaCredito;
	}
	public void setContaPoupancaCredito(String contaPoupancaCredito) {
		this.contaPoupancaCredito = contaPoupancaCredito;
	}
	public String getNumCartaoCredito() {
		return numCartaoCredito;
	}
	public void setNumCartaoCredito(String numCartaoCredito) {
		this.numCartaoCredito = numCartaoCredito;
	}
	public String getVinculo() {
		return vinculo;
	}
	public void setVinculo(String vinculo) {
		this.vinculo = vinculo;
	}
	public String getSituacaoContrato() {
		return situacaoContrato;
	}
	public void setSituacaoContrato(String situacaoContrato) {
		this.situacaoContrato = situacaoContrato;
	}
	public String getContaFundo() {
		return contaFundo;
	}
	public void setContaFundo(String contaFundo) {
		this.contaFundo = contaFundo;
	}
	public ConcessionariaAgendamentoEnum getConcessionaria() {
		return concessionaria;
	}
	public void setConcessionaria(ConcessionariaAgendamentoEnum concessionaria) {
		this.concessionaria = concessionaria;
	}
	public String getNumeroContratoCDB() {
		return numeroContratoCDB;
	}
	public void setNumeroContratoCDB(String numeroContratoCDB) {
		this.numeroContratoCDB = numeroContratoCDB;
	}
	public Integer getPrazoCDB() {
		return prazoCDB;
	}
	public void setPrazoCDB(Integer prazoCDB) {
		this.prazoCDB = prazoCDB;
	}
	public Date getDataVencimentoTitulo() {
		return dataVencimentoTitulo;
	}
	public void setDataVencimentoTitulo(Date dataVencimentoTitulo) {
		this.dataVencimentoTitulo = dataVencimentoTitulo;
	}
	public FinalidadesAgendamentoEnum getFinalidadeDOC() {
		return finalidadeDOC;
	}
	public void setFinalidadeDOC(FinalidadesAgendamentoEnum finalidadeDOC) {
		this.finalidadeDOC = finalidadeDOC;
	}
	public String getBancoDestino() {
		return bancoDestino;
	}
	public void setBancoDestino(String bancoDestino) {
		this.bancoDestino = bancoDestino;
	}
	public String getAgenciaDestino() {
		return agenciaDestino;
	}
	public void setAgenciaDestino(String agenciaDestino) {
		this.agenciaDestino = agenciaDestino;
	}
	public String getContaDestino() {
		return contaDestino;
	}
	public void setContaDestino(String contaDestino) {
		this.contaDestino = contaDestino;
	}
	public String getFavorecido() {
		return favorecido;
	}
	public void setFavorecido(String favorecido) {
		this.favorecido = favorecido;
	}
	public String getTipoTED() {
		return tipoTED;
	}
	public void setTipoTED(String tipoTED) {
		this.tipoTED = tipoTED;
	}
	public FinalidadesDocAgendamentoEnum getFinalidadeTED() {
		return finalidadeTED;
	}
	public void setFinalidadeTED(FinalidadesDocAgendamentoEnum finalidadeTED) {
		this.finalidadeTED = finalidadeTED;
	}
	public String getHistorico() {
		return historico;
	}
	public void setHistorico(String historico) {
		this.historico = historico;
	}
	public TipoContaAgendamentoEnum getTipoConta() {
		return tipoConta;
	}
	public void setTipoConta(TipoContaAgendamentoEnum tipoConta) {
		this.tipoConta = tipoConta;
	}
	public String getPrefeitura() {
		return prefeitura;
	}
	public void setPrefeitura(String prefeitura) {
		this.prefeitura = prefeitura;
	}
	public String getRenavam() {
		return renavam;
	}
	public void setRenavam(String renavam) {
		this.renavam = renavam;
	}
	public String getNomeContribuinteGPS() {
		return nomeContribuinteGPS;
	}
	public void setNomeContribuinteGPS(String nomeContribuinteGPS) {
		this.nomeContribuinteGPS = nomeContribuinteGPS;
	}
	public String getCodigoPagamentoGPS() {
		return codigoPagamentoGPS;
	}
	public void setCodigoPagamentoGPS(String codigoPagamentoGPS) {
		this.codigoPagamentoGPS = codigoPagamentoGPS;
	}
	public String getCompetenciaGPS() {
		return competenciaGPS;
	}
	public void setCompetenciaGPS(String competenciaGPS) {
		this.competenciaGPS = competenciaGPS;
	}
	public String getIdentificadorGPS() {
		return identificadorGPS;
	}
	public void setIdentificadorGPS(String identificadorGPS) {
		this.identificadorGPS = identificadorGPS;
	}
	public BigDecimal getValorINSSGPS() {
		return valorINSSGPS;
	}
	public void setValorINSSGPS(BigDecimal valorINSSGPS) {
		this.valorINSSGPS = valorINSSGPS;
	}
	public BigDecimal getValorOutrasEntidadesGPS() {
		return valorOutrasEntidadesGPS;
	}
	public void setValorOutrasEntidadesGPS(BigDecimal valorOutrasEntidadesGPS) {
		this.valorOutrasEntidadesGPS = valorOutrasEntidadesGPS;
	}
	public BigDecimal getValorMultasJurosGPS() {
		return valorMultasJurosGPS;
	}
	public void setValorMultasJurosGPS(BigDecimal valorMultasJurosGPS) {
		this.valorMultasJurosGPS = valorMultasJurosGPS;
	}
	public BigDecimal getValorTotalGPS() {
		return valorTotalGPS;
	}
	public void setValorTotalGPS(BigDecimal valorTotalGPS) {
		this.valorTotalGPS = valorTotalGPS;
	}
	public String getFornecedor() {
		return fornecedor;
	}
	public void setFornecedor(String fornecedor) {
		this.fornecedor = fornecedor;
	}
	public String getPos() {
		return pos;
	}
	public void setPos(String pos) {
		this.pos = pos;
	}
	public String getNomeOperadora() {
		return nomeOperadora;
	}
	public void setNomeOperadora(String nomeOperadora) {
		this.nomeOperadora = nomeOperadora;
	}
	public String getNumeroTelefone() {
		return numeroTelefone;
	}
	public void setNumeroTelefone(String numeroTelefone) {
		this.numeroTelefone = numeroTelefone;
	}
	public String getCodigoMunicipio() {
		return codigoMunicipio;
	}
	public void setCodigoMunicipio(String codigoMunicipio) {
		this.codigoMunicipio = codigoMunicipio;
	}
	public String getPlacaVeiculo() {
		return placaVeiculo;
	}
	public void setPlacaVeiculo(String placaVeiculo) {
		this.placaVeiculo = placaVeiculo;
	}
	public String getNomeProprietario() {
		return nomeProprietario;
	}
	public void setNomeProprietario(String nomeProprietario) {
		this.nomeProprietario = nomeProprietario;
	}
	public String getAnoExercicioIPVA() {
		return anoExercicioIPVA;
	}
	public void setAnoExercicioIPVA(String anoExercicioIPVA) {
		this.anoExercicioIPVA = anoExercicioIPVA;
	}
	public String getCotaIPVA() {
		return cotaIPVA;
	}
	public void setCotaIPVA(String cotaIPVA) {
		this.cotaIPVA = cotaIPVA;
	}
	public TipoCotaOuParcelaMGAgendamentoEnum getCotaParcela() {
		return cotaParcela;
	}
	public void setCotaParcela(TipoCotaOuParcelaMGAgendamentoEnum cotaParcela) {
		this.cotaParcela = cotaParcela;
	}
	public String getTransacao() {
		return transacao;
	}
	public void setTransacao(String transacao) {
		this.transacao = transacao;
	}
	public String getNossoNumero() {
		return nossoNumero;
	}
	public void setNossoNumero(String nossoNumero) {
		this.nossoNumero = nossoNumero;
	}
	public String getInstituicaoFinanceira() {
		return instituicaoFinanceira;
	}
	public void setInstituicaoFinanceira(String instituicaoFinanceira) {
		this.instituicaoFinanceira = instituicaoFinanceira;
	}
	public String getCodigoISPB() {
		return codigoISPB;
	}
	public void setCodigoISPB(String codigoISPB) {
		this.codigoISPB = codigoISPB;
	}
	public String getNumeroDocumento() {
		return numeroDocumento;
	}
	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}
	public String getNomeBeneficiarioOriginal() {
		return nomeBeneficiarioOriginal;
	}
	public void setNomeBeneficiarioOriginal(String nomeBeneficiarioOriginal) {
		this.nomeBeneficiarioOriginal = nomeBeneficiarioOriginal;
	}
	public String getDocumentoBeneficiarioOriginal() {
		return documentoBeneficiarioOriginal;
	}
	public void setDocumentoBeneficiarioOriginal(String documentoBeneficiarioOriginal) {
		this.documentoBeneficiarioOriginal = documentoBeneficiarioOriginal;
	}
	public String getTipoPessoaBeneficiarioOriginal() {
		return tipoPessoaBeneficiarioOriginal;
	}
	public void setTipoPessoaBeneficiarioOriginal(String tipoPessoaBeneficiarioOriginal) {
		this.tipoPessoaBeneficiarioOriginal = tipoPessoaBeneficiarioOriginal;
	}
	public String getNomePagadorOriginal() {
		return nomePagadorOriginal;
	}
	public void setNomePagadorOriginal(String nomePagadorOriginal) {
		this.nomePagadorOriginal = nomePagadorOriginal;
	}
	public String getDocumentoPagadorOriginal() {
		return documentoPagadorOriginal;
	}
	public void setDocumentoPagadorOriginal(String documentoPagadorOriginal) {
		this.documentoPagadorOriginal = documentoPagadorOriginal;
	}
	public String getTipoPessoaPagadorOriginal() {
		return tipoPessoaPagadorOriginal;
	}
	public void setTipoPessoaPagadorOriginal(String tipoPessoaPagadorOriginal) {
		this.tipoPessoaPagadorOriginal = tipoPessoaPagadorOriginal;
	}
	public String getNomePagadorEfetivo() {
		return nomePagadorEfetivo;
	}
	public void setNomePagadorEfetivo(String nomePagadorEfetivo) {
		this.nomePagadorEfetivo = nomePagadorEfetivo;
	}
	public String getDocumentoPagadorEfetivo() {
		return documentoPagadorEfetivo;
	}
	public void setDocumentoPagadorEfetivo(String documentoPagadorEfetivo) {
		this.documentoPagadorEfetivo = documentoPagadorEfetivo;
	}
	public String getTipoPessoaPagadorEfetivo() {
		return tipoPessoaPagadorEfetivo;
	}
	public void setTipoPessoaPagadorEfetivo(String tipoPessoaPagadorEfetivo) {
		this.tipoPessoaPagadorEfetivo = tipoPessoaPagadorEfetivo;
	}
	public String getNomeSacadorAvalista() {
		return nomeSacadorAvalista;
	}
	public void setNomeSacadorAvalista(String nomeSacadorAvalista) {
		this.nomeSacadorAvalista = nomeSacadorAvalista;
	}
	public String getDocumentoSacadorAvalista() {
		return documentoSacadorAvalista;
	}
	public void setDocumentoSacadorAvalista(String documentoSacadorAvalista) {
		this.documentoSacadorAvalista = documentoSacadorAvalista;
	}
	public String getTipoPessoaSacadorAvalista() {
		return tipoPessoaSacadorAvalista;
	}
	public void setTipoPessoaSacadorAvalista(String tipoPessoaSacadorAvalista) {
		this.tipoPessoaSacadorAvalista = tipoPessoaSacadorAvalista;
	}
	public BigDecimal getValorNominal() {
		return valorNominal;
	}
	public void setValorNominal(BigDecimal valorNominal) {
		this.valorNominal = valorNominal;
	}
	public BigDecimal getValorEncargos() {
		return valorEncargos;
	}
	public void setValorEncargos(BigDecimal valorEncargos) {
		this.valorEncargos = valorEncargos;
	}
	public BigDecimal getValorDesconto() {
		return valorDesconto;
	}
	public void setValorDesconto(BigDecimal valorDesconto) {
		this.valorDesconto = valorDesconto;
	}
	public BigDecimal getValorPago() {
		return valorPago;
	}
	public void setValorPago(BigDecimal valorPago) {
		this.valorPago = valorPago;
	}
	public Long getNumeroDocumentoBeneficiarioOriginal() {
		return numeroDocumentoBeneficiarioOriginal;
	}
	public void setNumeroDocumentoBeneficiarioOriginal(Long numeroDocumentoBeneficiarioOriginal) {
		this.numeroDocumentoBeneficiarioOriginal = numeroDocumentoBeneficiarioOriginal;
	}
	public Long getNumeroDocumentoPagadorOriginal() {
		return numeroDocumentoPagadorOriginal;
	}
	public void setNumeroDocumentoPagadorOriginal(Long numeroDocumentoPagadorOriginal) {
		this.numeroDocumentoPagadorOriginal = numeroDocumentoPagadorOriginal;
	}
	public Long getNumeroDocumentoPagadorEfetivo() {
		return numeroDocumentoPagadorEfetivo;
	}
	public void setNumeroDocumentoPagadorEfetivo(Long numeroDocumentoPagadorEfetivo) {
		this.numeroDocumentoPagadorEfetivo = numeroDocumentoPagadorEfetivo;
	}
	public Long getNumeroDocumentoSacadorAvalista() {
		return numeroDocumentoSacadorAvalista;
	}
	public void setNumeroDocumentoSacadorAvalista(Long numeroDocumentoSacadorAvalista) {
		this.numeroDocumentoSacadorAvalista = numeroDocumentoSacadorAvalista;
	}
	public boolean isExibeMsgBoletoBancario() {
		return exibeMsgBoletoBancario;
	}
	public void setExibeMsgBoletoBancario(boolean exibeMsgBoletoBancario) {
		this.exibeMsgBoletoBancario = exibeMsgBoletoBancario;
	}
	public TipoOperacaoAgendamentoEnum getTipoOperacaoAgendamento() {
		return tipoOperacaoAgendamento;
	}
	public void setTipoOperacaoAgendamento(TipoOperacaoAgendamentoEnum tipoOperacaoAgendamento) {
		this.tipoOperacaoAgendamento = tipoOperacaoAgendamento;
	}
	public String getTipoPessoa() {
		return tipoPessoa;
	}
	public void setTipoPessoa(String tipoPessoa) {
		this.tipoPessoa = tipoPessoa;
	}
	
}
