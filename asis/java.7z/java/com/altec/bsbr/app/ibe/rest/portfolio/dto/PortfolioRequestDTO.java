package com.altec.bsbr.app.ibe.rest.portfolio.dto;

import java.io.Serializable;

public class PortfolioRequestDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String participantCode;
	private String bank;
	private String agency;
	private String account;
	
	public String getParticipantCode() {
		return participantCode;
	}
	public void setParticipantCode(String participantCode) {
		this.participantCode = participantCode;
	}
	public String getBank() {
		return bank;
	}
	public void setBank(String bank) {
		this.bank = bank;
	}
	public String getAgency() {
		return agency;
	}
	public void setAgency(String agency) {
		this.agency = agency;
	}
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}

}
