package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.altec.bsbr.app.ibe.dto.perfilautorizacaotransacao.PerfilAutorizacaoTransacaoResponseDTO;

public class ListarTransacoesAutorizacaoDetalheCashResponseDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private List<PerfilAutorizacaoTransacaoResponseDTO> listaTransacoes = new ArrayList<PerfilAutorizacaoTransacaoResponseDTO>();

	public List<PerfilAutorizacaoTransacaoResponseDTO> getListaTransacoes() {
		return listaTransacoes;
	}

	public void setListaTransacoes(List<PerfilAutorizacaoTransacaoResponseDTO> listaTransacoes) {
		this.listaTransacoes = listaTransacoes;
	}

}