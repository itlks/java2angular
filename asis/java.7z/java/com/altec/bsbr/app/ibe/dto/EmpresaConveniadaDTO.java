package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;

import com.altec.bsbr.app.ibe.anotation.Hash;
import com.altec.bsbr.app.ibe.dto.convenios.EntDeb;
import com.altec.bsbr.app.ibe.enumeration.DebitoAutomaticoTipoContaEnum;
import com.altec.bsbr.app.ibe.hash.converter.BigDecimalConverter;
import com.altec.bsbr.app.ibe.message.Mensagem;
import com.altec.bsbr.app.ibe.util.Utils;


@SuppressWarnings("unused")
public class EmpresaConveniadaDTO implements Serializable {

	private static final long serialVersionUID = 5034494499346409021L;

	private Integer idEmpresaConveniada;
	private String nomeEmpresaConveniada;
	private String identificacaoConsumidor;
	private String historicoComplementar;
	private String formaPagamento;
	
	@Hash(position=1, converter=BigDecimalConverter.class)
	private BigDecimal valorMaximoDebito;
	private Boolean emitirAvisoCorreios;
	private Boolean alteracaoFormaPagamento;
	private Boolean possuiLimiteDebito;
	private String possuiLimiteDebitoFormatada;

	private String dataCadastramento;
	private String dataUltimoLancamento;
	private String dataCancelamento;

	// Dados saida servico detalharEmpresaConveniada
	private String numeroReferencia;
	private String dataUltimaAlteracao;
	private String dataUltimaMovimentacao;
	private String numeroCartaoCredito;
	private Integer bancoRechamada;
	private Integer agenciaRechamada;
	private Integer contaRechamada;
	private Integer tamanhoDesc;
	private String descConsumidor;

	private String indicadorRechamada;
	private String tipoDocumento;
	private String numeroDocumento;

	private String entidadBr;
	private String sucursalBr;
	private String nroCuentaBr;

	// Propriedades utilizadas no servi�o de exclus�o de debito automatico
	private String estdev;
	private String destdev;
	private String consald;
	private String lancfut;
	private String consdeb;
	private String envarq;
	private String ctadesp;
	private EntDeb entDeb;
	
	private String userAlt;
	private String userId;
	private String consDeb;
	private String lancFut;
	private String titular;
	private String tipIden;
	private String protoco;
	
	private String naoDeb;
	
	private String txextr;

	private DebitoAutomaticoTipoContaEnum tipoConta;

	public EmpresaConveniadaDTO() {
	}

	public EmpresaConveniadaDTO(Integer idEmpresaConveniada, String nomeEmpresaConveniada,
			String identificacaoConsumidor, String historicoComplementar, String formaPagamento,
			DebitoAutomaticoTipoContaEnum tipoConta, String motivoExclusao) {
		super();
		this.idEmpresaConveniada = idEmpresaConveniada;
		this.nomeEmpresaConveniada = nomeEmpresaConveniada;
		this.identificacaoConsumidor = identificacaoConsumidor;
		this.historicoComplementar = historicoComplementar;
		this.formaPagamento = formaPagamento;
		this.tipoConta = tipoConta;
	}

	public Integer getIdEmpresaConveniada() {
		return idEmpresaConveniada;
	}

	public void setIdEmpresaConveniada(Integer idEmpresaConveniada) {
		this.idEmpresaConveniada = idEmpresaConveniada;
	}

	public String getNomeEmpresaConveniada() {
		return nomeEmpresaConveniada;
	}

	public void setNomeEmpresaConveniada(String nomeEmpresaConveniada) {
		this.nomeEmpresaConveniada = nomeEmpresaConveniada;
	}

	public DebitoAutomaticoTipoContaEnum getTipoConta() {
		return tipoConta;
	}

	public void setTipoConta(DebitoAutomaticoTipoContaEnum tipoConta) {
		this.tipoConta = tipoConta;
	}

	public String getIdentificacaoConsumidor() {
		return identificacaoConsumidor;
	}

	public void setIdentificacaoConsumidor(String identificacaoConsumidor) {
		this.identificacaoConsumidor = identificacaoConsumidor;
	}

	public String getHistoricoComplementar() {
		return historicoComplementar;
	}

	public void setHistoricoComplementar(String historicoComplementar) {
		this.historicoComplementar = historicoComplementar;
	}
	public Integer getTamanhoDesc() {
		return tamanhoDesc;
	}
	
	public void setTamanhoDesc(Integer tamanhoDesc) {
		this.tamanhoDesc = tamanhoDesc;
	}

	public String getFormaPagamento() {
		return formaPagamento;
	}

	public void setFormaPagamento(String formaPagamento) {
		this.formaPagamento = formaPagamento;
	}
	
	public BigDecimal getValorMaximoDebito() {
		return valorMaximoDebito;
	}

	public void setValorMaximoDebito(BigDecimal valorMaximoDebito) {
		this.valorMaximoDebito = valorMaximoDebito;
	}

	public Boolean getEmitirAvisoCorreios() {
		return emitirAvisoCorreios;
	}

	public void setEmitirAvisoCorreios(Boolean emitirAvisoCorreios) {
		this.emitirAvisoCorreios = emitirAvisoCorreios;
	}

	public Boolean getAlteracaoFormaPagamento() {
		return alteracaoFormaPagamento;
	}

	public void setAlteracaoFormaPagamento(Boolean alteracaoFormaPagamento) {
		this.alteracaoFormaPagamento = alteracaoFormaPagamento;
	}

	public Boolean getPossuiLimiteDebito() {
		return possuiLimiteDebito;
	}

	public void setPossuiLimiteDebito(Boolean possuiLimiteDebito) {
		this.possuiLimiteDebito = possuiLimiteDebito;
	}

	public String getNumeroReferencia() {
		return numeroReferencia;
	}

	public void setNumeroReferencia(String numeroReferencia) {
		this.numeroReferencia = numeroReferencia;
	}

	public String getDataUltimaAlteracao() {
		return dataUltimaAlteracao;
	}

	public void setDataUltimaAlteracao(String dataUltimaAlteracao) {
		this.dataUltimaAlteracao = dataUltimaAlteracao;
	}

	public String getDataUltimaMovimentacao() {
		return dataUltimaMovimentacao;
	}

	public void setDataUltimaMovimentacao(String dataUltimaMovimentacao) {
		this.dataUltimaMovimentacao = dataUltimaMovimentacao;
	}

	public String getNumeroCartaoCredito() {
		return numeroCartaoCredito;
	}

	public void setNumeroCartaoCredito(String numeroCartaoCredito) {
		this.numeroCartaoCredito = numeroCartaoCredito;
	}

	public Integer getBancoRechamada() {
		return bancoRechamada;
	}

	public void setBancoRechamada(Integer bancoRechamada) {
		this.bancoRechamada = bancoRechamada;
	}

	public Integer getAgenciaRechamada() {
		return agenciaRechamada;
	}

	public void setAgenciaRechamada(Integer agenciaRechamada) {
		this.agenciaRechamada = agenciaRechamada;
	}

	public Integer getContaRechamada() {
		return contaRechamada;
	}

	public void setContaRechamada(Integer contaRechamada) {
		this.contaRechamada = contaRechamada;
	}

	public String getIndicadorRechamada() {
		return indicadorRechamada;
	}

	public void setIndicadorRechamada(String indicadorRechamada) {
		this.indicadorRechamada = indicadorRechamada;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getDataCadastramento() {
		return dataCadastramento;
	}

	public void setDataCadastramento(String dataCadastramento) {
		this.dataCadastramento = dataCadastramento;
	}

	public String getDataUltimoLancamento() {
		return dataUltimoLancamento;
	}

	public void setDataUltimoLancamento(String dataUltimoLancamento) {
		this.dataUltimoLancamento = dataUltimoLancamento;
	}

	public String getEntidadBr() {
		return entidadBr;
	}

	public void setEntidadBr(String entidadBr) {
		this.entidadBr = entidadBr;
	}

	public String getSucursalBr() {
		return sucursalBr;
	}

	public void setSucursalBr(String sucursalBr) {
		this.sucursalBr = sucursalBr;
	}

	public String getNroCuentaBr() {
		return nroCuentaBr;
	}

	public void setNroCuentaBr(String nroCuentaBr) {
		this.nroCuentaBr = nroCuentaBr;
	}

	public String getFormaPagamentoFormatada() {
		String retorno = "";
		// Se retorno do servico para formaPagamento for iqual a N, exibe Conta
		// Corrente
		if (this.formaPagamento.equals("N")) {
			retorno = Mensagem
					.getMensagem("pages.pagamento.debitoAutomatico.cadastro.alterar.selecionar.contaCorrente");
		}
		// Senao, exibe Cartao de credito com XXXX.XXXX.XXXX. + ultimos 4
		// digitos do cartao
		else {
			StringBuilder sb = new StringBuilder();
			sb.append(
					Mensagem.getMensagem("pages.pagamento.debitoAutomatico.cadastro.alterar.selecionar.cartaoCredito"));
			sb.append(" XXXX.XXXX.XXXX.");
			sb.append(this.getNumeroCartaoCredito().substring(this.getNumeroCartaoCredito().length() - 4));
			retorno = sb.toString();
		}
		return retorno;
	}

	public String getDataCadastramentoFormatada() {
		StringBuilder sb = new StringBuilder();
		sb.append(this.getDataCadastramento().substring(this.getDataCadastramento().length() - 2));
		sb.append("/");
		sb.append(this.getDataCadastramento().substring(5, 7));
		sb.append("/");
		sb.append(this.getDataCadastramento().substring(0, 4));

		return sb.toString();
	}

	public String getDataUltimoLancamentoFormatada() {

		StringBuilder sb = new StringBuilder();
	
			if(null != this.getDataUltimoLancamento() && !this.getDataUltimoLancamento().equals("0001-01-01")){
				boolean retorno = Utils.isDateEmpty(this.getDataUltimoLancamento());
				if (!retorno) {
					sb.append(this.getDataUltimoLancamento().substring(this.getDataUltimoLancamento().length() - 2));
					sb.append("/");
					sb.append(this.getDataUltimoLancamento().substring(5, 7));
					sb.append("/");
					sb.append(this.getDataUltimoLancamento().substring(0, 4));
				} else {
					sb.append("");
				}
			}
		return sb.toString();
	}

	public Boolean getExibeDataUltimoLancamento() {
		Boolean retorno = false;
		if (null != this.getDataUltimoLancamento()) {
			if (!this.getDataUltimoLancamento().equals("0001-01-01")) {
				retorno = true;
			}
		}
		return retorno;
	}

	public String getEstdev() {
		return estdev;
	}

	public void setEstdev(String estdev) {
		this.estdev = estdev;
	}

	public String getDestdev() {
		return destdev;
	}

	public void setDestdev(String destdev) {
		this.destdev = destdev;
	}

	public String getConsald() {
		return consald;
	}

	public void setConsald(String consald) {
		this.consald = consald;
	}

	public String getLancfut() {
		return lancfut;
	}

	public void setLancfut(String lancfut) {
		this.lancfut = lancfut;
	}

	public String getConsdeb() {
		return consdeb;
	}

	public void setConsdeb(String consdeb) {
		this.consdeb = consdeb;
	}

	public String getEnvarq() {
		return envarq;
	}

	public void setEnvarq(String envarq) {
		this.envarq = envarq;
	}

	public String getCtadesp() {
		return ctadesp;
	}

	public void setCtadesp(String ctadesp) {
		this.ctadesp = ctadesp;
	}

	public EntDeb getEntDeb() {
		return entDeb;
	}

	public void setEntDeb(EntDeb entDeb) {
		this.entDeb = entDeb;
	}

	public String getPossuiLimiteDebitoFormatada() {
		// Se ValorMaximoDebito for = 0 ou = 999999999999999, setar valor para
		// N�O, caso contr�rio, SIM
		String retorno = Mensagem.getMensagem("page.txt.simMaiusculo");
		if (this.getValorMaximoDebito().compareTo(BigDecimal.ZERO) == 0) {
			retorno = Mensagem.getMensagem("page.txt.naoMaiusculo");
		}

		this.setPossuiLimiteDebitoFormatada(retorno);

		return retorno;
	}

	public void setPossuiLimiteDebitoFormatada(String possuiLimiteDebitoFormatada){
		
		this.possuiLimiteDebitoFormatada = possuiLimiteDebitoFormatada;
	}
	
	
	public String getValorMaximoDebitoFormatado() {
		String retorno = this.getValorMaximoDebito().toString();
		return retorno;
	}

	public String getDataCancelamento() {
		return dataCancelamento;
	}

	public void setDataCancelamento(String dataCancelamento) {
		this.dataCancelamento = dataCancelamento;
	}

	public String getDescConsumidor() {
		return descConsumidor;
	}

	public void setDescConsumidor(String descConsumidor) {
		this.descConsumidor = descConsumidor;
	}

	public String getUserAlt() {
		return userAlt;
	}

	public void setUserAlt(String userAlt) {
		this.userAlt = userAlt;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getConsDeb() {
		return consDeb;
	}

	public void setConsDeb(String consDeb) {
		this.consDeb = consDeb;
	}

	public String getLancFut() {
		return lancFut;
	}

	public void setLancFut(String lancFut) {
		this.lancFut = lancFut;
	}

	public String getTitular() {
		return titular;
	}

	public void setTitular(String titular) {
		this.titular = titular;
	}

	public String getTipIden() {
		return tipIden;
	}

	public void setTipIden(String tipIden) {
		this.tipIden = tipIden;
	}

	public String getProtoco() {
		return protoco;
	}

	public void setProtoco(String protoco) {
		this.protoco = protoco;
	}

	public String getNaoDeb() {
		return naoDeb;
	}

	public void setNaoDeb(String naoDeb) {
		this.naoDeb = naoDeb;
	}

	public String getTxextr() {
		return txextr;
	}

	public void setTxextr(String txextr) {
		this.txextr = txextr;
	}

}
