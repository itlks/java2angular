package com.altec.bsbr.app.ibe.dto;

import java.util.Date;

public class TransferenciaSegundaViaDadosComprovanteDetalheDTO {

	private String agenciaOrigem;
	private String contaOrigem;
	private String agenciaDestino;
	private String contaDestino;
	private String favorecido;
	private String valor;
	private String tipoTransferencia;
	private String contaOrigemInformada;
	private String contaDestinoInformada;	
	private String titularidade;
	private String finalidade;
	private String historico;
	private String banco;
	private String cpf;
	private String remetente;
	private String tipoDoc;
	private String tipoConta;
	private String nome;
	private Date dataTransacao;
	private String autenticacao;
	private String codSIPB;
	private String motivoDOC;
	private String nomeBancoDestino;
	private String idLancamento;
	private String bancoDestino;
	private Date dataTransferencia;
	private Double valorTarifaServico;
	private String nomeIspb;
	
	
	public String getAgenciaOrigem() {
		return agenciaOrigem;
	}
	public void setAgenciaOrigem(String agenciaOrigem) {
		this.agenciaOrigem = agenciaOrigem;
	}
	public String getContaOrigem() {
		return contaOrigem;
	}
	public void setContaOrigem(String contaOrigem) {
		this.contaOrigem = contaOrigem;
	}
	public String getAgenciaDestino() {
		return agenciaDestino;
	}
	public void setAgenciaDestino(String agenciaDestino) {
		this.agenciaDestino = agenciaDestino;
	}
	public String getContaDestino() {
		return contaDestino;
	}
	public void setContaDestino(String contaDestino) {
		this.contaDestino = contaDestino;
	}
	public String getFavorecido() {
		return favorecido;
	}
	public void setFavorecido(String favorecido) {
		this.favorecido = favorecido;
	}
	public String getValor() {
		return valor;
	}
	public void setValor(String valor) {
		this.valor = valor;
	}
	public String getTipoTransferencia() {
		return tipoTransferencia;
	}
	public void setTipoTransferencia(String tipoTransferencia) {
		this.tipoTransferencia = tipoTransferencia;
	}
	public String getContaOrigemInformada() {
		return contaOrigemInformada;
	}
	public void setContaOrigemInformada(String contaOrigemInformada) {
		this.contaOrigemInformada = contaOrigemInformada;
	}
	public String getContaDestinoInformada() {
		return contaDestinoInformada;
	}
	public void setContaDestinoInformada(String contaDestinoInformada) {
		this.contaDestinoInformada = contaDestinoInformada;
	}
	public String getTitularidade() {
		return titularidade;
	}
	public void setTitularidade(String titularidade) {
		this.titularidade = titularidade;
	}
	public String getFinalidade() {
		return finalidade;
	}
	public void setFinalidade(String finalidade) {
		this.finalidade = finalidade;
	}
	public String getHistorico() {
		return historico;
	}
	public void setHistorico(String historico) {
		this.historico = historico;
	}
	public String getBanco() {
		return banco;
	}
	public void setBanco(String banco) {
		this.banco = banco;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getRemetente() {
		return remetente;
	}
	public void setRemetente(String remetente) {
		this.remetente = remetente;
	}
	public String getTipoDoc() {
		return tipoDoc;
	}
	public void setTipoDoc(String tipoDoc) {
		this.tipoDoc = tipoDoc;
	}
	public String getTipoConta() {
		return tipoConta;
	}
	public void setTipoConta(String tipoConta) {
		this.tipoConta = tipoConta;
	}
	public Date getDataTransacao() {
		return dataTransacao;
	}
	public void setDataTransacao(Date dataTransacao) {
		this.dataTransacao = dataTransacao;
	}
	public String getAutenticacao() {
		return autenticacao;
	}
	public void setAutenticacao(String autenticacao) {
		this.autenticacao = autenticacao;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCodSIPB() {
		return codSIPB;
	}
	public void setCodSIPB(String codSIPB) {
		this.codSIPB = codSIPB;
	}
	public String getMotivoDOC() {
		return motivoDOC;
	}
	public void setMotivoDOC(String motivoDOC) {
		this.motivoDOC = motivoDOC;
	}
	public String getNomeBancoDestino() {
		return nomeBancoDestino;
	}
	public void setNomeBancoDestino(String nomeBancoDestino) {
		this.nomeBancoDestino = nomeBancoDestino;
	}
	public String getIdLancamento() {
		return idLancamento;
	}
	public void setIdLancamento(String idLancamento) {
		this.idLancamento = idLancamento;
	}
	public String getBancoDestino() {
		return bancoDestino;
	}
	public void setBancoDestino(String bancoDestino) {
		this.bancoDestino = bancoDestino;
	}
	public Date getDataTransferencia() {
		return dataTransferencia;
	}
	public void setDataTransferencia(Date dataTransferencia) {
		this.dataTransferencia = dataTransferencia;
	}
	public Double getValorTarifaServico() {
		return valorTarifaServico;
	}
	public void setValorTarifaServico(Double valorTarifaServico) {
		this.valorTarifaServico = valorTarifaServico;
	}
	public String getNomeIspb() {
		return nomeIspb;
	}
	public void setNomeIspb(String nomeIspb) {
		this.nomeIspb = nomeIspb;
	}
	
}
