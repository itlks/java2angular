package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

import com.altec.bsbr.app.ibe.dto.titulos.ArrayOfStringDTO;
import com.altec.bsbr.app.ibe.dto.titulos.ErrosDTO;

public class ConsultaPgtoTitulosResponseDTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2299468414412406256L;
	private ErrosDTO erros;
	private String strGerouPendencia;
	private String linhasRet;
	private String strChave23;
	private String strChave23SemCript;
	private String strOEFJCHAVEAMARRACAO;
	private String strOEFJDTACONTAB;
	private String strOEFJDTPGTOTITU;
	private String strOEFJDTAVCTO;
	private String strOEFJDTAAGD;
	private String strOEFJNOMECEDENTE;
	private String strOEFJNOMESACADO;
	private String strOEFJVLRDIGICLIE;
	private String strOEFJVLRTOTALTITU;
	private String strOEFJVLRBASELEGADO;
	private String strOEFJTPCAPBAR;
	private String strOEFJCODBARRAS;
	private String strOEFJTIPOTITU;
	private String strOEFJCODCEDENTE;
	private String strOEFJCODNOSNUM;
	private String strOEFJCODSEUNUM;
	private String strOEFJVLRDESCTITU;
	private String strOEFJVLRABATTITU;
	private String strOEFJVLRJURTITU;
	private String strOEFJVLRMULTATITU;
	private String strOEFJVLRIOFTITU;
	private String strOEFJDATARECIBO;
	private String strOEFJHORARECIBO;
	private String strOEFJINDFORMPGTO;
	private String strOEFJPAN;
	private String strOEFJCARTAOBANCO;
	private String strOEFJCARTAOAGENCIA;
	private String strOEFJCARTAOCONTRATO;
	private String strOEFJTARIFAVALOR;
	private String strOEFJTARIFAPERC;
	private String strOEFJTARIFAMINIMA;
	private String strOEFJTARIFAMAXIMA;
	private String strNomeCedente;
	private String strNomeSacado;
	private String strtxtTipo;
	private String strtxtBandeira;
	private ArrayOfStringDTO arrBoletoVR;
	public ErrosDTO getErros() {
		return erros;
	}
	public void setErros(ErrosDTO erros) {
		this.erros = erros;
	}
	public String getStrGerouPendencia() {
		return strGerouPendencia;
	}
	public void setStrGerouPendencia(String strGerouPendencia) {
		this.strGerouPendencia = strGerouPendencia;
	}
	public String getLinhasRet() {
		return linhasRet;
	}
	public void setLinhasRet(String linhasRet) {
		this.linhasRet = linhasRet;
	}
	public String getStrChave23() {
		return strChave23;
	}
	public void setStrChave23(String strChave23) {
		this.strChave23 = strChave23;
	}
	public String getStrChave23SemCript() {
		return strChave23SemCript;
	}
	public void setStrChave23SemCript(String strChave23SemCript) {
		this.strChave23SemCript = strChave23SemCript;
	}
	public String getStrOEFJCHAVEAMARRACAO() {
		return strOEFJCHAVEAMARRACAO;
	}
	public void setStrOEFJCHAVEAMARRACAO(String strOEFJCHAVEAMARRACAO) {
		this.strOEFJCHAVEAMARRACAO = strOEFJCHAVEAMARRACAO;
	}
	public String getStrOEFJDTACONTAB() {
		return strOEFJDTACONTAB;
	}
	public void setStrOEFJDTACONTAB(String strOEFJDTACONTAB) {
		this.strOEFJDTACONTAB = strOEFJDTACONTAB;
	}
	public String getStrOEFJDTPGTOTITU() {
		return strOEFJDTPGTOTITU;
	}
	public void setStrOEFJDTPGTOTITU(String strOEFJDTPGTOTITU) {
		this.strOEFJDTPGTOTITU = strOEFJDTPGTOTITU;
	}
	public String getStrOEFJDTAVCTO() {
		return strOEFJDTAVCTO;
	}
	public void setStrOEFJDTAVCTO(String strOEFJDTAVCTO) {
		this.strOEFJDTAVCTO = strOEFJDTAVCTO;
	}
	public String getStrOEFJDTAAGD() {
		return strOEFJDTAAGD;
	}
	public void setStrOEFJDTAAGD(String strOEFJDTAAGD) {
		this.strOEFJDTAAGD = strOEFJDTAAGD;
	}
	public String getStrOEFJNOMECEDENTE() {
		return strOEFJNOMECEDENTE;
	}
	public void setStrOEFJNOMECEDENTE(String strOEFJNOMECEDENTE) {
		this.strOEFJNOMECEDENTE = strOEFJNOMECEDENTE;
	}
	public String getStrOEFJNOMESACADO() {
		return strOEFJNOMESACADO;
	}
	public void setStrOEFJNOMESACADO(String strOEFJNOMESACADO) {
		this.strOEFJNOMESACADO = strOEFJNOMESACADO;
	}
	public String getStrOEFJVLRDIGICLIE() {
		return strOEFJVLRDIGICLIE;
	}
	public void setStrOEFJVLRDIGICLIE(String strOEFJVLRDIGICLIE) {
		this.strOEFJVLRDIGICLIE = strOEFJVLRDIGICLIE;
	}
	public String getStrOEFJVLRTOTALTITU() {
		return strOEFJVLRTOTALTITU;
	}
	public void setStrOEFJVLRTOTALTITU(String strOEFJVLRTOTALTITU) {
		this.strOEFJVLRTOTALTITU = strOEFJVLRTOTALTITU;
	}
	public String getStrOEFJVLRBASELEGADO() {
		return strOEFJVLRBASELEGADO;
	}
	public void setStrOEFJVLRBASELEGADO(String strOEFJVLRBASELEGADO) {
		this.strOEFJVLRBASELEGADO = strOEFJVLRBASELEGADO;
	}
	public String getStrOEFJTPCAPBAR() {
		return strOEFJTPCAPBAR;
	}
	public void setStrOEFJTPCAPBAR(String strOEFJTPCAPBAR) {
		this.strOEFJTPCAPBAR = strOEFJTPCAPBAR;
	}
	public String getStrOEFJCODBARRAS() {
		return strOEFJCODBARRAS;
	}
	public void setStrOEFJCODBARRAS(String strOEFJCODBARRAS) {
		this.strOEFJCODBARRAS = strOEFJCODBARRAS;
	}
	public String getStrOEFJTIPOTITU() {
		return strOEFJTIPOTITU;
	}
	public void setStrOEFJTIPOTITU(String strOEFJTIPOTITU) {
		this.strOEFJTIPOTITU = strOEFJTIPOTITU;
	}
	public String getStrOEFJCODCEDENTE() {
		return strOEFJCODCEDENTE;
	}
	public void setStrOEFJCODCEDENTE(String strOEFJCODCEDENTE) {
		this.strOEFJCODCEDENTE = strOEFJCODCEDENTE;
	}
	public String getStrOEFJCODNOSNUM() {
		return strOEFJCODNOSNUM;
	}
	public void setStrOEFJCODNOSNUM(String strOEFJCODNOSNUM) {
		this.strOEFJCODNOSNUM = strOEFJCODNOSNUM;
	}
	public String getStrOEFJCODSEUNUM() {
		return strOEFJCODSEUNUM;
	}
	public void setStrOEFJCODSEUNUM(String strOEFJCODSEUNUM) {
		this.strOEFJCODSEUNUM = strOEFJCODSEUNUM;
	}
	public String getStrOEFJVLRDESCTITU() {
		return strOEFJVLRDESCTITU;
	}
	public void setStrOEFJVLRDESCTITU(String strOEFJVLRDESCTITU) {
		this.strOEFJVLRDESCTITU = strOEFJVLRDESCTITU;
	}
	public String getStrOEFJVLRABATTITU() {
		return strOEFJVLRABATTITU;
	}
	public void setStrOEFJVLRABATTITU(String strOEFJVLRABATTITU) {
		this.strOEFJVLRABATTITU = strOEFJVLRABATTITU;
	}
	public String getStrOEFJVLRJURTITU() {
		return strOEFJVLRJURTITU;
	}
	public void setStrOEFJVLRJURTITU(String strOEFJVLRJURTITU) {
		this.strOEFJVLRJURTITU = strOEFJVLRJURTITU;
	}
	public String getStrOEFJVLRMULTATITU() {
		return strOEFJVLRMULTATITU;
	}
	public void setStrOEFJVLRMULTATITU(String strOEFJVLRMULTATITU) {
		this.strOEFJVLRMULTATITU = strOEFJVLRMULTATITU;
	}
	public String getStrOEFJVLRIOFTITU() {
		return strOEFJVLRIOFTITU;
	}
	public void setStrOEFJVLRIOFTITU(String strOEFJVLRIOFTITU) {
		this.strOEFJVLRIOFTITU = strOEFJVLRIOFTITU;
	}
	public String getStrOEFJDATARECIBO() {
		return strOEFJDATARECIBO;
	}
	public void setStrOEFJDATARECIBO(String strOEFJDATARECIBO) {
		this.strOEFJDATARECIBO = strOEFJDATARECIBO;
	}
	public String getStrOEFJHORARECIBO() {
		return strOEFJHORARECIBO;
	}
	public void setStrOEFJHORARECIBO(String strOEFJHORARECIBO) {
		this.strOEFJHORARECIBO = strOEFJHORARECIBO;
	}
	public String getStrOEFJINDFORMPGTO() {
		return strOEFJINDFORMPGTO;
	}
	public void setStrOEFJINDFORMPGTO(String strOEFJINDFORMPGTO) {
		this.strOEFJINDFORMPGTO = strOEFJINDFORMPGTO;
	}
	public String getStrOEFJPAN() {
		return strOEFJPAN;
	}
	public void setStrOEFJPAN(String strOEFJPAN) {
		this.strOEFJPAN = strOEFJPAN;
	}
	public String getStrOEFJCARTAOBANCO() {
		return strOEFJCARTAOBANCO;
	}
	public void setStrOEFJCARTAOBANCO(String strOEFJCARTAOBANCO) {
		this.strOEFJCARTAOBANCO = strOEFJCARTAOBANCO;
	}
	public String getStrOEFJCARTAOAGENCIA() {
		return strOEFJCARTAOAGENCIA;
	}
	public void setStrOEFJCARTAOAGENCIA(String strOEFJCARTAOAGENCIA) {
		this.strOEFJCARTAOAGENCIA = strOEFJCARTAOAGENCIA;
	}
	public String getStrOEFJCARTAOCONTRATO() {
		return strOEFJCARTAOCONTRATO;
	}
	public void setStrOEFJCARTAOCONTRATO(String strOEFJCARTAOCONTRATO) {
		this.strOEFJCARTAOCONTRATO = strOEFJCARTAOCONTRATO;
	}
	public String getStrOEFJTARIFAVALOR() {
		return strOEFJTARIFAVALOR;
	}
	public void setStrOEFJTARIFAVALOR(String strOEFJTARIFAVALOR) {
		this.strOEFJTARIFAVALOR = strOEFJTARIFAVALOR;
	}
	public String getStrOEFJTARIFAPERC() {
		return strOEFJTARIFAPERC;
	}
	public void setStrOEFJTARIFAPERC(String strOEFJTARIFAPERC) {
		this.strOEFJTARIFAPERC = strOEFJTARIFAPERC;
	}
	public String getStrOEFJTARIFAMINIMA() {
		return strOEFJTARIFAMINIMA;
	}
	public void setStrOEFJTARIFAMINIMA(String strOEFJTARIFAMINIMA) {
		this.strOEFJTARIFAMINIMA = strOEFJTARIFAMINIMA;
	}
	public String getStrOEFJTARIFAMAXIMA() {
		return strOEFJTARIFAMAXIMA;
	}
	public void setStrOEFJTARIFAMAXIMA(String strOEFJTARIFAMAXIMA) {
		this.strOEFJTARIFAMAXIMA = strOEFJTARIFAMAXIMA;
	}
	public String getStrNomeCedente() {
		return strNomeCedente;
	}
	public void setStrNomeCedente(String strNomeCedente) {
		this.strNomeCedente = strNomeCedente;
	}
	public String getStrNomeSacado() {
		return strNomeSacado;
	}
	public void setStrNomeSacado(String strNomeSacado) {
		this.strNomeSacado = strNomeSacado;
	}
	public ArrayOfStringDTO getArrBoletoVR() {
		return arrBoletoVR;
	}
	public void setArrBoletoVR(ArrayOfStringDTO arrBoletoVR) {
		this.arrBoletoVR = arrBoletoVR;
	}
	public String getStrtxtTipo() {
		return strtxtTipo;
	}
	public void setStrtxtTipo(String strtxtTipo) {
		this.strtxtTipo = strtxtTipo;
	}
	public String getStrtxtBandeira() {
		return strtxtBandeira;
	}
	public void setStrtxtBandeira(String strtxtBandeira) {
		this.strtxtBandeira = strtxtBandeira;
	}
	
	

}
