package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;


public class ItemConvenioProdutoDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private BancoDTO banco;
	private String nomeConvenio;
	private String comprovanteLote;
	private String numeroPessoa;
	private String codigoTipoPessoa;
	private String numeroDocumentoPessoa;
	private String indicadorConta;
	private String indicadorInclusao;
	private String indicadorProcessar;
	private String indicadorCompromisso;
	private String indicadorListaDebito;
	private String indicadorSacadoEletronico;
	private String tipoAutorizacao;
	private String todos;
	

	public String getTodos() {
		return todos;
	}

	public void setTodos(String todos) {
		this.todos = todos;
	}

	/**
	 * @return the nomeConvenio
	 */
	public String getNomeConvenio() {
		return nomeConvenio;
	}

	/**
	 * @param nomeConvenio
	 *            the nomeConvenio to set
	 */
	public void setNomeConvenio(String nomeConvenio) {
		this.nomeConvenio = nomeConvenio;
	}

	/**
	 * @return the comprovanteLote
	 */
	public String getComprovanteLote() {
		return comprovanteLote;
	}

	/**
	 * @param comprovanteLote
	 *            the comprovanteLote to set
	 */
	public void setComprovanteLote(String comprovanteLote) {
		this.comprovanteLote = comprovanteLote;
	}

	/**
	 * @return the numeroPessoa
	 */
	public String getNumeroPessoa() {
		return numeroPessoa;
	}

	/**
	 * @param numeroPessoa
	 *            the numeroPessoa to set
	 */
	public void setNumeroPessoa(String numeroPessoa) {
		this.numeroPessoa = numeroPessoa;
	}

	/**
	 * @return the codigoTipoPessoa
	 */
	public String getCodigoTipoPessoa() {
		return codigoTipoPessoa;
	}

	/**
	 * @param codigoTipoPessoa
	 *            the codigoTipoPessoa to set
	 */
	public void setCodigoTipoPessoa(String codigoTipoPessoa) {
		this.codigoTipoPessoa = codigoTipoPessoa;
	}

	/**
	 * @return the numeroDocumentoPessoa
	 */
	public String getNumeroDocumentoPessoa() {
		return numeroDocumentoPessoa;
	}

	/**
	 * @param numeroDocumentoPessoa
	 *            the numeroDocumentoPessoa to set
	 */
	public void setNumeroDocumentoPessoa(String numeroDocumentoPessoa) {
		this.numeroDocumentoPessoa = numeroDocumentoPessoa;
	}

	/**
	 * @return the indicadorConta
	 */
	public String getIndicadorConta() {
		return indicadorConta;
	}

	/**
	 * @param indicadorConta
	 *            the indicadorConta to set
	 */
	public void setIndicadorConta(String indicadorConta) {
		this.indicadorConta = indicadorConta;
	}

	/**
	 * @return the indicadorInclusao
	 */
	public String getIndicadorInclusao() {
		return indicadorInclusao;
	}

	/**
	 * @param indicadorInclusao
	 *            the indicadorInclusao to set
	 */
	public void setIndicadorInclusao(String indicadorInclusao) {
		this.indicadorInclusao = indicadorInclusao;
	}

	/**
	 * @return the indicadorProcessar
	 */
	public String getIndicadorProcessar() {
		return indicadorProcessar;
	}

	/**
	 * @param indicadorProcessar
	 *            the indicadorProcessar to set
	 */
	public void setIndicadorProcessar(String indicadorProcessar) {
		this.indicadorProcessar = indicadorProcessar;
	}

	/**
	 * @return the indicadorCompromisso
	 */
	public String getIndicadorCompromisso() {
		return indicadorCompromisso;
	}

	/**
	 * @param indicadorCompromisso
	 *            the indicadorCompromisso to set
	 */
	public void setIndicadorCompromisso(String indicadorCompromisso) {
		this.indicadorCompromisso = indicadorCompromisso;
	}

	/**
	 * @return the indicadorListaDebito
	 */
	public String getIndicadorListaDebito() {
		return indicadorListaDebito;
	}

	/**
	 * @param indicadorListaDebito
	 *            the indicadorListaDebito to set
	 */
	public void setIndicadorListaDebito(String indicadorListaDebito) {
		this.indicadorListaDebito = indicadorListaDebito;
	}

	/**
	 * @return the indicadorSacadoEletronico
	 */
	public String getIndicadorSacadoEletronico() {
		return indicadorSacadoEletronico;
	}

	/**
	 * @param indicadorSacadoEletronico
	 *            the indicadorSacadoEletronico to set
	 */
	public void setIndicadorSacadoEletronico(String indicadorSacadoEletronico) {
		this.indicadorSacadoEletronico = indicadorSacadoEletronico;
	}

	/**
	 * @return the tipoAutorizacao
	 */
	public String getTipoAutorizacao() {
		return tipoAutorizacao;
	}

	/**
	 * @param tipoAutorizacao
	 *            the tipoAutorizacao to set
	 */
	public void setTipoAutorizacao(String tipoAutorizacao) {
		this.tipoAutorizacao = tipoAutorizacao;
	}

	
	/**
	 * @return the bancoDTO
	 */
	public BancoDTO getBanco() {
		return banco;
	}

	/**
	 * @param bancoDTO the bancoDTO to set
	 */
	public void setBanco(BancoDTO banco) {
		this.banco= banco;
	}
	
}
