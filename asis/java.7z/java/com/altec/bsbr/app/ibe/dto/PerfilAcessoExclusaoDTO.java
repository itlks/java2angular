package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

import com.altec.bsbr.app.ibe.mocks.PerfilUsuario;

public class PerfilAcessoExclusaoDTO implements Serializable{

	private static final long serialVersionUID = 1L;

	private PerfilUsuario perfilUsuario;

	public PerfilUsuario getPerfilUsuario() {
		return perfilUsuario;
	}

	public void setPerfilUsuario(PerfilUsuario perfilUsuario) {
		this.perfilUsuario = perfilUsuario;
	}
	
	
}
