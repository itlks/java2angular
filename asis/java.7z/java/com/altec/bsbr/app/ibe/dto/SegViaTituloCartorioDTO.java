package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

import com.altec.bsbr.app.ibe.util.UtilFunction;

public class SegViaTituloCartorioDTO extends GenericDTO implements Serializable {
	private static final long serialVersionUID = 1098095989842217717L;

	private String banco;
	private String agencia;
	private String conta;
	private String codigoDoCanal;
	private String descricaoDoCanal;
	private String referOper;
	private String dataInicial;
	private String dataFinal;
	private String numDocSacado;
	private String meioPagamento;
	private String agenciaPagamento;
	private String horarioPagamento;
	private String indicadorRearranque;
	private String codCra;
	private String chaveUnica;
	private String dataLimitePagamento;
	private String nomeRazaoSocial;
	private double valorTotal;
	private int idCartorio;
	private String codUf;
	private String codMunicipio;
	private String descMunicipio;
	private String codEspecieTitulo;
	private String descEspecieTitulo;
	private String nomeCedente;
	private String nomeRazaoSocialSacadoAva;
	private double valorTitulo;
	private String codNsuPagamento;
	private String protocolo;
	private String dataProtocolo;
	private String numTitulo;
	private String dataVencimentoTitulo;
	private double valorCustoEmolumento;
	private String dataPagamento;
	private boolean selecionado;

	public SegViaTituloCartorioDTO() {
	}

	public String getCodCra() {
		return codCra;
	}

	public void setCodCra(String codCra) {
		this.codCra = codCra;
	}

	public String getCodUf() {
		return codUf;
	}

	public void setCodUf(String codUf) {
		this.codUf = codUf;
	}
	
	public String getCodMunicipio() {
		return codMunicipio;
	}

	public void setCodMunicipio(String codMunicipio) {
		this.codMunicipio = codMunicipio;
	}

	public String getCodEspecieTitulo() {
		return codEspecieTitulo;
	}

	public void setCodEspecieTitulo(String codEspecieTitulo) {
		this.codEspecieTitulo = codEspecieTitulo;
	}

	public String getNomeCedente() {
		return nomeCedente;
	}

	public void setNomeCedente(String nomeCedente) {
		this.nomeCedente = nomeCedente;
	}

	public String getNomeRazaoSocialSacadoAva() {
		return nomeRazaoSocialSacadoAva;
	}

	public void setNomeRazaoSocialSacadoAva(String nomeRazaoSocialSacadoAva) {
		this.nomeRazaoSocialSacadoAva = nomeRazaoSocialSacadoAva;
	}

	public String getCodNsuPagamento() {
		return codNsuPagamento;
	}

	public void setCodNsuPagamento(String codNsuPagamento) {
		this.codNsuPagamento = codNsuPagamento;
	}

	public void setValorCustoEmolumento(double valorCustoEmolumento) {
		this.valorCustoEmolumento = valorCustoEmolumento;
	}

	public String getIndicadorRearranque() {
		return indicadorRearranque;
	}

	public void setIndicadorRearranque(String indicadorRearranque) {
		this.indicadorRearranque = indicadorRearranque;
	}

	public String getHorarioPagamento() {
		return horarioPagamento;
	}

	public void setHorarioPagamento(String horarioPagamento) {
		this.horarioPagamento = horarioPagamento;
	}

	public String getAgenciaPagamento() {
		return agenciaPagamento;
	}

	public void setAgenciaPagamento(String agenciaPagamento) {
		this.agenciaPagamento = agenciaPagamento;
	}

	public String getMeioPagamento() {
		return meioPagamento;
	}

	public void setMeioPagamento(String meioPagamento) {
		this.meioPagamento = meioPagamento;
	}

	public String getNumDocSacado() {
		return numDocSacado;
	}

	public void setNumDocSacado(String numDocSacado) {
		this.numDocSacado = numDocSacado;
	}
	
	public String getNumDocSacadoFormatado() {
		return UtilFunction.formatarCpfCnpj(this.numDocSacado);
	}

	public String getDataInicial() {
		return dataInicial;
	}

	public void setDataInicial(String dataInicial) {
		this.dataInicial = dataInicial;
	}

	public String getDataFinal() {
		return dataFinal;
	}

	public void setDataFinal(String dataFinal) {
		this.dataFinal = dataFinal;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getConta() {
		return conta;
	}

	public void setConta(String conta) {
		this.conta = conta;
	}

	public String getDescricaoDoCanal() {
		return descricaoDoCanal;
	}

	public void setDescricaoDoCanal(String descricaoDoCanal) {
		this.descricaoDoCanal = descricaoDoCanal;
	}
	
	public String getCodigoDoCanal() {
		return codigoDoCanal;
	}

	public void setCodigoDoCanal(String codigoDoCanal) {
		this.codigoDoCanal = codigoDoCanal;
	}

	public String getReferOper() {
		return referOper;
	}

	public void setReferOper(String referOper) {
		this.referOper = referOper;
	}

	public String getChaveUnica() {
		return chaveUnica;
	}

	public void setChaveUnica(String chaveUnica) {
		this.chaveUnica = chaveUnica;
	}

	public String getNomeRazaoSocial() {
		return nomeRazaoSocial;
	}

	public void setNomeRazaoSocial(String nomeRazao) {
		this.nomeRazaoSocial = nomeRazao;
	}

	public int getIdCartorio() {
		return idCartorio;
	}

	public void setIdCartorio(int idCartorio) {
		this.idCartorio = idCartorio;
	}

	public String getDescMunicipio() {
		return descMunicipio;
	}

	public void setDescMunicipio(String descMunicipio) {
		this.descMunicipio = descMunicipio;
	}

	public String getProtocolo() {
		return protocolo;
	}

	public void setProtocolo(String protocolo) {
		this.protocolo = protocolo;
	}

	public String getDataProtocolo() {
		return dataProtocolo;
	}

	public void setDataProtocolo(String dataProtocolo) {
		this.dataProtocolo = dataProtocolo;
	}

	public String getDataLimitePagamento() {
		return this.formatDateFromService(dataLimitePagamento);
	}

	public void setDataLimitePagamento(String dataLimitePagamento) {
		this.dataLimitePagamento = dataLimitePagamento;
	}

	public String getNumTitulo() {
		return numTitulo;
	}

	public void setNumTitulo(String numTitulo) {
		this.numTitulo = numTitulo;
	}

	public String getDescEspecieTitulo() {
		return descEspecieTitulo;
	}

	public void setDescEspecieTitulo(String descEspecieTitulo) {
		this.descEspecieTitulo = descEspecieTitulo;
	}

	public String getDataVencimentoTitulo() {
		return this.formatDateFromService(dataVencimentoTitulo);
	}

	public void setDataVencimentoTitulo(String dataVencimentoTitulo) {
		this.dataVencimentoTitulo = dataVencimentoTitulo;
	}

	public double getValorTitulo() {
		return valorTitulo;
	}

	public void setValorTitulo(double valorTitulo) {
		this.valorTitulo = valorTitulo;
	}

	public double getValorCustoEmolumento() {
		return valorCustoEmolumento;
	}

	public double getValorTotal() {
		return valorTotal;
	}

	public void setValorTotal(double valorTotal) {
		this.valorTotal = valorTotal;
	}

	public String getDataPagamento() {
		return this.formatDateFromService(dataPagamento);
	}

	public void setDataPagamento(String dataPagamento) {
		this.dataPagamento = dataPagamento;
	}

	public boolean isSelecionado() {
		return selecionado;
	}

	public void setSelecionado(boolean selecionado) {
		this.selecionado = selecionado;
	}
	
	private String formatDateFromService(String date) {
		if (date != null && !UtilFunction.validarFormatoDataHoraByPattern(date, "dd/MM/yyyy")) {
			date = UtilFunction.formataMascaraData(date, "yyyy-MM-dd", "dd/MM/yyyy");
		}
		return date;
	}
}