package com.altec.bsbr.app.ibe.dto;

import java.util.ArrayList;
import java.util.List;

public class GrupoTransacaoLimiteDiarioDTO {
	private String grupoTransacao;
	private List<TransacaoLimiteDiarioDTO> listaTransacoes = new ArrayList<TransacaoLimiteDiarioDTO>();
	

	public String getGrupoTransacao() {
		return grupoTransacao;
	}
	
	public GrupoTransacaoLimiteDiarioDTO(String grupoTransacao, List<TransacaoLimiteDiarioDTO> listaTransacoes) {
		this.grupoTransacao = grupoTransacao;
		this.listaTransacoes = listaTransacoes;
	}

	public void setGrupoTransacao(String grupoTransacao) {
		this.grupoTransacao = grupoTransacao;
	}

	public List<TransacaoLimiteDiarioDTO> getListaTransacoes() {
		return listaTransacoes;
	}

	public void setListaTransacoes(List<TransacaoLimiteDiarioDTO> listaTransacoes) {
		this.listaTransacoes = listaTransacoes;
	}
	
}
