package com.altec.bsbr.app.ibe.dto.agendamentos;

import java.io.Serializable;

public class ConcessionariaDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -668861656787524605L;

	private String tipoConcessionaria;

	private String codigoBarras;

	public String getTipoConcessionaria() {
		return tipoConcessionaria;
	}

	public void setTipoConcessionaria(String tipoConcessionaria) {
		this.tipoConcessionaria = tipoConcessionaria;
	}

	public String getCodigoBarras() {
		return codigoBarras;
	}

	public void setCodigoBarras(String codigoBarras) {
		this.codigoBarras = codigoBarras;
	}

}
