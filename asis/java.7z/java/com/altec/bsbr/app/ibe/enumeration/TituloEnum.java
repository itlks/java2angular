package com.altec.bsbr.app.ibe.enumeration;

import java.awt.Color;

public enum TituloEnum {
	
	TITULOVENCIDO ("T�TULOS VENCIDOS",new Color(255, 74, 57)),
	TITULOAVENCER ("T�TULOS A VENCER",new Color(255, 127, 23));


	private String descricao;
	private Color cor;

	private TituloEnum( String descricao, Color cor) {
		this.descricao=descricao;
		this.cor=cor;
	}

	public String getDescricao() {
		return descricao;
	}

	public Color getCor() {
		return cor;
	}

	
}
