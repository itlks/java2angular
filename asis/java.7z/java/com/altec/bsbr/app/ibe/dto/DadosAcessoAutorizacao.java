package com.altec.bsbr.app.ibe.dto;

/**
 * Dados para montar a tabela de uma unica linha
 */
public class DadosAcessoAutorizacao {

	private String agenciaConta;
	private String perfilAcesso;
	private String perfilAutorizacao;

	public DadosAcessoAutorizacao() { 
		//
	}

	public DadosAcessoAutorizacao(String agenciaConta, String perfilAcesso, String perfilAutorizacao) {
		super();
		this.agenciaConta = agenciaConta;
		this.perfilAcesso = perfilAcesso;
		this.perfilAutorizacao = perfilAutorizacao;
	}

	/**
	 * @return the agenciaConta
	 */
	public String getAgenciaConta() {
		return agenciaConta;
	}


	/**
	 * @return the perfilAcesso
	 */
	public String getPerfilAcesso() {
		return "".equals(perfilAcesso) || perfilAcesso == null? "<-- SEM ACESSO -->" :perfilAcesso;
	}


	/**
	 * @return the perfilAutorizacao
	 */
	public String getPerfilAutorizacao() {
		return perfilAutorizacao;
	}

	
}