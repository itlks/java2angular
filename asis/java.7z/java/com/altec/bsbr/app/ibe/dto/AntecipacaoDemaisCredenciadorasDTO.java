package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import com.altec.bsbr.app.ibe.anotation.Hash;

public class AntecipacaoDemaisCredenciadorasDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4622764765788269519L;
	
	@Hash(position = 1)
	private String strValorSolicitacao;

	public String getStrValorSolicitacao() {
		return strValorSolicitacao;
	}

	public void setStrValorSolicitacao(String strValorSolicitacao) {
		this.strValorSolicitacao = strValorSolicitacao;
	}

}
