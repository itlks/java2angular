package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;

import com.altec.bsbr.app.ibe.util.UtilFunction;
import com.altec.bsbr.app.ibe.web.jsf.converter.CodigoBarrasConverter;

public class SegundaViaComprTitulosDTO  extends GenericDTO implements Serializable {

	private static final long serialVersionUID = -7629269744537793521L;
	
	private String banco;
	private String agencia;
	private String conta;		
	private String codigoUsuario;
	private String hostAddress;
	private String canal;
	
	private String dataInicial;
	private String dataFinal;
	
	private String canalPagamento;
	private String formaPagamento;	
	private String codigoBarras;
	private String horaTransacao;
	private String dataTransacao;
	private String autenticacaoBancaria;
	private String nossoNumero;
	private String pagador; 	
	private String dataVencimento;
	private String dataPagamento;
	
	private String razaoSacado;
	private String contaSacado;
	private String digitoSacado;
	private String bancoSacado;
	private String nomeSacado;
	
	private String dataContabil;	
	private String nsuPagamento;	
	private String codigoCedente;		
	private String nomeCedente;
	private String tipoTitulo;
	private String tipoPessoa;
	private BigDecimal valorDesconto;
	private BigDecimal valorMoraMulta;
	private BigDecimal valorPago; 
	private BigDecimal valorDocumento;
	
	private String nomeInstFinanc; //OECCNMIFBENEFI;
	private String nroDocCedente; //OECCNRCPFCNPJCEDE;
	private String nomeFantasiaCedente; //OECCNMFANTCEDE;
	private String tipoDocCedente; //OECCTPDOCTCEDE;
	private String tipoDocAvalista; //OECCTPDOCTAVAL;
	private String tipoDocSacado; //OECCTPDOCTSACD;
	private String tipoDocPagador; //OECCTPDOCTPGAD;
	private String nroDocAvalista; //OECCNRCPFCNPJAVAL;
	private String nomeAvalista; //OECCNMAVALTITU;
	private String nomeFantasiaAvalista; //OECCNMFANTAVALTITU;
	private String nroDocSacado; //OECCNRCPFCNPJSACD;
	private String nroDocPagador; //OECCNRCPFCNPJPGAD;
	private String nomePagador; //OECCNMPGADTITU;
		
	private Integer contratoCartao;
	private String bancoCartao;
	private String agenciaCartao;
	private String contaCartao;
	
	private String codigoCliente;
	
	private String nroDocCedenteFormatado;
	private String nroDocAvalistaFormatado;
	private String nroDocSacadoFormatado;
	private String nroDocPagadorFormatado;
	
	private String nomeOuRazaoSocialCedente;
	private String nomeOuRazaoSocialAvalista;
	private String nomeOuRazaoSocialSacado;
	private String nomeOuRazaoSocialPagador;
	
	private boolean selecionado;
	
	public SegundaViaComprTitulosDTO() {	
	}
		
	public String getCanal() {
		return canal;
	}
	public void setCanal(String canal) {
		this.canal = canal;
	}

	public boolean isSelecionado() {
		return selecionado;
	}

	public void setSelecionado(boolean selecionado) {
		this.selecionado = selecionado;
	}

	public String getDataInicial() {
		return dataInicial;
	}

	public void setDataInicial(String dataInicial) {
		this.dataInicial = dataInicial;
	}

	public String getDataFinal() {
		return dataFinal;
	}

	public void setDataFinal(String dataFinal) {
		this.dataFinal = dataFinal;
	}

	public String getDataPagamento() {
		return dataPagamento;
	}

	public void setDataPagamento(String dataPagamento) {
		this.dataPagamento = dataPagamento;
	}

	public String getDataTransacao() {
		return dataTransacao;
	}

	public void setDataTransacao(String dataTransacao) {
		this.dataTransacao = dataTransacao;
	}

	public String getAutenticacaoBancaria() {
		return autenticacaoBancaria;
	}

	public void setAutenticacaoBancaria(String autenticacaoBancaria) {
		this.autenticacaoBancaria = autenticacaoBancaria;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getConta() {
		return conta;
	}

	public void setConta(String conta) {
		this.conta = conta;
	}

	public String getCanalPagamento() {
		return canalPagamento;
	}

	public void setCanalPagamento(String canalPagamento) {
		this.canalPagamento = canalPagamento;
	}

	public String getCanalPagamentoCaseSensitive() {
		return UtilFunction.convertStringToCaseSensitive(canalPagamento);		
	}

	public String getCanalPagamentoUpperCase() {
		String retorno=canalPagamento;
		if (canalPagamento!=null) {
			retorno = canalPagamento.toUpperCase().trim();			
		}
		return retorno; 
	}
	
	public String getCodigoUsuario() {
		return codigoUsuario;
	}

	public void setCodigoUsuario(String codigoUsuario) {
		this.codigoUsuario = codigoUsuario;
	}

	public String getHostAddress() {
		return hostAddress;
	}

	public void setHostAddress(String hostAddress) {
		this.hostAddress = hostAddress;
	}
	
	public String getHoraTransacao() {
		return horaTransacao;
	}

	public void setHoraTransacao(String horaTransacao) {
		this.horaTransacao = horaTransacao;
	}

	public String getFormaPagamento() {
		return formaPagamento;
	}

	public void setFormaPagamento(String formaPagamento) {
		this.formaPagamento = formaPagamento;
	}

	public String getCodigoBarras() {
		return codigoBarras;
	}

	public String getCodigoBarrasFormatado() {
		return new CodigoBarrasConverter().getAsString(null, null, codigoBarras);		
	}
	
	public void setCodigoBarras(String codigoBarras) {
		this.codigoBarras = codigoBarras;
	}

	public BigDecimal getValorDocumento() {
		return valorDocumento;
	}

	public void setValorDocumento(BigDecimal valorDocumento) {
		this.valorDocumento = valorDocumento;
	}

	public String getNossoNumero() {
		return nossoNumero;
	}

	public void setNossoNumero(String nossoNumero) {
		this.nossoNumero = nossoNumero;
	}

	public String getPagador() {
		return pagador;
	}

	public void setPagador(String pagador) {
		this.pagador = pagador;
	}

	public String getDataVencimento() {
		return dataVencimento;
	}

	public void setDataVencimento(String dataVencimento) {
		this.dataVencimento = dataVencimento;
	}

	public BigDecimal getValorPago() {
		return valorPago;
	}

	public void setValorPago(BigDecimal valorPago) {
		this.valorPago = valorPago;
	}

	public String getRazaoSacado() {
		return razaoSacado;
	}

	public void setRazaoSacado(String razaoSacado) {
		this.razaoSacado = razaoSacado;
	}

	public String getContaSacado() {
		return contaSacado;
	}

	public void setContaSacado(String contaSacado) {
		this.contaSacado = contaSacado;
	}

	public String getDigitoSacado() {
		return digitoSacado;
	}

	public void setDigitoSacado(String digitoSacado) {
		this.digitoSacado = digitoSacado;
	}

	public String getBancoSacado() {
		return bancoSacado;
	}

	public void setBancoSacado(String bancoSacado) {
		this.bancoSacado = bancoSacado;
	}

	public String getNomeSacado() {
		return nomeSacado;
	}

	public void setNomeSacado(String nomeSacado) {
		this.nomeSacado = nomeSacado;
	}

	public String getDataContabil() {
		return dataContabil;
	}

	public void setDataContabil(String dataContabil) {
		this.dataContabil = dataContabil;
	}

	public String getNsuPagamento() {
		return nsuPagamento;
	}

	public void setNsuPagamento(String nsuPagamento) {
		this.nsuPagamento = nsuPagamento;
	}

	public String getCodigoCedente() {
		return codigoCedente;
	}

	public void setCodigoCedente(String codigoCedente) {
		this.codigoCedente = codigoCedente;
	}

	public String getNomeCedente() {
		return nomeCedente;
	}

	public void setNomeCedente(String nomeCedente) {
		this.nomeCedente = nomeCedente;
	}

	public BigDecimal getValorDesconto() {
		return valorDesconto;
	}

	public void setValorDesconto(BigDecimal valorDesconto) {
		this.valorDesconto = valorDesconto;
	}

	public BigDecimal getValorMoraMulta() {
		return valorMoraMulta;
	}

	public void setValorMoraMulta(BigDecimal valorMoraMulta) {
		this.valorMoraMulta = valorMoraMulta;
	}

	public String getTipoTitulo() {
		return tipoTitulo;
	}

	public void setTipoTitulo(String tipoTitulo) {
		this.tipoTitulo = tipoTitulo;
	}

	public Integer getContratoCartao() {
		return contratoCartao;
	}

	public void setContratoCartao(Integer contratoCartao) {
		this.contratoCartao = contratoCartao;
	}

	public String getCodigoCliente() {
		return codigoCliente;
	}

	public void setCodigoCliente(String codigoCliente) {
		this.codigoCliente = codigoCliente;
	}

	public String getBancoCartao() {
		return bancoCartao;
	}

	public void setBancoCartao(String bancoCartao) {
		this.bancoCartao = bancoCartao;
	}

	public String getAgenciaCartao() {
		return agenciaCartao;
	}

	public void setAgenciaCartao(String agenciaCartao) {
		this.agenciaCartao = agenciaCartao;
	}

	public String getContaCartao() {
		return contaCartao;
	}

	public void setContaCartao(String contaCartao) {
		this.contaCartao = contaCartao;
	}

	public String getTipoPessoa() {
		return tipoPessoa;
	}

	public void setTipoPessoa(String tipoPessoa) {
		this.tipoPessoa = tipoPessoa;
	}
	
	public String getNomeInstFinanc() {
		return nomeInstFinanc;
	}

	public void setNomeInstFinanc(String nomeInstFinanc) {
		this.nomeInstFinanc = nomeInstFinanc;
	}

	public String getNroDocCedente() {
		return nroDocCedente;
	}

	public void setNroDocCedente(String nroDocCedente) {
		this.nroDocCedente = nroDocCedente;
	}

	public String getNomeFantasiaCedente() {
		return nomeFantasiaCedente;
	}

	public void setNomeFantasiaCedente(String nomeFantasiaCedente) {
		this.nomeFantasiaCedente = nomeFantasiaCedente;
	}

	public String getTipoDocCedente() {
		return tipoDocCedente;
	}

	public void setTipoDocCedente(String tipoDocCedente) {
		this.tipoDocCedente = tipoDocCedente;
	}

	public String getTipoDocAvalista() {
		return tipoDocAvalista;
	}

	public void setTipoDocAvalista(String tipoDocAvalista) {
		this.tipoDocAvalista = tipoDocAvalista;
	}

	public String getTipoDocSacado() {
		return tipoDocSacado;
	}

	public void setTipoDocSacado(String tipoDocSacado) {
		this.tipoDocSacado = tipoDocSacado;
	}

	public String getTipoDocPagador() {
		return tipoDocPagador;
	}

	public void setTipoDocPagador(String tipoDocPagadorEfetivo) {
		this.tipoDocPagador = tipoDocPagadorEfetivo;
	}

	public String getNroDocAvalista() {
		return nroDocAvalista;
	}

	public void setNroDocAvalista(String nroDocAvalista) {
		this.nroDocAvalista = nroDocAvalista;
	}

	public String getNomeAvalista() {
		return nomeAvalista;
	}

	public void setNomeAvalista(String nomeAvalista) {
		this.nomeAvalista = nomeAvalista;
	}

	public String getNomeFantasiaAvalista() {
		return nomeFantasiaAvalista;
	}

	public void setNomeFantasiaAvalista(String nomeFantasiaAvalista) {
		this.nomeFantasiaAvalista = nomeFantasiaAvalista;
	}

	public String getNroDocSacado() {
		return nroDocSacado;
	}

	public void setNroDocSacado(String nroDocSacado) {
		this.nroDocSacado = nroDocSacado;
	}

	public String getNroDocPagador() {
		return nroDocPagador;
	}

	public void setNroDocPagador(String nroDocPagador) {
		this.nroDocPagador = nroDocPagador;
	}

	public String getNomePagador() {
		return nomePagador;
	}

	public void setNomePagador(String nomePagador) {
		this.nomePagador = nomePagador;
	}

	public String getNomeOuRazaoSocialCedente() {
		return nomeOuRazaoSocialCedente;
	}

	public void setNomeOuRazaoSocialCedente(String nomeOuRazaoSocialCedente) {
		this.nomeOuRazaoSocialCedente = nomeOuRazaoSocialCedente;
	}

	public String getNomeOuRazaoSocialAvalista() {
		return nomeOuRazaoSocialAvalista;
	}

	public void setNomeOuRazaoSocialAvalista(String nomeOuRazaoSocialAvalista) {
		this.nomeOuRazaoSocialAvalista = nomeOuRazaoSocialAvalista;
	}

	public String getNroDocCedenteFormatado() {
		return nroDocCedenteFormatado;
	}

	public void setNroDocCedenteFormatado(String nroDocCedenteFormatado) {
		this.nroDocCedenteFormatado = nroDocCedenteFormatado;
	}

	public String getNroDocAvalistaFormatado() {
		return nroDocAvalistaFormatado;
	}

	public void setNroDocAvalistaFormatado(String nroDocAvalistaFormatado) {
		this.nroDocAvalistaFormatado = nroDocAvalistaFormatado;
	}

	public String getNroDocSacadoFormatado() {
		return nroDocSacadoFormatado;
	}

	public void setNroDocSacadoFormatado(String nroDocSacadoFormatado) {
		this.nroDocSacadoFormatado = nroDocSacadoFormatado;
	}

	public String getNroDocPagadorFormatado() {
		return nroDocPagadorFormatado;
	}

	public void setNroDocPagadorFormatado(String nroDocPagadorFormatado) {
		this.nroDocPagadorFormatado = nroDocPagadorFormatado;
	}

	public String getNomeOuRazaoSocialSacado() {
		return nomeOuRazaoSocialSacado;
	}

	public void setNomeOuRazaoSocialSacado(String nomeOuRazaoSocialSacado) {
		this.nomeOuRazaoSocialSacado = nomeOuRazaoSocialSacado;
	}

	public String getNomeOuRazaoSocialPagador() {
		return nomeOuRazaoSocialPagador;
	}

	public void setNomeOuRazaoSocialPagador(String nomeOuRazaoSocialPagador) {
		this.nomeOuRazaoSocialPagador = nomeOuRazaoSocialPagador;
	}
}