package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class PacoteServicoDTO extends GenericDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer codigo;
	private String banco;
	private String agencia;
	private String conta;
	private String pacote;
	private Integer diaDebito;
	private BigDecimal valorPacote;
	private String valorPacoteFormatado;
	private String canal;
	private String referOper;
	private String codigoUsuario;
	private String hostAddress;	
	private List<ItemPacoteServicoDTO> lstDetalhe;
	private List<PacoteServicoDTO> listaPacotesDisponiveis;
	private String dtinire;
	private String penumpe;
	private String termoAceite;
	private String autenticacaoBancaria;
	private String dataTransacao;
	private String horaTransacao;

	private boolean selecionado;
	private boolean pacoteAtual;
	private boolean diaDebitoEditavel;
	private boolean pacoteAgendado;
	
	public boolean isSelecionado() {
		return selecionado;
	}

	public void setSelecionado(boolean selecionado) {
		this.selecionado = selecionado;
	}

	public PacoteServicoDTO () {
		lstDetalhe =  new ArrayList<ItemPacoteServicoDTO>(); 
	}
	
	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getConta() {
		return conta;
	}

	public void setConta(String conta) {
		this.conta = conta;
	}

	public Integer getDiaDebito() {
		return diaDebito;
	}

	public void setDiaDebito(Integer diaDebito) {
		this.diaDebito = diaDebito;
	}

	public BigDecimal getValorPacote() {
		return valorPacote;
	}

	public void setValorPacote(BigDecimal valorPacote) {
		this.valorPacote = valorPacote;
	}

	public String getValorPacoteFormatado() {
		return valorPacoteFormatado;
	}

	public void setValorPacoteFormatado(String valorPacoteFormatado) {
		this.valorPacoteFormatado = valorPacoteFormatado;
	}

	public List<ItemPacoteServicoDTO> getLstDetalhe() {
		return lstDetalhe;
	}

	public void setLstDetalhe(List<ItemPacoteServicoDTO> lstDetalhe) {
		this.lstDetalhe = lstDetalhe;
	}

	public String getPacote() {
		return pacote;
	}

	public void setPacote(String pacote) {
		this.pacote = pacote;
	}

	public String getCanal() {
		return canal;
	}

	public void setCanal(String canal) {
		this.canal = canal;
	}

	public String getCodigoUsuario() {
		return codigoUsuario;
	}

	public void setCodigoUsuario(String codigoUsuario) {
		this.codigoUsuario = codigoUsuario;
	}

	public String getHostAddress() {
		return hostAddress;
	}

	public void setHostAddress(String hostAddress) {
		this.hostAddress = hostAddress;
	}

	public String getReferOper() {
		return referOper;
	}

	public void setReferOper(String referOper) {
		this.referOper = referOper;
	}

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public boolean isPacoteAtual() {
		return pacoteAtual;
	}

	public void setPacoteAtual(boolean pacoteAtual) {
		this.pacoteAtual = pacoteAtual;
	}
	
	public List<PacoteServicoDTO> getListaPacotesDisponiveis() {
		return listaPacotesDisponiveis;
	}

	public void setListaPacotesDisponiveis(List<PacoteServicoDTO> listaPacotesDisponiveis) {
		this.listaPacotesDisponiveis = listaPacotesDisponiveis;
	}

	public String getTermoAceite() {
		return termoAceite;
	}

	public void setTermoAceite(String termoAceite) {
		this.termoAceite = termoAceite;
	}

	public String getAutenticacaoBancaria() {
		return autenticacaoBancaria;
	}

	public void setAutenticacaoBancaria(String autenticacaoBancaria) {
		this.autenticacaoBancaria = autenticacaoBancaria;
	}
	
	public String getDataTransacao() {
		return dataTransacao;
	}

	public void setDataTransacao(String dataTransacao) {
		this.dataTransacao = dataTransacao;
	}

	public String getHoraTransacao() {
		return horaTransacao;
	}

	public void setHoraTransacao(String horaTransacao) {
		this.horaTransacao = horaTransacao;
	}

	public String getDtinire() {
		return dtinire;
	}

	public void setDtinire(String dtinire) {
		this.dtinire = dtinire;
	}

	public String getPenumpe() {
		return penumpe;
	}

	public void setPenumpe(String penumpe) {
		this.penumpe = penumpe;
	}

	public boolean isDiaDebitoEditavel() {
		return diaDebitoEditavel;
	}

	public void setDiaDebitoEditavel(boolean diaDebitoEditavel) {
		this.diaDebitoEditavel = diaDebitoEditavel;
	}

	public boolean isPacoteAgendado() {
		return pacoteAgendado;
	}

	public void setPacoteAgendado(boolean pacoteAgendado) {
		this.pacoteAgendado = pacoteAgendado;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((agencia == null) ? 0 : agencia.hashCode());
		result = prime * result + ((banco == null) ? 0 : banco.hashCode());
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		result = prime * result + ((conta == null) ? 0 : conta.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof PacoteServicoDTO)) {
			return false;
		}
		PacoteServicoDTO other = (PacoteServicoDTO) obj;
		if (agencia == null) {
			if (other.agencia != null) {
				return false;
			}
		} else if (!agencia.equals(other.agencia)) {
			return false;
		}
		if (banco == null) {
			if (other.banco != null) {
				return false;
			}
		} else if (!banco.equals(other.banco)) {
			return false;
		}
		if (codigo == null) {
			if (other.codigo != null) {
				return false;
			}
		} else if (!codigo.equals(other.codigo)) {
			return false;
		}
		if (conta == null) {
			if (other.conta != null) {
				return false;
			}
		} else if (!conta.equals(other.conta)) {
			return false;
		}
		return true;
	}
	
}
