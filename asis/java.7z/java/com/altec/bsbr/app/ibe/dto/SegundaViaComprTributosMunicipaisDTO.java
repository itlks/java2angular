package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.altec.bsbr.app.ibe.util.UtilFunction;

public class SegundaViaComprTributosMunicipaisDTO extends GenericDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String banco;
	private String agencia;
	private String conta;
	private String codigoUsuario;
	private String hostAddress;
	private String canal;

	private String dataInicial;
	private String dataFinal;

	private String canalPagamento;

	private String empresa;
	private String convenio;
	private String codigoBarras;
	private String dataPagamento;
	private BigDecimal valorPago;
	private String horaTransacao;
	private String dataTransacao;
	private String autenticacaoBancaria;
	private String tipoConta;

	private String Nio;
	private Integer MaxSeqNio;
	private String Tabela;

	private String dataMov;
	private String seqArre;
	private String codigoCliente;	
	private boolean selecionado;
	
	private List<DadosTributosMunicipaisDTO> dados;

	public SegundaViaComprTributosMunicipaisDTO() {
		this.dados = new ArrayList<DadosTributosMunicipaisDTO>();
	}
	
	public String getNio() {
		return Nio;
	}

	public void setNio(String nio) {
		Nio = nio;
	}

	public Integer getMaxSeqNio() {
		return MaxSeqNio;
	}

	public void setMaxSeqNio(Integer maxSeqNio) {
		MaxSeqNio = maxSeqNio;
	}

	public String getTabela() {
		return Tabela;
	}

	public void setTabela(String tabela) {
		Tabela = tabela;
	}

	public String getCanal() {
		return canal;
	}

	public void setCanal(String canal) {
		this.canal = canal;
	}

	public boolean isSelecionado() {
		return selecionado;
	}

	public void setSelecionado(boolean selecionado) {
		this.selecionado = selecionado;
	}

	public String getDataInicial() {
		return dataInicial;
	}

	public void setDataInicial(String dataInicial) {
		this.dataInicial = dataInicial;
	}

	public String getDataFinal() {
		return dataFinal;
	}

	public void setDataFinal(String dataFinal) {
		this.dataFinal = dataFinal;
	}

	public BigDecimal getValorPago() {
		return valorPago;
	}

	public void setValorPago(BigDecimal valorPago) {
		this.valorPago = valorPago;
	}

	public String getDataPagamento() {
		return dataPagamento;
	}

	public void setDataPagamento(String dataPagamento) {
		this.dataPagamento = dataPagamento;
	}

	public String getDataTransacao() {
		return dataTransacao;
	}

	public void setDataTransacao(String dataTransacao) {
		this.dataTransacao = dataTransacao;
	}

	public String getAutenticacaoBancaria() {
		return autenticacaoBancaria;
	}

	public void setAutenticacaoBancaria(String autenticacaoBancaria) {
		this.autenticacaoBancaria = autenticacaoBancaria;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getConta() {
		return conta;
	}

	public void setConta(String conta) {
		this.conta = conta;
	}

	public String getCanalPagamento() {
		return canalPagamento;
	}

	public void setCanalPagamento(String canalPagamento) {
		this.canalPagamento = canalPagamento;
	}

	public String getCanalPagamentoCaseSensitive() {
		return UtilFunction.convertStringToCaseSensitive(canalPagamento);
	}

	public String getCanalPagamentoUpperCase() {
		String retorno = canalPagamento;
		if (canalPagamento != null) {
			retorno = canalPagamento.toUpperCase().trim();
		}
		return retorno;
	}

	public String getCodigoUsuario() {
		return codigoUsuario;
	}

	public void setCodigoUsuario(String codigoUsuario) {
		this.codigoUsuario = codigoUsuario;
	}

	public String getHostAddress() {
		return hostAddress;
	}

	public void setHostAddress(String hostAddress) {
		this.hostAddress = hostAddress;
	}

	public String getHoraTransacao() {
		return horaTransacao;
	}

	public void setHoraTransacao(String horaTransacao) {
		this.horaTransacao = horaTransacao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((agencia == null) ? 0 : agencia.hashCode());
		result = prime * result + ((autenticacaoBancaria == null) ? 0 : autenticacaoBancaria.hashCode());
		result = prime * result + ((banco == null) ? 0 : banco.hashCode());
		result = prime * result + ((canal == null) ? 0 : canal.hashCode());
		result = prime * result + ((canalPagamento == null) ? 0 : canalPagamento.hashCode());
		result = prime * result + ((codigoUsuario == null) ? 0 : codigoUsuario.hashCode());
		result = prime * result + ((conta == null) ? 0 : conta.hashCode());
		result = prime * result + ((dataFinal == null) ? 0 : dataFinal.hashCode());
		result = prime * result + ((dataTransacao == null) ? 0 : dataTransacao.hashCode());
		result = prime * result + ((dataInicial == null) ? 0 : dataInicial.hashCode());
		result = prime * result + ((dataPagamento == null) ? 0 : dataPagamento.hashCode());
		result = prime * result + ((horaTransacao == null) ? 0 : horaTransacao.hashCode());
		result = prime * result + ((hostAddress == null) ? 0 : hostAddress.hashCode());
		result = prime * result + (selecionado ? 1231 : 1237);
		result = prime * result + ((valorPago == null) ? 0 : valorPago.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof SegundaViaComprTributosMunicipaisDTO)) {
			return false;
		}
		SegundaViaComprTributosMunicipaisDTO other = (SegundaViaComprTributosMunicipaisDTO) obj;
		if (agencia == null) {
			if (other.agencia != null) {
				return false;
			}
		} else if (!agencia.equals(other.agencia)) {
			return false;
		}
		if (autenticacaoBancaria == null) {
			if (other.autenticacaoBancaria != null) {
				return false;
			}
		} else if (!autenticacaoBancaria.equals(other.autenticacaoBancaria)) {
			return false;
		}
		if (banco == null) {
			if (other.banco != null) {
				return false;
			}
		} else if (!banco.equals(other.banco)) {
			return false;
		}
		if (canal == null) {
			if (other.canal != null) {
				return false;
			}
		} else if (!canal.equals(other.canal)) {
			return false;
		}
		if (canalPagamento == null) {
			if (other.canalPagamento != null) {
				return false;
			}
		} else if (!canalPagamento.equals(other.canalPagamento)) {
			return false;
		}
		if (codigoUsuario == null) {
			if (other.codigoUsuario != null) {
				return false;
			}
		} else if (!codigoUsuario.equals(other.codigoUsuario)) {
			return false;
		}
		if (conta == null) {
			if (other.conta != null) {
				return false;
			}
		} else if (!conta.equals(other.conta)) {
			return false;
		}
		if (dataFinal == null) {
			if (other.dataFinal != null) {
				return false;
			}
		} else if (!dataFinal.equals(other.dataFinal)) {
			return false;
		}
		if (dataTransacao == null) {
			if (other.dataTransacao != null) {
				return false;
			}
		} else if (!dataTransacao.equals(other.dataTransacao)) {
			return false;
		}
		if (dataInicial == null) {
			if (other.dataInicial != null) {
				return false;
			}
		} else if (!dataInicial.equals(other.dataInicial)) {
			return false;
		}
		if (dataPagamento == null) {
			if (other.dataPagamento != null) {
				return false;
			}
		} else if (!dataPagamento.equals(other.dataPagamento)) {
			return false;
		}
		if (horaTransacao == null) {
			if (other.horaTransacao != null) {
				return false;
			}
		} else if (!horaTransacao.equals(other.horaTransacao)) {
			return false;
		}
		if (hostAddress == null) {
			if (other.hostAddress != null) {
				return false;
			}
		} else if (!hostAddress.equals(other.hostAddress)) {
			return false;
		}
		if (selecionado != other.selecionado) {
			return false;
		}
		if (valorPago == null) {
			if (other.valorPago != null) {
				return false;
			}
		} else if (!valorPago.equals(other.valorPago)) {
			return false;
		}
		return true;
	}

	public String getDataMov() {
		return dataMov;
	}

	public void setDataMov(String dataMov) {
		this.dataMov = dataMov;
	}

	public String getSeqArre() {
		return seqArre;
	}

	public void setSeqArre(String seqArre) {
		this.seqArre = seqArre;
	}

	public String getTipoConta() {
		return tipoConta;
	}

	public void setTipoConta(String tipoConta) {
		this.tipoConta = tipoConta;
	}

	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}

	public String getConvenio() {
		return convenio;
	}

	public void setConvenio(String convenio) {
		this.convenio = convenio;
	}

	public String getCodigoBarras() {
		return codigoBarras;
	}

	public void setCodigoBarras(String codigoBarras) {
		this.codigoBarras = codigoBarras;
	}

	public String getCodigoCliente() {
		return codigoCliente;
	}

	public void setCodigoCliente(String codigoCliente) {
		this.codigoCliente = codigoCliente;
	}
	
	public List<DadosTributosMunicipaisDTO> getDados() {
		return dados;
	}
	public void setDados(List<DadosTributosMunicipaisDTO> dados) {
		this.dados = dados;
	}
}
