package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class AparelhoDTO implements Serializable {
	
	private static final long serialVersionUID = -355624841120592755L;
	private String nomeCompl;
	private String cpf;
	private String aparelho;
	private String status;
	
	
	public AparelhoDTO(String nome, String cpf, String aparelho, String status){
		this.nomeCompl = nome;
		this.cpf = cpf;
		this.aparelho = aparelho;
		this.status = status;
	}
	
	public String getNomeCompl() {
		return nomeCompl;
	}
	public void setNomeCompl(String nomeCompl) {
		this.nomeCompl = nomeCompl;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getAparelho() {
		return aparelho;
	}
	public void setAparelho(String aparelho) {
		this.aparelho = aparelho;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

}
