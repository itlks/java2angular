package com.altec.bsbr.app.ibe.dto;

import java.util.Date;

import com.altec.bsbr.app.ibe.dto.debitoautomatico.consultarSuspensaoTemporaria.SuspensaoTemporariaDTO;

public class DebitoAutomaticoSuspensaoExcluirDTO {

	private SuspensaoTemporariaDTO suspensao;
	private String codigoNSU;
	private Date dataHoraTransacao;
	private String autenticacaoBancaria;

	public String getCodigoNSU() {
		return codigoNSU;
	}

	public void setCodigoNSU(String codigoNSU) {
		this.codigoNSU = codigoNSU;
	}

	public SuspensaoTemporariaDTO getSuspensao() {
		return suspensao;
	}

	public void setSuspensao(SuspensaoTemporariaDTO suspensao) {
		this.suspensao = suspensao;
	}

	/**
	 * @return the dataHoraTransacao
	 */
	public Date getDataHoraTransacao() {
		return dataHoraTransacao;
	}

	/**
	 * @param dataHoraTransacao the dataHoraTransacao to set
	 */
	public void setDataHoraTransacao(Date dataHoraTransacao) {
		this.dataHoraTransacao = dataHoraTransacao;
	}

	/**
	 * @return the autenticacaoBancaria
	 */
	public String getAutenticacaoBancaria() {
		return autenticacaoBancaria;
	}

	/**
	 * @param autenticacaoBancaria the autenticacaoBancaria to set
	 */
	public void setAutenticacaoBancaria(String autenticacaoBancaria) {
		this.autenticacaoBancaria = autenticacaoBancaria;
	}

	

}
