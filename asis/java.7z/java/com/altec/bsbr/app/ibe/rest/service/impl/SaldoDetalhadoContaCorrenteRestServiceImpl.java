
/*
 * Cheque Ades�o Empresa Protegido (Service Rest implementa��o para controle de fluxo)
 *
 */
package com.altec.bsbr.app.ibe.rest.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.altec.bsbr.app.ibe.dto.SaldoDetalhadoContaCorrenteRequestDTO;
import com.altec.bsbr.app.ibe.dto.SaldoDetalhadoContaCorrenteResponseDTO;
import com.altec.bsbr.app.ibe.rest.hub.HubRest;
import com.altec.bsbr.app.ibe.rest.hub.dto.HubRestResourceDTO;
import com.altec.bsbr.app.ibe.rest.service.SaldoDetalhadoContaCorrenteRestService;
import com.altec.bsbr.app.ibe.util.MensagensRetorno;
import com.altec.bsbr.app.ibe.util.UtilFunction;
import com.altec.bsbr.app.ibe.web.jsf.attributes.AtributosDaSessao;
import com.altec.bsbr.fw.BusinessException;

@Service
public class SaldoDetalhadoContaCorrenteRestServiceImpl implements SaldoDetalhadoContaCorrenteRestService {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1775144186799431684L;
	private static final Logger LOGGER = LoggerFactory.getLogger(SaldoDetalhadoContaCorrenteRestServiceImpl.class);
	private static final int NUMERO_DOZE = 12;
	private static final int NUMERO_QUATRO = 4;
	private static final int NUMERO_DUZENTOS = 200;

	@Autowired
	@Qualifier("saldoDetalhadoContaCorrente_UY86")	
	private transient HubRestResourceDTO resource;
	
	@Autowired
	private transient HubRest hubRest;
	
	public SaldoDetalhadoContaCorrenteRestServiceImpl() {
		LOGGER.info("Inicializando classe ChequeEspecialProtegidoDelegateServiceImpl");
	}
	@Override
	public SaldoDetalhadoContaCorrenteResponseDTO adesao(final AtributosDaSessao session) throws BusinessException{
		SaldoDetalhadoContaCorrenteRequestDTO request = getRequest(session);
		SaldoDetalhadoContaCorrenteResponseDTO saldoDetalhadoResponse = new SaldoDetalhadoContaCorrenteResponseDTO();
		try {
			ResponseEntity<SaldoDetalhadoContaCorrenteResponseDTO> response;
			response = hubRest.postForEntity(resource.getUrl(), request, SaldoDetalhadoContaCorrenteResponseDTO.class);
			if ( null != response &&  response.getStatusCode().value() == NUMERO_DUZENTOS ){
				saldoDetalhadoResponse = response.getBody();
				LOGGER.debug("ADES�O HubRest Consultado com SUCESSO !!!!");
			}
		} catch (Exception e) {
			LOGGER.error("Exception [InvestimentoHomeRestServiceImpl] consultarInvestimentos : [{}]" , e);
		}
		return saldoDetalhadoResponse;
	}
	
	public SaldoDetalhadoContaCorrenteRequestDTO getRequest(final AtributosDaSessao session){
		final SaldoDetalhadoContaCorrenteRequestDTO saldodetalhadocontacorrenterequestdto = new SaldoDetalhadoContaCorrenteRequestDTO();
		saldodetalhadocontacorrenterequestdto.setLogLevel("00");
		saldodetalhadocontacorrenterequestdto.setLegacyProgramCode("");
		saldodetalhadocontacorrenterequestdto.setAreaSize("00863");
		saldodetalhadocontacorrenterequestdto.setResponseQueueName("");
		saldodetalhadocontacorrenterequestdto.setMessageType("N");
		saldodetalhadocontacorrenterequestdto.setProcessType("1");
		saldodetalhadocontacorrenterequestdto.setChannelCode("06");
		saldodetalhadocontacorrenterequestdto.setTransactionName("UY86");
		saldodetalhadocontacorrenterequestdto.setAltairUserAcronym("DHN0001");
		saldodetalhadocontacorrenterequestdto.setCicsUserAcronym("COMTNETH");
		saldodetalhadocontacorrenterequestdto.setMessageFormatCode("P");
		saldodetalhadocontacorrenterequestdto.setFinancialEntity("0033");
		saldodetalhadocontacorrenterequestdto.setAccountingBranch(UtilFunction.preencherZeroEsquerda(session.getAgencia(), NUMERO_QUATRO));
		saldodetalhadocontacorrenterequestdto.setTransaction("UY86");
		saldodetalhadocontacorrenterequestdto.setOperationType("N");
		saldodetalhadocontacorrenterequestdto.setAccountingDate("");
		saldodetalhadocontacorrenterequestdto.setChannel("06");
		saldodetalhadocontacorrenterequestdto.setOperationReference("MBB359AA5FFA81285E58BAE");
		saldodetalhadocontacorrenterequestdto.setPaymentInstrumentCode("CB");
		saldodetalhadocontacorrenterequestdto.setTransactionKey("");
		saldodetalhadocontacorrenterequestdto.setOperationReversalReference("");
		saldodetalhadocontacorrenterequestdto.setOriginDate(UtilFunction.dataAtualString("yyyyMMdd"));
		saldodetalhadocontacorrenterequestdto.setOriginTime(UtilFunction.dataAtualString("HHmmss"));
		saldodetalhadocontacorrenterequestdto.setClientCodeType("1");
		saldodetalhadocontacorrenterequestdto.setScheduleIndicator("N");
		saldodetalhadocontacorrenterequestdto.setAuthenticationNumber("0000");
		saldodetalhadocontacorrenterequestdto.setModuleType("");
		saldodetalhadocontacorrenterequestdto.setTerminalType("00");
		saldodetalhadocontacorrenterequestdto.setPabNumber("0000000");
		saldodetalhadocontacorrenterequestdto.setChannelVersion("000000");
		saldodetalhadocontacorrenterequestdto.setTerminalNumber("");
		saldodetalhadocontacorrenterequestdto.setUserAcronym("");
		saldodetalhadocontacorrenterequestdto.setOperatorNumber("000000");
		saldodetalhadocontacorrenterequestdto.setOperatorRegistration("000000");
		saldodetalhadocontacorrenterequestdto.setSupervisorNumber("000000");
		saldodetalhadocontacorrenterequestdto.setSupervisorRegistration("000000");
		saldodetalhadocontacorrenterequestdto.setMessageMAC("");
		saldodetalhadocontacorrenterequestdto.setCryptographedPAN("");
		saldodetalhadocontacorrenterequestdto.setCryptographedPANContinuation("");
		saldodetalhadocontacorrenterequestdto.setAccountEntity("0033");
		saldodetalhadocontacorrenterequestdto.setAccountBranch(UtilFunction.preencherZeroEsquerda(session.getAgencia(), NUMERO_QUATRO));
		saldodetalhadocontacorrenterequestdto.setAccountNumber(UtilFunction.preencherZeroEsquerda(session.getConta(), NUMERO_DOZE));
		saldodetalhadocontacorrenterequestdto.setAccountType("CC");
		saldodetalhadocontacorrenterequestdto.setChannelData("O                             N");
		saldodetalhadocontacorrenterequestdto.setRequestType("01");
		saldodetalhadocontacorrenterequestdto.setResponseIndicator("D");

		return saldodetalhadocontacorrenterequestdto;
	}

}