package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;


public class ManutencaoRecargaProgramadaResponseDTO extends GenericDTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1610121830573772553L;
	
	private String codigoArea;
	private Integer numCelular;
	private BigDecimal valorRecarga;
	private String numProtocolo;
	private String numTransacao;
	private String descMsg;
	private String codigoProduto;
	private String codigoSubproduto;
	private String codigoSegmento;
	private String descConvenio;
	private List<ListaComprovanteDTO> listaComprovante;
	private AvisoRecargaDTO aviso;
	private String descricaoErro;
	
	/**
	 * @return the codigoArea
	 */
	public String getCodigoArea() {
		return codigoArea;
	}
	/**
	 * @param codigoArea the codigoArea to set
	 */
	public void setCodigoArea(String codigoArea) {
		this.codigoArea = codigoArea;
	}
	/**
	 * @return the numCelular
	 */
	public Integer getNumCelular() {
		return numCelular;
	}
	/**
	 * @param numCelular the numCelular to set
	 */
	public void setNumCelular(Integer numCelular) {
		this.numCelular = numCelular;
	}
	/**
	 * @return the valorRecarga
	 */
	public BigDecimal getValorRecarga() {
		return valorRecarga;
	}
	/**
	 * @param valorRecarga the valorRecarga to set
	 */
	public void setValorRecarga(BigDecimal valorRecarga) {
		this.valorRecarga = valorRecarga;
	}
	/**
	 * @return the numProtocolo
	 */
	public String getNumProtocolo() {
		return numProtocolo;
	}
	/**
	 * @param numProtocolo the numProtocolo to set
	 */
	public void setNumProtocolo(String numProtocolo) {
		this.numProtocolo = numProtocolo;
	}
	/**
	 * @return the numTransacao
	 */
	public String getNumTransacao() {
		return numTransacao;
	}
	/**
	 * @param numTransacao the numTransacao to set
	 */
	public void setNumTransacao(String numTransacao) {
		this.numTransacao = numTransacao;
	}
	/**
	 * @return the descMsg
	 */
	public String getDescMsg() {
		return descMsg;
	}
	/**
	 * @param descMsg the descMsg to set
	 */
	public void setDescMsg(String descMsg) {
		this.descMsg = descMsg;
	}
	/**
	 * @return the codigoProduto
	 */
	public String getCodigoProduto() {
		return codigoProduto;
	}
	/**
	 * @param codigoProduto the codigoProduto to set
	 */
	public void setCodigoProduto(String codigoProduto) {
		this.codigoProduto = codigoProduto;
	}
	/**
	 * @return the codigoSubproduto
	 */
	public String getCodigoSubproduto() {
		return codigoSubproduto;
	}
	/**
	 * @param codigoSubproduto the codigoSubproduto to set
	 */
	public void setCodigoSubproduto(String codigoSubproduto) {
		this.codigoSubproduto = codigoSubproduto;
	}
	/**
	 * @return the codigoSegmento
	 */
	public String getCodigoSegmento() {
		return codigoSegmento;
	}
	/**
	 * @param codigoSegmento the codigoSegmento to set
	 */
	public void setCodigoSegmento(String codigoSegmento) {
		this.codigoSegmento = codigoSegmento;
	}
	/**
	 * @return the descConvenio
	 */
	public String getDescConvenio() {
		return descConvenio;
	}
	/**
	 * @param descConvenio the descConvenio to set
	 */
	public void setDescConvenio(String descConvenio) {
		this.descConvenio = descConvenio;
	}
	/**
	 * @return the listaComprovante
	 */
	public List<ListaComprovanteDTO> getListaComprovante() {
		return listaComprovante;
	}
	/**
	 * @param listaComprovante the listaComprovante to set
	 */
	public void setListaComprovante(List<ListaComprovanteDTO> listaComprovante) {
		this.listaComprovante = listaComprovante;
	}
	/**
	 * @return the aviso
	 */
	public AvisoRecargaDTO getAviso() {
		return aviso;
	}
	/**
	 * @param aviso the aviso to set
	 */
	public void setAviso(AvisoRecargaDTO aviso) {
		this.aviso = aviso;
	}
	public String getDescricaoErro() {
		return descricaoErro;
	}
	public void setDescricaoErro(String descricaoErro) {
		this.descricaoErro = descricaoErro;
	}
	
	

}
