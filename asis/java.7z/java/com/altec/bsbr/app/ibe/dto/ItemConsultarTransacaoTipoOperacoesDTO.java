package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

import org.apache.poi.util.StringUtil;

import com.altec.bsbr.app.ba.util.StringUtils;

public class ItemConsultarTransacaoTipoOperacoesDTO implements Serializable {
	
	private static final long serialVersionUID = 8447340482851484709L;

	private String dataTransacao;
	
	private String horaTransacao;
	
	private String valor;
	
	private String nomeTransacao;
	
	private String idTransacao;
	
	private String codigoAgencia;
	
	private String contaCorrente;
	
	private String nomeUsuario;
	
	private String numeroAutenticacao;
	
	private String nomePagina;
	
	private boolean selecionado;

	private String nomeServico;
	
	private String nomeProduto;
	
	private OperacoesRealizadaTransacaoResponseDTO operacao;
	
	
	/**
	 * @return the nomeServico
	 */
	public String getNomeServico() {
		return nomeServico;
	}
	/**
	 * @param nomeServico the nomeServico to set
	 */
	public void setNomeServico(String nomeServico) {
		this.nomeServico = nomeServico;
	}
	/**
	 * @return the nomeProduto
	 */
	public String getNomeProduto() {
		return nomeProduto;
	}
	/**
	 * @param nomeProduto the nomeProduto to set
	 */
	public void setNomeProduto(String nomeProduto) {
		this.nomeProduto = nomeProduto;
	}
	/**
	 * @return the numeroAutenticacao
	 */
	public String getNumeroAutenticacao() {
		return numeroAutenticacao;
	}
	/**
	 * @param numeroAutenticacao the numeroAutenticacao to set
	 */
	public void setNumeroAutenticacao(String numeroAutenticacao) {
		this.numeroAutenticacao = numeroAutenticacao;
	}
	/**
	 * @return the codigoAgencia
	 */
	public String getCodigoAgencia() {
		return codigoAgencia;
	}
	/**
	 * @param codigoAgencia the codigoAgencia to set
	 */
	public void setCodigoAgencia(String codigoAgencia) {
		this.codigoAgencia = codigoAgencia;
	}
	/**
	 * @return the contaCorrente
	 */
	public String getContaCorrente() {
		return contaCorrente;
	}
	/**
	 * @param contaCorrente the contaCorrente to set
	 */
	public void setContaCorrente(String contaCorrente) {
		this.contaCorrente = contaCorrente;
	}
	/**
	 * @return the nomeUsuario
	 */
	public String getNomeUsuario() {
		return nomeUsuario;
	}
	/**
	 * @param nomeUsuario the nomeUsuario to set
	 */
	public void setNomeUsuario(String nomeUsuario) {
		this.nomeUsuario = nomeUsuario;
	}
	
	/**
	 * @return the selecionado
	 */
	public boolean isSelecionado() {
		return selecionado;
	}
	/**
	 * @param selecionado the selecionado to set
	 */
	public void setSelecionado(boolean selecionado) {
		this.selecionado = selecionado;
	}
	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	 
	/**
	 * @return the dataTransacao
	 */
	public String getDataTransacao() {
		return dataTransacao;
	}

	/**
	 * @param dataTransacao the dataTransacao to set
	 */
	public void setDataTransacao(String dataTransacao) {
		this.dataTransacao = dataTransacao;
	}

	/**
	 * @return the horaTransacao
	 */
	public String getHoraTransacao() {
		return horaTransacao;
	}

	/**
	 * @param horaTransacao the horaTransacao to set
	 */
	public void setHoraTransacao(String horaTransacao) {
		this.horaTransacao = horaTransacao;
	}

	/**
	 * @return the valorTransacao
	 */
	public String getValor() {
		return valor;
	}

	/**
	 * @param valorTransacao the valorTransacao to set
	 */
	public void setValor(String valor) {
		this.valor = valor;
	}

	/**
	 * @return the nomeTransacao
	 */
	public String getNomeTransacao() {
		return nomeTransacao;
	}

	/**
	 * @param nomeTransacao the nomeTransacao to set
	 */
	public void setNomeTransacao(String nomeTransacao) {
		this.nomeTransacao = nomeTransacao;
	}
	/**
	 * @return the idTransacao
	 */
	public String getIdTransacao() {
		return idTransacao;
	}
	/**
	 * @param idTransacao the idTransacao to set
	 */
	public void setIdTransacao(String idTransacao) {
		this.idTransacao = idTransacao;
	}
	public String getNomePagina() {
			return nomePagina;
	
		
	}
	public void setNomePagina(String nomePagina) {
		this.nomePagina = nomePagina;
	}
	
	public OperacoesRealizadaTransacaoResponseDTO getOperacao() {
		return operacao;
	}
	public void setOperacao(OperacoesRealizadaTransacaoResponseDTO operacao) {
		this.operacao = operacao;
	}
	

}
