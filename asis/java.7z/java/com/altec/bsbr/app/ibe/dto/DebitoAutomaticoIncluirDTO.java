package com.altec.bsbr.app.ibe.dto;

import java.util.Date;

import com.altec.bsbr.app.ibe.anotation.Hash;
import com.altec.bsbr.app.ibe.enumeration.FormaPagamentoEnum;
import com.altec.bsbr.app.ibe.web.util.ConverterUtil;

public class DebitoAutomaticoIncluirDTO {

	private String tipoConta;
	private String empresaConveniada;
	
	
	private String identificacaoConsumidor;
	private boolean limiteMaximoDebito;
	
	@Hash(position = 1)
	private String limiteMaximoAutorizado;
	private boolean emitirAvisoCorreio;
	private String historicoComplementar;
	private FormaPagamentoEnum formaPagamentoSelecionado;
	private CartaoCreditoParceladoDTO cartaoSelecionado;
	private Date dataHoraTransacao;
	private String autenticacaoBancaria;
	private String entidadBr;
	private String sucursalBr;
	private String nroCuentaBr;
	

	public String getTipoConta() {
		return tipoConta;
	}

	public void setTipoConta(String tipoConta) {
		this.tipoConta = tipoConta;
	}

	public String getEmpresaConveniada() {
		return empresaConveniada;
	}

	public void setEmpresaConveniada(String empresaConveniada) {
		this.empresaConveniada = empresaConveniada;
	}

	public String getIdentificacaoConsumidor() {
		return identificacaoConsumidor;
	}

	public void setIdentificacaoConsumidor(String identificacaoConsumidor) {
		this.identificacaoConsumidor = identificacaoConsumidor;
	}

	public boolean getLimiteMaximoDebito() {
		return limiteMaximoDebito;
	}

	public void setLimiteMaximoDebito(boolean limiteMaximoDebito) {
		this.limiteMaximoDebito = limiteMaximoDebito;
	}

	public String getLimiteMaximoAutorizado() {
		return limiteMaximoAutorizado;
	}

	public void setLimiteMaximoAutorizado(String limiteMaximoAutorizado) {
		this.limiteMaximoAutorizado = limiteMaximoAutorizado;
	}

	public boolean getEmitirAvisoCorreio() {
		return emitirAvisoCorreio;
	}

	public void setEmitirAvisoCorreio(boolean emitirAvisoCorreio) {
		this.emitirAvisoCorreio = emitirAvisoCorreio;
	}

	public String getHistoricoComplementar() {
		return historicoComplementar;
	}

	public void setHistoricoComplementar(String historicoComplementar) {
		this.historicoComplementar = historicoComplementar;
	}

	public FormaPagamentoEnum getFormaPagamentoSelecionado() {
		return formaPagamentoSelecionado;
	}

	public void setFormaPagamentoSelecionado(FormaPagamentoEnum formaPagamentoSelecionado) {
		this.formaPagamentoSelecionado = formaPagamentoSelecionado;
	}

	public CartaoCreditoParceladoDTO getCartaoSelecionado() {
		return cartaoSelecionado;
	}

	public void setCartaoSelecionado(CartaoCreditoParceladoDTO cartaoSelecionado) {
		this.cartaoSelecionado = cartaoSelecionado;
	}

	public Date getDataHoraTransacao() {
		return dataHoraTransacao;
	}

	public void setDataHoraTransacao(Date dataHoraTransacao) {
		this.dataHoraTransacao = dataHoraTransacao;
	}

	public String getAutenticacaoBancaria() {
		return autenticacaoBancaria;
	}

	public void setAutenticacaoBancaria(String autenticacaoBancaria) {
		this.autenticacaoBancaria = autenticacaoBancaria;
	}

	public String getEntidadBr() {
		return entidadBr;
	}

	public void setEntidadBr(String entidadBr) {
		this.entidadBr = entidadBr;
	}

	public String getSucursalBr() {
		return sucursalBr;
	}

	public void setSucursalBr(String sucursalBr) {
		this.sucursalBr = sucursalBr;
	}

	public String getNroCuentaBr() {
		return nroCuentaBr;
	}

	public void setNroCuentaBr(String nroCuentaBr) {
		this.nroCuentaBr = nroCuentaBr;
	}

	
	public String getDataHoraFormatada(){
		return ConverterUtil.dateToString(getDataHoraTransacao(), "dd/MM/yyyy - HH:mm:ss");
	}
	
}
