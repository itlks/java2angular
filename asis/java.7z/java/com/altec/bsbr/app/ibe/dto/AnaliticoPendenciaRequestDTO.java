package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.List;


public class AnaliticoPendenciaRequestDTO implements Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1;

	private String index;
	
	private List<AutorizacoesPendenciaDadosSinteticaDTO> listaSintetica;

	
	public List<AutorizacoesPendenciaDadosSinteticaDTO> getListaSintetica() {
		return listaSintetica;
	}

	
	public void setListaSintetica(List<AutorizacoesPendenciaDadosSinteticaDTO> listaSintetica) {
		this.listaSintetica = listaSintetica;
	}


	
	public String getIndex() {
		return index;
	}


	
	public void setIndex(String index) {
		this.index = index;
	}
	
	
	
}

