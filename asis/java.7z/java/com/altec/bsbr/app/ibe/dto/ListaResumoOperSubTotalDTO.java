package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

public class ListaResumoOperSubTotalDTO  implements Serializable {

	private static final long serialVersionUID = -9159207532887902578L;
	
	private List<ListaResumoOperDTO> listaResumoOperDTO;
	private BigDecimal subTotal;

	public List<ListaResumoOperDTO> getListaResumoOperDTO() {
		return listaResumoOperDTO;
	}
	public void setListaResumoOperDTO(List<ListaResumoOperDTO> listaResumoOperDTO) {
		this.listaResumoOperDTO = listaResumoOperDTO;
	}
	public BigDecimal getSubTotal() {
		return subTotal;
	}
	public void setSubTotal(BigDecimal subTotal) {
		this.subTotal = subTotal;
	}
}
