package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.math.BigDecimal;


public class LimitesDTO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	/**
	 * Dados de apresenta��o na tela
	 * As letras referenciam as posi��es na tela 
	 */
	
	private String subTitulo;
	private int qtdeMaximaDiariaAutorizados; 
	private int qtdeMaximaDiariaNaoAutorizados; 
	private BigDecimal valorMaximoDiarioAutorizado; 
	private BigDecimal valorMaximoDiarioNaoAutorizado; 
	private BigDecimal valorMaximoTransacao;
	private BigDecimal valorMinimoTransacao; 
	private BigDecimal limiteGlobal; 
	private int qtdeDisponivelAutorizado; 
	private BigDecimal valorDisponivelAutorizado; 
	private int qtdeDisponivelNaoAutorizado; 
	private BigDecimal valorDisponivelNaoAutorizado; 
	
	/**
	 * Atributos de renderezi��o dos campos
	 */
	
	private boolean qtdeMaximaDiariaRender = false;
	private boolean valorMaximoDiarioRender= false;
	private boolean valorMaximoTransacaoRender = false;
	private boolean valorMinimoTransacaoRender = false;
	private boolean limiteGlobalRender = false;
	private boolean qtdeDisponivelRender = false;
	private boolean valorDisponivelRender = false;
	
	public int getQtdeMaximaDiariaAutorizados() {
		return qtdeMaximaDiariaAutorizados;
	}

	public void setQtdeMaximaDiariaAutorizados(int qtdeMaximaDiariaAutorizados) {
		this.qtdeMaximaDiariaAutorizados = qtdeMaximaDiariaAutorizados;
	}

	public int getQtdeMaximaDiariaNaoAutorizados() {
		return qtdeMaximaDiariaNaoAutorizados;
	}

	public void setQtdeMaximaDiariaNaoAutorizados(int qtdeMaximaDiariaNaoAutorizados) {
		this.qtdeMaximaDiariaNaoAutorizados = qtdeMaximaDiariaNaoAutorizados;
	}

	public BigDecimal getValorMaximoDiarioAutorizado() {
		return valorMaximoDiarioAutorizado;
	}

	public void setValorMaximoDiarioAutorizado(BigDecimal valorMaximoDiarioAutorizado) {
		this.valorMaximoDiarioAutorizado = valorMaximoDiarioAutorizado;
	}

	public BigDecimal getValorMaximoDiarioNaoAutorizado() {
		return valorMaximoDiarioNaoAutorizado;
	}

	public void setValorMaximoDiarioNaoAutorizado(BigDecimal valorMaximoDiarioNaoAutorizado) {
		this.valorMaximoDiarioNaoAutorizado = valorMaximoDiarioNaoAutorizado;
	}

	public BigDecimal getValorMaximoTransacao() {
		return valorMaximoTransacao;
	}

	public void setValorMaximoTransacao(BigDecimal valorMaximoTransacao) {
		this.valorMaximoTransacao = valorMaximoTransacao;
	}

	public BigDecimal getValorMinimoTransacao() {
		return valorMinimoTransacao;
	}

	public void setValorMinimoTransacao(BigDecimal valorMinimoTransacao) {
		this.valorMinimoTransacao = valorMinimoTransacao;
	}

	public BigDecimal getLimiteGlobal() {
		return limiteGlobal;
	}

	public void setLimiteGlobal(BigDecimal limiteGlobal) {
		this.limiteGlobal = limiteGlobal;
	}

	public int getQtdeDisponivelAutorizado() {
		return qtdeDisponivelAutorizado;
	}

	public void setQtdeDisponivelAutorizado(int qtdeDisponivelAutorizado) {
		this.qtdeDisponivelAutorizado = qtdeDisponivelAutorizado;
	}

	public BigDecimal getValorDisponivelAutorizado() {
		return valorDisponivelAutorizado;
	}

	public void setValorDisponivelAutorizado(BigDecimal valorDisponivelAutorizado) {
		this.valorDisponivelAutorizado = valorDisponivelAutorizado;
	}

	public int getQtdeDisponivelNaoAutorizado() {
		return qtdeDisponivelNaoAutorizado;
	}

	public void setQtdeDisponivelNaoAutorizado(int qtdeDisponivelNaoAutorizado) {
		this.qtdeDisponivelNaoAutorizado = qtdeDisponivelNaoAutorizado;
	}

	public BigDecimal getValorDisponivelNaoAutorizado() {
		return valorDisponivelNaoAutorizado;
	}

	public void setValorDisponivelNaoAutorizado(BigDecimal valorDisponivelNaoAutorizado) {
		this.valorDisponivelNaoAutorizado = valorDisponivelNaoAutorizado;
	}
	
	public boolean isQtdeMaximaDiariaRender() {
		return qtdeMaximaDiariaRender;
	}

	public void setQtdeMaximaDiariaRender(boolean qtdeMaximaDiariaRender) {
		this.qtdeMaximaDiariaRender = qtdeMaximaDiariaRender;
	}

	public boolean isValorMaximoDiarioRender() {
		return valorMaximoDiarioRender;
	}

	public void setValorMaximoDiarioRender(boolean valorMaximoDiarioRender) {
		this.valorMaximoDiarioRender = valorMaximoDiarioRender;
	}

	public boolean isValorMaximoTransacaoRender() {
		return valorMaximoTransacaoRender;
	}

	public void setValorMaximoTransacaoRender(boolean valorMaximoTransacaoRender) {
		this.valorMaximoTransacaoRender = valorMaximoTransacaoRender;
	}

	public boolean isValorMinimoTransacaoRender() {
		return valorMinimoTransacaoRender;
	}

	public void setValorMinimoTransacaoRender(boolean valorMinimoTransacaoRender) {
		this.valorMinimoTransacaoRender = valorMinimoTransacaoRender;
	}

	public boolean isLimiteGlobalRender() {
		return limiteGlobalRender;
	}

	public void setLimiteGlobalRender(boolean limiteGlobalRender) {
		this.limiteGlobalRender = limiteGlobalRender;
	}

	public boolean isQtdeDisponivelRender() {
		return qtdeDisponivelRender;
	}

	public void setQtdeDisponivelRender(boolean qtdeDisponivelRender) {
		this.qtdeDisponivelRender = qtdeDisponivelRender;
	}

	public boolean isValorDisponivelRender() {
		return valorDisponivelRender;
	}

	public void setValorDisponivelRender(boolean valorDisponivelRender) {
		this.valorDisponivelRender = valorDisponivelRender;
	}

	public String getSubTitulo() {
		return subTitulo;
	}

	public void setSubTitulo(String subTitulo) {
		this.subTitulo = subTitulo;
	}
 
}
