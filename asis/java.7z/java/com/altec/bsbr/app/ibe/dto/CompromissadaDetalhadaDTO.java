package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class CompromissadaDetalhadaDTO implements Serializable {

	private static final long serialVersionUID = 6660773043346049593L;

	private String dataInicio;
	private String dataVencimento;
	private String valorPrincipal;
	private String rendimento;
	private String imposto;
	private String saldo;
	private String titulo;
	private String lOVencimento;
	private String quantidade;
	private String taxa;

	/**
	 * @return the taxa
	 */
	public String getTaxa() {
		return taxa;
	}

	/**
	 * @param taxa the taxa to set
	 */
	public void setTaxa(String taxa) {
		this.taxa = taxa;
	}

	/**
	 * @return the dataInicio
	 */
	public String getDataInicio() {
		return dataInicio;
	}

	/**
	 * @param dataInicio
	 *            the dataInicio to set
	 */
	public void setDataInicio(String dataInicio) {
		this.dataInicio = dataInicio;
	}

	/**
	 * @return the dataVencimento
	 */
	public String getDataVencimento() {
		return dataVencimento;
	}

	/**
	 * @param dataVencimento
	 *            the dataVencimento to set
	 */
	public void setDataVencimento(String dataVencimento) {
		this.dataVencimento = dataVencimento;
	}

	/**
	 * @return the valorPrincipal
	 */
	public String getValorPrincipal() {
		return valorPrincipal;
	}

	/**
	 * @param valorPrincipal
	 *            the valorPrincipal to set
	 */
	public void setValorPrincipal(String valorPrincipal) {
		this.valorPrincipal = valorPrincipal;
	}

	/**
	 * @return the rendimento
	 */
	public String getRendimento() {
		return rendimento;
	}

	/**
	 * @param rendimento
	 *            the rendimento to set
	 */
	public void setRendimento(String rendimento) {
		this.rendimento = rendimento;
	}

	/**
	 * @return the imposto
	 */
	public String getImposto() {
		return imposto;
	}

	/**
	 * @param imposto
	 *            the imposto to set
	 */
	public void setImposto(String imposto) {
		this.imposto = imposto;
	}

	/**
	 * @return the saldo
	 */
	public String getSaldo() {
		return saldo;
	}

	/**
	 * @param saldo
	 *            the saldo to set
	 */
	public void setSaldo(String saldo) {
		this.saldo = saldo;
	}

	/**
	 * @return the titulo
	 */
	public String getTitulo() {
		return titulo;
	}

	/**
	 * @param titulo
	 *            the titulo to set
	 */
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	/**
	 * @return the lOVencimento
	 */
	public String getlOVencimento() {
		return lOVencimento;
	}

	/**
	 * @param lOVencimento
	 *            the lOVencimento to set
	 */
	public void setlOVencimento(String lOVencimento) {
		this.lOVencimento = lOVencimento;
	}

	/**
	 * @return the quantidade
	 */
	public String getQuantidade() {
		return quantidade;
	}

	/**
	 * @param quantidade
	 *            the quantidade to set
	 */
	public void setQuantidade(String quantidade) {
		this.quantidade = quantidade;
	}
}
