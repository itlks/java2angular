package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.altec.bsbr.app.ibe.enumeration.StatusUsuarioEnum;
import com.altec.bsbr.app.ibe.util.UtilFunction;
import com.altec.bsbr.app.ibe.util.WSFormat;

public class UsuarioSecundarioPerfisAcessoDTO implements Serializable {

	private static final long serialVersionUID = 4542145037551513764L;

	private Integer idUsuario;

	private String nomeUsuario;

	private String nomeAcesso;

	private String dataCriacao;

	private String numeroAgencia;

	private String numeroConta;

	private String statusUsuario;

	private String perfilAcesso;

	private String descricaoAcesso;

	private String nrSequPerfAcesSecu;

	private String inAcesMobl;

	private String nomeArea;

	private String dddTelefone;

	private String numeroTelefone;

	private String dddCelular;

	private String numeroCelular;

	private String cpf;
	
	private String nmPerfilAutorizacao;
	
	private String dsPerfilAutorizacao;
	
	private Integer nrPerfilAutorizacao;
	
	private List<UsuarioSecundarioConsultaPerfil> listaPerfis;
	
	private List<ItemConvenioConsultarDTO> listaConvenios;
	
	public UsuarioSecundarioPerfisAcessoDTO() {
		this.listaPerfis = new ArrayList<UsuarioSecundarioConsultaPerfil>();
		this.listaConvenios = new ArrayList<ItemConvenioConsultarDTO>();
	}

	public Integer getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}

	public String getNomeUsuario() {
		return nomeUsuario;
	}

	public void setNomeUsuario(String nomeUsuario) {
		this.nomeUsuario = nomeUsuario;
	}

	public String getNomeAcesso() {
		return nomeAcesso;
	}

	public void setNomeAcesso(String nomeAcesso) {
		this.nomeAcesso = nomeAcesso;
	}

	public String getDataCriacao() {
		String retorno = "";
		try{
		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		Date date = (Date)formatter.parse(dataCriacao);
		DateFormat saidaFormat = new SimpleDateFormat("dd/MM/yyyy");
		retorno = saidaFormat.format(date);
		}catch(Exception e){
			
		}
		return retorno;
	}

	public void setDataCriacao(String dataCriacao) {
		this.dataCriacao = dataCriacao;
	}

	public String getNumeroAgencia() {
		return numeroAgencia;
	}

	public void setNumeroAgencia(String numeroAgencia) {
		this.numeroAgencia = numeroAgencia;
	}

	public String getNumeroConta() {
		return numeroConta;
	}

	public void setNumeroConta(String numeroConta) {
		this.numeroConta = numeroConta;
	}

	public String getStatusUsuario() {
		return statusUsuario;
	}

	public String getStatusGridUsuario() {
		return  StatusUsuarioEnum.getById(statusUsuario).getDescricao();
	}
	
	public void setStatusUsuario(String statusUsuario) {
		this.statusUsuario = statusUsuario;
	}

	public String getPerfilAcesso() {
		return perfilAcesso;
	}

	public void setPerfilAcesso(String perfilAcesso) {
		this.perfilAcesso = perfilAcesso;
	}

	public String getDescricaoAcesso() {
		return descricaoAcesso;
	}

	public void setDescricaoAcesso(String descricaoAcesso) {
		this.descricaoAcesso = descricaoAcesso;
	}

	public String getNrSequPerfAcesSecu() {
		return nrSequPerfAcesSecu;
	}

	public void setNrSequPerfAcesSecu(String nrSequPerfAcesSecu) {
		this.nrSequPerfAcesSecu = nrSequPerfAcesSecu;
	}

	public String getInAcesMobl() {
		return inAcesMobl;
	}

	public void setInAcesMobl(String inAcesMobl) {
		this.inAcesMobl = inAcesMobl;
	}

	public String getNomeArea() {
		return nomeArea;
	}

	public void setNomeArea(String nomeArea) {
		this.nomeArea = nomeArea;
	}

	public String getDddTelefone() {
		return dddTelefone;
	}

	public void setDddTelefone(String dddTelefone) {
		this.dddTelefone = dddTelefone;
	}

	public String getNumeroTelefone() {
		return numeroTelefone;
	}

	public void setNumeroTelefone(String numeroTelefone) {
		this.numeroTelefone = numeroTelefone;
	}

	public String getDddCelular() {
		return dddCelular;
	}

	public void setDddCelular(String dddCelular) {
		this.dddCelular = dddCelular;
	}

	public String getNumeroCelular() {
		return numeroCelular;
	}

	public void setNumeroCelular(String numeroCelular) {
		this.numeroCelular = numeroCelular;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getAgenciaConta() {
		StringBuilder agenciaConta = new StringBuilder();
		if (!UtilFunction.isBlankOrNull(getNumeroAgencia())) {
			StringBuilder sb = new StringBuilder();

			String contaFormatada = StringUtils.leftPad(numeroConta, 9, "0");
			
			sb.append(WSFormat.formatarRetornoAgencia(numeroAgencia));
			sb.append(" ");
			sb.append(contaFormatada.substring(0, 2));
			sb.append("");
			sb.append(contaFormatada.substring(2, contaFormatada.length() - 1));
			sb.append("");
			sb.append(contaFormatada.substring(contaFormatada.length() - 1));
			
			return sb.toString();
		}
		return agenciaConta.toString();
	}

	public String getTelefoneFixoFormatado() {
		StringBuilder telFixoFormatado = new StringBuilder();
		if (!UtilFunction.isBlankOrNull(getDddTelefone())) {
			telFixoFormatado.append(getDddTelefone());
		}
		if (!UtilFunction.isBlankOrNull(getNumeroTelefone())) {
			telFixoFormatado.append(getNumeroTelefone());
		}
		return UtilFunction.formatarTelefoneBR(telFixoFormatado.toString());
	}

	public String getCelularFormatado() {
		StringBuilder celFormatado = new StringBuilder();
		if (!UtilFunction.isBlankOrNull(getNumeroCelular())) {
			if (!UtilFunction.isBlankOrNull(getDddCelular())) {
				celFormatado.append(getDddCelular());
			}
			celFormatado.append(getNumeroCelular());
		}
		return UtilFunction.formatarTelefoneBR(celFormatado.toString());
	}

	public String getCpfFormatado() {
		return UtilFunction.formatarCpfComTraco(getCpf());
	}

	public String getAcessoMobile() {
		String retorno = "-";
		if (!UtilFunction.isBlankOrNull(getInAcesMobl()) && getInAcesMobl().equalsIgnoreCase("S")) {
			retorno = "Habilitado";
		}
		return retorno;
	}
	
	
	public String getNmPerfilAutorizacao() {
		return nmPerfilAutorizacao;
	}

	public void setNmPerfilAutorizacao(String nmPerfilAutorizacao) {
		this.nmPerfilAutorizacao = nmPerfilAutorizacao;
	}
   
	public String getDsPerfilAutorizacao() {
		return dsPerfilAutorizacao;
	}

	public void setDsPerfilAutorizacao(String dsPerfilAutorizacao) {
		this.dsPerfilAutorizacao = dsPerfilAutorizacao;
	}

	public Integer getNrPerfilAutorizacao() {
		return nrPerfilAutorizacao;
	}

	public void setNrPerfilAutorizacao(Integer nrPerfilAutorizacao) {
		this.nrPerfilAutorizacao = nrPerfilAutorizacao;
	}

	public List<UsuarioSecundarioConsultaPerfil> getListaPerfis() {
		return listaPerfis;
	}

	public void setListaPerfis(List<UsuarioSecundarioConsultaPerfil> listaPerfis) {
		this.listaPerfis = listaPerfis;
	}

	public List<ItemConvenioConsultarDTO> getListaConvenios() {
		return listaConvenios;
	}

	public void setListaConvenios(List<ItemConvenioConsultarDTO> listaConvenios) {
		this.listaConvenios = listaConvenios;
	}

	
	public String getAcessoMobileSimNao() {
		String retorno = "N�o";
		if (!UtilFunction.isBlankOrNull(getInAcesMobl()) && getInAcesMobl().equalsIgnoreCase("S")) {
			retorno = "Sim";
		}
		return retorno;
	}

	

	
}
