package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class OperacoesVisaDTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5546514942582835664L;
	private List<OperacaoVisaDTO> listaOperacoesVisa = new ArrayList<OperacaoVisaDTO>();
	private String retCode;
	private String erro;
	private String erroTecnica;
	
	public List<OperacaoVisaDTO> getListaOperacoesVisa() {
		return listaOperacoesVisa;
	}
	public void setListaOperacoesVisa(List<OperacaoVisaDTO> listaOperacoesVisa) {
		this.listaOperacoesVisa = listaOperacoesVisa;
	}
	public String getRetCode() {
		return retCode;
	}
	public void setRetCode(String retCode) {
		this.retCode = retCode;
	}
	public String getErro() {
		return erro;
	}
	public void setErro(String erro) {
		this.erro = erro;
	}
	public String getErroTecnica() {
		return erroTecnica;
	}
	public void setErroTecnica(String erroTecnica) {
		this.erroTecnica = erroTecnica;
	}
	
	

}
