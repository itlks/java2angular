package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class CampanhaRetornoDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String codError;
	private String msgError;
	private String canal;
	private String segmentoPrimarioCliente;
	private Integer lote;
	private Integer pagina;
	private String[] link;
	private String raAttribSeg;
 	private String boId;
 	private Integer campanhaCRM;
	private List<MidiasRetornoDTO> listaMidia = new ArrayList<MidiasRetornoDTO>();
	/**
	 * @return the codError
	 */
	public String getCodError() {
		return codError;
	}
	/**
	 * @param codError the codError to set
	 */
	public void setCodError(String codError) {
		this.codError = codError;
	}
	/**
	 * @return the msgError
	 */
	public String getMsgError() {
		return msgError;
	}
	/**
	 * @param msgError the msgError to set
	 */
	public void setMsgError(String msgError) {
		this.msgError = msgError;
	}
	/**
	 * @return the canal
	 */
	public String getCanal() {
		return canal;
	}
	/**
	 * @param canal the canal to set
	 */
	public void setCanal(String canal) {
		this.canal = canal;
	}
	/**
	 * @return the segmentoPrimarioCliente
	 */
	public String getSegmentoPrimarioCliente() {
		return segmentoPrimarioCliente;
	}
	/**
	 * @param segmentoPrimarioCliente the segmentoPrimarioCliente to set
	 */
	public void setSegmentoPrimarioCliente(String segmentoPrimarioCliente) {
		this.segmentoPrimarioCliente = segmentoPrimarioCliente;
	}
	/**
	 * @return the lote
	 */
	public Integer getLote() {
		return lote;
	}
	/**
	 * @param lote the lote to set
	 */
	public void setLote(Integer lote) {
		this.lote = lote;
	}
	/**
	 * @return the pagina
	 */
	public Integer getPagina() {
		return pagina;
	}
	/**
	 * @param pagina the pagina to set
	 */
	public void setPagina(Integer pagina) {
		this.pagina = pagina;
	}
	/**
	 * @return the listaMidia
	 */
	public List<MidiasRetornoDTO> getListaMidia() {
		return listaMidia;
	}
	/**
	 * @param listaMidia the listaMidia to set
	 */
	public void setListaMidia(List<MidiasRetornoDTO> listaMidia) {
		this.listaMidia = listaMidia;
	}
	public String[] getLink() {
		return link;
	}
	public void setLink(String[] link) {
		this.link = link;
	}
	public String getRaAttribSeg() {
		return raAttribSeg;
	}
	public void setRaAttribSeg(String raAttribSeg) {
		this.raAttribSeg = raAttribSeg;
	}
	public String getBoId() {
		return boId;
	}
	public void setBoId(String boId) {
		this.boId = boId;
	}
	public Integer getCampanhaCRM() {
		return campanhaCRM;
	}
	public void setCampanhaCRM(Integer campanhaCRM) {
		this.campanhaCRM = campanhaCRM;
	}

}
