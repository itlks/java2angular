package com.altec.bsbr.app.ibe.dto.agendamentos;

public class ContaConsumoDTO {

	private String contaCorrenteDebito;
	private String codigoDeBarras;
	private String tipoConcessionaria;

	public String getContaCorrenteDebito() {
		return contaCorrenteDebito;
	}

	public void setContaCorrenteDebito(String contaCorrenteDebito) {
		this.contaCorrenteDebito = contaCorrenteDebito;
	}

	public String getCodigoDeBarras() {
		return codigoDeBarras;
	}

	public void setCodigoDeBarras(String codigoDeBarras) {
		this.codigoDeBarras = codigoDeBarras;
	}

	public String getTipoConcessionaria() {
		return tipoConcessionaria;
	}

	public void setTipoConcessionaria(String tipoConcessionaria) {
		this.tipoConcessionaria = tipoConcessionaria;
	}

}
