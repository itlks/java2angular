package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.Date;

public class ConsultaOpcaoBloqueioAtm implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5592722770756996525L;
	
	private String codigoMensajeOk;
	private String descErro;
	private String indicadorExtratoATM;
	private String codigoProduto;
	private String codigoSubproduto;
	private String indContaInativa;
	private String agenciaAbertura;
	private Date dtAlta;
	private String estadoConta;
	
	
	public String getCodigoMensajeOk() {
		return codigoMensajeOk;
	}
	public void setCodigoMensajeOk(String codigoMensajeOk) {
		this.codigoMensajeOk = codigoMensajeOk;
	}
	public String getDescErro() {
		return descErro;
	}
	public void setDescErro(String descErro) {
		this.descErro = descErro;
	}
	public String getIndicadorExtratoATM() {
		return indicadorExtratoATM;
	}
	public void setIndicadorExtratoATM(String indicadorExtratoATM) {
		this.indicadorExtratoATM = indicadorExtratoATM;
	}
	public String getCodigoProduto() {
		return codigoProduto;
	}
	public void setCodigoProduto(String codigoProduto) {
		this.codigoProduto = codigoProduto;
	}
	public String getCodigoSubproduto() {
		return codigoSubproduto;
	}
	public void setCodigoSubproduto(String codigoSubproduto) {
		this.codigoSubproduto = codigoSubproduto;
	}
	public String getIndContaInativa() {
		return indContaInativa;
	}
	public void setIndContaInativa(String indContaInativa) {
		this.indContaInativa = indContaInativa;
	}
	public String getAgenciaAbertura() {
		return agenciaAbertura;
	}
	public void setAgenciaAbertura(String agenciaAbertura) {
		this.agenciaAbertura = agenciaAbertura;
	}
	public Date getDtAlta() {
		return dtAlta;
	}
	public void setDtAlta(Date dtAlta) {
		this.dtAlta = dtAlta;
	}
	public String getEstadoConta() {
		return estadoConta;
	}
	public void setEstadoConta(String estadoConta) {
		this.estadoConta = estadoConta;
	}
	
	

}
