package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;
import java.util.List;

import com.altec.bsbr.app.ibe.dto.usuariosecundario.UsuarioSecundarioResponseDTO;

public class UsuarioSecundarioIncluirDTO implements Serializable{

	private static final long serialVersionUID = 3563815215242904789L;
	
	private Integer idUsuario;
	private String nomeUsuario;
	private String nomeLogon;
	private String nomeArea;
	private String nrCpf;
	private Boolean inAcesMobl;
	private String nrTelefone;
	private String nrCelular;
	private String habilitado;
	private String novaSenha;
	private String senhaNovaHash;
	private String senhaNovaConfirmaHash;
	public String getSenhaNovaHash() {
		return senhaNovaHash;
	}

	public void setSenhaNovaHash(String senhaNovaHash) {
		this.senhaNovaHash = senhaNovaHash;
	}

	public String getSenhaNovaConfirmaHash() {
		return senhaNovaConfirmaHash;
	}

	public void setSenhaNovaConfirmaHash(String senhaNovaConfirmaHash) {
		this.senhaNovaConfirmaHash = senhaNovaConfirmaHash;
	}

	private String senhaConfirmacao;
	private String senhaHash;
	private String novaAssinatura;
	private String confirmacaoAssinatura;
	private String assinaturaHash;
	private String hashAcessNovo;
	private boolean exibeCel = false;
	
	@SuppressWarnings("unused")
	private String descAcessoMobile;
	
	private List<UsuarioSecundarioResponseDTO> usuarioSecundarioList;
	private UsuarioSecundarioResponseDTO userSelecionado;
	
	private String msgErroJavaStript;
	
	
	public UsuarioSecundarioIncluirDTO(){}

	public Integer getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}

	public String getNomeUsuario() {
		return nomeUsuario;
	}

	public void setNomeUsuario(String nomeUsuario) {
		this.nomeUsuario = nomeUsuario;
	}

	public String getNomeLogon() {
		return nomeLogon;
	}

	public void setNomeLogon(String nomeLogon) {
		this.nomeLogon = nomeLogon;
	}

	public String getNomeArea() {
		return nomeArea;
	}

	public void setNomeArea(String nomeArea) {
		this.nomeArea = nomeArea;
	}

	public String getNrCpf() {
		return nrCpf;
	}

	public void setNrCpf(String nrCpf) {
		this.nrCpf = nrCpf;
	}

	public String getNrTelefone() {
		return nrTelefone;
	}

	public void setNrTelefone(String nrTelefone) {
		this.nrTelefone = nrTelefone;
	}

	public String getNrCelular() {
		return nrCelular;
	}

	public void setNrCelular(String nrCelular) {
		this.nrCelular = nrCelular;
	}

	public String getHabilitado() {
		return habilitado;
	}

	public void setHabilitado(String habilitado) {
		this.habilitado = habilitado;
	}

	public String getNovaSenha() {
		return novaSenha;
	}

	public void setNovaSenha(String novaSenha) {
		this.novaSenha = novaSenha;
	}
	
	public String getSenhaConfirmacao() {
		return senhaConfirmacao;
	}

	public void setSenhaConfirmacao(String senhaConfirmacao) {
		this.senhaConfirmacao = senhaConfirmacao;
	}

	public String getSenhaHash() {
		return senhaHash;
	}

	public void setSenhaHash(String senhaHash) {
		this.senhaHash = senhaHash;
	}
	
	public String getNovaAssinatura() {
		return novaAssinatura;
	}

	public void setNovaAssinatura(String novaAssinatura) {
		this.novaAssinatura = novaAssinatura;
	}

	public String getConfirmacaoAssinatura() {
		return confirmacaoAssinatura;
	}

	public void setConfirmacaoAssinatura(String confirmacaoAssinatura) {
		this.confirmacaoAssinatura = confirmacaoAssinatura;
	}

	public String getAssinaturaHash() {
		return assinaturaHash;
	}

	public void setAssinaturaHash(String assinaturaHash) {
		this.assinaturaHash = assinaturaHash;
	}

	public String getMsgErroJavaStript() {
		return msgErroJavaStript;
	}

	public void setMsgErroJavaStript(String msgErroJavaStript) {
		this.msgErroJavaStript = msgErroJavaStript;
	}

	public List<UsuarioSecundarioResponseDTO> getUsuarioSecundarioList() {
		return usuarioSecundarioList;
	}

	public void setUsuarioSecundarioList(List<UsuarioSecundarioResponseDTO> usuarioSecundarioList) {
		this.usuarioSecundarioList = usuarioSecundarioList;
	}

	public UsuarioSecundarioResponseDTO getUserSelecionado() {
		return userSelecionado;
	}

	public void setUserSelecionado(UsuarioSecundarioResponseDTO userSelecionado) {
		this.userSelecionado = userSelecionado;
	}

	public String getHashAcessNovo() {
		return hashAcessNovo;
	}

	public void setHashAcessNovo(String hashAcessNovo) {
		this.hashAcessNovo = hashAcessNovo;
	}

	public String getDescAcessoMobile() {
		
		
		if(getInAcesMobl() != null){
			if(getInAcesMobl()){
				 return "SIM";
			 } else{
				 return "N�O"; 
			 }
		} else{
			return "N�O";
		}
		
	}

	public void setDescAcessoMobile(String descAcessoMobile) {
		this.descAcessoMobile = descAcessoMobile;
	}

	public Boolean getInAcesMobl() {
		return inAcesMobl;
	}

	public void setInAcesMobl(Boolean inAcesMobl) {
		this.inAcesMobl = inAcesMobl;
	}

	public boolean isExibeCel() {
		return exibeCel;
	}

	public void setExibeCel(boolean exibeCel) {
		this.exibeCel = exibeCel;
	}		
}
