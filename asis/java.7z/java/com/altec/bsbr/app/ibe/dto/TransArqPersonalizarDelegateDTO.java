package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class TransArqPersonalizarDelegateDTO implements Serializable{
		
	private String operacao;
	private String banco;
	private String agencia;
	private String conta;
	private String usuario;
	private String tipTransfer;
	private String solParTransfer;
	private Integer retCodeDB;
	private String retParam1;
	private String retParam2;
	
	private static final long serialVersionUID = -5397329844777504751L;
	
	public TransArqPersonalizarDelegateDTO(){
		
	}


	public TransArqPersonalizarDelegateDTO(String operacao, String banco, String agencia, String conta, String usuario,
			String tipTransfer, String solParTransfer, Integer retCodeDB, String retParam1, String retParam2) {
		super();
		this.operacao = operacao;
		this.banco = banco;
		this.agencia = agencia;
		this.conta = conta;
		this.usuario = usuario;
		this.tipTransfer = tipTransfer;
		this.solParTransfer = solParTransfer;
		this.retCodeDB = retCodeDB;
		this.retParam1 = retParam1;
		this.retParam2 = retParam2;
	}

	public String getOperacao() {
		return operacao;
	}

	public void setOperacao(String operacao) {
		this.operacao = operacao;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getConta() {
		return conta;
	}

	public void setConta(String conta) {
		this.conta = conta;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getTipTransfer() {
		return tipTransfer;
	}

	public void setTipTransfer(String tipTransfer) {
		this.tipTransfer = tipTransfer;
	}

	public String getSolParTransfer() {
		return solParTransfer;
	}

	public void setSolParTransfer(String solParTransfer) {
		this.solParTransfer = solParTransfer;
	}

	public Integer getRetCodeDB() {
		return retCodeDB;
	}

	public void setRetCodeDB(Integer retCodeDB) {
		this.retCodeDB = retCodeDB;
	}


	public String getRetParam1() {
		return retParam1;
	}


	public void setRetParam1(String retParam1) {
		this.retParam1 = retParam1;
	}


	public String getRetParam2() {
		return retParam2;
	}


	public void setRetParam2(String retParam2) {
		this.retParam2 = retParam2;
	}


	
	
	
	
	
	

	
}
