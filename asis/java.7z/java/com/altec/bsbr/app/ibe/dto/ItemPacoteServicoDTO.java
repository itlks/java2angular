package com.altec.bsbr.app.ibe.dto;

public class ItemPacoteServicoDTO  {

	private String descricao;
	private String quantidade;
	private String quantidade2;
	private String quantidade3;
	
	public String getDescricao() {
		return descricao;
	}
	
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	public String getQuantidade() {
		return quantidade;
	}
	
	public void setQuantidade(String quantidade) {
		this.quantidade = quantidade;
	}

	public String getQuantidade2() {
		return quantidade2;
	}

	public void setQuantidade2(String quantidade2) {
		this.quantidade2 = quantidade2;
	}

	public String getQuantidade3() {
		return quantidade3;
	}

	public void setQuantidade3(String quantidade3) {
		this.quantidade3 = quantidade3;
	}

	
	
}
