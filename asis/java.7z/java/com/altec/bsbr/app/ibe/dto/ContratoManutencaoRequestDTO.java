package com.altec.bsbr.app.ibe.dto;

import java.io.Serializable;

public class ContratoManutencaoRequestDTO implements Serializable {

	private static final long serialVersionUID = 8526945326509259849L;
	private String banco;
	private String agencia;
	private String conta;
	
	public String getBanco() {
		return banco;
	}
	public void setBanco(String banco) {
		this.banco = banco;
	}
	public String getAgencia() {
		return agencia;
	}
	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}
	public String getConta() {
		return conta;
	}
	public void setConta(String conta) {
		this.conta = conta;
	}
	
}
