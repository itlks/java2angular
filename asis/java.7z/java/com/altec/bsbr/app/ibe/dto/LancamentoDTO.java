package com.altec.bsbr.app.ibe.dto;

import java.util.Date;

public class LancamentoDTO {
	Date data;
	String historico;
	String valor;

	public Date getData() {
		return data;
	}
	public void setData(Date data) {
		this.data = data;
	}

	public String getHistorico() {
		return historico;
	}
	public void setHistorico(String historico) {
		this.historico = historico;
	} 
	
	public String getValor() {
		return valor;
	}
	public void setValor(String valor) {
		this.valor = valor;
	}
}
