package com.altec.bsbr.fw.config;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;
import org.springframework.util.ClassUtils;

public class RunningMode
{
    private static Set<String> modes;
    private static String environment;
    public static final String WEBSPHERE = "websphere";
    public static final String TOMCAT = "tomcat";
    public static final String GERONIMO = "geronimo";
    public static final String BATCH = "batch";
    public static final String UNKNOWN = "unknown";
    public static boolean configured;

    public static Set<String> get()
    {
        return Collections.unmodifiableSet(modes);
    }

    public static void configure(String defaultEnvironment)
    {
        environment = defaultEnvironment;
        configure();
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
	public static void configure()
    {
        if (modes != null)
        {
            System.out.println("WARNING: Running modes already defined");
            return;
        }
        modes = new LinkedHashSet();

        modes.add(detectServerFamily());
        try
        {
            String systemRunningModes = System.getProperty("runningMode", null);
            parse(systemRunningModes, modes);
        }
        catch (SecurityException e)
        {
            System.out.println("WARNING: Can't read system property \"runningMode\": " + e);
        }
        configured = true;
    }

	private static void parse(String string, Set<String> list)
    {
        if (string == null) {
            return;
        }
        Scanner sc = new Scanner(string);
        sc.useDelimiter(",");
        while (sc.hasNext())
        {
            String s = sc.next().trim();
            if (!s.equals("")) {
                list.add(s);
            }
        }
        sc.close();
    }

    private static String detectServerFamily()
    {
        if (ClassUtils.isPresent("com.ibm.wsspi.uow.UOWManager", ClassUtils.getDefaultClassLoader())) {
            return "websphere";
        }
        if (ClassUtils.isPresent("org.apache.catalina.startup.Bootstrap", ClassUtils.getDefaultClassLoader())) {
            return "tomcat";
        }
        if (ClassUtils.isPresent("org.apache.geronimo.kernel.Kernel", ClassUtils.getDefaultClassLoader())) {
            return "geronimo";
        }

        if (ClassUtils.isPresent("org.eclipse.jetty.server.Server", ClassUtils.getDefaultClassLoader())
                || "local-tomcat".equals(System.getProperty("runningMode"))) {
            return "tomcat";
        }


        if ((environment != null) &&
                (environment.equalsIgnoreCase("batch"))) {
            return "batch";
        }
        return "unknown";
    }

    public static boolean isConfigured()
    {
        return configured;
    }
}
